"""İlaçTarif — kullanıcı bilgisayarındaki ana giriş noktası (Katman 5).

Kurulumdan sonra masaüstü/başlat menüsü kısayolu  pythonw.exe App.pyw  şeklinde
bu dosyayı çalıştırır. Görevleri:

  1. sys.path'e  <app>\src  ekle (paket import'ları için)
  2. KATMAN 5: GUI'nin ihtiyaç duyduğu 3. parti modüller import edilebiliyor mu?
     Eksikse kullanıcıya ANLAMLI bir hata kutusu göster (sessiz crash yok).
  3. Uygulamayı başlat; herhangi bir hata olursa  <app>\logs\crash_log.txt
     dosyasına tam traceback yaz + kullanıcıya kutu göster.

Not: pythonw.exe altında sys.stdout/stderr None olabilir; ona göre korunur.
"""
from __future__ import annotations

import ctypes
import sys
import traceback
from datetime import datetime
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent
SRC = APP_ROOT / "src"
LOG_DIR = APP_ROOT / "logs"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# pythonw.exe altında stdout/stderr None olabilir
for _stream in ("stdout", "stderr"):
    s = getattr(sys, _stream, None)
    if s is not None:
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass


def _msgbox(baslik: str, mesaj: str, ikon: int = 0x10) -> None:
    """Windows MessageBox (0x10 = hata ikonu)."""
    try:
        ctypes.windll.user32.MessageBoxW(0, mesaj, baslik, ikon)
    except Exception:
        pass


def _write_log(name: str, text: str) -> Path | None:
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        p = LOG_DIR / name
        with open(p, "a", encoding="utf-8") as f:
            f.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} =====\n")
            f.write(text)
        return p
    except Exception:
        return None


# --- KATMAN 5: eksik modül kontrolü -----------------------------------------
def _eksik_moduller() -> list[str]:
    eksik: list[str] = []
    # (import_adı, kullanıcıya gösterilecek paket adı)
    for mod, paket in [
        ("PIL", "Pillow"),
        ("bs4", "beautifulsoup4"),
        ("lxml", "lxml"),
        ("comtypes", "comtypes"),
        ("win32print", "pywin32"),
        ("pywinauto", "pywinauto"),
    ]:
        try:
            __import__(mod)
        except Exception:
            eksik.append(paket)
    return eksik


def main() -> None:
    eksik = _eksik_moduller()
    if eksik:
        liste = ", ".join(eksik)
        _write_log(
            "crash_log.txt",
            f"Eksik modüller (Katman 5): {liste}\nPython: {sys.executable}\n",
        )
        _msgbox(
            "İlaçTarif — Kurulum eksik",
            "Aşağıdaki bileşenler yüklenememiş:\n\n"
            f"    {liste}\n\n"
            "Programı kaldırıp yeniden kurun. Sorun sürerse şu dosyayı iletin:\n"
            f"{LOG_DIR / 'install_log.txt'}",
        )
        sys.exit(1)

    # --- Uygulamayı başlat ---
    from ilactarif.ui.manual_label_ui import main as run_ui
    run_ui()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        tb = traceback.format_exc()
        p = _write_log("crash_log.txt", tb)
        _msgbox(
            "İlaçTarif — Hata",
            "Program başlatılırken bir hata oluştu.\n\n"
            + (f"Hata günlüğü:\n{p}" if p else "Günlük dosyası yazılamadı."),
        )
        raise
