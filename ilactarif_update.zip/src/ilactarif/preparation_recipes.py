"""Hastanın EVDE hazırlaması/sulandırması gereken ilaçlar için hazırlama
talimatı şablonları.

application_techniques.py "nasıl kullanılır" (teknik) bloğunu üretir; bu modül
ise "kullanmadan önce nasıl HAZIRLANIR" (hazirlama) bloğunu üretir. Çıktı
drug_label_blocks.block_type='hazirlama' içeriğidir ve label_from_db.py'de
TİP B "HAZIRLAMA BİLGİSİ" ikinci etiketine dönüşür.

Kapsam (hastanın kendisinin hazırladığı formlar):
  - recon_oral    : kuru toz → oral süspansiyon/solüsyon (antibiyotik şurupları,
                    erdostein/asetilsistein toz şuruplar, oseltamivir toz)
  - ors           : oral rehidratasyon tuzu (suda eritilen)
  - sachet_oral   : oral toz/granül saşe (suda eritilip içilen)
  - effervescent  : efervesan tablet (suda eritilen)
  - recon_topical : eritromisin+benzoil peroksit topikal jel (Acnemix/Benzamycin/
                    Benzaderm) — eritromisin tozu jele karıştırılıp BUZDOLABINDA
                    saklanır (ATC D10AF52)

DİKKAT: Sağlık personelinin sulandırdığı enjeksiyonluk/infüzyon tozları
(flakon, ampul) KAPSAM DIŞIDIR — bunlar hastanın evde hazırladığı ürünler değil.

Kulak/göz/burun damlaları "hazırlama" değil "uygulama tekniği" olduğundan
application_techniques.py üzerinden ayrı (KULLANIM TEKNİĞİ) etiketiyle basılır.

Kullanım:
    from ilactarif.preparation_recipes import prep_category, build_hazirlama
    cat = prep_category(name, form)          # 'recon_oral' | 'ors' | ... | None
    text = build_hazirlama(name, form)       # hazirlama bloğu içeriği veya None
"""
from __future__ import annotations

import re
from typing import Optional


def _fold(s: str) -> str:
    """Türkçe karakterleri ASCII'ye indirger (eşleştirme dayanıklılığı için)."""
    s = (s or "").upper()
    for a, b in (("Ü", "U"), ("İ", "I"), ("I", "I"), ("Ş", "S"),
                 ("Ç", "C"), ("Ö", "O"), ("Ğ", "G")):
        s = s.replace(a, b)
    return s


# Enjeksiyonluk / infüzyonluk tozlar — hasta hazırlamaz, sağlık personeli sulandırır.
_INJECTABLE_HINTS = (
    "FLAKON", "AMPUL", "ENJEKS", "INFUZYON", "INFÜZYON", "INTRAVEN",
    "I.V", "IV ", " IM", "INTRAMUSK", "PERFUZYON", "ENJEKTOR",
)

# Oral sıvı işareti — kuru tozun oral süspansiyona/solüsyona dönüştüğünü doğrular.
# (Marka adındaki "ORAL" tek başına işaret SAYILMAZ — ör. GE-ORAL yanlış eşleşmesin.)
_ORAL_LIQUID_HINTS = ("SUSPANS", "SUESPANS", "SURUP", "SOLUSYON", "COZELTI")

# Tek-doz saşe/poşet işaretleri (şişe sulandırmasından ayırmak için).
# NOT: "KAŞE" (Gripin/Derman/Gripaljin) SUDA ERİTİLMEZ — eski tip yutulan
# kaşedir (cachet); saşe sanılıp "suya boşaltın" etiketi basılıyordu (2026-06-12).
_SACHET_HINTS = ("SASE", "SAS.", "POSET")


def prep_category(
    drug_name: str,
    form: Optional[str] = None,
    atc_code: Optional[str] = None,
) -> Optional[str]:
    """İlaç adı + form + ATC'den hazırlama kategorisini döndürür (yoksa None).

    Öncelik (spesifikten genele):
      enjeksiyonluk(=None) > ors > efervesan > tek-doz saşe > şişe-sulandırma
      (recon_oral) > serbest granül(=saşe)

    ATC J01 (sistemik antibiyotik) oral süspansiyon/şurupları adında "TOZ"
    geçmese de neredeyse daima tozdan sulandırılır (Augmentin, Zinnat, Klacid…);
    bu yüzden ATC bazlı ek kural ile yakalanır.
    """
    n = _fold(drug_name)
    f = (form or "").lower()
    code = (atc_code or "").upper()

    # 0) Topikal eritromisin+benzoil peroksit jel (D10AF52) — eritromisin tozu
    #    jele karıştırılıp buzdolabında saklanır. Enjeksiyon guard'ından ÖNCE,
    #    çünkü Benzamycin adındaki "FLAKON" eritromisin toz şişesidir (enjeksiyon
    #    değil). Ada da bakarız (Benzaderm form=None olabilir).
    if code == "D10AF52" or any(
        h in n for h in ("ACNEMIX", "BENZAMYCIN", "BENZADERM")
    ):
        return "recon_topical"

    # 0b) Fosfomisin trometamol saşe (Monurol/Üromisin/Ürocare, ATC J01XX01) —
    #     tek doz idrar yolu antibiyotiği; özel uygulama protokolü vardır
    #     (mesane boşalt → suda erit-iç → 4 saat idrar tut). Saşe olduğundan
    #     genel saşe kuralından ÖNCE yakalanır.
    if code == "J01XX01" or any(
        h in n for h in ("MONUROL", "UROMISIN", "UROCARE", "FOSFOMISIN",
                         "FOSFOSIN", "FOSFORAL")
    ):
        return "fosfomisin"

    # Enjeksiyonluk tozları — hasta hazırlamaz, sağlık personeli sulandırır.
    if any(h in n for h in _INJECTABLE_HINTS):
        return None

    # 1) Oral rehidratasyon (en kesin işaret).
    if "REHIDRAT" in n or re.search(r"\bORS\b", n):
        return "ors"

    # 2) Efervesan tablet (suda eritilen).
    if f == "tablet_effervescent" or "EFERVESAN" in n:
        return "effervescent"

    has_volume = bool(re.search(r"\d{2,4}\s*ML\b", n))
    oral_liquid = any(h in n for h in _ORAL_LIQUID_HINTS)
    name_has_sachet = any(h in n for h in _SACHET_HINTS)

    # 2b) Suda ERİTİLMEYEN tek-doz formlar: oral JEL saşesi (Jeligra) doğrudan
    #     ağza sıkılıp yutulur, ağızda dağılan film (Icarus) dil üstünde erir —
    #     "suda eritin" şablonu YANLIŞ olur, hazırlama etiketi gerekmez.
    if name_has_sachet and "JEL" in n:
        return None
    if "FILM" in n and "DAGILAN" in n:
        return None

    # 3) Adı saşe/poşet diyen ürün — her doz ayrı suda eritilir (tek-doz).
    #    powder_for_suspension formu şişe sulandırmasını zorladığından onu dışlarız.
    if name_has_sachet and f != "powder_for_suspension":
        return "sachet_oral"

    # 4) Şişede sulandırılan kuru toz/granül → oral süspansiyon/solüsyon.
    #    (Hacim veya oral-sıvı işareti varsa şişe sulandırması say; ör. 100ML GRANÜL.)
    if f == "powder_for_suspension" or "HAZIRLAMAK" in n or "KURU TOZ" in n:
        return "recon_oral"
    if ("TOZ" in n or "GRANUL" in n) and (oral_liquid or has_volume):
        return "recon_oral"

    # 4b) ATC J01 antibiyotik oral süspansiyon/şurup — adında "toz" yazmasa da
    #     tozdan sulandırılır (çocuk antibiyotik şurupları).
    is_oral_suspension = (
        f in ("syrup_or_suspension", "powder_for_suspension")
        or (oral_liquid and not any(
            h in n for h in ("KREM", "MERHEM", "POMAD", "JEL", "DAMLA",
                             "GOZ", "KULAK", "BURUN", "TOPIK", "HARICI")))
    )
    if code.startswith("J01") and is_oral_suspension:
        return "recon_oral"

    # 5) Form'u saşe olan / geri kalan oral granüller (suda eritilip içilen).
    if f == "sachet_oral" or "GRANUL" in n:
        return "sachet_oral"

    return None


def needs_home_prep(
    drug_name: str,
    form: Optional[str] = None,
    atc_code: Optional[str] = None,
) -> bool:
    """Hasta bu ilacı kullanmadan önce kendisi hazırlıyor mu?"""
    return prep_category(drug_name, form, atc_code) is not None


def _extract_volume(drug_name: str) -> str:
    """Ad içinden hazırlanacak son hacmi yakalar (ör. '100ML' → '100 ml')."""
    m = re.search(r"(\d{2,4})\s*ML\b", _fold(drug_name))
    if m:
        return f"{m.group(1)} ml"
    return ""


# Kategori şablonları. Her satır bir adımdır; render adımları 1./2./… olarak
# numaralandırır (en çok 4 adım gösterilir). Saklama/son-kullanma bilgisi
# ürüne özgü olduğundan adımlarda sabitlenmez; saklama bloğundan alt-meta olarak
# basılır. Adımlar yalnızca evrensel hazırlama mekaniğini anlatır.
_TEMPLATES: dict[str, list[str]] = {
    "recon_oral": [
        "Şişeyi çalkalayıp tozu gevşetin.",
        "Suyu çizgiye kadar 2 kez ekleyip her seferinde çalkalayın.",
        "Köpük inince çizgiye tamamlayın; her kullanımdan önce çalkalayın.",
    ],
    "ors": [
        "1 poşeti 200 ml (1 bardak) kaynamış-ılınmış suda eritin.",
        "İyice karıştırın; şeker/tuz eklemeyin, süt/meyve suyuna katmayın.",
        "24 saat içinde tüketin, buzdolabında saklayın.",
    ],
    "sachet_oral": [
        "İçeriği yarım-1 bardak (100-200 ml) suya boşaltın.",
        "İyice karıştırıp tamamen eritin.",
        "Hazırlayınca hemen için, bekletmeyin.",
    ],
    "effervescent": [
        "1 tableti 1 bardak (150-200 ml) suda eritin.",
        "Köpürme tamamen bitince karıştırıp için.",
        "Çiğnemeyin, bütün yutmayın.",
    ],
    "recon_topical": [
        "Eritromisin tozu + çözücüsü jel kabına eklenip çubukla ~2-3 dk homojen olana dek karıştırılır (genellikle eczacı hazırlar).",
        "Hazırlanınca BUZDOLABINDA (2-8°C) saklayın; dondurmayın, oda sıcaklığında bırakmayın.",
        "Hazırlanan jeli en geç 3 ay içinde kullanın.",
    ],
    "fosfomisin": [
        "Gece yatmadan önce idrarınızı yapıp mesaneyi boşaltın.",
        "1 saşeyi bir bardak suda eritip aç karnına HEMEN için.",
        "İçtikten sonra en az 4 saat idrara çıkmayın.",
    ],
}

# Etiket başlığı (forma göre küçük farklılık).
PREP_TITLE = "HAZIRLAMA BİLGİSİ"


def build_hazirlama(
    drug_name: str,
    form: Optional[str] = None,
    atc_code: Optional[str] = None,
) -> Optional[str]:
    """İlaç için hazirlama bloğu içeriğini (satır=adım) üretir; uygun değilse None.

    Kategori şablonu + ilaca özel ince ayar (hacim) uygulanır.
    """
    cat = prep_category(drug_name, form, atc_code)
    if not cat:
        return None
    steps = list(_TEMPLATES[cat])

    # İlaca özel ince ayar: recon için son hacmi 2. adıma işle.
    if cat == "recon_oral":
        vol = _extract_volume(drug_name)
        if vol:
            steps[1] = (
                f"Suyu çizgiye (≈{vol}) kadar 2 kez ekleyip her seferinde "
                f"çalkalayın."
            )

    return "\n".join(steps)
