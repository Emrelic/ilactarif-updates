"""Botanik EOS perakende satış grid'ini UI Automation (pywinauto) ile okur.

Botanik EOS bir WinForms (DevExpress) uygulamasıdır; satış grid'i ayrı bir
pencere değil ANA pencereye gömülüdür. Grid UI Automation'a şu desende açılır:

    Satır N            → ControlType.ListItem
    "{Kolon} satır N"  → ControlType.DataItem   (örn. "Ürün Adı satır 1")

Hücre değeri (gerçek metin) ValuePattern veya LegacyIAccessible.Value ile okunur.
İlgili kolonlar: Barkod, Ürün Adı, Adet.

Not: Bu modül yalnızca okuma yapar; hiçbir tuşa basmaz / pencereyi değiştirmez.
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field

log = logging.getLogger("ilactarif.botanik")

# "Ürün Adı satır 12" → "Ürün Adı" (sondaki " satır N" ekini at)
_ROW_SUFFIX = re.compile(r"\s+satır\s+\d+\s*$")
# "Satır 12" → 12 (satır numarası; sayfa/grid ayrımı için)
_ROW_NUM = re.compile(r"^Satır\s+(\d+)\s*$")

# Satır sayısı bilinmediği için "Satır N" bulunamayınca dururuz; sonsuz döngüye
# karşı güvenlik tavanı.
_MAX_ROWS = 300


@dataclass
class SaleRow:
    barkod: str = ""
    ad: str = ""
    adet: str = ""


@dataclass
class SalePage:
    """Tek bir Botanik satış sayfası (grid) ve içindeki ürün satırları."""
    rows: list = field(default_factory=list)  # list[SaleRow]


class BotanikNotFound(RuntimeError):
    """Botanik ana penceresi bulunamadı (program açık değil)."""


def _cell_value(el) -> str:
    """Bir DataItem hücresinin metnini oku (ValuePattern → Legacy fallback)."""
    try:
        v = el.iface_value.CurrentValue
        if v is not None and str(v) != "":
            return str(v)
    except Exception:
        pass
    try:
        leg = el.legacy_properties()
        if isinstance(leg, dict):
            v = leg.get("Value")
            if v:
                return str(v)
    except Exception:
        pass
    return ""


def _ensure_visible(win) -> bool:
    """Pencere simge durumundaysa (minimize) ODAĞI ÇALMADAN geri açar.

    Botanik küçültülmüşken DevExpress satış grid'i ekranda gerçekleşmediği için
    UIA hiçbir satır göremez (yalnızca pencere çerçevesi ~7 eleman görünür).
    Okumadan önce pencereyi SW_SHOWNOACTIVATE ile geri açarız: pencere görünür
    olur ama İlaçTarif'in odağı bozulmaz. Geri açtıysak True döner (çağıran
    grid'in oluşması için kısa süre beklemeli).
    """
    try:
        if not win.is_minimized():
            return False
    except Exception:
        return False
    # Odağı çalmadan geri aç (SW_SHOWNOACTIVATE=4)
    try:
        import win32con
        import win32gui
        win32gui.ShowWindow(win.handle, win32con.SW_SHOWNOACTIVATE)
        log.info("Botanik penceresi simge durumundaydı → odağı bozmadan geri açıldı")
        return True
    except Exception:
        # Yedek: pywinauto restore (odağı aktive edebilir)
        try:
            win.restore()
            log.info("Botanik penceresi restore() ile geri açıldı")
            return True
        except Exception:
            log.warning("Botanik penceresi geri açılamadı (simge durumunda kaldı)")
            return False


def _has_sale_rows(win) -> bool:
    """Pencerede en az bir 'Satır N' öğesi UIA ağacında var mı (grid gerçekleşti mi)."""
    try:
        for el in win.descendants():
            try:
                if _ROW_NUM.match(str(el.element_info.name or "")):
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _find_main_windows(dsk) -> list:
    """Açık TÜM BotanikEOS top-level pencerelerini döndürür (çoklu satış)."""
    out = []
    for w in dsk.windows():
        try:
            if "BotanikEOS" in str(w.window_text()):
                out.append(w)
        except Exception:
            continue
    return out


def _read_window_pages(win) -> list[SalePage]:
    """Tek bir Botanik penceresindeki satış grid'lerini AYRI sayfalara böler.

    Bir pencerede birden fazla satış sayfası (grid) açık olabilir ve hepsinin
    satır/hücre isimleri AYNIDIR ("Satır 1", "Ürün Adı satır 1"…). Her "Satır N"
    ListItem'inin KENDİ çocuk hücrelerini okuruz (düz isim haritası çakışırdı).

    Sayfa ayrımı: her satırın ait olduğu GRID'in parent panel ("Veri Paneli")
    EKRAN DİKDÖRTGENİ ile gruplanır — her satış grid'i ayrı bir dikdörtgendedir
    (satır numarası sıfırlanması güvenilir değildi: arama açılır listesi vb.
    araya girip yanlış bölüyordu).

    Satış grid'i FİLTRESİ: gerçek satış grid'inde **Barkod** kolonu vardır.
    Ürün arama açılır listesinde Barkod kolonu YOKTUR (Stok/Ürün Adı/Fiyat/Raf…),
    bu yüzden Barkod hücresi olmayan satırlar elenir. Çocuğu olmayan satırlar
    (kaydırma düğmeleri) ve Ürün Adı boş olanlar da atlanır.
    """
    groups: dict[object, list[SaleRow]] = {}
    order: list[object] = []
    for el in win.descendants():
        try:
            nm = str(el.element_info.name or "")
        except Exception:
            continue
        if not _ROW_NUM.match(nm):
            continue
        try:
            kids = el.children()
        except Exception:
            continue
        if not kids:
            continue  # "Satır yukarı/aşağı" gibi kaydırma düğmeleri
        # Çocuk hücreleri kolon adına göre eşle: "Ürün Adı satır 5" → "Ürün Adı"
        cells: dict[str, object] = {}
        for k in kids:
            try:
                kn = str(k.element_info.name or "")
            except Exception:
                continue
            col = _ROW_SUFFIX.sub("", kn)
            if col and col not in cells:
                cells[col] = k
        ad_el = cells.get("Ürün Adı")
        bk_el = cells.get("Barkod")
        # Satış satırı = hem Ürün Adı hem Barkod kolonu olmalı (arama açılır
        # listesinde Barkod yok → elenir).
        if ad_el is None or bk_el is None:
            continue
        ad = _cell_value(ad_el)
        if not ad.strip():
            continue
        # Grup anahtarı = ait olduğu grid'in parent panel dikdörtgeni.
        try:
            r = el.parent().element_info.rectangle
            key = (r.left, r.top, r.right, r.bottom)
        except Exception:
            key = "_default"
        if key not in groups:
            groups[key] = []
            order.append(key)
        adet_el = cells.get("Adet")
        groups[key].append(SaleRow(
            barkod=_cell_value(bk_el).strip(),
            ad=ad.strip(),
            adet=(_cell_value(adet_el) if adet_el is not None else "").strip(),
        ))
    return [SalePage(rows=groups[k]) for k in order]


def read_sale_pages() -> list[SalePage]:
    """Açık TÜM Botanik satış sayfalarını AYRI AYRI döndürür.

    Her satış sayfası (grid) → bir SalePage. Birden fazla pencere/grid açıksa
    hepsi ayrı sayfalar olarak listelenir.

    Raises:
        BotanikNotFound: Hiç Botanik penceresi açık değilse.
    """
    from pywinauto import Desktop

    dsk = Desktop(backend="uia")
    mains = _find_main_windows(dsk)
    if not mains:
        raise BotanikNotFound("BotanikEOS penceresi bulunamadı.")

    def _read_one(win) -> list[SalePage]:
        try:
            return _read_window_pages(win)
        except Exception:
            log.exception("Botanik pencere okuma hatası")
            return []  # Bir pencere okunamazsa diğerlerini engelleme

    pages: list[SalePage] = []
    for w in mains:
        # ÖNCE pencereyi olduğu gibi oku. Pencere minimize iken bile grid
        # okunabilen kurulumlarda bu yeterlidir ve pencereye DOKUNMAYIZ.
        wp = _read_one(w)

        # Sadece HİÇ satır gelmediyse VE pencere simge durumundaysa: muhtemelen
        # grid minimize yüzünden gerçekleşmemiştir → odağı bozmadan geri aç,
        # grid oluşunca yeniden oku. (Minimize iken okuyabilen bilgisayarlarda
        # bu dal hiç çalışmaz; pencere oldukları gibi minimize kalır.)
        if not wp:
            try:
                mini = w.is_minimized()
            except Exception:
                mini = False
            if mini and _ensure_visible(w):
                for _ in range(20):  # grid'in UIA ağacında oluşmasını bekle (~2 sn)
                    if _has_sale_rows(w):
                        break
                    time.sleep(0.1)
                wp = _read_one(w)

        pages.extend(wp)

    log.info("Botanik: %d pencere → %d satış sayfası okundu", len(mains), len(pages))
    return pages


def read_sale_rows() -> list[SaleRow]:
    """Geriye dönük: tüm satış sayfalarının satırlarını tek listede birleştirir."""
    rows: list[SaleRow] = []
    for pg in read_sale_pages():
        rows.extend(pg.rows)
    return rows
