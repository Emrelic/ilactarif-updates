"""İlaç veritabanı yönetimi: ekle / güncelle / sil + etiket içerikleri.

"Veri Ekle / Düzenle" sekmesinin veri-erişim katmanı. UI'ı ince tutmak için
tüm SQL burada toplanır. Yazma stratejisi (etiket akışıyla tutarlı olacak şekilde):

  • Kullanım etiketi (A): hem `drugs` yapısal kolonları hem `drug_labels`
    tip-1 JSON yazılır. Böylece Manuel sekme (JSON okur) ve Medula sekme
    (JSON override + yapısal zenginleştirme) aynı sonucu üretir.
  • Hazırlama/Teknik (B), Ciddi uyarı (C), Dikkat (D): render bunları
    `drug_label_blocks`'tan üretir → ilgili block_type'lara source='manual'
    yazılır (kullanıcı düzenlemesi en yüksek önceliklidir).
"""
from __future__ import annotations

import json
import sqlite3
from typing import Optional

from .db import get_connection

# Bu sekmede düzenlenebilen drugs kolonları (id/created_at/updated_at hariç HEPSİ).
DRUG_EDIT_COLS = [
    "barcode", "name", "manufacturer", "drug_type", "equivalent_code",
    "atc_code", "atc_name", "prescription_type", "skrs_status",
    "active_ingredient", "form", "route", "dose_unit", "default_dose",
    "daily_freq", "hours_apart", "meal_relation", "treatment_days",
    "indication_short", "olcek_ml",
    # Öğün detayı (hassas iki katmanlı öğün modeli + meta)
    "meal_group", "meal_detail", "meal_ac_critical", "meal_source",
    "meal_confidence", "meal_reviewed",
    # İstatistik / operasyonel
    "sales_count", "stock", "rank",
]

# INTEGER kolonlar (boş → NULL, aksi halde int'e çevrilir).
INT_COLS = {
    "daily_freq", "hours_apart", "treatment_days", "meal_ac_critical",
    "meal_reviewed", "sales_count", "stock", "rank",
}

# Düzenlenebilen modüler blok tipleri (drug_label_blocks.block_type).
BLOCK_TYPES = [
    "endikasyon", "hazirlama", "teknik", "saklama", "dikkat",
    "etkilesim", "sivi", "yan_etki", "hatirlatma", "sonlandirma",
]

# Blok kaynak önceliği (yüksek = tercih edilir).
_SOURCE_PRIORITY = {
    "manual": 3, "prospektus_kt": 2, "general_knowledge": 1, "category_template": 0,
}


# ---------------------------------------------------------------------------
# Okuma
# ---------------------------------------------------------------------------
def search_drugs(q: str, limit: int = 200) -> list[sqlite3.Row]:
    """Barkod (rakamsa) veya isimle ara; boşsa en çok satanları döner."""
    q = (q or "").strip()
    with get_connection() as conn:
        if not q:
            return conn.execute(
                "SELECT id, barcode, name FROM drugs "
                "ORDER BY sales_count DESC, name LIMIT ?", (limit,),
            ).fetchall()
        if q.isdigit():
            rows = conn.execute(
                "SELECT id, barcode, name FROM drugs WHERE barcode LIKE ? "
                "ORDER BY sales_count DESC LIMIT ?", (f"{q}%", limit),
            ).fetchall()
            if rows:
                return rows
        return conn.execute(
            "SELECT id, barcode, name FROM drugs WHERE name LIKE ? "
            "ORDER BY sales_count DESC, name LIMIT ?", (f"%{q}%", limit),
        ).fetchall()


def get_drug(drug_id: int) -> Optional[dict]:
    """drugs satırını dict olarak döner (yoksa None)."""
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM drugs WHERE id = ?", (drug_id,)).fetchone()
        return dict(row) if row else None


def get_usage_json(drug_id: int) -> dict:
    """drug_labels tip-1 (kullanım) content_json'unu dict olarak döner."""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT content_json FROM drug_labels WHERE drug_id=? AND label_type=1",
            (drug_id,),
        ).fetchone()
    if not row:
        return {}
    try:
        return json.loads(row["content_json"]) or {}
    except Exception:
        return {}


def get_blocks_effective(drug_id: int) -> dict[str, str]:
    """Her block_type için EFEKTİF metni (en yüksek öncelikli kaynak) döner."""
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT block_type, source, content FROM drug_label_blocks WHERE drug_id=?",
            (drug_id,),
        ).fetchall()
    best: dict[str, tuple[int, str]] = {}
    for r in rows:
        bt = r["block_type"]
        pr = _SOURCE_PRIORITY.get(r["source"], 0)
        if bt not in best or pr > best[bt][0]:
            best[bt] = (pr, r["content"] or "")
    return {bt: best.get(bt, (0, ""))[1] for bt in BLOCK_TYPES}


def find_by_barcode(barcode: str) -> Optional[sqlite3.Row]:
    barcode = (barcode or "").strip()
    if not barcode:
        return None
    with get_connection() as conn:
        return conn.execute(
            "SELECT id, barcode, name FROM drugs WHERE barcode = ?", (barcode,)
        ).fetchone()


# ---------------------------------------------------------------------------
# Yazma — hepsi tek transaction
# ---------------------------------------------------------------------------
def save_drug_all(
    *, drug_id: Optional[int], drug_fields: dict,
    usage_json: dict, blocks: dict[str, str],
) -> int:
    """İlacı (drugs) + kullanım reçetesini (drug_labels tip-1) + modüler blokları
    (drug_label_blocks, source='manual') tek transaction'da kaydeder.

    drug_id None ise: barkod varsa o kayıt güncellenir, yoksa yeni eklenir.
    Kaydedilen ilacın id'sini döner.
    """
    with get_connection() as conn:
        did = _upsert_drug(conn, drug_fields, drug_id)
        _set_usage_json(conn, did, usage_json)
        for bt, content in (blocks or {}).items():
            _set_block_manual(conn, did, bt, content)
        conn.commit()
        return did


def delete_drug(drug_id: int) -> None:
    """İlacı ve (FK cascade ile) tüm etiket/blok/tercih kayıtlarını siler."""
    with get_connection() as conn:
        conn.execute("DELETE FROM drugs WHERE id = ?", (drug_id,))
        conn.commit()


# ---------------------------------------------------------------------------
# İç yardımcılar
# ---------------------------------------------------------------------------
def _upsert_drug(conn: sqlite3.Connection, fields: dict, drug_id: Optional[int]) -> int:
    cols = [c for c in DRUG_EDIT_COLS if c in fields]
    if not cols:
        raise ValueError("Kaydedilecek alan yok.")

    # Var olan kaydı bul (id verildiyse o, yoksa barkodla)
    if drug_id is None:
        bc = (fields.get("barcode") or "").strip()
        if bc:
            row = conn.execute("SELECT id FROM drugs WHERE barcode=?", (bc,)).fetchone()
            if row:
                drug_id = row["id"]

    if drug_id is not None:
        sets = ", ".join(f"{c}=?" for c in cols) + ", updated_at=CURRENT_TIMESTAMP"
        conn.execute(
            f"UPDATE drugs SET {sets} WHERE id=?",
            [fields[c] for c in cols] + [drug_id],
        )
        return drug_id

    placeholders = ", ".join("?" for _ in cols)
    cur = conn.execute(
        f"INSERT INTO drugs ({', '.join(cols)}) VALUES ({placeholders})",
        [fields[c] for c in cols],
    )
    return int(cur.lastrowid)


def _set_usage_json(conn: sqlite3.Connection, drug_id: int, data: dict) -> None:
    # Boş/anlamsız değerleri ayıkla; tamamen boşsa kayıt yazma.
    clean = {k: v for k, v in (data or {}).items()
             if v not in (None, "", [], {})}
    if not clean:
        return
    conn.execute(
        "INSERT INTO drug_labels (drug_id, label_type, content_json, reviewed, filled_at) "
        "VALUES (?, 1, ?, 2, CURRENT_TIMESTAMP) "
        "ON CONFLICT(drug_id, label_type) DO UPDATE SET "
        "  content_json=excluded.content_json, reviewed=2, filled_at=CURRENT_TIMESTAMP",
        (drug_id, json.dumps(clean, ensure_ascii=False)),
    )


def _set_block_manual(conn: sqlite3.Connection, drug_id: int,
                      block_type: str, content: str) -> None:
    content = (content or "").strip()
    if not content:
        # Boşaltıldıysa kullanıcının manuel bloğunu kaldır (alttaki kaynaklar kalır).
        conn.execute(
            "DELETE FROM drug_label_blocks "
            "WHERE drug_id=? AND block_type=? AND source='manual'",
            (drug_id, block_type),
        )
        return
    conn.execute(
        "INSERT INTO drug_label_blocks "
        "  (drug_id, block_type, source, content, reviewed, created_at, updated_at) "
        "VALUES (?, ?, 'manual', ?, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) "
        "ON CONFLICT(drug_id, block_type, source) DO UPDATE SET "
        "  content=excluded.content, reviewed=2, updated_at=CURRENT_TIMESTAMP",
        (drug_id, block_type, content),
    )
