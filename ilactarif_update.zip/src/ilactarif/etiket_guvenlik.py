"""ETİKET GÜVENLİK SATIRI — DB satırı etiket üretimine girmeden önce sağlamaya alınır.

Niçin var
---------
Etiketteki ana talimat, B tekniği, hazırlama etiketi, öğün rozeti ve C
filtrelerinin HEPSİ `drugs.form` ve `drugs.route_class` alanlarına bakar. Bu iki
alan ilacın ADINDAN türetilmiştir ve ad tuzağa düştüğünde ikisi birden yanlış
cevabı onaylar. Ölçülmüş vakalar (2026-09-30 tam denetim, canlı kod + canlı DB):

    VENTOFOR COMBI / TIOUMIT / FORADIL   inhalasyon kapsülü → "BİR BARDAK SU İLE YUTUNUZ"
    ALVESCO inhaler (form=şurup)         → "İÇİNİZ, 1 ÖLÇEK"
    ACLASTA / FLAGYL / MOXAI infüzyon    → "İÇİNİZ" + "suyu çizgiye kadar ekleyin"
    EYLEA / LUCENTIS (göz içi enj.)      → "SABAH-ÖĞLE-AKŞAM 1 DAMLA CİLT ALTINA"
    DEXA-SINE SE göz damlası (formsuz)   → "BİR BARDAK SUYLA YUTULUR"
    TILCOTIL fitil / MINIRIN nazal       → "YUTULUR"
    CIBINQO / PROPECIA tablet            → "ETKİLENEN BÖLGEYE SÜRÜLÜR"
    VEMLIDY / TENOFOVİR (J05, df=5)      → "GÜNDE 5 DEFA"
    MORFIA CR 100 (default_dose=20)      → "GÜNDE 1 DEFA 20 TABLET"

`YAPISAL-BULGU-01`: veri düzeltmesi yalnız bir bilgisayarda kalır; KOD dört
bilgisayara gider. Bu modül bu yüzden VERİYİ DEĞİŞTİRMEZ — okunan satırı
bellekte düzeltir.

Kural
-----
Yalnız KESİN sinyal (ATC ailesi veya addaki açık ibare) DB alanıyla ÇELİŞİRSE
ya da alan BOŞSA devreye girer. Sinyal yoksa ya da iki sinyal çelişirse
(ör. "IM/IV ENJ. VE İNHALASYON") hiçbir şeye dokunulmaz — `AMAC.md`: emin
değilsen yazma.
"""
from __future__ import annotations

import re
from typing import Any, Optional

__all__ = ["guvenli_satir", "kesin_kanal", "GuvenliSatir"]


class GuvenliSatir(dict):
    """sqlite3.Row yerine geçen, alanları düzeltilebilir satır.

    Eksik alan KeyError verir (sqlite3.Row IndexError verir) — çağıranlar
    ikisini de yakalıyor. `duzeltmeler` hangi alanın niçin değiştiğini taşır.
    """

    duzeltmeler: list[str]

    def __getitem__(self, k):
        if isinstance(k, int):
            return list(self.values())[k]
        return super().__getitem__(k)


def _fold(s: str) -> str:
    s = (s or "").upper()
    for a, b in (("İ", "I"), ("I", "I"), ("Ş", "S"), ("Ğ", "G"), ("Ü", "U"),
                 ("Ö", "O"), ("Ç", "C"), ("Â", "A")):
        s = s.replace(a, b)
    return " " + s + " "


# --- Addaki KESİN ibareler -------------------------------------------------
_RX = {
    "inhal": re.compile(r"\bINH\b|\bINH\.|INHAL|ROTADISK|DISKHALER|ROTACAP|AERSOL"
                        r"|\bINHALER\b|INHALASYON"),
    "nebul": re.compile(r"NEBUL"),
    "intranazal": re.compile(r"NAZAL|NASAL|BURUN SPREY|BURUN DAML|SPYREY"),
    "parenteral": re.compile(r"AMPUL|\bAMP\b|ENJEKSIYON|ENJEKTABL|\bENJ\b|\bENJ\."
                             r"|INFUZYON|INFUSYON|\bINF\b|\bINF\.|KARPUL|\bVIAL\b"
                             r"|\bI\.?V\.?\b|\bI\.?M\.?\b|\bS\.?C\.?\b|SUBKUTAN"),
    "intraoculer": re.compile(r"INTRAVITREAL|INTRAKAMERAL|INTRAOKULER"),
    "goz": re.compile(r"GOZ DAML|GOZ  DAML|OFTALM|\bOFT\b|\bOFT\.|MINIMS|THILO"),
    "kulak": re.compile(r"KULAK"),
    # \bSUPP\b: "SUPPORTAN / RESOURCE SUPPORT" (içilen beslenme ürünü) EŞLEŞMEMELİ
    # — ölçüldü 2026-09-30: aksi halde "1 FİTİL MAKATTAN UYGULANIR" basılıyordu.
    "rektal": re.compile(r"\bSUPP\b|\bSUPP\.|SUPOZ|FITIL|REKTAL|RECTAL"),
    "enema": re.compile(r"ENEMA|LAVMAN"),
    "transdermal_jel": re.compile(r"TRANSD\S*\s+JEL|JEL\S*\s+TRANSD"),
    "vajinal": re.compile(r"\bOVUL|VAJ|VAGINAL|\bVAG\b|\bVAG\."),
    "oral_kati": re.compile(r"TABLET|\bTB\b|\bTBL\b|\bFTB\b|KAPSUL|DRAJE"),
    # Yalnız AĞIZDAN olduğu kesin ibareler (SÜSPANSİYON/DAMLA enjeksiyonda da geçer)
    "oral_isaret": re.compile(r"\bORAL\b|ICILEBILIR|SURUP|\bSASE\b|POSET|EFERVESAN"),
    "dilalti": re.compile(r"DILALTI|DIL ALTI|SUBLINGUAL|BUKKAL|AGIZDA DAGILAN|MELT"),
    "topikal": re.compile(r"KREM|POMAD|MERHEM|\bJEL\b|LOSYON|SPREY|SAMPUAN|\bTUP\b"),
}

_INHALER_FORMS = {"inhaler_pmdi", "inhaler_dpi", "nebule"}
_INJ_FORMS = {"injection_im", "injection_iv", "injection_sc"}
_ORAL_FORMS = {"tablet_normal", "tablet_effervescent", "tablet_enteric_or_extended",
               "tablet_chewable", "capsule_normal", "capsule_pellet_open",
               "syrup_or_suspension", "powder_for_suspension", "sachet_oral",
               "oral_drop", "nutritional_supplement_oral", "nutritional_powder_oral",
               "FILM TABLET"}
_EYE_FORMS = {"eye_drop", "eye_ointment"}
_NOSE_FORMS = {"nasal_spray", "nasal_drop"}
_RECTAL_FORMS = {"suppository_rectal", "cream_rectal", "enema_rectal"}


def kesin_kanal(name: str, atc: Optional[str]) -> str:
    """Addan/ATC'den KESİN kanal; belirsizse ''.

    Dönüş: inhal | nebul | parenteral | intraoculer | goz | burun | rektal |
           vajinal | transdermal_jel | oral_kati | oral_diger | ''
    İki farklı kanal ailesi birlikte görülürse (ör. "IM/IV REKTAL",
    "ENJ. VE INHALASYON") '' döner: çok-yollu ürüne hüküm verilmez.
    """
    n = _fold(name)
    a = (atc or "").strip().upper()
    has = {k: bool(rx.search(n)) for k, rx in _RX.items()}

    # Aşılar (J07): ağızdan olanlar da (ROTARIX) sağlık personelince verilir;
    # "1 ölçek / çalkalayınız" gibi ev kullanımı cümlesi üretilmesin.
    if a.startswith("J07"):
        return ""

    # Göz içi enjeksiyon/implant — göz hekimi uygular.
    # S01LA01 verteporfin (VISUDYNE) DAMAR İÇİNE infüzyondur → göz içi değil.
    if has["intraoculer"] or (a.startswith(("S01LA", "S01EB02"))
                              and not a.startswith("S01LA01")
                              and not re.search(r"INFUZYON|INFUSYON", n)
                              and (has["parenteral"] or re.search(r"SIRINGA|IMPLANT|FLAKON", n))):
        return "intraoculer"

    atc_inhal = a.startswith(("R03A", "R03B"))
    atc_iv = a.startswith(("B05B", "B05X"))          # IV solüsyon/katkıları
    # Astım biyolojikleri yalnız enjeksiyondur (omalizumab/reslizumab/mepolizumab/
    # benralizumab/tezepelumab). R03DX07 roflumilast AĞIZDAN tablettir → dahil değil.
    # (XOLAIR "ENJELSIYONLUK" yazım hatasıyla addan yakalanamıyordu — ölçüldü.)
    atc_iv = atc_iv or a.startswith(("R03DX05", "R03DX08", "R03DX09", "R03DX10", "R03DX11"))
    inhal = (atc_inhal or has["inhal"] or has["nebul"]) and not has["intranazal"]
    if inhal and re.search(r"TABLET|SURUP|\bTB\b|\bFTB\b", n) and not atc_inhal:
        inhal = False                                  # "SGLT2 INH" kısaltması
    parenteral = (has["parenteral"] or atc_iv) and not (
        has["oral_isaret"] or has["oral_kati"] or has["topikal"])
    # B05B/B05X IV solüsyon torbaları adında "POŞET" taşır (PLEGISOL ESNEK POŞET);
    # ATC IV diyorsa ve ağızdan olduğuna dair başka ibare yoksa parenteraldir.
    if atc_iv and not parenteral and not (has["oral_kati"] or has["topikal"] or re.search(
            r"\bORAL\b|ICILEBILIR|SURUP|EFERVESAN|\bSASE\b", n)):
        parenteral = True

    aileler = [k for k, v in (("inhal", inhal), ("parenteral", parenteral),
                              ("goz", has["goz"] and not has["kulak"]),
                              ("burun", has["intranazal"]),
                              # "VAG. SUPOZİTUAR" vajinaldir; SUPOZ tek başına rektal
                              ("rektal", has["rektal"] and not has["vajinal"]),
                              ("vajinal", has["vajinal"]))
               if v]
    if len(aileler) > 1:
        return ""
    if aileler:
        k = aileler[0]
        if k == "inhal":
            return "nebul" if has["nebul"] else "inhal"
        return k

    if has["transdermal_jel"]:
        return "transdermal_jel"
    if has["oral_kati"] and not (has["topikal"] or has["dilalti"] or has["enema"]):
        return "oral_kati"
    if has["oral_isaret"] and not (has["topikal"] or has["dilalti"] or has["enema"]
                                   or has["parenteral"]):
        return "oral_diger"
    return ""


# kanal → (kabul edilen formlar, kabul edilen route_class kodları)
_BEKLENEN: dict[str, tuple[set, set]] = {
    "inhal": (_INHALER_FORMS, {"12"}),
    "nebul": (_INHALER_FORMS, {"12"}),
    "intraoculer": (_INJ_FORMS, {"16"}),
    "parenteral": (_INJ_FORMS, {"3", "4", "5", "16"}),
    "goz": (_EYE_FORMS, {"6"}),
    "burun": (_NOSE_FORMS, {"10"}),
    "rektal": (_RECTAL_FORMS, {"13"}),
    "vajinal": ({"vaginal_ovule_or_cream"}, {"13"}),
    "transdermal_jel": ({"gel_topical", "cream_or_ointment_topical"}, {"2"}),
    "oral_kati": (_ORAL_FORMS | {"tablet_sublingual"}, {"1", "8", "11", "14"}),
    "oral_diger": (_ORAL_FORMS | {"tablet_sublingual"}, {"1", "8", "11", "14"}),
}


def _rc_set(rc: Any) -> set[str]:
    return {p.strip() for p in str(rc or "").split(",") if p.strip()}


# J05 antiviralleri: toplu veri hatasıyla hepsine asiklovirin "günde 5" sıklığı
# yazılmış (34 kayıt, ölçüldü 2026-09-30). Asiklovir DIŞINDA günde 5 yoktur.
_J05_GUNLUK = {
    "J05AB01": None,   # asiklovir — günde 5 GEÇERLİ (zona/herpes), dokunma
    "J05AB11": 2,      # valasiklovir (endikasyona göre 2-3)
    "J05AB14": 2,      # valgansiklovir
    "J05AB15": 1,      # brivudin
    "J05AF05": 1,      # lamivudin 100 mg (hepatit B)
    "J05AF07": 1,      # tenofovir disoproksil
    "J05AF10": 1,      # entekavir
    "J05AF13": 1,      # tenofovir alafenamid
    "J05AH02": 2,      # oseltamivir
    "J05AJ03": 1,      # dolutegravir
    "J05AR03": 1,      # tenofovir disoproksil/emtrisitabin
    "J05AR10": 2,      # lopinavir/ritonavir
    "J05AR18": 1,      # elvitegravir/kobisistat/emtrisitabin/TAF
    "J05AR20": 1,      # biktegravir/emtrisitabin/TAF
}


def _j05_duzelt(atc: str, df: Any) -> Optional[int]:
    if df != 5 or not atc.startswith("J05"):
        return None
    if atc.startswith("J05AB01"):
        return None
    for pre, v in _J05_GUNLUK.items():
        if atc.startswith(pre):
            return v
    # Listede olmayan antiviral (ör. J05AX05 inosin pranobeks): TAHMİN YOK,
    # DB değeri olduğu gibi kalır. Toptan "günde 1" saymak yanlış olurdu.
    return None


def guvenli_satir(row) -> Optional["GuvenliSatir"]:
    """DB satırını kesin sinyallere göre bellekte düzeltir. None → None."""
    if row is None:
        return None
    d = GuvenliSatir({k: row[k] for k in row.keys()})
    d.duzeltmeler = []
    name = d.get("name") or ""
    atc = (d.get("atc_code") or "").strip().upper()
    form = d.get("form") or None
    rc = _rc_set(d.get("route_class"))
    n = _fold(name)
    kanal = "" if "0" in rc else kesin_kanal(name, atc)

    # Yalnız ÇELİŞKİ ya da tam BOŞLUK varsa müdahale et. Formu boş ama
    # route_class'ı doğru kayıt (ör. SYMBICORT form=None rc=12) bugün doğru
    # cümle basıyor; ona dokunmak etiket planını (B/C basımı) değiştirir.
    if kanal:
        bek_form, bek_rc = _BEKLENEN[kanal]
        form_yanlis = form is not None and form not in bek_form
        rc_yanlis = bool(rc) and not (rc & bek_rc)
        bos = form is None and not rc
        if not (form_yanlis or rc_yanlis or bos):
            kanal = ""

    def set_(k, v, neden):
        if d.get(k) != v:
            d.duzeltmeler.append(f"{k}: {d.get(k)!r} -> {v!r} ({neden})")
            d[k] = v

    if kanal in ("inhal", "nebul"):
        if form not in _INHALER_FORMS:
            if kanal == "nebul":
                yeni = "nebule"
            elif re.search(r"AERSOL|AEROSOL|\bINHALER\b", n) and not re.search(r"KAPSUL|TOZ", n):
                yeni = "inhaler_pmdi"
            else:
                yeni = "inhaler_dpi"
            set_("form", yeni, "inhalasyon ürünü")
        if rc != {"12"}:
            set_("route_class", "12", "inhalasyon ürünü")
        if "meal_relation" in d:
            set_("meal_relation", None, "inhalasyon")
    elif kanal == "intraoculer":
        set_("form", "injection_iv", "göz içi uygulama (hekim)")
        set_("route_class", "16", "göz içi uygulama (hekim)")
        for k in ("daily_freq", "hours_apart", "meal_relation"):
            if k in d:
                set_(k, None, "göz içi uygulama (hekim)")
        if "dose_unit" in d and (d.get("dose_unit") or "").lower() in ("damla", "ml", "ölçek"):
            set_("dose_unit", "doz", "göz içi uygulama (hekim)")
    elif kanal == "parenteral":
        if form not in _INJ_FORMS:
            if re.search(r"\bS\.?C\.?\b|SUBKUTAN|KALEM|\bPEN\b", n):
                yeni = "injection_sc"
            elif re.search(r"\bI\.?V\.?\b|INFUZYON|INFUSYON|\bINF\b|\bINF\.", n):
                yeni = "injection_iv"
            else:
                yeni = "injection_im"
            set_("form", yeni, "enjeksiyon ürünü")
        if not (rc & {"3", "4", "5", "16", "0"}):
            set_("route_class", {"injection_sc": "5", "injection_iv": "3",
                                 "injection_im": "4"}.get(d["form"], "3,4"),
                 "enjeksiyon ürünü")
        if "meal_relation" in d:
            set_("meal_relation", None, "enjeksiyon")
        ind = d.get("indication_short") or ""
        if re.search(r"HAR[İI]C[İI]|D[İI]Ş KULLAN", ind.upper()):
            set_("indication_short", re.sub(r"\s*\((HAR[İI]C[İI]|D[İI]Ş KULLANIM)\)", "", ind,
                                            flags=re.I).strip(), "enjeksiyon harici değildir")
    elif kanal == "goz":
        if form not in _EYE_FORMS:
            set_("form", "eye_ointment" if re.search(r"POMAD|MERHEM|\bJEL\b", n) else "eye_drop",
                 "göz ürünü")
        if "6" not in rc:
            set_("route_class", "6", "göz ürünü")
    elif kanal == "burun":
        if form not in _NOSE_FORMS:
            set_("form", "nasal_drop" if "DAMLA" in n else "nasal_spray", "burun ürünü")
        if "10" not in rc:
            set_("route_class", "10", "burun ürünü")
    elif kanal == "rektal":
        if form not in _RECTAL_FORMS:
            set_("form", "suppository_rectal", "rektal ürün")
        if "13" not in rc:
            set_("route_class", "13", "rektal ürün")
    elif kanal == "vajinal":
        if form is None:
            set_("form", "vaginal_ovule_or_cream", "vajinal ürün")
        if "13" not in rc:
            set_("route_class", "13", "vajinal ürün")
    elif kanal == "transdermal_jel":
        if form != "gel_topical":
            set_("form", "gel_topical", "transdermal JEL (bant değil, içilmez)")
        if rc != {"2"}:
            set_("route_class", "2", "transdermal JEL (bant değil, içilmez)")
    elif kanal in ("oral_kati", "oral_diger"):
        agiz_disi = {"14", "8", "11", "0"}
        if kanal == "oral_kati":
            hedef = "capsule_normal" if "KAPSUL" in n else "tablet_normal"
        elif re.search(r"\bSASE\b|POSET", n):
            hedef = "sachet_oral"
        elif "EFERVESAN" in n:
            hedef = "tablet_effervescent"
        else:
            hedef = "syrup_or_suspension"
        form_agiz_disi = form is not None and form not in _ORAL_FORMS and form != "tablet_sublingual"
        rc_agiz_disi = bool(rc) and "1" not in rc and not (rc & agiz_disi)
        if form_agiz_disi or (form is None and rc_agiz_disi):
            set_("form", hedef, "ağızdan alınan ürün")
        if rc_agiz_disi:
            set_("route_class", "1", "ağızdan alınan ürün")

    # Form VE route_class TAMAMEN BOŞ + adda yalnız dış kullanım ibaresi
    # (LIDORIN %5 TÜP → "BİR BARDAK SUYLA YUTULUR" basıyordu). Yalnız tam boşluğu
    # doldurur; dolu bir alanı asla değiştirmez.
    if (not kanal and form is None and not rc
            and re.search(r"KREM|POMAD|MERHEM|\bTUP\b|LOSYON", n)
            and not re.search(r"GOZ|OFT|VAJ|VAG|OVUL|REKT|RECT|NAZAL|BURUN|ORAL|ORABASE"
                              r"|\bDIS\b|AGIZ|KAPSUL|TABLET|ENJ|AMPUL", n)):
        set_("form", "cream_or_ointment_topical", "dış kullanım (krem/pomad/tüp), alanlar boş")
        set_("route_class", "2", "dış kullanım (krem/pomad/tüp), alanlar boş")

    # --- Sıklık / doz akıl-sağlığı (DB varsayılanı; reçete sıklığını ezmez) ---
    if "daily_freq" in d:
        yeni_df = _j05_duzelt(atc, d.get("daily_freq"))
        if yeni_df:
            set_("daily_freq", yeni_df, "J05 toplu 'günde 5' veri hatası")
            if "hours_apart" in d:
                set_("hours_apart", None, "J05 toplu 'günde 5' veri hatası")
    # Zanamivir diskhaler: kayıtta sıklık/doz yok → "günde 1 sefer" basılıyordu.
    # Tedavi şeması: günde 2 kez 2 inhalasyon (reçete sıklığı bunu ezer).
    if atc == "J05AH01" and not d.get("daily_freq"):
        for k, v in (("daily_freq", 2), ("default_dose", "2"), ("dose_unit", "sefer")):
            if k in d:
                set_(k, v, "zanamivir tedavi şeması")

    if "default_dose" in d:
        try:
            v = float(str(d.get("default_dose") or "").replace(",", "."))
        except ValueError:
            v = None
        birim = (d.get("dose_unit") or "").lower()
        if v is not None and v > 4 and re.search(r"tablet|kaps|tane|draje|fitil|ovül|ovul|saşe|sase|ampul|bant", birim):
            set_("default_dose", "1", "imkânsız varsayılan doz (kutu adedi doz alanına girmiş)")
    return d
