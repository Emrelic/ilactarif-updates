"""Etiket görseli üretimi — Pillow ile.

Hedef yazıcı: Gprinter GP-1125D (203 DPI, 60×40 mm)
  60 mm × 203 DPI / 25.4 = 479.7 ≈ 480 px (en)
  40 mm × 203 DPI / 25.4 = 319.8 ≈ 320 px (boy)

3 etiket tipi üretir:
  1) Kullanım (UsageLabel)   — dozaj matrisli yeni tasarım
  2) Hazırlama (PreparationLabel)
  3) Uyarı (WarningLabel)

Sade kompozisyon, fontlar Windows'ta hazır gelen arial ailesi.

Etiket 1 yerleşimi (yeni tasarım):
  ┌─────────────────────────────────────────────┐
  │ HASTA ADI                  ┌───────────┐    │  hasta + kategori (çerçeveli)
  │                            │ KATEGORİ  │    │
  ├────────────────────────────└───────────┘────┤
  │ İLAÇ ADI (çerçeveli bant)                    │
  │                       Reçete: ..  Bitiş: ..  │
  ├──────────────────┬──────────────────────────┤
  │  SABAH    1      │   BİR BARDAK SU İLE      │  sol: dozaj ızgarası (sadece dolu)
  │  AKŞAM    1      │   YUTUNUZ                 │  sağ: talimat + teknik
  │  ███████████     │   ───────────────        │
  │  █   TOK   █     │   KULLANMADAN ÖNCE       │  TOK/AÇ ters renkli
  │  ███████████     │   ÇALKALAYINIZ           │
  │  █ ALKOL YOK █   │                          │  kritik rozet ters renkli (varsa)
  ├──────────────────┴──────────────────────────┤
  │      İKİZLER ECZANESİ / 0212-515-74-40      │
  └─────────────────────────────────────────────┘
"""
from __future__ import annotations

import re
from dataclasses import asdict
from datetime import date, timedelta
from pathlib import Path
from typing import Optional

from PIL import Image, ImageChops, ImageDraw, ImageFont

from .models import PreparationLabel, UsageLabel, WarningLabel

# Etiket fiziksel boyutu
LABEL_W = 480   # 60 mm @ 203 DPI
LABEL_H = 320   # 40 mm @ 203 DPI
DPI = 203

# Kenar boşlukları
PAD_X = 10
PAD_Y = 6

# Renkler — etiket zemini SARI (fiziksel sarı etiket stoğu). Termal yazıcı yalnız
# siyahı basar; sarı luminansı yüksek olduğu için basılmaz, ekran önizleme ile
# fiziksel etiket görünümü birebir uyumlu olur.
BG = "#FFE680"
FG = "black"

# Punto (font) büyütme çarpanı. Tüm yazılar bu oranda büyür; satır aralıkları ve
# kutu yükseklikleri de aynı oranda ölçeklenir (bkz. _sv). Genişliğe sığmayan
# yazılar _fit_font/_wrap ile otomatik küçülür, yani etikete sığar.
# 1.0 = orijinal tasarım. Boş alanı doldurmak için ~1.6 önerilir.
FONT_SCALE = 1.6

# Kargo firması şeridi: ekran önizlemesinde firmaya göre renk (FİZİKSEL BASKI HER
# ZAMAN SİYAH — termal yazıcı yalnız siyahı basar). Anahtar = firma adının sade
# slug'ı (bkz. _kargo_slug). Açık renkliler için metin/logo otomatik siyaha döner.
KARGO_FIRMA_RENK = {
    "yurtici":  "#0a2a6b",   # lacivert
    "aras":     "#c8102e",   # kırmızı
    "mng":      "#e30613",   # kırmızı
    "ptt":      "#ffcc00",   # sarı (açık → metin siyah)
    "surat":    "#e2001a",
    "sendeo":   "#ff6a00",
    "hepsijet": "#ff6000",
    "trendyolexpress": "#f27a1a",
}

# Firma logoları (siyah-beyaz) buraya konur: assets/kargo_logos/<slug>.png
# Dosya yoksa şeritte firma adı metni basılır (otomatik geri dönüş).
PROJECT_ROOT = Path(__file__).resolve().parents[2]
KARGO_LOGO_DIR = PROJECT_ROOT / "assets" / "kargo_logos"


def _sv(v: float) -> int:
    """Dikey ölçek: satır aralığı / kutu yüksekliği gibi metrikleri FONT_SCALE ile büyütür."""
    return round(v * FONT_SCALE)


# ---------------------------------------------------------------------------
# Font yükleme
# ---------------------------------------------------------------------------
def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    """Windows'taki arial/arialbd fontunu (FONT_SCALE ile büyütülmüş) döndürür."""
    name = "arialbd.ttf" if bold else "arial.ttf"
    size = max(6, round(size * FONT_SCALE))
    try:
        return ImageFont.truetype(name, size)
    except OSError:
        # Sistem fontu bulunamazsa fallback
        return ImageFont.load_default()


# ---------------------------------------------------------------------------
# Yardımcılar
# ---------------------------------------------------------------------------
def _text_w(draw: ImageDraw.ImageDraw, text: str, font) -> int:
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0]


def _wrap(text: str, font, max_w: int, draw: ImageDraw.ImageDraw) -> list[str]:
    """Kelime-bazlı satır sarma; \n ile zorunlu satır kesmesi desteklenir."""
    lines: list[str] = []
    for paragraph in text.split("\n"):
        words = paragraph.split()
        cur = ""
        for w in words:
            trial = (cur + " " + w).strip()
            if _text_w(draw, trial, font) <= max_w:
                cur = trial
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
    return lines


def _fit_font(
    draw: ImageDraw.ImageDraw,
    text: str,
    max_w: int,
    base_size: int,
    bold: bool = False,
    min_size: int = 8,
) -> ImageFont.FreeTypeFont:
    """Metni max_w'ye sığdıran en büyük fontu döndürür (base_size'tan aşağı küçülterek)."""
    size = base_size
    while size > min_size:
        f = _font(size, bold)
        if _text_w(draw, text, f) <= max_w:
            return f
        size -= 1
    return _font(min_size, bold)


def _centered_text(
    d: ImageDraw.ImageDraw,
    x0: int, y0: int, x1: int, y1: int,
    text: str, font, fill: str,
) -> None:
    """Bir dikdörtgen içine yatay+dikey ortalanmış tek satır metin yazar."""
    tw = _text_w(d, text, font)
    try:
        bbox = font.getbbox(text)
    except Exception:
        bbox = (0, 0, 0, font.size)
    th = (bbox[3] - bbox[1]) or font.size
    tx = x0 + ((x1 - x0) - tw) // 2
    ty = y0 + ((y1 - y0) - th) // 2 - bbox[1]
    d.text((tx, ty), text, font=font, fill=fill)


def _inv_box(
    d: ImageDraw.ImageDraw,
    x0: int, y0: int, x1: int, y1: int,
    text: str, base_size: int,
    bold: bool = True, min_size: int = 8,
) -> None:
    """Ters renkli kutu: siyah dolgu + beyaz, ortalanmış metin (oto-sığdırma)."""
    d.rectangle([x0, y0, x1, y1], fill="black")
    if not text:
        return
    f = _fit_font(d, text, (x1 - x0) - 8, base_size, bold, min_size)
    _centered_text(d, x0, y0, x1, y1, text, f, "white")


def _bordered_box(
    d: ImageDraw.ImageDraw,
    x0: int, y0: int, x1: int, y1: int,
    text: str, base_size: int,
    bold: bool = True, min_size: int = 8,
) -> None:
    """Çerçeveli kutu: kenarlık + siyah, ortalanmış metin (oto-sığdırma)."""
    d.rectangle([x0, y0, x1, y1], outline="black", width=2)
    if not text:
        return
    f = _fit_font(d, text, (x1 - x0) - 10, base_size, bold, min_size)
    _centered_text(d, x0, y0, x1, y1, text, f, "black")


def _bordered_box_wrap(
    d: ImageDraw.ImageDraw,
    x0: int, y0: int, x1: int, y1: int,
    text: str, base_size: int,
    bold: bool = True, max_lines: int = 2, min_size: int = 9,
) -> None:
    """Çerçeveli kutu: metni en çok max_lines satıra sararak ortalar.

    Tek satıra sığmayan uzun ibarelerde (örn. 'BUZDOLABININ ORTA RAFINDA
    SAKLAYINIZ') fontu min_size'a indirmek yerine 2 satıra böler → okunaklı kalır.
    """
    d.rectangle([x0, y0, x1, y1], outline="black", width=2)
    if not text:
        return
    inner_w = (x1 - x0) - 10
    size = base_size
    while size > min_size:
        f = _font(size, bold)
        if len(_wrap(text, f, inner_w, d)) <= max_lines:
            break
        size -= 1
    f = _font(size, bold)
    lines = _wrap(text, f, inner_w, d)[:max_lines]
    line_h = f.size + _sv(2)
    block_h = line_h * len(lines)
    ty = y0 + ((y1 - y0) - block_h) // 2
    for ln in lines:
        w = _text_w(d, ln, f)
        d.text((x0 + ((x1 - x0) - w) // 2, ty), ln, font=f, fill="black")
        ty += line_h


# İlaç adının ilk kelimesinden sonra korunacak kısa marka ekleri (güç/form değil).
_BRAND_MODIFIERS = {
    "PLUS", "FORT", "FORTE", "SR", "XL", "XR", "MR", "CR", "ZOK", "COR",
    "DUO", "HCT", "RETARD", "COMBI", "MITE", "UNO", "BID", "OD", "QUATTRO",
}


def _short_drug_name(ilac_adi: str) -> str:
    """İlaç adından kısa MARKA adını çıkarır (ikincil etiketlerde kullanılır).

    İlk kelime + ardından gelen kısa marka eklerini (PLUS/FORT/ZOK...) korur;
    güç/birim/form/sayı içeren kelimede (100IU/ML, MG, 3ML, SOLOSTAR, TABLET...)
    durur. Örn: 'LANTUS SOLOSTAR SUBKUTAN 100IU/ML 3ML 5 KALEM' → 'LANTUS';
    'DELİX PLUS 5/1.25 MG' → 'DELİX PLUS'; 'BELOC ZOK 50 MG' → 'BELOC ZOK'.
    """
    words = (ilac_adi or "").strip().split()
    if not words:
        return ilac_adi or ""
    out = [words[0]]
    for w in words[1:]:
        wu = w.upper().strip(".,")
        if any(ch.isdigit() for ch in wu) or "%" in wu:
            break
        if wu in _BRAND_MODIFIERS:
            out.append(w)
        else:
            break
    return " ".join(out)


def _draw_header_two(
    d: ImageDraw.ImageDraw, hasta_adi: str, ilac_adi: str, hasta_base: int = 15,
    shorten: bool = True,
) -> None:
    """Üst satır: hasta adı solda + ilaç (marka) adı sağda; çakışmayı önlemek
    için hasta adı en fazla yarı genişliğe sığdırılır, ilaç adı kalan alana küçültülür.

    shorten=True (varsayılan): ilaç adından KISA marka adı çıkarılır (örn. uzun
    'LANTUS SOLOSTAR ... 5 KALEM' → 'LANTUS'). İkincil ilaç etiketlerinde tercih edilir.

    shorten=False: TAM ürün adı yazılır (kalan genişliğe sığacak puntoyla; sığmazsa
    '…' ile kırpılır). Tıbbi malzeme/cihaz tarif etiketlerinde (kan şekeri çubuğu vb.)
    hasta için ürünün tam adı önemli olduğundan bu mod kullanılır.

    hasta_base: ÖLÇEKLENMEMİŞ punto (FONT_SCALE _font içinde uygulanır)."""
    hasta = hasta_adi.upper()
    hasta_maxw = (LABEL_W - 2 * PAD_X) // 2
    fh = _fit_font(d, hasta, hasta_maxw, hasta_base, bold=True, min_size=9)
    d.text((PAD_X, PAD_Y), hasta, font=fh, fill=FG)
    hw = _text_w(d, hasta, fh)

    remaining = LABEL_W - PAD_X - (PAD_X + hw + 12)
    if remaining < 60:
        return

    if shorten:
        _brand = _short_drug_name(ilac_adi)
        ilac_txt = _brand if len(_brand) <= 30 else _brand[:28] + "…"
        fi = _fit_font(d, ilac_txt, remaining, 12, bold=False, min_size=8)
    else:
        # Tam ad: kalan genişliğe en küçük punto (7) ile dahi sığmıyorsa sondan
        # karakter atıp '…' ekleyerek kırp (marka kısaltma YOK).
        ilac_txt = ilac_adi.upper()
        fi = _fit_font(d, ilac_txt, remaining, 12, bold=False, min_size=7)
        while ilac_txt and _text_w(d, ilac_txt + "…", fi) > remaining:
            ilac_txt = ilac_txt[:-1].rstrip()
        if ilac_txt != ilac_adi.upper():
            ilac_txt = ilac_txt + "…"
    w = _text_w(d, ilac_txt, fi)
    d.text((LABEL_W - PAD_X - w, PAD_Y + 2), ilac_txt, font=fi, fill=FG)


def _draw_footer(draw: ImageDraw.ImageDraw, eczane: str, telefon: str,
                 line_x1: int | None = None) -> None:
    """Etiketin alt çizgisi + eczane bilgisi (referans format: 'AD / TELEFON')."""
    line_y = LABEL_H - 24
    x1 = line_x1 if line_x1 is not None else LABEL_W - PAD_X
    draw.line([(PAD_X, line_y), (x1, line_y)], fill="black", width=1)
    parts = [eczane.strip()]
    if telefon:
        # Referansta "İKİZLER ECZANESİ / 0212-515-74-40" formatı
        parts.append(telefon.replace(" ", "-"))
    txt = " / ".join(p for p in parts if p)
    # Punto bir-iki kademe düşürüldü (13→11) ve genişliğe otomatik sığdırılır.
    font = _fit_font(draw, txt, LABEL_W - 2 * PAD_X, 11, bold=True, min_size=8)
    w = _text_w(draw, txt, font)
    draw.text(((LABEL_W - w) // 2, line_y + 5), txt, font=font, fill="black")


def _format_date(d: date) -> str:
    return d.strftime("%d.%m.%Y")


# Türkçe gün adları (strftime locale'e güvenmeden — Windows'ta TR locale garanti değil)
_TR_GUNLER = [
    "PAZARTESİ", "SALI", "ÇARŞAMBA", "PERŞEMBE", "CUMA", "CUMARTESİ", "PAZAR",
]


def _format_date_tr(d: date) -> str:
    """date → '22.06.2026 PAZARTESİ' (Türkçe gün adı dahil)."""
    return f"{d.strftime('%d.%m.%Y')} {_TR_GUNLER[d.weekday()]}"


# Türkçe ay adları (1=Ocak). upper() Türkçe'yi bozduğu için doğrudan büyük yazılı.
_TR_AYLAR = [
    "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN",
    "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK",
]


def _format_date_tr_long(d: date) -> str:
    """date → '22 HAZİRAN 2026 PAZARTESİ' (gün sayısı + ay adı + yıl + gün adı)."""
    return f"{d.day} {_TR_AYLAR[d.month - 1]} {d.year} {_TR_GUNLER[d.weekday()]}"


def _truncate(text: str, max_chars: int) -> str:
    text = (text or "").strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 1].rstrip() + "…"


# ---------------------------------------------------------------------------
# Etiket 1 — yapısal alanlardan türetme yardımcıları
# ---------------------------------------------------------------------------
_ZAMAN_DISPLAY = {
    "sabah": "SABAH", "öğle": "ÖĞLEN", "öğlen": "ÖĞLEN",
    "akşam": "AKŞAM", "gece": "GECE", "yatmadan": "GECE",
}

# Açıklayıcı öğün rozeti metni (yalnız AÇ/TOK'a indirgenmez). Rozet metni sol
# sütun genişliğini aşarsa render kutuyu sağa doğru uzatır (font küçültmez).
_MEAL_BADGE = {
    "aç": "AÇ",
    "tok": "TOK",
    "fark etmez": "AÇ TOK FARKETMEZ",
    "yemekle": "YEMEKLE",
    "yemekten önce": "YEMEKTEN ÖNCE",
    "yemekten sonra": "YEMEKTEN SONRA",
    "yemeğin hemen başında": "YEMEKLE",
    "yemek başlangıcında": "YEMEK BAŞINDA",
}


def _grid_dose_token(doz: str) -> str:
    """Dozaj ızgarasının dar sütununa sığacak kısa doz jetonu üretir.

    '1 TANE' → '1', '1 TABLET' → '1', 'YARIM TABLET' → 'YARIM',
    'BİR BUÇUK TANE' → 'BİR BUÇUK', '1 ÖLÇEK (5 ml)' → '1 ÖLÇEK',
    'BİR BUÇUK ÖLÇEK' → '1,5 ÖLÇEK', '7 MİLİLİTRE' → '7 ml',
    '2 PUF' → '2 PUF', '1 ENJEKTÖR' → '1' (geniş birim → talimat satırında belli).
    """
    doz = (doz or "").strip().upper()
    if not doz:
        return "1"
    parts = doz.split()
    # İnsülin dozu: "ÜNİTE" asla atılmaz/kırpılmaz (örn. '30 ÜNİTE', '100 ÜNİTE').
    # Not: Python upper() Türkçe bilmez ('ünite'→'ÜNITE' noktasız I); foldlayarak ara
    # ve çıktıyı her zaman düzgün 'ÜNİTE' (noktalı İ) olarak yaz.
    if "UNITE" in doz.replace("Ü", "U").replace("İ", "I"):
        num = parts[0] if parts and parts[0][:1].isdigit() else ""
        return (num + " ÜNİTE").strip()
    # Tablet birimi (TANE/TABLET/ADET) + inhaler 'SEFER' sonda ise at; miktar kısmını
    # ('YARIM', '1') tut → A ızgarası sade "SABAH 2" kalsın (birim sağ talimatta/B'de belli).
    _units = {"TANE", "TABLET", "ADET", "SEFER"}
    if len(parts) >= 2 and parts[-1] in _units:
        return " ".join(parts[:-1])
    if "ÖLÇEK" in doz:
        doz = doz.split("(")[0].strip()
        # Yazı biçimli miktarı sayıya çevir; "BİR BUÇUK ÖLÇEK" len>8 kuralına
        # takılarak "BİR BUÇU" şeklinde K'sız kırpılmasın. YARIM/ÇEYREK ızgarada da
        # yazı kalsın (hasta için anlaşılır; "0,5/0,25 ÖLÇEK" yerine YARIM/ÇEYREK).
        _WORD_OLCEK = {
            "YARIM ÖLÇEK":      "YARIM ÖLÇEK",
            "ÇEYREK ÖLÇEK":     "ÇEYREK ÖLÇEK",
            "BİR ÖLÇEK":        "1 ÖLÇEK",
            "BİR BUÇUK ÖLÇEK":  "1,5 ÖLÇEK",
            "İKİ ÖLÇEK":        "2 ÖLÇEK",
            "İKİ BUÇUK ÖLÇEK":  "2,5 ÖLÇEK",
            "ÜÇ ÖLÇEK":         "3 ÖLÇEK",
            "ÜÇ BUÇUK ÖLÇEK":   "3,5 ÖLÇEK",
            "DÖRT ÖLÇEK":       "4 ÖLÇEK",
        }
        return _WORD_OLCEK.get(doz, doz)
    # MİLİLİTRE birimini kısalt; aksi hâlde len>8 kuralı bare sayıya indirir
    # ("7 MİLİLİTRE" → "7") ve hasta yanlış birim anlayabilir.
    if "MİLİLİTRE" in doz or "MILILITRE" in doz:
        num = parts[0] if parts else ""
        return f"{num} ml".strip() if num else doz
    # Dar sütuna sığmayan uzun jetonlarda sadece baştaki sayıyı göster
    if len(doz) > 8:
        return parts[0] if parts and parts[0].isdigit() else doz[:8]
    return doz


def _saat_ara_note(n_rows: int) -> str:
    """A tipi ızgarada sağ bölüme saat notu eklenmez; B tipinde sol freetext gösterir."""
    return ""


# interval_mode için kez → saat aralığı metni (son satır: "X SAAT ARAYLA")
_KEZ_SAAT_ARA: dict[int, str] = {
    2: "12 SAAT ARAYLA",
    3: "8 SAAT ARAYLA",
    4: "6 SAAT ARAYLA",
    5: "5 SAAT ARAYLA",
    6: "4 SAAT ARAYLA",
    8: "3 SAAT ARAYLA",
    12: "2 SAAT ARAYLA",
}

# Türkçe sayı kelimesi (doz satırı için 1-10)
_TR_SAYI = {
    1: "BİR", 2: "İKİ", 3: "ÜÇ", 4: "DÖRT", 5: "BEŞ",
    6: "ALTI", 7: "YEDİ", 8: "SEKİZ", 9: "DOKUZ", 10: "ON",
}


def _doz_turkce(doz_str: str) -> str:
    """'1 tablet' → 'BİR TABLET', '2 kapsül' → 'İKİ KAPSÜL', '5 ml' → '5 ML'."""
    doz_str = (doz_str or "").strip()
    if not doz_str:
        return ""
    parts = doz_str.upper().split(None, 1)
    birim = parts[1] if len(parts) > 1 else ""
    try:
        n = int(parts[0])
        sayi = _TR_SAYI.get(n, parts[0])
    except ValueError:
        return doz_str.upper()
    return f"{sayi} {birim}".strip() if birim else f"{sayi} ADET"


def _interval_block_lines(label: UsageLabel, ilac_adi: str, kez: int) -> list[str]:
    """B Tipi ortalı blok satırları: "GÜNDE N KEZ / DOZ / X SAAT ARA İLE".

    Hem interval_mode (B butonu) hem de günde 5+ kez ilaçların ortak gösterimi.
    """
    ara = _KEZ_SAAT_ARA.get(kez, "SAAT BAŞI")
    from .drug_guess import is_topical_surulen
    if is_topical_surulen(ilac_adi or "", getattr(label, "kullanim_sekli", "") or ""):
        # Krem/pomad/jel: doz miktarı anlamsız, "DEFA" + "SÜRÜNÜZ" notu
        return [f"GÜNDE {kez} DEFA", ara, "SÜRÜNÜZ"]
    doz_tr = _doz_turkce(label.doz)
    return [f"GÜNDE {kez} KEZ", doz_tr, ara] if doz_tr else [f"GÜNDE {kez} KEZ", ara]


def _derive_grid(label: UsageLabel, ilac_adi: str = "") -> tuple[list[tuple[str, str]], str, list[str]]:
    """Sol dozaj sütununun içeriğini döndürür.

    Dönen üçlü: (rows, note, freetext)
      • rows     — [(zaman, doz)] iki sütunlu satırlar (SABAH | 1)
      • note     — satırların altına eklenecek "(8 SAAT ARA İLE)" gibi not
      • freetext — doluysa rows yerine ORTALI çok satırlı metin (günde 1,
                   zaman bilgisi yoksa: "GÜNDE / 1 ADET / HER GÜN / AYNI SAATTE")
    """
    dose_tok = _grid_dose_token(label.doz)

    # 0a) interval_mode (B Tipi): "GÜNDE N KEZ / DOZ / X SAAT ARA İLE"
    if getattr(label, "interval_mode", False):
        kez_i = int(label.gunluk_kez or 1)
        periyot_i = (label.periyot or "").strip().lower()
        if (not periyot_i or periyot_i.startswith("gün") or periyot_i.startswith("gun")) and kez_i >= 2:
            return [], "", _interval_block_lines(label, ilac_adi, kez_i)

    # 0) Periyot günlük DEĞİLSE (Haftada/Ayda/Yılda) → SABAH-AKŞAM ızgarası YANLIŞTIR.
    #    Reçetedeki "Haftada 2" gibi doz, günde 2 kez sanılıp SABAH/AKŞAM çizilmesin;
    #    bunun yerine "HAFTADA 2 KEZ / 3-4 GÜN ARAYLA" gibi ortalı ifade yazılır.
    periyot = (label.periyot or "").strip().lower()
    if periyot and not periyot.startswith("gün") and not periyot.startswith("gun"):
        kez = label.gunluk_kez or 1
        doz_full = (label.doz or "").strip().upper() or dose_tok
        # Krem/pomad/jel gibi SÜRÜLEN formlarda doz "1 KEZ" placeholder'ıdır
        # (gerçek miktar=GRAM hastaya anlamsız; auto_label_builder birim="kez").
        # Frekans satırı zaten "X KEZ" ile bittiğinden doz_full="1 KEZ" TEKRARA
        # düşer ("HAFTADA / 1 KEZ / 1 KEZ"). Sürülen formda doz satırını atla →
        # günlük kremle paralel temiz ızgara ("HAFTADA / 1 KEZ / HER HAFTA /
        # AYNI GÜN"); "SÜRÜNÜZ" zaten sağ talimat sütununda yazıyor.
        from .drug_guess import is_topical_surulen
        if is_topical_surulen(ilac_adi or "", getattr(label, "kullanim_sekli", "") or ""):
            doz_full = ""
        # `ara` İKİ SATIRA bölünür — tek uzun satır (örn. "HER HAFTA AYNI GÜN")
        # ızgaranın puntosunu küçültüyordu; kısa satırlara bölünce punto büyür.
        if periyot.startswith("haft"):
            birim = "HAFTADA"
            ara = {
                1: ["HER HAFTA", "AYNI GÜN"],
                2: ["3-4 GÜN", "ARAYLA"],
                3: ["GÜN AŞIRI"],
            }.get(kez, [])
        elif periyot.startswith("ay"):
            birim, ara = "AYDA", (["HER AY", "AYNI GÜN"] if kez == 1 else [])
        elif periyot.startswith("yıl") or periyot.startswith("yil"):
            birim, ara = "YILDA", []
        else:
            birim, ara = periyot.upper(), []
        lines = [birim, f"{kez} KEZ"] + ([doz_full] if doz_full else []) + ara
        return [], "", lines

    # 1) Açık zaman_satirlari override'ı
    if label.zaman_satirlari:
        rows = [(str(r[0]), str(r[1])) for r in label.zaman_satirlari if r]
        return rows, _saat_ara_note(len(rows)), []

    # 2) Zaman bilgisi (reçete verisinden VEYA ilaç bilgisinden gelen
    #    kullanim_zamani) varsa onu kullan: SABAH/ÖĞLEN/AKŞAM/GECE
    zaman_rows = [
        _ZAMAN_DISPLAY[(z or "").strip().lower()]
        for z in (label.kullanim_zamani or [])
        if _ZAMAN_DISPLAY.get((z or "").strip().lower())
    ]
    if zaman_rows:
        rows = [(z, dose_tok) for z in zaman_rows]
        return rows, _saat_ara_note(len(rows)), []

    kez = label.gunluk_kez or 0

    _antibiyotik = getattr(label, "antibiotic_interval", False)

    # 3) Günde 1 ve hiçbir zaman bilgisi yok → ortalı metin bloğu
    if kez == 1:
        if _antibiyotik:
            return [], "", ["GÜNDE 1 KEZ", "24 SAAT ARAYLA"]
        doz_full = (label.doz or "").strip().upper() or dose_tok
        return [], "", ["GÜNDE", doz_full, "HER GÜN AYNI SAATTE"]

    # 4) Günde 2/3/4 → standart zaman satırları + saat ara notu
    _ANTIBIYOTIK_ARA = {
        2: "12 SAAT ARAYLA",
        3: "8 SAAT ARA İLE",
        4: "6 SAAT ARA İLE",
    }
    seq = {
        2: ["SABAH", "AKŞAM"],
        3: ["SABAH", "ÖĞLEN", "AKŞAM"],
        4: ["SABAH", "ÖĞLEN", "AKŞAM", "GECE"],
    }.get(kez)
    if seq:
        rows = [(s, dose_tok) for s in seq]
        note = _ANTIBIYOTIK_ARA.get(kez, "") if _antibiyotik else _saat_ara_note(len(rows))
        return rows, note, []

    # 5) Günde 5+ kez: A-tipi ızgara ("GÜNDE 5 1") tek satıra sıkışıp bozuluyor;
    #    bu sıklıkta SABAH/ÖĞLEN/AKŞAM/GECE ızgarası da anlamsız. Doğrudan B-tipi
    #    ortalı blok ("GÜNDE 5 KEZ / BİR TABLET / 5 SAAT ARAYLA") çizilir.
    if kez and kez >= 5:
        return [], "", _interval_block_lines(label, ilac_adi, kez)
    if kez:
        return [(f"GÜNDE {kez}", dose_tok)], "", []
    return [], "", []


def _derive_meal(label: UsageLabel) -> str:
    if label.meal_badge:
        return label.meal_badge.strip().upper()
    return _MEAL_BADGE.get((label.yemek or "").strip().lower(), "")


# Sağ talimat sütununun BAŞINDAKİ zaman/periyot öneki. Sol dozaj ızgarası bu
# bilgiyi (SABAH/ÖĞLEN/AKŞAM/GECE veya GÜNDE N) zaten gösterdiği için, sağda
# tekrar yazmak gereksiz ve uzun ("GECE" sığmıyor) — bu önek ayıklanır.
_SCHEDULE_PREFIX_RE = re.compile(
    r"^(?:"
    r"(?:SABAH|ÖĞLE|ÖĞLEN|AKŞAM|GECE|YATMADAN|ÖNCE)"
    r"(?:[\s\-]+(?:SABAH|ÖĞLE|ÖĞLEN|AKŞAM|GECE|YATMADAN|ÖNCE))*"
    r"|GÜNDE\s+\d+\s+DEFA"
    r"|\d+\s+SAATTE\s+BİR"
    r")"
    r"(?:\s*\[[^\]]*\])?\s*",
    re.IGNORECASE,
)


def _strip_schedule_prefix(text: str) -> str:
    """Talimat cümlesinin başındaki zaman/periyot önekini (SABAH-ÖĞLE-AKŞAM-GECE
    YATMADAN / GÜNDE 3 DEFA / 8 SAATTE BİR + opsiyonel '[...]') kaldırır.
    Sol ızgara bu bilgiyi gösterdiğinde sağda tekrarı önlemek için kullanılır."""
    return _SCHEDULE_PREFIX_RE.sub("", text or "", count=1).strip()


def _build_talimat_fallback(label: UsageLabel, ilac_adi: str) -> str:
    """UsageLabel.kullanim_talimati boşsa otomatik üret."""
    from .drug_guess import build_kullanim_talimati
    return build_kullanim_talimati(
        drug_name=ilac_adi,
        gunluk_kez=label.gunluk_kez,
        saat_arasi=label.saat_arasi,
        kullanim_zamani=label.kullanim_zamani,
        yemek=label.yemek,
        doz_str=label.doz,
        kullanim_sekli=label.kullanim_sekli,
    )


# ---------------------------------------------------------------------------
# Tip 1 — Kullanım etiketi (dozaj matrisli tasarım)
# ---------------------------------------------------------------------------
# Sol dozaj sütunu ile sağ talimat sütununu ayıran dikey çizgi
_DIV_X = 172


def render_usage_label(
    *,
    hasta_adi: str,
    ilac_adi: str,
    label: UsageLabel,
    recete_tarihi: Optional[date] = None,
    bitis_tarihi: Optional[date] = None,
    eczane_adi: str = "",
    eczane_telefon: str = "",
    kutu_adet: Optional[int] = None,
) -> Image.Image:
    """Etiket 1 — dozaj matrisli yeni tasarım."""
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)

    # Üst güvenli pay: yazıcının ilk etikette ~4-5 mm yukarı kayması nedeniyle
    # içerik en tepeden değil biraz aşağıdan başlasın (hasta adı/kategori kaybolmasın).
    top_y = _sv(8)

    # --- Üst satır: önce kategori kutusu (sağ), sonra hasta adı (sol) ona göre sığar ---
    kategori = (label.kategori or label.ilac_turu or "").strip().upper()
    cat_h = _sv(22)
    cat_y0, cat_y1 = top_y, top_y + cat_h
    cat_x0 = LABEL_W - PAD_X
    if kategori:
        # İlaç çeşidi (AĞRI KESİCİ / ANTİBİYOTİK ...) — puntosu büyütüldü
        f_cat = _fit_font(d, kategori, 270, 17, bold=True, min_size=9)
        cw = min(_text_w(d, kategori, f_cat) + 16, 280)
        cx1 = LABEL_W - PAD_X
        cx0 = cx1 - cw
        cat_x0 = cx0
        _bordered_box(d, cx0, cat_y0, cx1, cat_y1, kategori, 17, bold=True, min_size=9)

    # Hasta adı — puntosu küçültüldü; kategori kutusuna kadarki alana sığdırılır
    pat_max = max(120, cat_x0 - PAD_X - 8)
    f_pat = _fit_font(d, hasta_adi.upper(), pat_max, 12, bold=True, min_size=8)
    try:
        _pb = f_pat.getbbox(hasta_adi.upper())
    except Exception:
        _pb = (0, 0, 0, f_pat.size)
    _pth = (_pb[3] - _pb[1]) or f_pat.size
    _pty = cat_y0 + (cat_h - _pth) // 2 - _pb[1]
    d.text((PAD_X, _pty), hasta_adi.upper(), font=f_pat, fill="black")

    # Ayırıcı
    sep1_y = cat_y1 + _sv(4)
    d.line([(PAD_X, sep1_y), (LABEL_W - PAD_X, sep1_y)], fill="black", width=1)

    # --- İlaç adı bandı (çerçeveli; kutu adedi varsa sağ uçta dolu kare) ---
    band_y0 = sep1_y + _sv(4)
    band_h = _sv(22)
    band_y1 = band_y0 + band_h
    drug_text = _truncate(ilac_adi.upper(), 46)

    # Kutu adedi karesi: bant yüksekliği kadar kare, sağ kenara yapışık
    _kt_box_w = 0
    if kutu_adet and kutu_adet >= 1:
        _kt = str(kutu_adet)
        f_kt = _font(14, bold=True)
        kt_w = _text_w(d, _kt, f_kt)
        _kt_box_w = max(band_h, kt_w + _sv(8))  # en az kare
        kbx0 = LABEL_W - PAD_X - _kt_box_w
        d.rectangle([kbx0, band_y0, LABEL_W - PAD_X, band_y1], fill="#333333")
        try:
            _kbb = f_kt.getbbox(_kt)
        except Exception:
            _kbb = (0, 0, kt_w, f_kt.size)
        _kth = (_kbb[3] - _kbb[1]) or f_kt.size
        _kty = band_y0 + (band_h - _kth) // 2 - _kbb[1]
        d.text((kbx0 + (_kt_box_w - kt_w) // 2, _kty), _kt, font=f_kt, fill="white")

    # Bant çerçevesi: kutu karesi varsa sağ kenarı onun solunda biter
    band_x1 = LABEL_W - PAD_X - _kt_box_w
    d.rectangle([PAD_X, band_y0, band_x1, band_y1], outline="black", width=2)
    drug_inner_w = band_x1 - PAD_X - 20
    f_drug = _fit_font(d, drug_text, drug_inner_w, 14, bold=True, min_size=8)
    try:
        _bb = f_drug.getbbox(drug_text)
    except Exception:
        _bb = (0, 0, 0, f_drug.size)
    _dth = (_bb[3] - _bb[1]) or f_drug.size
    _dty = band_y0 + (band_h - _dth) // 2 - _bb[1]
    d.text((PAD_X + 10, _dty), drug_text, font=f_drug, fill="black")

    # Reçete/bitiş tarihi etiketten kaldırıldı (istenmedi).
    grid_top = band_y1 + _sv(4)

    # --- Doktor notu şeridi (footer'ın üstü) ---
    # Reçetede ilaca düşülmüş doktor notu varsa etiketin en altına, footer
    # çizgisinin hemen üstüne tam-genişlik bir şerit olarak basılır. Sütun alt
    # sınırı (col_bottom) bu şerit kadar yukarı çekilir ki ızgara/rozetlerle
    # çakışmasın. En çok 2 satır; taşarsa "…" ile kırpılır.
    f_drnot = _font(10, bold=True)
    drnot_lines: list[str] = []
    drnot_reserve = 0
    _drnot = (label.doktor_notu or "").strip()
    if _drnot:
        _all = _wrap(("DR. NOTU: " + _drnot).upper(), f_drnot, LABEL_W - 2 * PAD_X, d)
        if len(_all) > 2:
            drnot_lines = _all[:2]
            drnot_lines[-1] = drnot_lines[-1].rstrip() + "…"
        else:
            drnot_lines = _all
        drnot_reserve = _sv(4) + len(drnot_lines) * _sv(12)

    # --- Orta bölüm: sol dozaj ızgarası | sağ talimat ---
    col_bottom = LABEL_H - 28 - drnot_reserve
    d.line([(_DIV_X, grid_top), (_DIV_X, col_bottom)], fill="black", width=1)

    # SOL: dozaj ızgarası
    rows, grid_note, grid_freetext = _derive_grid(label, ilac_adi)
    gy = grid_top + 6
    row_h = _sv(26)
    left_x = PAD_X + 2
    dose_x_right = _DIV_X - 14
    avail = dose_x_right - left_x
    col_cx = (PAD_X + _DIV_X) // 2          # sol sütun yatay ortası
    col_w = _DIV_X - PAD_X - 8              # ortalı metin için kullanılabilir genişlik

    # Öğün/saklama rozetleri sol sütunun ALTINA sabitlenir. Izgara metni bu
    # rozetlerin üstünde kalmalı; bu yüzden rozet alanını ÖNCEDEN hesaplayıp
    # ızgaranın alt sınırını (grid_bottom) ona göre belirliyoruz (çakışma yok).
    meal = _derive_meal(label)
    saklama_b = (label.saklama_badge or "").strip().upper()
    # Saklama rozeti SAĞ sütuna taşındı; sol sütunda yalnız öğün rozeti yer kaplar.
    reserved = 0
    if meal:
        reserved += _sv(26)
    if reserved:
        reserved += _sv(6)                  # ızgara ile rozet arası nefes payı
    grid_bottom = col_bottom - 2 - reserved

    # Izgaranın kullanabileceği toplam dikey alan (rozetlerin üstü).
    avail_h = max(grid_bottom - gy, _sv(20))

    if grid_freetext:
        # Günde 1 / zaman yok → ortalı çok satırlı metin. Her satıra düşen dikey
        # "slot" = avail_h / satır sayısı. Punto, hem genişliğe (col_w) hem de bu
        # slot'a sığacak en büyük değer seçilir → blok asla rozet alanına taşmaz
        # (n * slot ≤ avail_h garantili). Sıkışıksa sistem puntoyu küçültür.
        n = max(len(grid_freetext), 1)
        slot = avail_h // n
        # Son satır "X SAAT ARAYLA / SAAT BAŞI" ise ana satırlardan ayrı punto.
        _last = grid_freetext[-1] if grid_freetext else ""
        _is_ara = len(grid_freetext) > 1 and ("SAAT" in _last or _last == "SAAT BAŞI")
        main_lines = grid_freetext[:-1] if _is_ara else grid_freetext
        size = 34
        while size > 6:
            ft = _font(size, bold=True)
            widest = max((_text_w(d, ln, ft) for ln in main_lines), default=0)
            if widest <= col_w and ft.size <= slot:
                break
            size -= 1
        ft = _font(size, bold=True)
        # Ara satırı için: col_w'ye sığan en büyük punto (ana puntoya kadar).
        if _is_ara:
            ara_size = size
            while ara_size > 6:
                ft_ara = _font(ara_size, bold=True)
                if _text_w(d, _last, ft_ara) <= col_w and ft_ara.size <= slot:
                    break
                ara_size -= 1
            ft_ara = _font(ara_size, bold=True)
        for i, ln in enumerate(grid_freetext):
            cur_ft = (ft_ara if (_is_ara and i == len(grid_freetext) - 1) else ft)
            lw = _text_w(d, ln, cur_ft)
            ty = gy + i * slot + max(0, (slot - cur_ft.size) // 2)
            d.text((col_cx - lw // 2, ty), ln, font=cur_ft, fill="black")
    else:
        # Çoklu zaman satırları (günde 2/3/4) — ORTALI, gruplu tasarım:
        #   "SABAH 1"  (zaman + sayı, büyük punto, ORTALI)
        #   "ÖLÇEK"    (birim varsa altına, biraz küçük, ORTALI)
        # Zaman ile sayı arasındaki büyük boşluk ve sağda asılı birim kaldırıldı;
        # blok dengeli ve büyük görünür. Birimsiz tablet → tek satır "SABAH 1".
        parsed = []   # (tlabel, sayi, birim)
        for (tlabel, dose) in rows[:4]:
            dose = (dose or "").strip()
            parts = dose.split(None, 1)
            if len(parts) == 2 and not parts[1][:1].isdigit():
                parsed.append((tlabel, parts[0], parts[1]))   # ("SABAH","1","ÖLÇEK")
            else:
                parsed.append((tlabel, dose, ""))             # ("SABAH","1","")
        stacked_lines = sum(2 if u else 1 for (_t2, _n, u) in parsed) or 1

        # Yığın düzen (birim alt satırda) ≤6 satıra sığıyorsa kullan; SIĞMIYORSA
        # (örn. günde 4 + birim = 8 satır) SADELEŞTİR: her zaman tek satırda
        # "SABAH 1 ÖLÇEK", punto küçültülerek 4 satıra sığdırılır.
        compact = stacked_lines > 6
        if compact:
            n = max(len(parsed), 1)
            line_h = max(_sv(12), min(_sv(24), avail_h // n))
            lines = [f"{tl} {sa} {bi}".strip() for (tl, sa, bi) in parsed]
            size = 16
            while size > 8:
                ft = _font(size, bold=True)
                widest = max((_text_w(d, ln, ft) for ln in lines), default=0)
                if widest <= col_w and ft.size <= line_h - _sv(1):
                    break
                size -= 1
            ft = _font(size, bold=True)
            for ln in lines:
                if gy + line_h > grid_bottom + _sv(3):
                    break
                w = _text_w(d, ln, ft)
                d.text((col_cx - w // 2, gy), ln, font=ft, fill="black")
                gy += line_h
        else:
            line_h = max(_sv(14), min(_sv(26), avail_h // stacked_lines))
            # Tek punto: en geniş "ZAMAN SAYI" col_w'ye + satır yüksekliğine sığsın.
            size = 20
            while size > 10:
                ft = _font(size, bold=True)
                widest = max(
                    (_text_w(d, f"{tl} {sa}", ft) for (tl, sa, _b) in parsed),
                    default=0,
                )
                if widest <= col_w and ft.size <= line_h - _sv(2):
                    break
                size -= 1
            ft = _font(size, bold=True)
            ft_b = _font(max(10, size - 3), bold=True)   # birim biraz küçük
            for (tlabel, sayi, birim) in parsed:
                need = 2 if birim else 1
                if gy + need * line_h > grid_bottom + _sv(3):
                    break
                line1 = f"{tlabel} {sayi}"
                w1 = _text_w(d, line1, ft)
                d.text((col_cx - w1 // 2, gy), line1, font=ft, fill="black")
                gy += line_h
                if birim:
                    bw = _text_w(d, birim, ft_b)
                    d.text((col_cx - bw // 2, gy), birim, font=ft_b, fill="black")
                    gy += line_h
        # NOT: "(X SAAT ARA İLE)" notu sol sütunda rozetlerle çakışmaması için
        # SAĞ talimat sütununa taşındı (aşağıda çiziliyor).

    # Öğün rozeti (AÇ/TOK/YEMEKTEN ÖNCE...) — sol sütun altına. Saklama rozeti SAĞ
    # sütuna taşındığı için burada yalnız öğün rozeti çizilir.
    bx0 = PAD_X + 6
    bx1 = _DIV_X - 14
    badge_bottom = col_bottom - 2
    # Öğün rozeti sağa uzayabildiği için sağ sütunun alt sınırını kısıtlayabilir.
    right_col_bottom = col_bottom
    if meal:
        my1 = badge_bottom
        my0 = my1 - _sv(26)
        # Rozet sol sütun genişliğinde başlar. Metin bu genişliğe okunaklı puntoyla
        # sığmıyorsa, fontu küçültmek yerine kutu SAĞA doğru uzar (en çok etiketin
        # sağ kenarına kadar). Böylece "YEMEKTEN SONRA" gibi uzun metin okunaklı kalır.
        meal_size = 17
        f_meal = _font(meal_size, bold=True)
        needed_w = _text_w(d, meal, f_meal) + _sv(12)
        mx1 = min(bx0 + max(bx1 - bx0, needed_w), LABEL_W - PAD_X)
        _inv_box(d, bx0, my0, mx1, my1, meal, meal_size, bold=True)
        # Rozet dikey ayırıcıyı aşıp sağ sütuna taştıysa, sağ sütun metni rozetin
        # üstüne binmesin diye sağ sütunun alt sınırını yukarı çek.
        if mx1 > _DIV_X:
            right_col_bottom = min(right_col_bottom, my0 - _sv(4))

    # Saklama rozeti SAĞ sütunun en altına çizilecek (aşağıda). Uzun ibareler
    # (insülin: "BUZDOLABININ ORTA RAFINDA SAKLAYINIZ") 2 satıra sarıldığı için
    # kutu yüksekliğini gerektiğinde büyütüyoruz. Sağ sütun metni bu rozetin
    # üstüne taşmasın diye metin alt sınırını yukarı çekiyoruz.
    saklama_y1 = right_col_bottom - 2
    saklama_box_h = 0
    if saklama_b:
        _sbw = (LABEL_W - PAD_X) - (_DIV_X + 8) - 10
        _slines = _wrap(saklama_b, _font(12, bold=True), _sbw, d)
        saklama_box_h = _sv(24) if len(_slines) <= 1 else _sv(42)
        right_col_bottom = saklama_y1 - saklama_box_h - _sv(4)

    # SAĞ: talimat + teknik + uyarı
    rx = _DIV_X + 12
    rmax = LABEL_W - PAD_X - rx
    ry = grid_top + 6

    talimat = (label.talimat_satiri or "").strip()
    if not talimat:
        # Geriye dönük: eski tek-cümle talimatı (varsa) / fallback
        talimat = (label.kullanim_talimati or "").strip() or _build_talimat_fallback(label, ilac_adi)
    # Sol dozaj ızgarası zaman/periyodu (SABAH/ÖĞLEN/AKŞAM/GECE veya GÜNDE N)
    # zaten gösteriyorsa, sağdaki talimatın başındaki AYNI zaman önekini ayıkla
    # (tekrar + 'GECE' taşması önlenir). Yalnız ACTION kalır: "2 MİLİLİTRE ... YUTULUR".
    if rows or grid_freetext:
        talimat = _strip_schedule_prefix(talimat) or talimat
    f_inst = _font(15, bold=True)
    inst_lines = _wrap(talimat.upper(), f_inst, rmax, d)
    # Uzun talimat (örn. insülin "KARIN, BACAK VE GÖBEK ÇEVRESİNE UYGULAYINIZ")
    # 3+ satıra taşarsa fontu kısarak 2 satıra sığdır → öneri/saklama satırlarına yer kalsın.
    if len(inst_lines) > 2:
        for sz in (14, 13, 12, 11):
            f_try = _font(sz, bold=True)
            if len(_wrap(talimat.upper(), f_try, rmax, d)) <= 2:
                f_inst, inst_lines = f_try, _wrap(talimat.upper(), f_try, rmax, d)
                break
    for ln in inst_lines[:4]:
        d.text((rx, ry), ln, font=f_inst, fill="black")
        ry += _sv(19)

    # --- Kritik güvenlik rozeti (TERS RENK) — sağ sütun, ana talimatın altında ---
    # Etiketteki en yüksek görsel ağırlık: alkol / kan sulandırıcı / greyfurt gibi
    # "kesinlikle dikkat" uyarıları. Talimattan hemen sonra çizilir ki ikincil
    # satırlardan (öneri/teknik/uyarı) önce yer kapsın ve göze ilk çarpsın.
    kritik = (label.kritik_rozet or "").strip().upper()
    if kritik and ry < right_col_bottom - _sv(20):
        ry += _sv(3)
        kb_y1 = ry + _sv(20)
        _inv_box(d, rx, ry, LABEL_W - PAD_X, kb_y1, kritik, 15, bold=True)
        ry = kb_y1 + _sv(4)

    # "(X SAAT ARA İLE)" notu — sağ sütunda, talimatın hemen altında (sol sütundan taşındı).
    # Alttaki saklama çerçevesi bottom-anchored olduğundan sınır kontrolü ŞART:
    # sütun sıkışıksa not çerçevenin üstüne biner (NOVORAPID vakası). Dar alanda
    # önce ara boşluk feda edilir; punto payı da yoksa not çizilmez (ızgara
    # SABAH/AKŞAM zaten aralığı gösteriyor).
    oneri = (label.oneri_satiri or "").strip()

    def _oneri_fits(start_y: int, n_lines: int) -> bool:
        return (start_y + _sv(3) + (n_lines - 1) * _sv(13)
                <= right_col_bottom - _sv(14))

    # Öneri metni için desteklenen her punto boyutunu dener; en küçüğünde bile
    # sığıyorsa (font, satırlar, satır-aralığı) üçlüsünü döndürür.
    _ONERI_SIZES = ((11, 13), (10, 12), (9, 11))

    def _best_oneri_fit(start_y: int):
        """Verilen y'den itibaren oneri metnini sığdırabilen en büyük (font, lines, lh)
        üçlüsünü döndürür; hiçbiri sığmazsa None."""
        for sz, lh_s in _ONERI_SIZES:
            f_s = _font(sz, bold=True)
            ls = _wrap(oneri.upper(), f_s, rmax, d)[:3]
            if ls and start_y + _sv(3) + (len(ls) - 1) * _sv(lh_s) <= right_col_bottom - _sv(14):
                return f_s, ls, lh_s
        return None

    if grid_note:
        f_note = _fit_font(d, grid_note, rmax, 12, bold=True, min_size=8)
        # Öneri satırı kritik olabilir (G04BE "KALP İLACI ... KULLANMAYIN",
        # G03AD "İLİŞKİDEN SONRA EN KISA SÜREDE" vb.); not basılınca öneri
        # sığmıyorsa ama not atılınca sığıyorsa (herhangi bir puntoda) not
        # feda edilir — saat aralığını sol ızgara (SABAH/AKŞAM) zaten gösteriyor.
        _note_h = _sv(3) + _sv(18)
        _oneri_with_note    = oneri and bool(_best_oneri_fit(ry + _note_h))
        _oneri_without_note = oneri and bool(_best_oneri_fit(ry))
        if oneri and not _oneri_with_note and _oneri_without_note:
            pass  # notu basma — öneri öncelikli
        elif ry + _sv(3) + f_note.size <= right_col_bottom:
            ry += _sv(3)
            d.text((rx, ry), grid_note, font=f_note, fill="black")
            ry += _sv(18)
        elif ry + f_note.size <= right_col_bottom:
            d.text((rx, ry), grid_note, font=f_note, fill="black")
            ry += _sv(15)

    # Kullanım zamanı önerisi (örn. statin → "TERCİHEN AKŞAM KULLANINIZ") —
    # "...YUTUNUZ" talimatının hemen altında, teknik nottan önce.
    # Yer yoksa küçük puntoda dener; o da sığmazsa basılmaz.
    if oneri:
        _fit = _best_oneri_fit(ry)
        if _fit:
            f_on, lines, lh = _fit
            ry += _sv(3)
            for ln in lines:
                if ry > right_col_bottom - _sv(14):
                    break
                d.text((rx, ry), ln, font=f_on, fill="black")
                ry += _sv(lh)

    teknik = (label.teknik_satiri or "").strip()
    if teknik and ry < right_col_bottom - 14:
        ry += 4
        d.line([(rx, ry), (LABEL_W - PAD_X, ry)], fill="black", width=1)
        ry += 4
        f_tk = _font(12, bold=True)
        for ln in _wrap(teknik.upper(), f_tk, rmax, d)[:3]:
            if ry > right_col_bottom - _sv(15):
                break
            d.text((rx, ry), ln, font=f_tk, fill="black")
            ry += _sv(15)

    uyari = (label.uyari_metni or "").strip()
    if uyari and ry < right_col_bottom - 14:
        ry += 3
        f_w = _font(10)
        for ln in _wrap("UYARI: " + uyari, f_w, rmax, d)[:3]:
            if ry > right_col_bottom - 12:
                break
            d.text((rx, ry), ln, font=f_w, fill="black")
            ry += _sv(12)

    # --- Saklama rozeti — SAĞ sütunun altı (sol sütundan taşındı) ---
    if saklama_b:
        sx0 = _DIV_X + 8
        sx1 = LABEL_W - PAD_X
        _bordered_box_wrap(
            d, sx0, saklama_y1 - saklama_box_h, sx1, saklama_y1,
            saklama_b, 12, bold=True, max_lines=2,
        )

    # --- Doktor notu — footer çizgisinin hemen üstünde, tam genişlik ---
    if drnot_lines:
        footer_line_y = LABEL_H - 24
        ny = footer_line_y - drnot_reserve + _sv(2)
        d.line([(PAD_X, ny - _sv(2)), (LABEL_W - PAD_X, ny - _sv(2))],
               fill="black", width=1)
        for ln in drnot_lines:
            d.text((PAD_X, ny), ln, font=f_drnot, fill="black")
            ny += _sv(12)

    _draw_footer(d, eczane_adi, eczane_telefon)
    return img


# ---------------------------------------------------------------------------
# Tip 2 — Hazırlama etiketi
# ---------------------------------------------------------------------------
def render_preparation_label(
    *,
    hasta_adi: str,
    ilac_adi: str,
    label: PreparationLabel,
    eczane_adi: str = "",
    eczane_telefon: str = "",
    title_override: str = "",
) -> Image.Image:
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)

    f_top    = _font(15, bold=True)
    f_title  = _font(16, bold=True)
    f_step   = _font(13)
    f_meta   = _font(12, bold=True)

    # Üst: hasta (solda, genişliğe sığdırılır) · ilaç (sağda, kalan alana)
    _draw_header_two(d, hasta_adi, ilac_adi, 15)

    # Başlık (override veya sade "HAZIRLANIŞI")
    title = title_override or "HAZIRLANIŞI"
    d.text((PAD_X, PAD_Y + _sv(24)), title, font=f_title, fill=FG)

    # Ayırıcı
    sep_y = PAD_Y + _sv(46)
    d.line([(PAD_X, sep_y), (LABEL_W - PAD_X, sep_y)], fill=FG, width=1)

    # Adımlar
    y = sep_y + 6
    for i, adim in enumerate(label.adimlar[:4], 1):
        prefix = f"{i}. "
        lines = _wrap(prefix + adim, f_step, LABEL_W - 2 * PAD_X, d)
        for ln in lines:
            d.text((PAD_X, y), ln, font=f_step, fill=FG)
            y += _sv(15)
            if y > LABEL_H - 80:
                break
        if y > LABEL_H - 80:
            break

    # Meta: saklama + geçerlilik
    meta_parts = []
    if label.saklama:
        meta_parts.append(label.saklama)
    if label.acildiktan_sonra_gecerlilik:
        meta_parts.append(f"Açıldıktan sonra {label.acildiktan_sonra_gecerlilik}")
    if meta_parts:
        meta = " · ".join(meta_parts)
        lines = _wrap(meta, f_meta, LABEL_W - 2 * PAD_X, d)
        my = LABEL_H - 60 - _sv(16) * len(lines)
        for ln in lines:
            w = _text_w(d, ln, f_meta)
            d.text(((LABEL_W - w) // 2, my), ln, font=f_meta, fill=FG)
            my += _sv(15)

    _draw_footer(d, eczane_adi, eczane_telefon)
    return img


# ---------------------------------------------------------------------------
# Hasta bilgi etiketi — tarih / ad-soyad / telefon / ödeme / reçete toplamı
# ---------------------------------------------------------------------------
def render_patient_label(
    *,
    hasta_adi: str,
    tarih: str = "",
    telefon: str = "",
    recete_tutari: str = "",
    recete_paid: bool = False,
    toplam_borc: str = "",
    recete_no: str = "",
    show_debt: bool = True,
    eczane_adi: str = "",
    eczane_telefon: str = "",
) -> Image.Image:
    """Hasta bilgi etiketi — bilgi hiyerarşisine göre tasarlanmış sade düzen.

    Tasarım ilkesi: en kritik bilgi en büyük. Eczane personeli bir yığın poşeti
    tararken önce HASTA ADINI eşler → ad en büyük (kimlik). TELEFON (aranır) ve
    REÇETE TUTARI (tahsil edilir) ikincil-aksiyon → büyük; reçete tutarı PARA
    olduğu için çerçeveli kutuda vurgulanır. TARİH küçük referans (üst köşe).
    TOPLAM BORÇ ikincil mali bilgi → küçük (show_debt=False ise hiç basılmaz).

        ┌────────────────────────────────────┐
        │ 22.06.2026                         │  küçük tarih + ayraç
        │ ────────────────────────────────── │
        │           EMRE GÖKMEN              │  AD — en büyük (kimlik)
        │              TELEFON               │  küçük başlık
        │          0507 947 74 23           │  telefon — büyük
        │ ┌────────────────────────────────┐ │
        │ │ REÇETE TUTARI       120,97 TL  │ │  para — çerçeveli vurgu
        │ └────────────────────────────────┘ │
        │ TOPLAM BORÇ            3.025,96 TL │  ikincil — küçük
        │        İKİZLER ECZANESİ / TEL       │  alt bilgi
        └────────────────────────────────────┘

    Boş alanlar atlanır; içerik dikey alana sığacak şekilde otomatik ölçeklenir.
    """
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)
    avail_w = LABEL_W - 2 * PAD_X

    def _amt(v: str) -> str:
        v = (v or "").strip()
        return f"{v} TL" if v else ""

    # --- Üst: tarih (küçük) + ince ayraç ----------------------------------
    y_top = PAD_Y
    if tarih:
        f_date = _font(12, bold=True)
        d.text((PAD_X, y_top), tarih.strip(), font=f_date, fill=FG)
        rule_y = y_top + f_date.size + _sv(3)
    else:
        rule_y = y_top
    d.line([(PAD_X, rule_y), (LABEL_W - PAD_X, rule_y)], fill=FG, width=1)

    content_top = rule_y + _sv(5)
    content_bottom = (LABEL_H - 24) - _sv(4)        # alt bilgi çizgisinin üstü
    avail_h = content_bottom - content_top

    # --- İçerik blokları (önem ağırlığına göre) ---------------------------
    # base = ÖLÇEKSİZ değer-puntosu (büyük = önemli). _font/_fit_font FONT_SCALE uygular.
    blocks: list[dict] = []
    if hasta_adi:
        blocks.append({"t": "hero", "val": hasta_adi.strip(), "base": 30, "min": 14})
    if telefon:
        blocks.append({"t": "capbig", "cap": "TELEFON", "val": telefon.strip(),
                       "base": 25, "min": 13})
    # REÇETE TUTARI: ödenmişse tutar yerine 'ÖDENMİŞ' yazılır
    if recete_paid or recete_tutari:
        _rt_val = "ÖDENMİŞ" if recete_paid else _amt(recete_tutari)
        blocks.append({"t": "box", "cap": "REÇETE TUTARI", "val": _rt_val,
                       "base": 23, "min": 12})
    if show_debt and toplam_borc:
        blocks.append({"t": "small", "cap": "TOPLAM BORÇ", "val": _amt(toplam_borc),
                       "base": 13, "min": 10})

    def _bh(b: dict, scale: float) -> int:
        vs = max(8, int(b["base"] * scale))
        if b["t"] == "hero":
            return _font(vs, bold=True).size + _sv(5)
        if b["t"] == "capbig":
            return _font(9).size + _sv(1) + _font(vs, bold=True).size + _sv(5)
        if b["t"] == "box":
            return _font(vs, bold=True).size + _sv(18)     # çerçeve + iç boşluk
        return _font(vs, bold=True).size + _sv(4)          # small

    # İçeriği dikey alana sığdıran en büyük ölçeği seç
    scale = 1.0
    while scale > 0.55 and sum(_bh(b, scale) for b in blocks) > avail_h:
        scale -= 0.05
    heights = [_bh(b, scale) for b in blocks]

    # Bloklar arası eşit boşlukla dikeyde yay (tek blok bile olsa ortalı görünür)
    n = max(1, len(blocks))
    gap = max(_sv(3), (avail_h - sum(heights)) // (n + 1))
    y = content_top + max(0, (avail_h - sum(heights) - gap * (n - 1)) // 2)

    def _center(text, f, yy):
        w = _text_w(d, text, f)
        d.text(((LABEL_W - w) // 2, yy), text, font=f, fill=FG)

    for b, h in zip(blocks, heights):
        vs = max(8, int(b["base"] * scale))
        if b["t"] == "hero":
            f = _fit_font(d, b["val"], avail_w, vs, bold=True, min_size=b["min"])
            _center(b["val"], f, y)
        elif b["t"] == "capbig":
            fc = _font(9, bold=True)
            _center(b["cap"], fc, y)
            f = _fit_font(d, b["val"], avail_w, vs, bold=True, min_size=b["min"])
            _center(b["val"], f, y + fc.size + _sv(1))
        elif b["t"] == "box":
            y0, y1 = y, y + h - _sv(4)
            d.rectangle([PAD_X, y0, LABEL_W - PAD_X, y1], outline="black", width=3)
            fc = _font(11, bold=True)
            cap_y = y0 + ((y1 - y0) - fc.size) // 2
            d.text((PAD_X + _sv(8), cap_y), b["cap"], font=fc, fill=FG)
            cap_w = _text_w(d, b["cap"], fc)
            val_max = (LABEL_W - PAD_X) - (PAD_X + _sv(8) + cap_w + _sv(10))
            f = _fit_font(d, b["val"], val_max, vs, bold=True, min_size=b["min"])
            vw = _text_w(d, b["val"], f)
            val_y = y0 + ((y1 - y0) - f.size) // 2
            d.text(((LABEL_W - PAD_X) - _sv(8) - vw, val_y), b["val"], font=f, fill=FG)
        else:  # small — "BAŞLIK            değer" (iki yana yaslı)
            f = _font(max(8, int(b["base"] * scale)), bold=True)
            d.text((PAD_X, y), b["cap"], font=f, fill=FG)
            vw = _text_w(d, b["val"], f)
            d.text(((LABEL_W - PAD_X) - vw, y), b["val"], font=f, fill=FG)
        y += h + gap

    _draw_footer(d, eczane_adi, eczane_telefon)
    return img


# ---------------------------------------------------------------------------
# Emanet etiketi — "BU İLAÇ SİZE EMANET VERİLMİŞTİR" + yazdırma tarihi (vurgulu)
# ---------------------------------------------------------------------------
def render_emanet_label(
    *,
    yazdirma_tarihi: str | date,
    hasta_adi: str = "",
    ilac_adi: str = "",
    show_hasta_adi: bool = True,
    show_ilac_adi: bool = True,
    eczane_adi: str = "",
    eczane_telefon: str = "",
) -> Image.Image:
    """'EMANET İLAÇ' etiketi: ilacın hangi tarihte yazdırılması gerektiğini gösterir.

    'EMANET İLAÇ' başlığı ve yazdırma tarihi AYNI (en büyük) puntoda; araya küçük
    'İlacın yazdırılması gereken tarih' açıklaması girer. Açık/beyaz ağırlıklı
    (siyah dolgu yok). Tarih Türkçe ay adıyla yazılır: '22 HAZİRAN 2026 PAZARTESİ'.

    Yerleşim:
      ┌─────────────────────────────────────┐
      │          Sayın EMRE GÖKMEN          │  ← hasta adı (orta)
      │ Bu ilaç size yazdırılmak üzere borç…│  ← borç açıklaması (küçük)
      │           EMANET İLAÇ                │  ← EN BÜYÜK punto
      │   İlacın yazdırılması gereken tarih  │  ← küçük açıklama
      │         22 HAZİRAN 2026             │  ← aynı EN BÜYÜK punto
      │            PAZARTESİ                │
      │      İKİZLER ECZANESİ / TEL          │
      └─────────────────────────────────────┘

    `hasta_adi` verilirse "Sayın <ad>" satırı, `ilac_adi` verilirse ayraç altında
    ilaç adı satırı çıkar. `yazdirma_tarihi` date ise uzun Türkçe biçime çevrilir.
    """
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)

    # Tarihi uzun Türkçe biçime getir ve gün adını ayır (alt satıra)
    if isinstance(yazdirma_tarihi, date):
        tarih_txt = _format_date_tr_long(yazdirma_tarihi)
    else:
        tarih_txt = (yazdirma_tarihi or "").strip().upper()
    parts = tarih_txt.split()
    if parts and parts[-1] in _TR_GUNLER:
        gun_adi = parts[-1]
        tarih_satiri = " ".join(parts[:-1])
    else:
        gun_adi = ""
        tarih_satiri = tarih_txt

    title = "EMANET İLAÇ"
    aciklama = "İLACIN YAZDIRILMASI GEREKEN TARİH"
    name_line = (f"Sayın {hasta_adi.strip()}"
                 if (show_hasta_adi and (hasta_adi or "").strip()) else "")
    ilac_line = (ilac_adi or "").strip() if show_ilac_adi else ""
    date_full = tarih_txt              # tek satır: "29 TEMMUZ 2026 PAZARTESİ"

    # --- Zarif çift köşeli çerçeve ---
    try:
        d.rounded_rectangle([5, 5, LABEL_W - 6, LABEL_H - 6], radius=16, outline="black", width=3)
        d.rounded_rectangle([11, 11, LABEL_W - 12, LABEL_H - 12], radius=11, outline="black", width=1)
    except Exception:
        d.rectangle([5, 5, LABEL_W - 6, LABEL_H - 6], outline="black", width=3)
        d.rectangle([11, 11, LABEL_W - 12, LABEL_H - 12], outline="black", width=1)

    M = _sv(16)
    inner_w = LABEL_W - 2 * M
    content_top = _sv(12)
    BOX_PAD, GAP = _sv(8), _sv(5)
    box_x0, box_x1 = M + _sv(4), LABEL_W - M - _sv(4)
    date_inner = (box_x1 - box_x0) - _sv(14)

    # Alt bilgi (eczane · telefon) EN ALT KENARA yapışık
    foot = "  ·  ".join(p for p in (eczane_adi.strip(), (eczane_telefon or "").strip()) if p)
    foot_line_y = LABEL_H - _sv(20)
    avail_bottom = foot_line_y - _sv(4)

    # Küçük puntolu satırlar: ilaç + hasta (genişliğe sığar)
    f_ilac = _fit_font(d, ilac_line, inner_w, 11, bold=True, min_size=8) if ilac_line else None
    f_name = _fit_font(d, name_line, inner_w, 11, bold=True, min_size=8) if name_line else None
    # Başlık (caption) — hasta/ilaçtan büyük, genişliğe sığan en büyük
    f_cap = _fit_font(d, aciklama, inner_w, 16, bold=True, min_size=9)

    # EMANET İLAÇ ve TARİH (tek satır) AYNI en büyük puntoda; her şey sığsın.
    def _flow_h(fb) -> int:
        h = fb.size + GAP                                   # EMANET İLAÇ
        if f_ilac: h += f_ilac.size + GAP
        if f_name: h += f_name.size + GAP
        h += f_cap.size + GAP                               # caption
        h += fb.size + 2 * BOX_PAD                          # tarih kutusu
        return h

    base = 30
    while base > 12:
        f_big = _font(base, bold=True)
        w_ok = (_text_w(d, title, f_big) <= inner_w
                and _text_w(d, date_full, f_big) <= date_inner)
        if w_ok and content_top + _flow_h(f_big) <= avail_bottom:
            break
        base -= 1
    f_big = _font(base, bold=True)

    # Çiz — üstten (EMANET İLAÇ en tepede)
    y = content_top
    _draw_centered_line(d, y, title, f_big, "black"); y += f_big.size + GAP
    if f_ilac:
        _draw_centered_line(d, y, ilac_line, f_ilac, "black"); y += f_ilac.size + GAP
    if f_name:
        _draw_centered_line(d, y, name_line, f_name, "black"); y += f_name.size + GAP
    _draw_centered_line(d, y, aciklama, f_cap, "black"); y += f_cap.size + GAP

    # Tarih kutusu (tek satır, büyük)
    box_h = f_big.size + 2 * BOX_PAD
    try:
        d.rounded_rectangle([box_x0, y, box_x1, y + box_h], radius=10, outline="black", width=3)
    except Exception:
        d.rectangle([box_x0, y, box_x1, y + box_h], outline="black", width=3)
    _draw_centered_line(d, y + BOX_PAD, date_full, f_big, "black")

    # Alt bilgi — en alt kenara yapışık
    d.line([(M, foot_line_y), (LABEL_W - M, foot_line_y)], fill="black", width=1)
    if foot:
        f_foot = _fit_font(d, foot, inner_w, 11, bold=True, min_size=8)
        fw = _text_w(d, foot, f_foot)
        d.text(((LABEL_W - fw) // 2, foot_line_y + _sv(3)), foot, font=f_foot, fill="black")

    return img


# ---------------------------------------------------------------------------
# Emanet — ECZANE NÜSHASI (kayıt etiketi: hasta/ilaç/telefon/tarihler)
# ---------------------------------------------------------------------------
def render_emanet_pharmacy_label(
    *,
    hasta_adi: str = "",
    ilac_adi: str = "",
    telefon: str = "",
    alis_tarihi: str = "",
    yazdirma_tarihi: str | date = "",
    eczane_adi: str = "",
    eczane_telefon: str = "",
) -> Image.Image:
    """Emanet 'ECZANE NÜSHASI' — eczanede kalan kayıt etiketi.

    Hangi hasta, hangi ilacı, hangi tarihte emanet aldı (ALIŞ TARİHİ) ve hangi
    tarihte yazdırılmalı (YAZDIRMA TARİHİ) + hasta telefonu. BAŞLIK/DEĞER satır
    düzeni (hasta bilgi etiketiyle aynı stil)."""
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)

    if isinstance(yazdirma_tarihi, date):
        yaz = _format_date_tr(yazdirma_tarihi)      # 22.06.2026 PAZARTESİ
    else:
        yaz = (yazdirma_tarihi or "").strip()

    # Başlık
    title = "EMANET — ECZANE NÜSHASI"
    f_title = _fit_font(d, title, LABEL_W - 2 * PAD_X, 16, bold=True, min_size=10)
    tw = _text_w(d, title, f_title)
    d.text(((LABEL_W - tw) // 2, PAD_Y + _sv(4)), title, font=f_title, fill=FG)
    sep_y = PAD_Y + _sv(26)
    d.line([(PAD_X, sep_y), (LABEL_W - PAD_X, sep_y)], fill=FG, width=2)

    # YAZDIRMA TARİHİ en tepede (eczanenin en kritik bilgisi).
    rows: list[tuple[str, str]] = []
    if yaz:                         rows.append(("YAZDIRMA TARİHİ", yaz))
    if (hasta_adi or "").strip():   rows.append(("HASTA", hasta_adi.strip()))
    if (ilac_adi or "").strip():    rows.append(("İLAÇ", ilac_adi.strip()))
    if (telefon or "").strip():     rows.append(("TELEFON", telefon.strip()))
    if (alis_tarihi or "").strip(): rows.append(("ALIŞ TARİHİ", alis_tarihi.strip()))

    bottom = LABEL_H - 28
    y0 = sep_y + 8
    avail_h = bottom - y0
    label_w = _sv(120)              # sol "başlık" sütun genişliği

    chosen_sz = 11
    f_key = _font(11, bold=True)
    line_h = avail_h // max(1, len(rows))
    for sz in range(16, 9, -1):
        lh = _font(sz, bold=True).size + _sv(7)
        if lh * len(rows) <= avail_h:
            chosen_sz, f_key, line_h = sz, _font(sz, bold=True), lh
            break

    colon_x = PAD_X + label_w
    val_x = colon_x + _sv(10)
    y = y0 + max(0, (avail_h - line_h * len(rows)) // 2)
    for key, val in rows:
        fk = _fit_font(d, key, label_w - _sv(4), chosen_sz, bold=True, min_size=8)
        d.text((PAD_X, y), key, font=fk, fill=FG)
        d.text((colon_x, y), ":", font=f_key, fill=FG)
        fv = _fit_font(d, val, (LABEL_W - PAD_X) - val_x, chosen_sz, bold=False, min_size=8)
        d.text((val_x, y), val, font=fv, fill=FG)
        y += line_h

    _draw_footer(d, eczane_adi, eczane_telefon)
    return img


# ---------------------------------------------------------------------------
# Kutu üstü fiyat etiketi — yalnız büyük puntoyla fiyat (serbest boyut)
# ---------------------------------------------------------------------------
def render_box_price_label(
    price_text: str,
    *,
    width_mm: float = 40.0,
    height_mm: float = 25.0,
    dpi: int = 203,
    eczane_adi: str = "",
) -> Image.Image:
    """Kutu üstüne yapıştırılan KÜÇÜK fiyat etiketi.

    İçinde yalnızca büyük puntoyla ortalanmış fiyat (ör. '198,55 TL') bulunur;
    isteğe bağlı olarak üstte küçük puntoyla eczane adı çıkar. Boyut mm cinsinden
    serbesttir (varsayılan 40×25 mm) — ana ilaç etiketinden bağımsız küçük
    kutu-üstü etiket stoğu içindir. Görsel, verilen mm × dpi oranında üretildiği
    için TSPL baskıda en-boy bozulmaz.
    """
    w = max(80, round(width_mm / 25.4 * dpi))
    h = max(60, round(height_mm / 25.4 * dpi))
    img = Image.new("RGB", (w, h), BG)
    d = ImageDraw.Draw(img)
    d.rectangle([2, 2, w - 3, h - 3], outline="black", width=2)

    pad = max(6, w // 22)
    inner_w = w - 2 * pad
    price = (price_text or "").strip() or "—"

    # Üst: eczane adı (varsa, küçük punto)
    top_h = 0
    eczane = (eczane_adi or "").strip()
    if eczane:
        f_top = _fit_font(d, eczane, inner_w, max(8, h // 14), bold=True, min_size=7)
        ew = _text_w(d, eczane, f_top)
        d.text(((w - ew) // 2, pad), eczane, font=f_top, fill="black")
        top_h = f_top.size + max(4, pad // 2)

    # Fiyat: kalan alana hem genişlik hem yüksekliğe sığan en büyük punto.
    # (_font FONT_SCALE ile çarptığı için ölçeği gerçek .size üzerinden ararız.)
    region_y0 = pad + top_h
    region_y1 = h - pad
    avail_h = region_y1 - region_y0
    f_price = _font(8, bold=True)
    for base in range(8, 140):
        f = _font(base, bold=True)
        bb = f.getbbox(price)
        if (bb[2] - bb[0]) <= inner_w and (bb[3] - bb[1]) <= avail_h:
            f_price = f
        else:
            break

    bb = f_price.getbbox(price)
    tw = bb[2] - bb[0]
    th = bb[3] - bb[1]
    tx = (w - tw) // 2 - bb[0]
    ty = region_y0 + (avail_h - th) // 2 - bb[1]
    d.text((tx, ty), price, font=f_price, fill="black")
    return img


# ---------------------------------------------------------------------------
# Raf etiketi — barkod deseni + barkod no + ilaç adı + satış fiyatı
# ---------------------------------------------------------------------------
def _ean13_checksum_ok(code: str) -> bool:
    """13 haneli sayısal kodun EAN-13 sağlama hanesi doğru mu?"""
    if len(code) != 13 or not code.isdigit():
        return False
    digits = [int(c) for c in code]
    s = sum(d * (3 if i % 2 else 1) for i, d in enumerate(digits[:12]))
    check = (10 - s % 10) % 10
    return check == digits[12]


def _make_barcode_image(
    code: str, avail_w: int, height_px: int,
    *, bg: str = BG, module_px: int = 3,
) -> Optional[Image.Image]:
    """`code` için barkod görseli üretir (siyah çubuklar, `bg` zemin, metinsiz).

    13/12 haneli geçerli GTIN → EAN-13 (perakende standardı); aksi → Code128
    (her dizgiyi birebir kodlar, tarayıcı aynı numarayı geri verir).

    Çubuklar tam sayı modül genişliğinde basılır (203 DPI termalde keskin kalsın
    diye yeniden boyutlandırma yok); `avail_w`'ye sığmazsa modül genişliği
    kademeli küçültülür. python-barcode yoksa / kod geçersizse None döner.
    """
    code = (code or "").strip()
    if not code:
        return None
    try:
        from barcode import Code128, EAN13
        from barcode.writer import ImageWriter
    except Exception:
        return None

    use_ean = code.isdigit() and (
        (len(code) == 12) or (len(code) == 13 and _ean13_checksum_ok(code))
    )
    dpi = 203
    for mpx in range(module_px, 0, -1):
        try:
            writer = ImageWriter()
            opts = {
                "module_width": mpx * 25.4 / dpi,        # mpx piksellik modül
                "module_height": height_px * 25.4 / dpi,
                "quiet_zone": 1.0,
                "write_text": False,                     # numarayı kendimiz yazarız
                "dpi": dpi,
                "background": bg,
                "foreground": "black",
            }
            if use_ean:
                img = EAN13(code, writer=writer).render(opts)
            else:
                img = Code128(code, writer=writer).render(opts)
        except Exception:
            return None
        if img.width <= avail_w or mpx == 1:
            return img
    return None


# ---------------------------------------------------------------------------
# Kargo etiketleri (alıcı + gönderen)
# ---------------------------------------------------------------------------
def _kargo_slug(name: str) -> str:
    """'Yurtiçi Kargo' → 'yurtici'. Türkçe karakter katlanır, 'kargo' eki atılır."""
    s = (name or "").lower()
    s = s.translate(str.maketrans("çğıíîöşü", "cgiiosu".ljust(8, "u")))
    s = "".join(ch for ch in s if ch.isalnum())
    if s.endswith("kargo"):
        s = s[:-5]
    return s


def kargo_firma_renk(name: str) -> str | None:
    """Firma adına karşılık gelen ekran şeridi rengi (yoksa None → siyah)."""
    return KARGO_FIRMA_RENK.get(_kargo_slug(name))


def _find_kargo_logo(name: str):
    """assets/kargo_logos/<slug>.<ext> varsa Path döndürür (yoksa None)."""
    slug = _kargo_slug(name)
    if not slug:
        return None
    for ext in (".png", ".bmp", ".jpg", ".jpeg", ".gif"):
        p = KARGO_LOGO_DIR / f"{slug}{ext}"
        if p.exists():
            return p
    return None


def _luminance(hex_color: str) -> float:
    h = (hex_color or "#000000").lstrip("#")
    if len(h) != 6:
        return 0.0
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return 0.299 * r + 0.587 * g + 0.114 * b


def _load_mono_logo(path, ink: str, box_w: int, box_h: int):
    """Logo görselini tek renkli (ink) silüete çevirip (box_w×box_h) içine sığacak
    şekilde ölçekler. RGBA döndürür (boş alan saydam). Hata olursa None."""
    try:
        src = Image.open(path).convert("RGBA")
    except Exception:
        return None
    r, g, b, a = src.split()
    gray = src.convert("L")
    # "Mürekkep" pikseli: yeterince opak VE yeterince koyu (beyaz zemin elenir).
    ink_mask = Image.eval(gray, lambda v: 255 if v < 180 else 0)
    ink_mask = ImageChops.multiply(ink_mask, Image.eval(a, lambda v: 255 if v > 60 else 0))
    bbox = ink_mask.getbbox()
    if bbox:
        ink_mask = ink_mask.crop(bbox)
    iw, ih = ink_mask.size
    if iw == 0 or ih == 0:
        return None
    scale = min(box_w / iw, box_h / ih)
    nw, nh = max(1, int(iw * scale)), max(1, int(ih * scale))
    ink_mask = ink_mask.resize((nw, nh))
    solid = Image.new("RGBA", (nw, nh), ink)
    out = Image.new("RGBA", (nw, nh), (0, 0, 0, 0))
    out.paste(solid, (0, 0), ink_mask)
    return out


def _draw_kargo_strip(d, img, x0, y0, x1, y1, firma, *,
                      firma_renk=None, use_logo=True):
    """Üst kargo şeridi: dolgu (ekran=firma_renk, baskı=siyah) + beyaz/siyah logo
    veya firma adı metni. firma_renk None → siyah dolgu (baskı görünümü)."""
    bg = firma_renk or "black"
    d.rectangle([x0, y0, x1, y1], fill=bg)
    ink = "black" if (firma_renk and _luminance(firma_renk) > 150) else "white"
    pad = _sv(4)
    box_w, box_h = (x1 - x0) - 2 * pad, (y1 - y0) - 2 * pad
    if use_logo:
        logo_path = _find_kargo_logo(firma)
        if logo_path is not None:
            logo = _load_mono_logo(logo_path, ink, box_w, box_h)
            if logo is not None:
                lx = x0 + ((x1 - x0) - logo.width) // 2
                ly = y0 + ((y1 - y0) - logo.height) // 2
                img.paste(logo, (lx, ly), logo)
                return
    # Geri dönüş: firma adı metni
    txt = (firma or "").strip().upper()
    if txt:
        f = _fit_font(d, txt, box_w, 15, bold=True, min_size=9)
        _centered_text(d, x0, y0, x1, y1, txt, f, ink)


def _draw_wrapped_block(
    d: ImageDraw.ImageDraw, text: str, x: int, y: int, max_w: int,
    bottom: int, base_size: int, min_size: int = 8, line_gap: int = 2,
) -> int:
    """Metni max_w'ye sararak, [y, bottom] dikey aralığına sığacak en büyük
    fontla yazar. Yazımdan sonra ulaşılan y'yi döndürür."""
    text = (text or "").strip()
    if not text:
        return y
    size = base_size
    while size > min_size:
        f = _font(size, bold=False)
        lines = _wrap(text, f, max_w, d)
        lh = f.size + _sv(line_gap)
        if y + len(lines) * lh <= bottom:
            break
        size -= 1
    f = _font(size, bold=False)
    lines = _wrap(text, f, max_w, d)
    lh = f.size + _sv(line_gap)
    for ln in lines:
        if y + f.size > bottom:
            break
        d.text((x, y), ln, font=f, fill=FG)
        y += lh
    return y


def _draw_role_band(d, x0, y0, x1, y1, text: str):
    """ALICI / GÖNDERİCİ şeridi: çerçeveli bant + ortalanmış kalın metin.
    Kargo firmasının siyah şeridinden ayırt edilsin diye çerçeveli (dolgu yok)."""
    d.rectangle([x0, y0, x1, y1], outline="black", width=2)
    f = _fit_font(d, text, (x1 - x0) - _sv(8), 14, bold=True, min_size=9)
    _centered_text(d, x0, y0, x1, y1, text, f, "black")


def render_kargo_label(
    *,
    alici_ad: str,
    telefon: str = "",
    adres: str = "",
    kargo_firma: str = "",
    eczane_adi: str = "",
    eczane_telefon: str = "",
    firma_renk: str | None = None,
    use_logo: bool = True,
) -> Image.Image:
    """Kargo (ALICI) etiketi.

    Üstte kargo firması şeridi (logo veya ad) → ALICI ad (en büyük) → telefon →
    adres (kalan alana sığacak şekilde otomatik küçülen font + satır sarma) →
    altta GÖNDEREN eczane bilgisi (footer).

    firma_renk: yalnız EKRAN önizlemesi için şerit rengi (firmaya göre). Baskıda
    None bırakılır → şerit siyah olur (termal yazıcı yalnız siyahı basar).
    use_logo: assets/kargo_logos/<slug>.png varsa şeritte logo basılır.
    """
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)
    avail_w = LABEL_W - 2 * PAD_X
    y = PAD_Y

    # --- Üst: kargo firması şeridi (logo/renk/ad) ---
    if (kargo_firma or "").strip():
        strip_h = _sv(24)
        _draw_kargo_strip(d, img, PAD_X, y, LABEL_W - PAD_X, y + strip_h,
                          kargo_firma.strip(), firma_renk=firma_renk,
                          use_logo=use_logo)
        y += strip_h + _sv(4)

    # --- ALICI şeridi (kargo firmasının altında) ---
    band_h = _sv(18)
    _draw_role_band(d, PAD_X, y, LABEL_W - PAD_X, y + band_h, "ALICI")
    y += band_h + _sv(4)

    # --- Ad (en büyük / kimlik) ---
    if (alici_ad or "").strip():
        f = _fit_font(d, alici_ad.strip(), avail_w, 24, bold=True, min_size=13)
        d.text((PAD_X, y), alici_ad.strip(), font=f, fill=FG)
        y += f.size + _sv(4)

    # --- Telefon ---
    if (telefon or "").strip():
        txt = "TEL: " + telefon.strip()
        ftel = _fit_font(d, txt, avail_w, 16, bold=True, min_size=10)
        d.text((PAD_X, y), txt, font=ftel, fill=FG)
        y += ftel.size + _sv(4)

    # --- Adres (kalan alana sığacak şekilde) ---
    footer_top = LABEL_H - 24
    addr_bottom = footer_top - _sv(4)
    _draw_wrapped_block(d, adres, PAD_X, y, avail_w, addr_bottom,
                        base_size=14, min_size=8, line_gap=2)

    # --- Alt: GÖNDEREN eczane ---
    gonderen = ("GÖNDEREN: " + (eczane_adi or "").strip()).strip(" :")
    _draw_footer(d, gonderen, eczane_telefon)
    return img


def render_kargo_sender_label(
    *,
    eczane_adi: str,
    eczane_telefon: str = "",
    eczane_adres: str = "",
    kargo_firma: str = "",
    firma_renk: str | None = None,
    use_logo: bool = True,
) -> Image.Image:
    """Kargo GÖNDERİCİ etiketi: üstte kargo firması şeridi → GÖNDERİCİ şeridi →
    eczane adı (büyük) + adres + telefon. Gönderici = eczane."""
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)
    avail_w = LABEL_W - 2 * PAD_X
    y = PAD_Y

    # --- Üst: kargo firması şeridi (alıcı etiketiyle aynı) ---
    if (kargo_firma or "").strip():
        strip_h = _sv(24)
        _draw_kargo_strip(d, img, PAD_X, y, LABEL_W - PAD_X, y + strip_h,
                          kargo_firma.strip(), firma_renk=firma_renk,
                          use_logo=use_logo)
        y += strip_h + _sv(4)

    # --- GÖNDERİCİ şeridi (kargo firmasının altında) ---
    band_h = _sv(18)
    _draw_role_band(d, PAD_X, y, LABEL_W - PAD_X, y + band_h, "GÖNDERİCİ")
    y += band_h + _sv(5)

    if (eczane_adi or "").strip():
        f = _fit_font(d, eczane_adi.strip(), avail_w, 24, bold=True, min_size=13)
        d.text((PAD_X, y), eczane_adi.strip(), font=f, fill=FG)
        y += f.size + _sv(5)

    # Telefon için en altta yer ayır; adres ortadaki kalan alana sığar.
    ftel = _font(16, bold=True)
    tel_h = (ftel.size + _sv(4)) if (eczane_telefon or "").strip() else 0
    addr_bottom = LABEL_H - PAD_Y - tel_h
    _draw_wrapped_block(d, eczane_adres, PAD_X, y, avail_w, addr_bottom,
                        base_size=15, min_size=9, line_gap=3)

    if (eczane_telefon or "").strip():
        txt = "TEL: " + eczane_telefon.strip()
        f = _fit_font(d, txt, avail_w, 18, bold=True, min_size=11)
        d.text((PAD_X, LABEL_H - PAD_Y - f.size), txt, font=f, fill=FG)
    return img


def render_shelf_label(
    *,
    barkod: str,
    ilac_adi: str,
    fiyat: str,
    width_mm: float = 60.0,
    height_mm: float = 40.0,
    dpi: int = 203,
) -> Image.Image:
    """Raf etiketi: ilaç adı (tepe) + büyük satış fiyatı (orta) + barkod (dip).

    Boyut mm cinsinden serbesttir (varsayılan 60×40 mm = ana sarı stok). Dikey
    tasarım referans 320 px yükseklikte kuruludur; genişlik en-boy oranına göre
    uyarlanır, sonra TSPL baskısı görseli fiziksel dot boyutuna ölçekler — yani
    her etiket stoğunda en-boy bozulmaz. Eczane adı/telefon YOK (yalnız ürün).

    Yerleşim (sarı zemin) — tepe/orta/dip sabit:
      ┌───────────────────────────────────┐
      │        İLAÇ ADI (kalın, sarma)     │  ← ad, EN ÜSTTE
      │ ───────────────◆─────────────────  │
      │        ┌─────────────────┐         │
      │        │   245,50 ₺      │         │  ← fiyat, ORTADA, en büyük
      │        └─────────────────┘         │
      │      ‖█‖‖█‖█‖‖█‖‖█‖█‖‖█‖‖          │  ← barkod, EN ALTTA (ince/yatay)
      │          8699832090055             │  ← barkod numarası (hemen altında)
      └───────────────────────────────────┘
    """
    # Yükseklik referansta sabit (LABEL_H=320 için ayarlı metrikler); genişlik
    # en-boy oranına göre. Aşırı uçları makul sınırda tut.
    H = LABEL_H
    try:
        aspect = float(width_mm) / float(height_mm)
    except (TypeError, ValueError, ZeroDivisionError):
        aspect = LABEL_W / LABEL_H
    W = int(min(960, max(220, round(H * aspect))))

    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)

    def _cline(yy: int, text: str, font, fill: str = "black") -> None:
        """W genişliğinde yatay ortalı tek satır metin."""
        try:
            bb = font.getbbox(text)
        except Exception:
            bb = (0, 0, 0, font.size)
        d.text(((W - (bb[2] - bb[0])) // 2 - bb[0], yy - bb[1]), text, font=font, fill=fill)

    barkod = (barkod or "").strip()
    ad = (ilac_adi or "").strip()
    fiyat = (fiyat or "").strip()
    # Fiyatta para birimi yoksa ekle (₺ / TL / sembol zaten varsa dokunma)
    if fiyat and not any(s in fiyat for s in ("₺", "TL", "tl", "Tl")):
        fiyat = f"{fiyat} ₺"

    # Çift köşeli çerçeve (emanet etiketiyle aynı zarif stil)
    try:
        d.rounded_rectangle([5, 5, W - 6, H - 6], radius=16, outline="black", width=3)
        d.rounded_rectangle([11, 11, W - 12, H - 12], radius=11, outline="black", width=1)
    except Exception:
        d.rectangle([5, 5, W - 6, H - 6], outline="black", width=3)
        d.rectangle([11, 11, W - 12, H - 12], outline="black", width=1)

    M = _sv(16)
    inner_w = W - 2 * M
    content_top = _sv(14)
    content_bottom = H - _sv(14)
    GAP = _sv(5)

    # --- İçerikleri hazırla ---
    # 1) İlaç adı (en çok 2 satır, oto-sığdırma)
    name_lines: list[str] = []
    f_name = _font(11, bold=True)
    if ad:
        size = 17
        while size > 10:
            f_name = _font(size, bold=True)
            name_lines = _wrap(ad, f_name, inner_w, d)
            if len(name_lines) <= 2:
                break
            size -= 1
        name_lines = _wrap(ad, f_name, inner_w, d)[:2]

    # 2) Fiyat fontu (en büyük; genişliğe sığdır)
    f_price = _fit_font(d, fiyat, inner_w - _sv(24), 44, bold=True, min_size=18) if fiyat else None

    # 3) Barkod — ince/yatay strip (numara hariç)
    bc_h = _sv(30)
    bc_img = _make_barcode_image(barkod, inner_w, bc_h) if barkod else None
    f_num = _font(12, bold=True)

    # --- TEPE: ilaç adı ---
    y = content_top
    for ln in name_lines:
        _cline(y, ln, f_name)
        y += f_name.size + _sv(2)
    name_bottom = y
    if name_lines:
        _draw_rule_diamond(d, M + _sv(14), W - M - _sv(14), name_bottom + _sv(3))
        name_bottom += _sv(9)

    # --- DİP: barkod deseni + hemen altında numara (alta sabit) ---
    by = content_bottom
    if barkod:
        by -= f_num.size
        _cline(by, barkod, f_num)              # numara en altta
        by -= _sv(2)
    if bc_img:
        by -= bc_img.height
        img.paste(bc_img, ((W - bc_img.width) // 2, by))
    bottom_top = by - GAP if barkod else content_bottom

    # --- ORTA: fiyat (büyük, çerçeveli) — tepe ile dip arasının ortasında ---
    if f_price:
        price_box_pad = _sv(6)
        box_h = f_price.size + 2 * price_box_pad
        pw = _text_w(d, fiyat, f_price)
        box_w = min(inner_w, pw + _sv(44))
        bx0 = (W - box_w) // 2
        bx1 = bx0 + box_w
        py = name_bottom + max(0, ((bottom_top - name_bottom) - box_h) // 2)
        try:
            d.rounded_rectangle([bx0, py, bx1, py + box_h], radius=9, outline="black", width=3)
        except Exception:
            d.rectangle([bx0, py, bx1, py + box_h], outline="black", width=3)
        _centered_text(d, bx0, py, bx1, py + box_h, fiyat, f_price, "black")

    return img


def _draw_centered_line(d: ImageDraw.ImageDraw, y: int, text: str, font,
                        fill: str = "black") -> None:
    """Verilen y satır-üstünden başlayarak yatayda ortalı tek satır metin yazar."""
    try:
        bbox = font.getbbox(text)
    except Exception:
        bbox = (0, 0, 0, font.size)
    w = bbox[2] - bbox[0]
    d.text(((LABEL_W - w) // 2 - bbox[0], y - bbox[1]), text, font=font, fill=fill)


def _draw_cross(d: ImageDraw.ImageDraw, cx: int, cy: int, L: int, T: int) -> None:
    """Eczane simgesi: eşit kollu artı (kol yarı-uzunluğu L, kalınlık 2T)."""
    d.rectangle([cx - T, cy - L, cx + T, cy + L], fill="black")
    d.rectangle([cx - L, cy - T, cx + L, cy + T], fill="black")


def _draw_rule_diamond(d: ImageDraw.ImageDraw, x0: int, x1: int, y: int) -> None:
    """Ortasında küçük elmas bulunan yatay ayraç çizgisi (zarif bölücü)."""
    cx = (x0 + x1) // 2
    r = _sv(3)
    d.line([(x0, y), (cx - r - 3, y)], fill="black", width=1)
    d.line([(cx + r + 3, y), (x1, y)], fill="black", width=1)
    d.polygon([(cx, y - r), (cx + r, y), (cx, y + r), (cx - r, y)], fill="black")


# ---------------------------------------------------------------------------
# Tip 3 — Uyarı etiketi
# ---------------------------------------------------------------------------
def render_warning_label(
    *,
    hasta_adi: str,
    ilac_adi: str,
    label: WarningLabel,
    eczane_adi: str = "",
    eczane_telefon: str = "",
    title_override: str = "",
    big_mode: bool = False,
) -> Image.Image:
    """2. etiket — varyantları:
      - title_override='KULLANIM TEKNİĞİ' (inhaler/sprey/damla teknik adımları)
      - title_override='ENJEKSİYON UYGULAMA' (subkutan)
      - title_override='HAZIRLANIŞI' (PreparationLabel ile çakışmaz, sadece warning ile)
      - title_override='DİKKAT' + big_mode=True → kritik ATC için büyük puntolu mesaj
    """
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)

    f_top   = _font(15, bold=True)
    f_item  = _font(14)

    # Üst: hasta (solda, genişliğe sığdırılır) · ilaç (sağda, kalan alana)
    _draw_header_two(d, hasta_adi, ilac_adi, 15)

    # Başlık (override veya varsayılan) — uzun başlıklar (örn. "DİKKAT EDİLECEK
    # HUSUSLAR") taşmasın diye genişliğe otomatik sığdırılır.
    title = title_override or "ÖNEMLİ UYARILAR"
    f_title = _fit_font(d, title, LABEL_W - 2 * PAD_X, 17, bold=True, min_size=11)
    w = _text_w(d, title, f_title)
    d.text(((LABEL_W - w) // 2, PAD_Y + _sv(26)), title, font=f_title, fill=FG)

    # Ayırıcı
    sep_y = PAD_Y + _sv(52)
    d.line([(PAD_X, sep_y), (LABEL_W - PAD_X, sep_y)], fill=FG, width=1)

    y = sep_y + 8

    if big_mode:
        # BÜYÜK PUNTO — kritik ATC (FLAGYL alkol uyarısı gibi)
        f_big = _font(17, bold=True)
        text = " ".join(label.uyarilar[:2])
        lines = _wrap(text, f_big, LABEL_W - 2 * PAD_X, d)
        for ln in lines[:5]:
            w = _text_w(d, ln, f_big)
            d.text(((LABEL_W - w) // 2, y), ln, font=f_big, fill=FG)
            y += _sv(22)
            if y > LABEL_H - 50:
                break
    else:
        # NORMAL liste — madde madde. Madde sayısı çoksa (örn. detaylı inhaler
        # tekniği) punto otomatik küçülerek TÜM maddeler alt bilgiye taşmadan sığar.
        import re as _re
        _rx_num = _re.compile(r"^\d+[\.\)]\s*")
        items: list[str] = []
        for i, u in enumerate(label.uyarilar, 1):
            u_clean = u.lstrip()
            items.append(u_clean if _rx_num.match(u_clean) else f"{i}. {u_clean}")

        avail_w = LABEL_W - 2 * PAD_X
        bottom = LABEL_H - 28        # alt bilgi çizgisinin üstü
        # Tüm maddeleri sığdıran en büyük puntoyu seç (14→8 punto).
        chosen = _font(8)
        chosen_lines: list[str] = []
        for sz in range(14, 7, -1):
            f = _font(sz)
            all_lines: list[str] = []
            for it in items:
                all_lines.extend(_wrap(it, f, avail_w, d))
            line_h = f.size + _sv(3)
            if y + line_h * len(all_lines) <= bottom:
                chosen, chosen_lines = f, all_lines
                break
        else:
            f = _font(8)
            chosen = f
            for it in items:
                chosen_lines.extend(_wrap(it, f, avail_w, d))

        line_h = chosen.size + _sv(3)
        for ln in chosen_lines:
            if y > bottom - line_h:
                break
            d.text((PAD_X, y), ln, font=chosen, fill=FG)
            y += line_h

    _draw_footer(d, eczane_adi, eczane_telefon)
    return img


# ---------------------------------------------------------------------------
# Kan şekeri ölçüm çubuğu/cihazı — TAM GENİŞLİKLİ tarif etiketi
# ---------------------------------------------------------------------------
def render_glucose_guide_label(
    *,
    hasta_adi: str,
    ilac_adi: str,
    title: str,
    steps: list[str],
    caveats: list[str],
    eczane_adi: str = "",
    eczane_telefon: str = "",
    full_name: bool = False,
) -> Image.Image:
    """Kan şekeri ölçüm çubuğu/cihazı için tam genişlikli tarif etiketi.

    İki sütunlu dozaj düzeni YOKTUR. Üstte 'nasıl ölçülür' adımları (numaralı),
    altında 'DİKKAT' başlığıyla önemli hususlar yazılır. İçerik etikete sığacak
    şekilde otomatik küçültülür ve alt bilgiye taşmadan kırpılır.

    full_name=True ise sağ üstte ürünün TAM adı yazılır (cihaz/malzeme etiketinde
    tercih edilir). False (varsayılan) ise kısa marka adı kullanılır — bu renderer'ı
    paylaşan inhaler kullanım etiketinde marka adı (örn. 'SYMBICORT') kısa kalsın diye.
    """
    img = Image.new("RGB", (LABEL_W, LABEL_H), BG)
    d = ImageDraw.Draw(img)

    # Üst: hasta adı (sol) + ürün adı (sağ). Cihaz/malzeme etiketinde (full_name)
    # marka kısaltması YAPILMAZ; hasta için ürünün tam adı önemlidir.
    _draw_header_two(d, hasta_adi, ilac_adi, 13, shorten=not full_name)

    # Başlık (ortalı) — uzun başlıklar (örn. "İNHALER KULLANIM VE UYARILAR") taşmasın.
    f_title = _fit_font(d, title, LABEL_W - 2 * PAD_X, 14, bold=True, min_size=9)
    tw = _text_w(d, title, f_title)
    ty = PAD_Y + _sv(18)
    d.text(((LABEL_W - tw) // 2, ty), title, font=f_title, fill=FG)

    sep_y = ty + _sv(19)
    d.line([(PAD_X, sep_y), (LABEL_W - PAD_X, sep_y)], fill=FG, width=2)

    bottom = LABEL_H - 28          # alt bilgi çizgisinin üstü
    avail_w = LABEL_W - 2 * PAD_X
    y0 = sep_y + 6
    avail_h = bottom - y0

    # Adım yoksa (sadece uyarılar etiketi) "DİKKAT EDİLECEK HUSUSLAR" alt başlığı
    # gereksiz — başlık zaten içeriği açıklıyor.
    heading = "DİKKAT EDİLECEK HUSUSLAR" if steps else ""

    # Adaptif yerleşim: tüm adımlar + uyarılar alt bilgiye TAŞMADAN sığacak en büyük
    # puntoyu seç (büyükten küçüğe dener). Başlangıç noktası: adım yoksa daha büyük
    # fonttan başla (uyarılar daha okunabilir olsun).
    fs_start = 13 if not steps else 11

    def _plan(fs: int):
        f_step = _font(fs, bold=False)
        f_head = _font(max(fs - 1, 7), bold=True)
        f_cav = _font(max(fs - 1, 6))
        lh_step = f_step.size + _sv(3)
        lh_cav = f_cav.size + _sv(2)
        head_h = (f_head.size + _sv(6)) if (caveats and heading) else 0
        cav_wrapped = [_wrap("• " + cv, f_cav, avail_w, d)[:3] for cv in caveats]
        n_cav_lines = sum(len(x) for x in cav_wrapped)
        total = len(steps) * lh_step + head_h + n_cav_lines * lh_cav
        return {
            "total": total, "fs": fs, "f_step": f_step, "f_head": f_head,
            "f_cav": f_cav, "lh_step": lh_step, "lh_cav": lh_cav,
            "head_h": head_h, "cav_wrapped": cav_wrapped,
        }

    plan = None
    for fs in range(fs_start, 6, -1):
        p = _plan(fs)
        if p["total"] <= avail_h:
            plan = p
            break
    if plan is None:
        plan = _plan(7)   # en küçük punto: yine de çiz (aşırı içerikte alttan kırpılır)

    y = y0
    # Adımlar — numaralı; uzun bir adım gerekiyorsa yalnız yatayda ayrıca küçülür
    # (dikey satır gridi sabit kalır).
    for i, st in enumerate(steps, 1):
        if y > bottom - plan["lh_step"]:
            break
        text = f"{i}. {st}"
        ff = plan["f_step"]
        if _text_w(d, text, ff) > avail_w:
            ff = _fit_font(d, text, avail_w, plan["fs"], bold=False, min_size=7)
        d.text((PAD_X, y), text, font=ff, fill=FG)
        y += plan["lh_step"]

    # DİKKAT alt başlığı (sadece adımlarla birlikte kullanıldığında gösterilir)
    if heading and caveats and y < bottom - plan["head_h"]:
        d.text((PAD_X, y), heading, font=plan["f_head"], fill=FG)
        y += plan["f_head"].size + _sv(3)
        d.line([(PAD_X, y), (LABEL_W - PAD_X, y)], fill=FG, width=1)
        y += _sv(3)

    # Uyarılar — madde imli (plan aşamasında sarılmış hâlleri kullanılır)
    for lines in plan["cav_wrapped"]:
        for ln in lines:
            if y > bottom - plan["lh_cav"]:
                break
            d.text((PAD_X, y), ln, font=plan["f_cav"], fill=FG)
            y += plan["lh_cav"]

    _draw_footer(d, eczane_adi, eczane_telefon)
    return img


# ---------------------------------------------------------------------------
# Tek noktadan üretim (dispatcher)
# ---------------------------------------------------------------------------
def render_label(label_type: int, **kwargs) -> Image.Image:
    if label_type == 1:
        return render_usage_label(**kwargs)
    if label_type == 2:
        return render_preparation_label(**kwargs)
    if label_type == 3:
        return render_warning_label(**kwargs)
    raise ValueError(f"Bilinmeyen etiket tipi: {label_type}")


def add_dose_change_band(p1_path: str | Path, detail: str) -> None:
    """Reçete başı ile sonu arasında doz değişen ilaçların p1 PNG'sine kırmızı uyarı şeridi ekler.

    `detail`: staged_recete.DiffRow.detail değeri, örn. "Günlük kez: 2 → 1 · Doz adet: 2 → 1"
    Etiketi genişletmeden en alt satırın üzerine kırmızı kutu çizer; beyaz metinle uyarı yazar.
    """
    p1_path = Path(p1_path)
    if not p1_path.exists():
        return
    img = Image.open(p1_path).convert("RGB")
    w, h = img.size
    draw = ImageDraw.Draw(img)

    band_h = max(18, round(h * 0.10))   # etiket yüksekliğinin ~%10'u
    y0 = h - band_h
    draw.rectangle([0, y0, w, h], fill="#C0141A")

    text = f"⚠ REÇETE BAŞI FARKLIYDI: {detail}"
    # Sığana kadar punto küçült
    for sz in (7, 6, 5):
        ft = _font(sz, bold=True)
        tw = _text_w(draw, text, ft)
        if tw <= w - 8:
            break
    bbox = draw.textbbox((0, 0), text, font=ft)
    th = bbox[3] - bbox[1]
    tx = max(4, (w - tw) // 2)
    ty = y0 + (band_h - th) // 2
    draw.text((tx, ty), text, font=ft, fill="white")

    img.save(p1_path)


# ---------------------------------------------------------------------------
# Majistral (yapma ilaç) etiketleri — İÇERİK + KULLANIM/BİLGİLENDİRME
# ---------------------------------------------------------------------------
# İki ayrı etiket üretilir; ikisi de AYRI basılabilir. İçerik/kullanım metni tek
# etikete sığmazsa otomatik olarak 2. (ve gerekirse 3.+) etikete taşar — her iki
# fonksiyon da liste[Image] (sayfalar) döndürür. Boyut mm cinsinden serbesttir
# (varsayılan 60×40 mm), TSPL baskıda en-boy bozulmaz.
def _tr_upper(s: str) -> str:
    """Türkçe büyük harf (i→İ, ı korunur) — 'Haricen' → 'HARİCEN'."""
    return (s or "").translate(str.maketrans("iı", "İI")).upper()


def _mag_footer(d, w, h, eczane_adi, telefon, page_idx, page_count,
                pad, footer_base):
    """Majistral etiketi alt şeridi: çizgi + eczane/telefon (+ çok sayfalıysa
    sağda 'sayfa/toplam'). Çizginin üst y'sini döndürür (gövde alt sınırı için)."""
    line_y = h - (_font(footer_base).size + _sv(10))
    d.line([(pad, line_y), (w - pad, line_y)], fill="black", width=1)
    parts = [(eczane_adi or "").strip()]
    if (telefon or "").strip():
        parts.append(telefon.strip().replace(" ", "-"))
    txt = " / ".join(p for p in parts if p)
    if txt:
        reserve = 0
        if page_count > 1:
            reserve = _text_w(d, f"{page_idx + 1}/{page_count}",
                              _font(footer_base, bold=True)) + _sv(8)
        f = _fit_font(d, txt, (w - 2 * pad) - reserve, footer_base,
                      bold=True, min_size=7)
        d.text((pad, line_y + _sv(3)), txt, font=f, fill="black")
    if page_count > 1:
        pg = f"{page_idx + 1}/{page_count}"
        fp = _font(footer_base, bold=True)
        pw = _text_w(d, pg, fp)
        d.text((w - pad - pw, line_y + _sv(3)), pg, font=fp, fill="black")
    return line_y


def _mag_draw_row(d, x0, x1, y, name, amount, row_base):
    """İçerik satırı: '• madde adı' solda + miktar sağda (kalın). Madde adı,
    miktara çakışmayacak şekilde kalan genişliğe otomatik küçülür."""
    name = ("• " + (name or "").strip()).strip()
    amt = (amount or "").strip()
    f_amt = _font(row_base, bold=True)
    aw = _text_w(d, amt, f_amt) if amt else 0
    gap = _sv(8)
    name_max = (x1 - x0) - (aw + gap if amt else 0)
    if name_max < 40:
        name_max = 40
    f_name = _fit_font(d, name or "—", name_max, row_base, bold=False, min_size=9)
    d.text((x0, y), name or "—", font=f_name, fill=FG)
    if amt:
        d.text((x1 - aw, y), amt, font=f_amt, fill=FG)


def render_magistral_content_label(
    drug_name: str,
    ingredients,
    *,
    prep_date: str = "",
    expiry: str = "",
    usage_route: str = "",
    usage_purpose: str = "",
    width_mm: float = 60.0,
    height_mm: float = 40.0,
    dpi: int = 203,
    eczane_adi: str = "",
    eczane_telefon: str = "",
) -> list[Image.Image]:
    """Majistral İÇERİK etiketi (bir veya daha fazla sayfa).

    Başlık = ilaç/preparat adı; altında hammadde (etkin madde) içeriği teker teker
    'madde + miktar' biçiminde listelenir. İlk sayfada hazırlama/son kullanma
    tarihi de basılır. İçerik tek etikete sığmazsa kalan maddeler 2.+ etikete taşar.

    ingredients: (madde_adi, miktar) ikililerinden oluşan dizilim
                 (miktar 'g'/'mg'/'ml' gibi birimi içeren serbest metindir).
    usage_purpose: kullanım amacı/endikasyon — SON sayfada maddelerden sonra YER
                   KALIRSA "KULLANIM AMACI: ..." olarak eklenir (sığmazsa atlanır).
    """
    rows = [
        ((n or "").strip(), (a or "").strip())
        for (n, a) in (ingredients or [])
        if (n or "").strip() or (a or "").strip()
    ]
    w = max(160, round(width_mm / 25.4 * dpi))
    h = max(160, round(height_mm / 25.4 * dpi))
    pad = max(8, w // 40)

    title_base, header_base, row_base = 15, 11, 12
    date_base, footer_base = 10, 10

    title_h = _font(title_base).size + _sv(8)
    header_h = _font(header_base).size + _sv(4)
    date_h = _font(date_base).size + _sv(4)
    footer_reserve = _font(footer_base).size + _sv(12)
    row_h = _font(row_base).size + _sv(4)

    body_bottom = h - footer_reserve
    has_dates = bool((prep_date or "").strip() or (expiry or "").strip())

    def body_top(page_idx: int) -> int:
        y = pad + title_h + _sv(4) + header_h
        if page_idx == 0 and has_dates:
            y += date_h
        return y

    # Sayfalama: her sayfaya sığan satır sayısını hesapla.
    pages: list[tuple[int, int]] = []
    if not rows:
        pages = [(0, 0)]
    else:
        idx, n, page_idx = 0, len(rows), 0
        while idx < n:
            avail = body_bottom - body_top(page_idx)
            rows_fit = max(1, avail // row_h)
            end = min(n, idx + rows_fit)
            pages.append((idx, end))
            idx, page_idx = end, page_idx + 1
    page_count = len(pages)

    out: list[Image.Image] = []
    for pi, (s, e) in enumerate(pages):
        img = Image.new("RGB", (w, h), BG)
        d = ImageDraw.Draw(img)
        d.rectangle([2, 2, w - 3, h - 3], outline="black", width=2)
        y = pad
        suffix = "" if pi == 0 else "  (DEVAM)"
        ttl = (_tr_upper((drug_name or "").strip()) or "MAJİSTRAL") + suffix
        _bordered_box(d, pad, y, w - pad, y + title_h, ttl, title_base,
                      bold=True, min_size=9)
        y += title_h + _sv(4)
        if pi == 0 and has_dates:
            dt = []
            if (prep_date or "").strip():
                dt.append("HAZ: " + prep_date.strip())
            if (expiry or "").strip():
                dt.append("SKT: " + expiry.strip())
            dtx = "    ".join(dt)
            fd = _fit_font(d, dtx, w - 2 * pad, date_base, bold=True, min_size=8)
            d.text((pad, y), dtx, font=fd, fill=FG)
            y += date_h
        if pi == 0 and (usage_route or "").strip():
            hdr = "İÇERİK (%s):" % _tr_upper(usage_route.strip())
        elif pi == 0:
            hdr = "İÇERİK:"
        else:
            hdr = "İÇERİK (devam):"
        d.text((pad, y), hdr, font=_font(header_base, bold=True), fill=FG)
        y += header_h
        for (nm, am) in rows[s:e]:
            _mag_draw_row(d, pad, w - pad, y, nm, am, row_base)
            y += row_h
        # Son sayfada YER KALIRSA kullanım amacını da yaz (sığmazsa atlanır).
        if pi == page_count - 1 and (usage_purpose or "").strip():
            ph_hdr = _font(header_base, bold=True)
            need = _sv(6) + ph_hdr.size + _font(11).size + _sv(2)
            if y + need <= body_bottom:
                y += _sv(4)
                d.line([(pad, y), (w - pad, y)], fill="black", width=1)
                y += _sv(4)
                d.text((pad, y), "KULLANIM AMACI:", font=ph_hdr, fill=FG)
                y += ph_hdr.size + _sv(2)
                _draw_wrapped_block(d, usage_purpose.strip(), pad, y, w - 2 * pad,
                                    body_bottom, base_size=11, min_size=8,
                                    line_gap=2)
        _mag_footer(d, w, h, eczane_adi, eczane_telefon, pi, page_count,
                    pad, footer_base)
        out.append(img)
    return out


def render_magistral_usage_label(
    drug_name: str,
    *,
    usage_text: str = "",
    usage_purpose: str = "",
    hasta_adi: str = "",
    doktor_adi: str = "",
    usage_route: str = "",
    storage: str = "",
    warnings: str = "",
    prep_date: str = "",
    expiry: str = "",
    width_mm: float = 60.0,
    height_mm: float = 40.0,
    dpi: int = 203,
    eczane_adi: str = "",
    eczane_telefon: str = "",
) -> list[Image.Image]:
    """Majistral KULLANIM / BİLGİLENDİRME etiketi (bir veya daha fazla sayfa).

    Başlık = ilaç adı; DAHİLEN/HARİCEN kullanım yolu varsa ters-renkli bant olarak
    vurgulanır. Hasta/doktor adı, kullanım şekli, saklama koşulu, uyarılar ve
    tarihler sırayla akar; tek etikete sığmazsa kalan metin 2.+ etikete taşar.
    """
    w = max(160, round(width_mm / 25.4 * dpi))
    h = max(160, round(height_mm / 25.4 * dpi))
    pad = max(8, w // 40)
    inner_w = w - 2 * pad

    title_base, footer_base = 15, 10
    title_h = _font(title_base).size + _sv(8)
    footer_reserve = _font(footer_base).size + _sv(12)

    scratch = ImageDraw.Draw(Image.new("RGB", (w, h), BG))
    lines: list[dict] = []

    def add_line(text, base, bold=False, gap=0, invert=False):
        lines.append({"text": text, "base": base, "bold": bold,
                      "gap": gap, "invert": invert})

    def add_section(header, text, base=12, gap=4):
        text = (text or "").strip()
        if not text:
            return
        add_line(header, base, bold=True, gap=gap)
        for ln in _wrap(text, _font(base), inner_w, scratch):
            add_line(ln, base, bold=False, gap=0)

    if (usage_route or "").strip():
        add_line(_tr_upper(usage_route.strip()) + " KULLANIM", 13,
                 bold=True, gap=2, invert=True)
    add_section("KULLANIM AMACI:", usage_purpose, base=12, gap=2)
    if (hasta_adi or "").strip():
        add_line("HASTA: " + hasta_adi.strip(), 12, bold=True, gap=4)
    if (doktor_adi or "").strip():
        add_line("DR: " + doktor_adi.strip(), 11, bold=False, gap=2)
    add_section("KULLANIM ŞEKLİ:", usage_text, base=13, gap=4)
    add_section("SAKLAMA:", storage, base=11, gap=4)
    add_section("UYARI:", warnings, base=11, gap=4)
    if (prep_date or "").strip() or (expiry or "").strip():
        dt = []
        if (prep_date or "").strip():
            dt.append("HAZ: " + prep_date.strip())
        if (expiry or "").strip():
            dt.append("SKT: " + expiry.strip())
        add_line("    ".join(dt), 11, bold=True, gap=4)
    if not lines:
        add_line("—", 12)

    def line_h(item) -> int:
        return _font(item["base"]).size + _sv(2) + _sv(item["gap"])

    body_bottom = h - footer_reserve
    body_start = pad + title_h + _sv(4)

    # Sayfalama: satırları gövde alt sınırına göre etiketlere böl.
    pages: list[list[dict]] = []
    cur: list[dict] = []
    y = body_start
    for item in lines:
        ih = line_h(item)
        if cur and y + ih > body_bottom:
            pages.append(cur)
            cur, y = [], body_start
        cur.append(item)
        y += ih
    if cur:
        pages.append(cur)
    page_count = len(pages)

    out: list[Image.Image] = []
    for pi, page in enumerate(pages):
        img = Image.new("RGB", (w, h), BG)
        d = ImageDraw.Draw(img)
        d.rectangle([2, 2, w - 3, h - 3], outline="black", width=2)
        y = pad
        suffix = "" if pi == 0 else "  (DEVAM)"
        ttl = (_tr_upper((drug_name or "").strip()) or "MAJİSTRAL") + suffix
        _bordered_box(d, pad, y, w - pad, y + title_h, ttl, title_base,
                      bold=True, min_size=9)
        y += title_h + _sv(4)
        for item in page:
            y += _sv(item["gap"])
            txt = item["text"]
            row_h = _font(item["base"]).size + _sv(2)
            if item["invert"]:
                _inv_box(d, pad, y, w - pad, y + row_h, txt,
                         item["base"], bold=True, min_size=8)
            else:
                f = _font(item["base"], bold=item["bold"])
                if _text_w(d, txt, f) > inner_w:
                    f = _fit_font(d, txt, inner_w, item["base"],
                                  bold=item["bold"], min_size=7)
                d.text((pad, y), txt, font=f, fill=FG)
            y += row_h
        _mag_footer(d, w, h, eczane_adi, eczane_telefon, pi, page_count,
                    pad, footer_base)
        out.append(img)
    return out


def render_magistral_combined_label(
    drug_name: str,
    ingredients,
    *,
    hasta_adi: str = "",
    usage_text: str = "",
    usage_purpose: str = "",
    usage_route: str = "",
    storage: str = "",
    warnings: str = "",
    prep_date: str = "",
    expiry: str = "",
    width_mm: float = 60.0,
    height_mm: float = 40.0,
    dpi: int = 203,
    eczane_adi: str = "",
    eczane_telefon: str = "",
) -> list[Image.Image]:
    """Majistral BİRLEŞİK etiket: hasta adı + ilaç ismi + içerik + kullanım şekli
    TEK etikette toplanır.

    Hepsi tek etikete sığarsa → tek sayfa. Sığmazsa KULLANIM bloğu (amaç/şekil/
    saklama/uyarı) BÜTÜN HALİNDE ikinci etikete taşınır (içerik 1. etikette kalır;
    yarıda bölünmez). Çok uzun olursa kullanım bloğu kendi içinde de akabilir.
    """
    rows = [
        ((n or "").strip(), (a or "").strip())
        for (n, a) in (ingredients or [])
        if (n or "").strip() or (a or "").strip()
    ]
    w = max(160, round(width_mm / 25.4 * dpi))
    h = max(160, round(height_mm / 25.4 * dpi))
    pad = max(8, w // 40)
    inner_w = w - 2 * pad

    title_base, hasta_base, header_base = 15, 12, 11
    row_base, date_base, footer_base = 12, 10, 10

    title_h = _font(title_base).size + _sv(8)
    header_h = _font(header_base).size + _sv(4)
    row_h = _font(row_base).size + _sv(4)
    footer_reserve = _font(footer_base).size + _sv(12)
    body_bottom = h - footer_reserve

    hasta = (hasta_adi or "").strip()
    has_dates = bool((prep_date or "").strip() or (expiry or "").strip())

    # --- Kullanım bloğunu satırlara çevir (bütün halinde taşınacak grup) ---
    scratch = ImageDraw.Draw(Image.new("RGB", (w, h), BG))
    usage_lines: list[dict] = []

    def uadd(text, base, bold=False, gap=0, invert=False):
        usage_lines.append({"text": text, "base": base, "bold": bold,
                            "gap": gap, "invert": invert})

    def usection(header, text, base=12, gap=4):
        text = (text or "").strip()
        if not text:
            return
        uadd(header, base, bold=True, gap=gap)
        for ln in _wrap(text, _font(base), inner_w, scratch):
            uadd(ln, base, bold=False, gap=0)

    if (usage_route or "").strip():
        uadd(_tr_upper(usage_route.strip()) + " KULLANIM", 12,
             bold=True, gap=2, invert=True)
    usection("KULLANIM AMACI:", usage_purpose, base=12, gap=2)
    usection("KULLANIM ŞEKLİ:", usage_text, base=12, gap=4)
    usection("SAKLAMA:", storage, base=11, gap=4)
    usection("UYARI:", warnings, base=11, gap=4)

    def uline_h(it) -> int:
        return _font(it["base"]).size + _sv(2) + _sv(it["gap"])

    usage_total = sum(uline_h(it) for it in usage_lines)

    imgs: list = []   # (img, draw)

    def new_page(*, first: bool, icerik_header):
        img = Image.new("RGB", (w, h), BG)
        d = ImageDraw.Draw(img)
        d.rectangle([2, 2, w - 3, h - 3], outline="black", width=2)
        y = pad
        suffix = "" if first else "  (DEVAM)"
        ttl = (_tr_upper((drug_name or "").strip()) or "MAJİSTRAL") + suffix
        _bordered_box(d, pad, y, w - pad, y + title_h, ttl, title_base,
                      bold=True, min_size=9)
        y += title_h + _sv(4)
        if hasta:
            ht = "HASTA: " + hasta
            fh = _fit_font(d, ht, inner_w, hasta_base, bold=True, min_size=9)
            d.text((pad, y), ht, font=fh, fill=FG)
            y += fh.size + _sv(3)
        if first and has_dates:
            dt = []
            if (prep_date or "").strip():
                dt.append("HAZ: " + prep_date.strip())
            if (expiry or "").strip():
                dt.append("SKT: " + expiry.strip())
            dtx = "    ".join(dt)
            fd = _fit_font(d, dtx, inner_w, date_base, bold=True, min_size=8)
            d.text((pad, y), dtx, font=fd, fill=FG)
            y += fd.size + _sv(3)
        if icerik_header is not None:
            d.text((pad, y), icerik_header,
                   font=_font(header_base, bold=True), fill=FG)
            y += header_h
        imgs.append((img, d))
        return img, d, y

    def draw_usage(d, y):
        """Kullanım satırlarını çiz; sayfa biterse yeni KULLANIM sayfası aç."""
        for it in usage_lines:
            lh = uline_h(it)
            if y + lh > body_bottom:
                _img, d, y = new_page(first=False, icerik_header=None)
            y += _sv(it["gap"])
            rh = _font(it["base"]).size + _sv(2)
            if it["invert"]:
                _inv_box(d, pad, y, w - pad, y + rh, it["text"],
                         it["base"], bold=True, min_size=8)
            else:
                f = _font(it["base"], bold=it["bold"])
                if _text_w(d, it["text"], f) > inner_w:
                    f = _fit_font(d, it["text"], inner_w, it["base"],
                                  bold=it["bold"], min_size=7)
                d.text((pad, y), it["text"], font=f, fill=FG)
            y += rh
        return d, y

    # --- 1) İçerik (hammaddeler) — sayfa sayfa akar ---
    img, d, y = new_page(first=True, icerik_header="İÇERİK:")
    if not rows:
        d.text((pad, y), "(madde eklenmedi)", font=_font(row_base), fill=FG)
        y += row_h
    for (nm, am) in rows:
        if y + row_h > body_bottom:
            img, d, y = new_page(first=False, icerik_header="İÇERİK (devam):")
        _mag_draw_row(d, pad, w - pad, y, nm, am, row_base)
        y += row_h

    # --- 2) Kullanım bloğu — yer kalırsa aynı etikette, yoksa TÜMDEN 2. etikette ---
    if usage_lines:
        sep = _sv(4) + 1 + _sv(4)
        if y + sep + usage_total <= body_bottom:
            y += _sv(4)
            d.line([(pad, y), (w - pad, y)], fill="black", width=1)
            y += _sv(4)
            d, y = draw_usage(d, y)
        else:
            img, d, y = new_page(first=False, icerik_header=None)
            d, y = draw_usage(d, y)

    page_count = len(imgs)
    out: list[Image.Image] = []
    for pi, (img, d) in enumerate(imgs):
        _mag_footer(d, w, h, eczane_adi, eczane_telefon, pi, page_count,
                    pad, footer_base)
        out.append(img)
    return out
