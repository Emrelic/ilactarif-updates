"""Etiket bandı için kısa ilaç adı: AD + GÜÇ + HACİM + FORM (+ adet).

Aynı markanın diğer ürünlerinden ayıran parçalar 'vurgu' olarak işaretlenir.
Güvenlik kuralı: form tanınamazsa ad KISALTILMAZ (None döner, tam ad basılır).
Tanınmayan kelimeler atılmaz; yalnız bilinen dolgu kelimeleri (FİLM, KAPLI...)
düşürülür.
"""
from __future__ import annotations

import re
import sqlite3
from functools import lru_cache
from typing import NamedTuple, Optional

_FOLD = str.maketrans("İIıŞşĞğÜüÖöÇç", "IIISSGGUUOOCC")


def _fold(s: str) -> str:
    return (s or "").translate(_FOLD).upper()


# (aranan kalıp [katlanmış metinde], etikette yazılacak form) — özelden genele.
_FORMLAR: list[tuple[str, str]] = [
    (r"GOZ DAMLA(SI)?", "GÖZ DAMLASI"),
    (r"KULAK DAMLA(SI)?", "KULAK DAMLASI"),
    (r"BURUN DAMLA(SI)?", "BURUN DAMLASI"),
    (r"ORAL DAMLA", "ORAL DAMLA"),
    (r"GOZ (MERHEMI|POMADI?)", "GÖZ MERHEMİ"),
    (r"(BURUN|NAZAL) SPREY(I)?", "BURUN SPREYİ"),
    (r"(ORAL|AGIZ) SPREY(I)?", "AĞIZ SPREYİ"),
    (r"TOPIKAL SPREY", "CİLT SPREYİ"),
    (r"GARGARA", "GARGARA"),
    (r"SPREY(I)?", "SPREY"),
    (r"EFERVESAN (TABLET|TB|TAB)", "EFERVESAN TABLET"),
    (r"CIGNEME (TABLETI?|TB|TAB)", "ÇİĞNEME TABLETİ"),
    (r"(DILALTI|DIL ALTI) (TABLETI?|TB|TAB)", "DİLALTI TABLET"),
    (r"(VAJINAL (TABLETI?|OVUL)|OVUL)", "OVÜL"),
    (r"(SUPOZITUAR|SUPP?\.?|FITIL)", "FİTİL"),
    (r"(TABLET|TABL|TAB|TB)", "TABLET"),
    (r"(KAPSUL|KAPS|KAP)", "KAPSÜL"),
    (r"DRAJE", "DRAJE"),
    (r"SURUP", "ŞURUP"),
    (r"(SUSPANSIYON|SUSP\.?|SUS\.?)", "SÜSP"),
    (r"DAMLA(SI)?", "DAMLA"),
    (r"KREM", "KREM"),
    (r"JEL", "JEL"),
    (r"POMAD", "POMAD"),
    (r"MERHEM", "MERHEM"),
    (r"LOSYON", "LOSYON"),
    (r"SAMPUAN", "ŞAMPUAN"),
    (r"FLASTER", "FLASTER"),
    (r"AMPUL", "AMPUL"),
    (r"FLAKON", "FLAKON"),
    (r"SASE", "SAŞE"),
    (r"(POSET|TOZ)", "TOZ"),
    (r"(SOLUSYON|COZELTI)", "SOLÜSYON"),
    (r"KALEM", "KALEM"),
]
_SAYILAN = {
    "TABLET", "EFERVESAN TABLET", "ÇİĞNEME TABLETİ", "DİLALTI TABLET", "KAPSÜL",
    "DRAJE", "FİTİL", "OVÜL", "AMPUL", "FLAKON", "SAŞE", "TOZ", "FLASTER", "KALEM",
}
# Ad kısmında/arasında geçse de ayırt edici olmayan dolgu kelimeleri.
_DOLGU = re.compile(
    r"\b(FILM ?TABLET|FILM|KAPLI|ENTERIK|YUMUSAK|SERT|STERIL|MIKROPELLET|LIKID|"
    r"KONTROLLU|KONT\.?|KON\.|SALIMLI|SALIM\.?|SAL\.|UZATILMIS|ICIN|HAZIRLAMAK|HAZ\.|"
    r"KURU|OFT\.?|COZ\.|TEK|DOZLUK|KUTU|SALINIMLI|UZATILMIS|GECIKTIRILMIS|MODIFIYE|ETKILI|INHALASYON|SUBKUTAN)(?=\W|$)"
)
# Ürün varyantını belirleyen ekler (her zaman korunur ve vurgulanır).
_EKLER = {
    "PLUS", "FORT", "FORTE", "SR", "XL", "XR", "MR", "CR", "SRO", "ZOK", "DUO",
    "HCT", "RETARD", "COMBI", "MITE", "UNO", "BID", "OD", "ES", "EMULGEL", "DURULES",
    "HOT", "COLD", "FLU", "PED", "PED.", "PEDIATRIK", "ZERO", "OPHTA", "IM", "IV",
}

_SAYMA = (r"EFERVESAN|CIGNEME|DILALTI|TABLETI?|TABL|TAB|TB|KAPSUL|KAPS|KAP|DRAJE|SUPOZITUAR|"
          r"FITIL|OVUL|AMPUL|FLAKON|SASE|POSET|FLASTER|KALEM|ADET|PAKET")
_FAZLA = re.compile(
    r"(?<![A-Z])(TOZU?|SOLUSYONU?|COZELTI|POSET|SASE|PAKET|ADET|GRANUL|TABLET|KAPSUL|"
    r"JELATIN|INFUZYON|ENJEKSIYONLUK|ICEREN|ORAL|TOPIKAL)(?![A-Z])\.?")
_BIRIM = r"(?:MCG|MG|GR|G|MIU|IU|I\.U\.|MMOL|ML|L)"
_SAYI = r"\d+(?:[.,]\d+)*"
_PARCA = rf"{_SAYI}\s*(?:{_BIRIM}(?![A-Z]))?"
_GUC = re.compile(
    rf"(?<![A-Z0-9])(?:%\s*{_SAYI}(?:\s*\+\s*%\s*{_SAYI})*"
    rf"|{_PARCA}(?:\s*[/+]\s*(?:{_PARCA}|{_BIRIM}(?![A-Z])))+"
    rf"|{_SAYI}\s*{_BIRIM}(?![A-Z]))"
)


class KisaAd(NamedTuple):
    ad: str          # marka (ilk kelime)
    ekler: tuple     # varyant kelimeleri
    guc: str
    hacim: str
    form: str
    adet: str


def ayristir(tam_ad: str) -> Optional[KisaAd]:
    ham = " ".join((tam_ad or "").replace("İ", "I").split())
    if not ham:
        return None
    s = _fold(tam_ad)
    s = re.sub(r"\(?\s*(?<!\d)\d{8,}.*$", " ", s)                  # sondaki barkod
    s = " ".join(s.replace("(", " ").replace(")", " ").split())
    s = re.sub(r"I\.U\.?", "IU", s)
    s = re.sub(r"%\s+", "%", s)
    s = re.sub(r"(MCG|MG) ?- ?(?=\d)", r"\1/", s)
    s = re.sub(r"(?<=[A-Z] )(\d+(?:[.,]\d+)?) (\d+(?:[.,]\d+)?) ?MG\b",  # "200 28 MG"
               r"\1/\2 MG", s)
    s = re.sub(r"\bFILM ?TABLET", "TABLET", s)
    s = _DOLGU.sub(" ", s)
    s = re.sub(r"^([A-Z]{4,})-(BID|FORT|PLUS)\b", r"\1 \2", s)

    form = ""
    form_m = None
    for kalip, yazi in _FORMLAR:
        m = re.search(rf"(?<![A-Z]){kalip}(?![A-Z])", s)
        if m and m.start() > 0:
            form, form_m = yazi, m
            break
    if not form:
        return None

    # Kutu içi adet: "30 TABLET", "10 SASE", "(10 ADET)", "56 ADET"
    adet = ""
    am = re.search(rf"(?<![\d.,/A-Z-])(\d{{1,3}}) *(?:RETARD +)?(?=(?:{_SAYMA})(?![A-Z]))", s)
    if am:
        adet = am.group(1)
        s = s[:am.start()] + " " + s[am.end():]
    # Tanınan form ifadesini ve eşlik eden genel form kelimelerini çıkar
    s = s.replace(form_m.group(0), " ", 1)
    s = _FAZLA.sub(" ", s)

    gucler, hacimler = [], []
    for m in _GUC.finditer(s):
        t = re.sub(r"\s+", "", m.group(0))
        if re.fullmatch(rf"{_SAYI}(ML|L|GR|G)", t):
            hacimler.append(t)
        else:
            gucler.append(t)
    s = _GUC.sub(" ", s)

    kelimeler = [k.strip(",;:-") for k in s.split()]
    kelimeler = [k for k in kelimeler if k and k not in {".", "/", "+"}]
    if not kelimeler:
        return None
    ekler = kelimeler[1:]
    if "SR" in ekler:
        ekler = [e for e in ekler if e != "RETARD"]
    return KisaAd(kelimeler[0], tuple(ekler), " ".join(gucler),
                  " ".join(hacimler), form, adet)


# Yalnız AKTİF ürünler: SKRS'de aktif ya da eczanede stoğu/satışı olan.
_AKTIF_SORGU = ("SELECT name FROM drugs WHERE skrs_status='Aktif' "
                "OR stock>0 OR sales_count>0",
                "SELECT ad FROM botanik_katalog WHERE stok>0")
_TUM_SORGU = ("SELECT name FROM drugs", "SELECT ad FROM botanik_katalog")


@lru_cache(maxsize=2)
def _aile_tablosu(yalniz_aktif: bool) -> dict:
    """marka → o markanın ürünlerinin ayrıştırılmış hâli (DB + Botanik katalog)."""
    from .db import DB_PATH

    aile: dict[str, set] = {}
    try:
        con = sqlite3.connect(f"file:{DB_PATH.as_posix()}?mode=ro", uri=True)
    except Exception:
        return aile
    try:
        for sql in (_AKTIF_SORGU if yalniz_aktif else _TUM_SORGU):
            try:
                for (n,) in con.execute(sql):
                    k = ayristir(n or "")
                    if k:
                        aile.setdefault(k.ad, set()).add(k)
            except sqlite3.Error:
                continue
    finally:
        con.close()
    return aile


def _ilk_doz(guc: str) -> str:
    """'200/28MG' → '200MG'; '120MG/5ML' → '120MG'. Birim yoksa MG varsayılır."""
    ilk = re.split(r"[/+ ]", guc)[0]
    if not ilk or ilk.startswith("%") or re.search(r"[A-Z]$", ilk):
        return ilk
    b = re.search(r"(MCG|MG|MIU|IU|GR|G)(?![A-Z])", guc)
    return ilk + (b.group(1) if b else "MG")


def _doz_anahtari(guc: str) -> str:
    """Aynı dozun farklı yazımlarını eşitler ('%0,025' = '%0.025', '400/57' = '400MG')."""
    return _ilk_doz(guc).replace(",", ".")


def _diger_maddeler(guc: str) -> tuple:
    """İlk dozdan sonraki etken madde miktarları ('/5ML' paydası hariç, tam sayı kısmı)."""
    sade = re.sub(r"/\d*ML", "", guc)
    kalan = re.split(r"[/+ ]", sade)[1:]
    return tuple(t.replace(",", ".") if t.startswith("%")   # %0,2 ≠ %0,45
                 else re.split(r"[.,]", re.sub(r"[^\d.,]", "", t))[0]
                 for t in kalan if re.search(r"\d", t))


def _payda(guc: str) -> str:
    """'200MG/5ML' → '5', '10MG/ML' → '1', paydasız → ''."""
    m = re.search(r"/([\d.,]*)ML", guc)
    return (m.group(1).replace(",", ".") or "1") if m else ""


def _ilk_doz_karisir(guc: str, cizgidekiler, sivi: bool = False) -> bool:
    """Aynı ilk dozlu ama diğer maddesi farklı bir kardeş var mı (75 vs 75/2800)?"""
    benim = _diger_maddeler(guc)
    for g in cizgidekiler:
        if _doz_anahtari(g) != _doz_anahtari(guc):
            continue
        if _payda(g) and _payda(guc) and _payda(g) != _payda(guc):
            return True                       # konsantrasyon farklı
        o = _diger_maddeler(g)
        if o != benim:
            # Süspansiyon/şurupta '200MG' ile '200/28' aynı ürünün iki yazımıdır;
            # katı formlarda eksik ikinci madde FARKLI üründür (300 / 300+12,5).
            if (o and benim) or not sivi or re.search(r"[/+][\d.,]+IU", g + " " + guc):
                return True
    return False


def kisa_parcalar(tam_ad: str, aile: Optional[set] = None) -> Optional[list]:
    """[(metin, vurgu), ...] döndürür. vurgu: 0 düz, 1 altı çizili, 2 siyah kutu.

    None → kısaltılamadı, çağıran tam adı basmalı.
    """
    k = ayristir(tam_ad)
    if k is None:
        return None
    if aile is None:
        # Görünüm (vurgu/adet) aktif ürünlere göre; doz GÜVENLİĞİ tüm ürünlere göre.
        tum = _aile_tablosu(False).get(k.ad, set())
        aile = _aile_tablosu(True).get(k.ad, set())
    else:
        tum = aile
    aile = set(aile) | {k}
    tum = set(tum) | aile

    # BID güç yazılıyken ayırt ettirmez; karşılaştırmada ve etikette yok sayılır.
    atla = {"BID"} if k.guc else set()
    ek_kume = lambda x: frozenset(
        "FORT" if e == "FORTE" else e for e in x.ekler if e not in atla)
    kumeler = {ek_kume(x) for x in aile}
    ortak = frozenset.intersection(*kumeler)
    coklu_form = len({x.form for x in aile}) > 1
    ayni_cizgi = [x for x in aile if ek_kume(x) == ek_kume(k) and x.form == k.form]
    gucler = {x.guc for x in ayni_cizgi if x.guc} | ({k.guc} if k.guc else set())
    sivi = k.form in {"SÜSP", "ŞURUP"}
    tum_gucler = {x.guc for x in tum
                  if x.guc and ek_kume(x) == ek_kume(k) and x.form == k.form} | gucler
    karisir = bool(k.guc) and _ilk_doz_karisir(k.guc, tum_gucler, sivi)
    coklu_guc = (len({_doz_anahtari(g) for g in gucler}) > 1
                 or any(_ilk_doz_karisir(g, gucler, sivi) for g in gucler))
    ayni_urun = [x for x in ayni_cizgi
                 if _doz_anahtari(x.guc) == _doz_anahtari(k.guc) and x.hacim == k.hacim]
    coklu_adet = len({x.adet for x in ayni_urun if x.adet}) > 1

    parcalar: list[tuple[str, int]] = [(k.ad, 0)]

    def ekle(metin: str, vurgu: int) -> None:
        if vurgu == 2 and parcalar[-1][1] == 2:       # bitişik vurgular tek kutu
            parcalar[-1] = (f"{parcalar[-1][0]} {metin}", 2)
        else:
            parcalar.append((metin, vurgu))

    for e in k.ekler:
        if e in atla:
            continue
        norm = "FORT" if e == "FORTE" else e
        ekle(e, 2 if norm not in ortak else 0)
    # 3+ etken maddeli uzun güç dizisi, tek gücü varsa ayırt ettirmez → yazılmaz.
    tek_guc = len({_doz_anahtari(g) for g in tum_gucler}) <= 1 and not karisir
    uclu = len(re.findall(r"[/+]", re.sub(r"/\d*ML", "", k.guc))) >= 2
    if k.guc and not (uclu and tek_guc):
        yaz = k.guc if karisir else _ilk_doz(k.guc)
        ekle(yaz, 1 if coklu_guc else 0)
    if k.hacim:
        coklu_hacim = len({x.hacim for x in ayni_cizgi
                           if _doz_anahtari(x.guc) == _doz_anahtari(k.guc) and x.hacim}) > 1
        ekle(k.hacim, 1 if coklu_hacim else 0)
    form_vurgu = 2 if coklu_form else 0
    if coklu_adet and k.adet and k.form in _SAYILAN:
        # Doğal okunuş: "20MG 28 TABLET" — ayırt eden adet siyah kutuda.
        if form_vurgu == 2:
            ekle(f"{k.adet} {k.form}", 2)
        else:
            parcalar.append((k.adet, 2))
            parcalar.append((k.form, 0))
    else:
        ekle(k.form, form_vurgu)
        if coklu_adet and k.adet:
            parcalar.append((f"{k.adet} ADET", 2))
    return parcalar
