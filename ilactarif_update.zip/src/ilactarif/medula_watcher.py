"""Medula penceresini arka planda izleyen polling watcher.

Akış:
  1) Belirli aralıklarla (varsayılan 1.0 sn) Botanik EOS penceresinde
     IE_Server child'larından HTML çekilir.
  2) Sayfa tipi tespit edilir (medula_parser.detect_page_kind).
  3) "e_recete_detay" görüldüğünde reçete parse edilir.
  4) Aynı e-reçete numarası daha önce işlenmemişse callback tetiklenir.

Kullanım:
    watcher = MedulaWatcher(on_recete=handle)
    watcher.start()       # ayrı thread'de döngü başlar
    ...
    watcher.stop()

Callback imzası:
    handle(cap: PrescriptionCapture, html: str) -> None
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Optional

import comtypes

from .medula_capture import (
    MedulaWindow,
    capture_one,
    find_medula_windows,
)
from .medula_parser import PrescriptionCapture, compute_medula_theme, parse_html

log = logging.getLogger("medula_watcher")

CallbackT = Callable[[PrescriptionCapture, str], None]
# on_state(hwnd, theme): ön plandaki Medula penceresinin hwnd'si ve reçete tema
# rengi ("green"/"orange"/"blue") ya da (None, None) = uygun pencere yok.
StateCallbackT = Callable[[Optional[int], Optional[str]], None]


class MedulaWatcher:
    def __init__(
        self,
        on_recete: CallbackT,
        interval: float = 1.0,
        target_page_kinds: tuple[str, ...] = ("e_recete_detay", "kagit_recete_basarili"),
        on_paper_tick: Optional[Callable[[str, str], None]] = None,
        on_state: Optional[StateCallbackT] = None,
    ):
        """
        on_recete(prescription, html) — hedeflenen sayfa görüldüğünde çağrılır.
        on_paper_tick(html, page_kind) — her tick'te kağıt reçete giriş
            sayfasındaysa (recete_yazma) çağrılır; GUI form snapshot tutar.
        on_state(hwnd, theme) — HER tick'te ön plandaki Medula penceresinin
            reçete durumu (tema rengi) ile çağrılır; pencere etrafı renkli
            çerçeve (medula_overlay) için. Dedup YOK — durum sürekli güncellenir.
        """
        self._cb = on_recete
        self._paper_cb = on_paper_tick
        self._state_cb = on_state
        self._interval = interval
        self._targets = target_page_kinds
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._seen_recete_no: set[str] = set()
        self._last_url_per_ie: dict[int, str] = {}

    # ----------------------------------------------------------------- API
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="medula-watcher")
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=timeout)

    def reset_seen(self) -> None:
        self._seen_recete_no.clear()

    def force_tick(self) -> None:
        """Seen listesini temizle — bir sonraki otomatik tick mevcut reçeteyi yeniden yakalar."""
        self._seen_recete_no.clear()
        log.info("force_tick: seen listesi temizlendi, bir sonraki tick yeniden okuyacak")

    @staticmethod
    def _content_sig(prescription: PrescriptionCapture) -> str:
        """Reçete içeriğinin deterministik kısa imzası (dedup için).

        İlaç listesinin çekirdek alanlarından (barkod/ad/adet/doz) türetilir; ilaç
        çıkma/ekleme/doz değişiminde değişir, aynı içerikte SABİT kalır. İlaç yoksa
        (örn. kağıt reçete sonu — ayrıntı UI'da parse edilir) hasta+tarihe düşer.
        """
        drugs = getattr(prescription, "drugs", None) or []
        if drugs:
            parts = [f"{d.barkod}|{d.ad}|{d.adet}|{d.doz_ham}" for d in drugs]
            base = f"{len(drugs)}#" + "||".join(parts)
        else:
            base = f"{prescription.hasta_ad}|{prescription.recete_tarihi}"
        # İTS Karekod İşlemleri: okutulan karekodlar arttıkça imza değişmeli ki
        # her yeni okutma callback'i yeniden tetiklesin (sayım güncellensin).
        scanned = getattr(prescription, "scanned_karekodlar", None) or []
        if scanned:
            base += "##KK##" + "|".join(scanned)
        return f"{hash(base) & 0xFFFFFFFF:x}"

    # ----------------------------------------------------------------- loop
    def _loop(self) -> None:
        comtypes.CoInitialize()
        try:
            while not self._stop.is_set():
                try:
                    self._tick()
                except Exception as e:
                    log.warning("watcher tick error: %s", e, exc_info=False)
                # interval, ama dur sinyali gelirse erken çık
                self._stop.wait(self._interval)
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

    def _tick(self) -> None:
        windows = find_medula_windows()
        if not windows:
            # Açık Medula yok → çerçeveyi gizle
            if self._state_cb is not None:
                try:
                    self._state_cb(None, None)
                except Exception:
                    pass
            return
        # Pencere tema rengi: her tick'te hesaplanır (dedup yok). Pencere bazında
        # son bulunan reçete-temasını sakla; tick sonunda ön plandaki pencereyi raporla.
        theme_by_hwnd: dict[int, str] = {}
        for w in windows:
            for ie_hwnd in w.ie_servers:
                cap_info = capture_one(ie_hwnd)
                if "error" in cap_info:
                    continue
                url  = cap_info.get("url", "") or ""
                html = cap_info.get("html", "") or ""
                if not html:
                    continue

                # Hafif optimizasyon: URL+title değişmemişse parse atla.
                # NOT: Medula JSF ile aynı URL içinde içerik değişiyor; bu yüzden
                # URL eşliyse bile periyodik parse şart, ama biz yine de farklı
                # bir kontrol yapacağız (recete_no dedup ile).
                prescription = parse_html(html, document_url=url)
                # Pencere tema rengi (dedup'tan ve targets filtresinden ÖNCE, çünkü
                # recete_yazma gibi target olmayan sayfalar da mavi tema verir).
                if self._state_cb is not None:
                    try:
                        t = compute_medula_theme(prescription)
                    except Exception:
                        t = None
                    if t:
                        theme_by_hwnd[w.hwnd] = t
                # Kağıt reçete form snapshot callback (her tick, dedup yok)
                if self._paper_cb and prescription.page_kind == "recete_yazma":
                    try:
                        self._paper_cb(html, prescription.page_kind)
                    except Exception:
                        log.exception("paper_tick callback error")
                if prescription.page_kind not in self._targets:
                    continue
                rno = prescription.recete_no.strip()
                if not rno:
                    # No yoksa hash al (basit)
                    rno = f"hash_{hash(html) & 0xFFFFFFFF:x}"
                # Dedup anahtarı SAYFA TİPİNİ de içerir: aynı reçetenin reçete
                # SONU (e_recete_basarili) ve reçete BAŞI (e_recete_detay)
                # sayfaları AYRI işlenmeli. Yalnız rno ile anahtarlanırsa, eski
                # bir reçete açılıp önce reçete sonu görülünce, ardından E-Reçeteyi
                # Göster sayfasına dönülse bile reçete başı "görüldü" sayılıp
                # atlanıyordu (reçete başı hiç kurulmuyordu).
                #
                # İÇERİK İMZASI: anahtara ilaç listesinin imzası da eklenir. Reçeteden
                # ilaç çıkarılıp tekrar kaydedilince içerik (ve dolayısıyla hasta
                # ödeme/veresiye tutarları) değişir → imza değişir → reçete YENİDEN
                # yakalanır (etiketler + hasta tutarları güncellenir). İmza parse'tan
                # türetilir (deterministik); aynı içerikte sabit kalır → boş re-fire yok.
                dedup_key = f"{prescription.page_kind}:{rno}:{self._content_sig(prescription)}"
                if dedup_key in self._seen_recete_no:
                    continue
                self._seen_recete_no.add(dedup_key)
                log.info("Yeni e-reçete tespit edildi: %s (hasta=%s, ilaç=%d)",
                         rno, prescription.hasta_ad, len(prescription.drugs))
                try:
                    self._cb(prescription, html)
                except Exception as e:
                    log.error("callback error: %s", e, exc_info=True)

        # Pencere tema durumu: ön plandaki (veya popup'ı ön planda olan) Medula
        # penceresini ve temasını raporla. Çerçeve yalnız aktif pencerede gösterilir.
        if self._state_cb is not None:
            self._report_state(windows, theme_by_hwnd)

    def _report_state(self, windows, theme_by_hwnd: dict[int, str]) -> None:
        import ctypes
        u = ctypes.windll.user32
        fg = u.GetForegroundWindow()
        by_hwnd = {w.hwnd: w for w in windows}
        target = by_hwnd.get(fg)
        if target is None:
            # Ön plan bir Medula ana penceresi değil → aynı süreçten (popup) dene
            fg_pid = ctypes.c_ulong(0)
            u.GetWindowThreadProcessId(fg, ctypes.byref(fg_pid))
            target = next((w for w in windows if w.pid == fg_pid.value), None)
        try:
            if target is None:
                self._state_cb(None, None)
            else:
                self._state_cb(target.hwnd, theme_by_hwnd.get(target.hwnd))
        except Exception:
            log.debug("state callback hatası", exc_info=False)
