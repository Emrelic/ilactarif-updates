"""Kağıt reçete (manuel giriş) form parse + akış mantığı.

Medula `index.jsp` üzerinde form id=`f` ile sunulan kağıt reçete giriş
ekranını parse eder. Anahtar alanlar (örnek değerlerle):

  f:t18         → Hasta TC (11 hane)
  f:text37      → Teslim alan TC
  f:menu4       → Teslim alan ilişki (Kendisi/Yakını) — SELECT
  f:t24         → Protokol No
  f:t33         → Tesis No
  f:t29         → Reçete tarihi (DD/MM/YYYY)
  f:t43         → Doktor diploma no
  f:tableEx1:N:text7  → ICD kodu (N. satır, 0-based)
  f:tableEx1:N:text3  → Teşhis metni
  f:tbl1:N:t1   → İlaç barkodu (N. ilaç satırı)
  f:tbl1:N:t2   → Kutu adedi
  f:tbl1:N:t5   → Periyot sayısı (3 haftada bir → 3)
  f:tbl1:N:m1   → Periyot birim SELECT (Günde/Haftada/Ayda/Yılda)
  f:tbl1:N:t3   → Günlük kez (X)
  f:tbl1:N:t4   → Doz adet (Y)
  f:buttonReceteKaydet → kaydet butonu

Kayıt sonrası `class=receteSuccessMessage` SPAN'i görünür ve içinde
"Kayıt tamamlandı. Reçete numarası : XXX" yazar.
"""
from __future__ import annotations

import datetime
import re
from dataclasses import dataclass, field
from typing import Optional

from bs4 import BeautifulSoup


# ---------------------------------------------------------------------------
# Veri yapıları
# ---------------------------------------------------------------------------
@dataclass
class PaperDrug:
    barkod: str = ""
    ad: str = ""                  # f:tbl1:N:t6 → "FLAGYL 500 MG.20 TB."
    kutu: str = ""
    periyot_sayi: str = ""        # 3 haftada bir → "3"
    periyot_birim: str = ""       # "Günde" | "Haftada" | "Ayda" | "Yılda"
    gunluk_kez: str = ""          # X kez (örn. "2")
    doz_adet: str = ""            # Y adet (örn. "1")

    @property
    def is_filled(self) -> bool:
        return bool(self.barkod and self.barkod.strip() and self.barkod.strip() != "0")


@dataclass
class PaperDiagnosis:
    icd: str = ""
    metin: str = ""

    @property
    def is_filled(self) -> bool:
        return bool((self.icd or "").strip() or (self.metin or "").strip())


@dataclass
class PaperReceteForm:
    hasta_tc: str = ""
    hasta_ad: str = ""            # f:t15 (ad)
    hasta_soyad: str = ""         # f:t16 (soyad)
    teslim_alan_tc: str = ""
    teslim_alan_iliski: str = ""  # Kendisi / Yakını
    protokol_no: str = ""
    tesis_no: str = ""
    recete_tarihi: str = ""       # DD/MM/YYYY
    doktor_diploma: str = ""
    dr_ad: str = ""               # f:t41
    dr_soyad: str = ""            # f:t42
    tanılar: list[PaperDiagnosis] = field(default_factory=list)
    drugs: list[PaperDrug] = field(default_factory=list)

    # ---- Kayıt sonrası alanlar (varsa)
    recete_no: str = ""           # success mesajından alınan E-Reçete No

    @property
    def hasta_full(self) -> str:
        return f"{self.hasta_ad} {self.hasta_soyad}".strip()

    @property
    def dr_full(self) -> str:
        return f"{self.dr_ad} {self.dr_soyad}".strip()

    @property
    def filled_drugs(self) -> list[PaperDrug]:
        return [d for d in self.drugs if d.is_filled]

    @property
    def filled_tanılar(self) -> list[PaperDiagnosis]:
        return [t for t in self.tanılar if t.is_filled]


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------
_ROW_RE_TBL1 = re.compile(r"^f:tbl1:(\d+):t\d+$")
_ROW_RE_TANI = re.compile(r"^f:tableEx1:(\d+):text\d+$")


def _input_val(soup: BeautifulSoup, hid: str) -> str:
    el = soup.find(id=hid)
    if el is None:
        return ""
    # INPUT: value attribute
    val = el.get("value")
    if val is not None:
        return str(val).strip()
    # SPAN/text element: get_text
    return el.get_text(" ", strip=True)


# Medula periyot SELECT'leri için value→Türkçe isim (encoding bağımsız)
_PERIYOT_VALUE_MAP = {
    "3": "Günde",
    "4": "Haftada",
    "5": "Ayda",
    "6": "Yılda",
}


def _select_val(soup: BeautifulSoup, hid: str) -> str:
    """SELECT element için seçili OPTION'un text'i.

    Periyot SELECT'i ise (f:tbl1:*:m1) value→Türkçe isim eşlemesi kullanılır
    (HTML'in mojibake encoding'inden bağımsız sonuç).
    """
    el = soup.find(id=hid)
    if el is None:
        return ""
    opt = el.find("option", selected=True)
    if opt is None:
        opt = el.find("OPTION", selected=True)
    if opt is None:
        for o in el.find_all(["option", "OPTION"]):
            if o.get("selected") is not None:
                opt = o
                break
    if opt is None:
        opt = el.find(["option", "OPTION"])
    if opt is None:
        return ""
    # Periyot SELECT'i mi (id paterni :m1 ile biten kağıt reçete satırı)
    if hid.endswith(":m1"):
        v = (opt.get("value") or "").strip()
        if v in _PERIYOT_VALUE_MAP:
            return _PERIYOT_VALUE_MAP[v]
    return opt.get_text(" ", strip=True)


def is_paper_form_page(soup: BeautifulSoup) -> bool:
    """Sayfa kağıt reçete giriş formu mu?

    Heuristic: form id="f" + Hasta TC alanı (f:t18) + ilaç tablosu (f:tbl1:0:t1)
    + Kaydet butonu (f:buttonReceteKaydet)
    """
    has_form_f = soup.find(id="f") is not None or soup.find("form", attrs={"name": "f"}) is not None
    has_tc = soup.find(id="f:t18") is not None
    has_drug_row = soup.find(id="f:tbl1:0:t1") is not None
    has_save = soup.find(id="f:buttonReceteKaydet") is not None
    return bool(has_tc and has_drug_row and (has_save or has_form_f))


def parse_paper_success(soup: BeautifulSoup) -> Optional[str]:
    """Sayfada `class=receteSuccessMessage` SPAN'i varsa içindeki reçete no'yu döndür."""
    span = soup.find("span", class_="receteSuccessMessage") or soup.find(
        "SPAN", class_="receteSuccessMessage"
    )
    if span is None:
        # CSS class arama: bazı sürümlerde attribute case farklı
        for s in soup.find_all(["span", "SPAN"]):
            cls = s.get("class") or []
            if "receteSuccessMessage" in cls:
                span = s
                break
    if span is None:
        return None
    txt = span.get_text(" ", strip=True)
    # "Kayıt tamamlandı. Reçete numarası : 3NLQXU9"
    m = re.search(r":\s*([A-Z0-9]{6,12})\s*$", txt)
    if m:
        return m.group(1)
    return txt  # fallback olarak ham metin


def parse_paper_form(soup: BeautifulSoup) -> PaperReceteForm:
    """Sayfa kağıt reçete giriş formu ise tüm field'leri çek."""
    f = PaperReceteForm(
        hasta_tc=_input_val(soup, "f:t18"),
        hasta_ad=_input_val(soup, "f:t15"),
        hasta_soyad=_input_val(soup, "f:t16"),
        teslim_alan_tc=_input_val(soup, "f:text37"),
        teslim_alan_iliski=_select_val(soup, "f:menu4"),
        protokol_no=_input_val(soup, "f:t24"),
        tesis_no=_input_val(soup, "f:t33"),
        recete_tarihi=_input_val(soup, "f:t29"),
        doktor_diploma=_input_val(soup, "f:t43"),
        dr_ad=_input_val(soup, "f:t41"),
        dr_soyad=_input_val(soup, "f:t42"),
    )

    # Tanılar (ICD + metin) — f:tableEx1:N:text7 + f:tableEx1:N:text3
    indices: set[int] = set()
    for el in soup.find_all(attrs={"id": True}):
        m = _ROW_RE_TANI.match(el["id"])
        if m:
            indices.add(int(m.group(1)))
    for i in sorted(indices):
        f.tanılar.append(PaperDiagnosis(
            icd=_input_val(soup, f"f:tableEx1:{i}:text7"),
            metin=_input_val(soup, f"f:tableEx1:{i}:text3"),
        ))

    # İlaçlar — f:tbl1:N:t1..t5 (sadece numerik prefix'ler)
    drug_indices: set[int] = set()
    for el in soup.find_all(attrs={"id": True}):
        m = _ROW_RE_TBL1.match(el["id"])
        if m:
            drug_indices.add(int(m.group(1)))
    for i in sorted(drug_indices):
        d = PaperDrug(
            barkod=_input_val(soup, f"f:tbl1:{i}:t1"),
            ad=_input_val(soup, f"f:tbl1:{i}:t6"),
            kutu=_input_val(soup, f"f:tbl1:{i}:t2"),
            periyot_sayi=_input_val(soup, f"f:tbl1:{i}:t5"),
            periyot_birim=_select_val(soup, f"f:tbl1:{i}:m1"),
            gunluk_kez=_input_val(soup, f"f:tbl1:{i}:t3"),
            doz_adet=_input_val(soup, f"f:tbl1:{i}:t4"),
        )
        f.drugs.append(d)

    # Success mesajı (kayıt sonrası aynı sayfada görünür)
    rno = parse_paper_success(soup)
    if rno:
        f.recete_no = rno
    return f


# ---------------------------------------------------------------------------
# Fark karşılaştırma
# ---------------------------------------------------------------------------
def diff_forms(before: PaperReceteForm, after: PaperReceteForm) -> list[str]:
    """Kayıt-öncesi state ile kayıt-sonrası state arasındaki farkları döndür.

    Sadece "anlamlı" alanları karşılaştırır:
      - Her ilacın: kutu, periyot, doz, günlük kez
      - Tarih, protokol, tesis (genelde değişmez ama yine de bildir)
    """
    diffs: list[str] = []

    def _cmp(label: str, a: str, b: str):
        a = (a or "").strip()
        b = (b or "").strip()
        if a != b:
            diffs.append(f"{label}: «{a}» → «{b}»")

    _cmp("Protokol No", before.protokol_no, after.protokol_no)
    _cmp("Tesis No", before.tesis_no, after.tesis_no)
    _cmp("Reçete tarihi", before.recete_tarihi, after.recete_tarihi)

    # Barkod bazlı eşleştirme
    bmap = {d.barkod: d for d in before.filled_drugs}
    amap = {d.barkod: d for d in after.filled_drugs}
    for bk in sorted(set(bmap) | set(amap)):
        b = bmap.get(bk)
        a = amap.get(bk)
        if b and not a:
            diffs.append(f"İlaç {bk}: kaldırıldı")
            continue
        if a and not b:
            diffs.append(f"İlaç {bk}: eklendi")
            continue
        # ikisi de var → alanları karşılaştır
        _cmp(f"[{bk}] Kutu", b.kutu, a.kutu)
        _cmp(f"[{bk}] Periyot sayı", b.periyot_sayi, a.periyot_sayi)
        _cmp(f"[{bk}] Periyot birim", b.periyot_birim, a.periyot_birim)
        _cmp(f"[{bk}] Günlük kez", b.gunluk_kez, a.gunluk_kez)
        _cmp(f"[{bk}] Doz adet", b.doz_adet, a.doz_adet)

    return diffs


# ---------------------------------------------------------------------------
# Etiket üretimi için: PaperReceteForm → PrescriptionCapture
# ---------------------------------------------------------------------------
def _ascii_lower(s: str) -> str:
    import unicodedata
    n = unicodedata.normalize("NFKD", s or "")
    # ü→u, ı→i, ş→s, ğ→g, ç→c, ö→o (combining marks atılır, türkçe i/ı için manuel)
    out = "".join(c for c in n if not unicodedata.combining(c))
    table = {"ı": "i", "İ": "i", "ş": "s", "Ş": "s", "ğ": "g", "Ğ": "g"}
    for k, v in table.items():
        out = out.replace(k, v)
    return out.lower()


def _medula_nz(v: str) -> str:
    """Medula doz alanı boş/sıfırsa 1'e çevirir.

    Kağıt reçete girişinde periyodu (Günde N kez) yazıp "kaç adet" alanını boş
    veya 0 bırakınca Medula bu değeri 1 olarak işler. Etiket de aynı varsayımı
    kullanmalı: "2 x 0" yerine "2 x 1". Boş/0/0,0 → "1"; aksi halde olduğu gibi.
    """
    s = (v or "").strip().replace(",", ".")
    try:
        if float(s) <= 0:
            return "1"
    except ValueError:
        return s or "1"
    # Orijinal biçimi koru (virgül ondalık dahil): "1" / "2" / "1,5"
    return (v or "").strip()


def _periyot_to_gunluk_kez(p_sayi: str, p_birim: str, kez: str) -> Optional[int]:
    """Periyot Günde ise kez doğrudan; haftada/ayda/yılda ise günlük ortalama
    (yuvarlanmamış float değil; tam sayı olarak günlük; küsuratlıysa None bırak).
    """
    try:
        n = int(kez or 0)
    except Exception:
        n = 0
    if n <= 0:
        return None
    birim = _ascii_lower(p_birim)
    try:
        psay = int(p_sayi or 1)
    except Exception:
        psay = 1
    if psay <= 0:
        psay = 1
    # "günde" / "gunde" / boş → günde
    if not birim or birim.startswith("gund"):
        return n
    # Haftada / Ayda / Yılda: kabaca ölçeklenir; ama etiket talimatında
    # "Haftada 3x1" daha anlamlı olduğundan günlük_kez=None bırakıyoruz
    return None


def paper_to_capture(form: PaperReceteForm, drug_name_lookup) -> "PrescriptionCapture":
    """Paper form → PrescriptionCapture (auto_label_builder ile uyumlu).

    drug_name_lookup(barkod: str) -> str  — barkodtan ilaç adı çözen fn
    (genelde DB'de drugs tablosuna bakar).
    """
    from .medula_parser import CapturedDrug, PrescriptionCapture

    cap = PrescriptionCapture(
        page_kind="kagit_recete",
        document_url="",
        hasta_ad=form.hasta_full,
        hasta_tc=form.hasta_tc,
        recete_no=form.recete_no,
        recete_tarihi=form.recete_tarihi,
        dr_ad=form.dr_full,
        dr_brans="",
        tanılar=[(t.icd, t.metin) for t in form.filled_tanılar],
        eczane="",
    )
    for d in form.filled_drugs:
        # İlaç adı için öncelik: form'daki SPAN (Medula AJAX ile dolduruldu),
        # yoksa DB lookup, son çare olarak "(Barkod: X)"
        ad = d.ad.strip()
        if not ad and drug_name_lookup:
            ad = drug_name_lookup(d.barkod) or ""
        # Medula boş/0 doz alanlarını 1 sayar: "Günde 2 kez x (boş)" → 2x1.
        kez_s = _medula_nz(d.gunluk_kez)
        doz_s = _medula_nz(d.doz_adet)
        gunluk = _periyot_to_gunluk_kez(d.periyot_sayi, d.periyot_birim, kez_s)
        # Doz adet (Y) → float
        try:
            doz_adet_f = float((doz_s or "0").replace(",", "."))
        except Exception:
            doz_adet_f = None

        # Ham doz açıklaması (etiket talimatında kullanılır)
        periyot_str = ""
        if d.periyot_sayi and d.periyot_birim and d.periyot_sayi.strip() not in ("", "0"):
            periyot_str = f"{d.periyot_sayi} {d.periyot_birim.lower()} "
        doz_ham = f"{periyot_str}{kez_s} x {doz_s}".strip()

        cap.drugs.append(CapturedDrug(
            barkod=d.barkod,
            ad=ad or f"(Barkod: {d.barkod})",
            adet=(d.kutu if d.kutu.strip() not in ("", "0") else ""),
            doz_ham=doz_ham,
            doz_gunluk_kez=gunluk,
            doz_birim_adedi=(doz_adet_f if doz_adet_f and doz_adet_f > 0 else None),
            doz_birim="",
            periyot=d.periyot_birim,
            kullanim_sekli="",
        ))
    return cap
