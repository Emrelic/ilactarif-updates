"""İlaçTarif sürüm bilgisi — çalışma zamanında okunur, otomatik güncelleme
karşılaştırması bunu kullanır.

ÖNEMLİ: Bu dosya `build.ps1` tarafından her derlemede OTOMATİK yazılır ve
setup.iss'teki BuildNo ile SENKRON tutulur. Elle değiştirmeyin — derlemede
üzerine yazılır. (Rehber: "MyAppVersion == uygulama sürümü" kuralı.)
"""

BASE_VERSION = "1.0"
BUILD_NO = 41
SURUM = f"{BASE_VERSION}.{BUILD_NO}"   # ör. "1.0.40"
