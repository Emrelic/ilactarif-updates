"""Windows'un kendi global kısayol sistemi (RegisterHotKey) ile kısayol kaydı.

NEDEN: 'keyboard' kütüphanesi Shift/Ctrl durumunu kendi alçak seviye
kancasından (LL hook) gelen olaylarla tutar. NumLock AÇIKKEN klavye sürücüsü
gri End/Home/Insert/Delete/PgUp/PgDn tuşlarından önce SAHTE bir "Shift
bırakıldı" olayı üretir; kütüphane bunu gerçek sanıp Shift'i bırakılmış
sayar ve 'shift+end' gibi kısayollar HİÇ tetiklenmez (ölçülen vaka: logda
shift+end ve shift+insert sıfır kez algılanmış, NumLock açık).

RegisterHotKey eşleştirmeyi Windows'a bırakır: Windows'un tuş durumu sahte
Shift'ten etkilenmez (Not Defteri'nde Shift+End seçim yapabilmesi bundan).
Ek olarak tuş yalnız bizim işe gider, odaktaki uygulamaya sızmaz — Medula'nın
kendi kısayoluyla çakışma da biter (keyboard'un suppress=True'su ise Ctrl/
Shift'i asılı bırakabildiği için kullanılamıyordu).

Kullanım: register('shift+end', fn) → kaldırma fonksiyonu, ya da None
(tuş tanınmadı / başka bir program bu kısayolu almış). None dönerse çağıran
'keyboard' kütüphanesine geri düşer.
"""
from __future__ import annotations

import ctypes
import logging
import queue
import sys
import threading
from ctypes import wintypes
from typing import Callable, Optional

log = logging.getLogger(__name__)

MOD_ALT, MOD_CONTROL, MOD_SHIFT = 0x0001, 0x0002, 0x0004
MOD_NOREPEAT = 0x4000      # basılı tutunca tekrar ateşleme yok
WM_HOTKEY = 0x0312
WM_APP = 0x8000

_MODS = {"ctrl": MOD_CONTROL, "control": MOD_CONTROL,
         "alt": MOD_ALT, "shift": MOD_SHIFT}

# Ayarlarda saklanan ('keyboard' kütüphanesi) tuş adları → sanal tuş kodu
_VK: dict[str, int] = {
    "home": 0x24, "end": 0x23,
    "page_up": 0x21, "page up": 0x21, "page_down": 0x22, "page down": 0x22,
    "insert": 0x2D, "delete": 0x2E, "backspace": 0x08,
    "tab": 0x09, "enter": 0x0D, "esc": 0x1B, "escape": 0x1B, "space": 0x20,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "print_screen": 0x2C, "print screen": 0x2C,
    "scroll_lock": 0x91, "scroll lock": 0x91, "pause": 0x13,
    "num *": 0x6A, "num +": 0x6B, "num -": 0x6D,
    "num decimal": 0x6E, "num /": 0x6F,
}
_VK.update({f"f{i}": 0x6F + i for i in range(1, 25)})
_VK.update({f"num {i}": 0x60 + i for i in range(10)})


def parse_combo(combo: str) -> Optional[tuple[int, int]]:
    """'ctrl+shift+end' → (mods, vk). Tanınmayan tuşta None."""
    parts = [p.strip().lower() for p in (combo or "").split("+") if p.strip()]
    mods, keys = 0, []
    for p in parts:
        if p in _MODS:
            mods |= _MODS[p]
        else:
            keys.append(p)
    if len(keys) != 1:
        return None
    key = keys[0]
    vk = _VK.get(key)
    if vk is None and len(key) == 1:
        # Harf/rakam: etkin klavye düzenine göre çöz ('keyboard' da böyle
        # yapar — Türkçe Q'da 'i' karakteri İ tuşundadır, I tuşunda değil).
        r = ctypes.windll.user32.VkKeyScanW(ord(key))
        if r != -1 and (r & 0xFF) != 0xFF:
            vk = r & 0xFF
    if vk is None:
        return None
    return mods, vk


class _Manager:
    """Kendi mesaj döngüsü olan tek bir arka plan iş parçacığı.

    RegisterHotKey(hwnd=NULL) WM_HOTKEY'i ÇAĞIRAN iş parçacığının kuyruğuna
    yollar; bu yüzden kayıt/silme de o iş parçacığında yapılmak zorunda.
    """

    def __init__(self):
        self._ops: queue.Queue = queue.Queue()
        self._callbacks: dict[int, Callable] = {}
        self._next_id = 1
        self._tid = 0
        self._ready = threading.Event()
        u = ctypes.windll.user32
        u.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND,
                                  wintypes.UINT, wintypes.UINT]
        u.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND,
                                   wintypes.UINT, wintypes.UINT, wintypes.UINT]
        u.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT,
                                         wintypes.WPARAM, wintypes.LPARAM]
        u.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int,
                                     wintypes.UINT, wintypes.UINT]
        u.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
        self._u = u
        threading.Thread(target=self._loop, name="win-hotkey",
                         daemon=True).start()
        if not self._ready.wait(3):
            raise RuntimeError("kısayol iş parçacığı başlamadı")

    def _loop(self):
        u = self._u
        msg = wintypes.MSG()
        u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)   # kuyruğu oluştur
        self._tid = ctypes.windll.kernel32.GetCurrentThreadId()
        self._ready.set()
        while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if msg.message == WM_HOTKEY:
                fn = self._callbacks.get(int(msg.wParam))
                if fn is not None:
                    try:
                        fn()
                    except Exception:
                        log.exception("Kısayol işlevi hata verdi")
            elif msg.message == WM_APP:
                self._run_ops()

    def _run_ops(self):
        while True:
            try:
                op, args, done, out = self._ops.get_nowait()
            except queue.Empty:
                return
            try:
                if op == "reg":
                    mods, vk, fn = args
                    hid = self._next_id
                    self._next_id += 1
                    if self._u.RegisterHotKey(None, hid, mods | MOD_NOREPEAT, vk):
                        self._callbacks[hid] = fn
                        out.append(hid)
                    else:
                        out.append(-ctypes.GetLastError() or -1)
                elif op == "unreg":
                    (hid,) = args
                    self._u.UnregisterHotKey(None, hid)
                    self._callbacks.pop(hid, None)
            finally:
                done.set()

    def _call(self, op: str, *args) -> list:
        done, out = threading.Event(), []
        self._ops.put((op, args, done, out))
        self._u.PostThreadMessageW(self._tid, WM_APP, 0, 0)
        done.wait(3)
        return out

    def register(self, mods: int, vk: int, fn: Callable) -> int:
        out = self._call("reg", mods, vk, fn)
        return out[0] if out else -1

    def unregister(self, hid: int) -> None:
        self._call("unreg", hid)


_manager: Optional[_Manager] = None
_manager_lock = threading.Lock()


def register(combo: str, fn: Callable) -> Optional[Callable[[], None]]:
    """Kısayolu Windows'a kaydet. Başarılıysa kaldırma fonksiyonu, değilse None."""
    global _manager
    if sys.platform != "win32":
        return None
    parsed = parse_combo(combo)
    if parsed is None:
        log.info("Kısayol Windows sistemine uygun değil [%s] — keyboard'a düşülüyor", combo)
        return None
    with _manager_lock:
        if _manager is None:
            _manager = _Manager()
        mgr = _manager
    hid = mgr.register(parsed[0], parsed[1], fn)
    if hid <= 0:
        # 1409 = ERROR_HOTKEY_ALREADY_REGISTERED (başka program / ikinci kopya)
        log.warning("Windows kısayolu alınamadı [%s] (hata %d) — keyboard'a düşülüyor",
                    combo, -hid)
        return None
    return lambda: mgr.unregister(hid)
