"""İlaçTarif — uygulama içi otomatik güncelleyici (GitHub kanalı).

Akış:
  1. Açılışta arka planda GitHub'daki manifest'i (latest.json) çeker.
  2. Uzak BUILD_NO, yereldeki surum.BUILD_NO'dan büyükse kullanıcıya notlarla
     birlikte sorar ("Şimdi güncelle?").
  3. Onaylanırsa güncelleme paketini (ilactarif_update.zip) indirir, sha256
     doğrular, byte-compile ile bozuk mu diye bakar, {app}/_update_staging'e açar.
  4. Harici uygulayıcıyı (tools\apply_update.py) başlatır ve programı kapatır.
     Uygulayıcı: eski src+App.pyw'yi yedekler, yenisini kopyalar, yeniden açar.

Sadece stdlib kullanır (urllib/zipfile/hashlib) — ek paket gerekmez.
Geliştirme makinesinde ({app}/.git varsa) HİÇ çalışmaz.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import urllib.request
import zipfile
from pathlib import Path

log = logging.getLogger(__name__)

# --- Yayın kanalı (GitHub raw) ---------------------------------------------
#  Repo public: Emrelic/ilactarif-updates. Sabit ham (raw) URL'ler — değişmez.
RAW_BASE = "https://raw.githubusercontent.com/Emrelic/ilactarif-updates/main"
MANIFEST_URL = RAW_BASE + "/latest.json"

# updater.py → src/ilactarif/updater.py  ⇒  parents[2] = {app}
APP_ROOT = Path(__file__).resolve().parents[2]
STAGING = APP_ROOT / "_update_staging"
STAGING_ZIP = APP_ROOT / "_update_staging.zip"
BACKUP = APP_ROOT / "_update_backup"


def _local_build() -> int:
    try:
        from . import surum
        return int(getattr(surum, "BUILD_NO", 0))
    except Exception:
        return 0


def _is_dev() -> bool:
    """Geliştirme makinesi (git deposu) → güncelleyiciyi çalıştırma."""
    return (APP_ROOT / ".git").exists()


def _http_get(url: str, timeout: float = 20.0) -> bytes:
    # CDN önbelleğini atlamak için basit cache-buster (manifest tazeliği önemli)
    sep = "&" if "?" in url else "?"
    full = f"{url}{sep}cb={os.getpid()}"
    req = urllib.request.Request(
        full, headers={"User-Agent": "IlacTarif-Updater",
                       "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_manifest() -> dict | None:
    try:
        data = _http_get(MANIFEST_URL, timeout=15)
        m = json.loads(data.decode("utf-8"))
        if not isinstance(m, dict) or "build_no" not in m:
            return None
        return m
    except Exception as e:
        log.info("Güncelleme kontrolü yapılamadı: %s", e)
        return None


def cleanup_after_launch() -> None:
    """Önceki güncelleme başarıyla açıldıysa (bu process çalışıyorsa) yedek/staging
    artıklarını temizle. Açılışta çağrılır."""
    for p in (STAGING, BACKUP):
        try:
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)
        except Exception:
            pass
    try:
        if STAGING_ZIP.exists():
            STAGING_ZIP.unlink()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Açılıştan çağrılan tek giriş noktası
# ---------------------------------------------------------------------------
def check_async(root) -> None:
    """Arka planda güncelleme kontrolü başlatır. Güncelleme varsa Tk ana
    thread'inde kullanıcıya sorar. root = Tk uygulaması."""
    if _is_dev():
        log.info("Geliştirme makinesi — güncelleme kontrolü atlandı.")
        return

    def _work():
        m = fetch_manifest()
        if not m:
            return
        try:
            remote = int(m.get("build_no", 0))
        except Exception:
            return
        local = _local_build()
        log.info("Güncelleme kontrolü: yerel=%s uzak=%s", local, remote)
        if remote > local:
            # Kullanıcı bu sürümü 'Sonra' ile ertelediyse tekrar sorma
            # (daha YENİ bir sürüm çıkarsa yine sorulur).
            if remote == getattr(root, "_update_declined_build", None):
                return
            try:
                root.after(0, lambda: _prompt(root, m))
            except Exception:
                pass

    threading.Thread(target=_work, daemon=True).start()


def _prompt(root, m: dict) -> None:
    """Tasarımlı güncelleme penceresi; açılamazsa basit messagebox'a düşer."""
    try:
        _show_update_dialog(root, m)
    except Exception:
        log.exception("Güncelleme penceresi açılamadı → messagebox")
        _prompt_fallback(root, m)


def _prompt_fallback(root, m: dict) -> None:
    from tkinter import messagebox
    surum = m.get("surum", str(m.get("build_no", "?")))
    notlar = (m.get("notlar") or "").strip() or "(not yok)"
    if messagebox.askyesno(
            "Güncelleme Var",
            f"Yeni sürüm: {surum}\n\n{notlar}\n\nŞimdi güncellensin mi?",
            parent=root):
        _start_download(root, m)
    else:
        setattr(root, "_update_declined_build", int(m.get("build_no", 0)))


def _show_update_dialog(root, m: dict) -> None:
    import tkinter as tk
    from tkinter import ttk
    from .ui.manual_label_ui import COLORS as C

    surum = m.get("surum", str(m.get("build_no", "?")))
    notlar = (m.get("notlar") or "").strip() or "(değişiklik notu belirtilmemiş)"
    tarih = str(m.get("tarih", "")).strip()
    zorunlu = bool(m.get("zorunlu", False))
    try:
        yerel_s = f"1.0.{_local_build()}"
    except Exception:
        yerel_s = ""

    # ⚠️ TEPSİ KİPİ (2026-09-23'te ölçüldü — güncellemenin 19 gün gelmeme sebebi)
    # Program boot'ta `--tray` ile gizli başlar; ana pencere `withdraw` edilir.
    # Tk, master'ı withdraw edilmiş bir `transient` çocuğu DA withdraw eder;
    # gizli pencerede lift/topmost/focus_force hiçbir şey yapmaz:
    #     transient + gizli root -> state=withdrawn  ismapped=False
    #     transient DEĞİL        -> state=normal     ismapped=True
    # Yani kutu her saat açılıyor, kimse GÖREMİYOR ("yerel=44 uzak=47" ×19 gün).
    # Gizliyken transient kurulmaz, kutu kendi başına ve ekranın ortasında çıkar.
    try:
        gizli = root.state() == "withdrawn"
    except Exception:
        log.debug("root.state() okunamadı — pencere görünür sayılıyor", exc_info=True)
        gizli = False

    dlg = tk.Toplevel(root)
    dlg.title("İlaç Tarif — Güncelleme")
    if not gizli:
        dlg.transient(root)
    dlg.resizable(False, False)
    dlg.configure(background=C["bg_main"])

    # --- Üst şerit (sarı): başlık + sürüm ---
    head = tk.Frame(dlg, background=C["bg_card"])
    head.pack(fill="x")
    tk.Label(head, text="🎉  Yeni Sürüm Hazır", background=C["bg_card"],
             foreground=C["text_dark"], font=("Segoe UI", 15, "bold"),
             anchor="w").pack(fill="x", padx=20, pady=(14, 2))
    sub = (f"Sürüm {yerel_s}  →  {surum}" if yerel_s else f"Sürüm {surum}")
    if tarih:
        sub += f"        {tarih}"
    tk.Label(head, text=sub, background=C["bg_card"], foreground=C["text_dark"],
             font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x", padx=20, pady=(0, 14))

    # --- Gövde: değişiklik notları ---
    body = tk.Frame(dlg, background=C["bg_main"])
    body.pack(fill="both", expand=True, padx=20, pady=(14, 6))
    tk.Label(body, text="Bu güncellemedeki değişiklikler:", background=C["bg_main"],
             foreground=C["text_yellow"], font=("Segoe UI", 10, "bold"),
             anchor="w").pack(fill="x", pady=(0, 6))

    nbox = tk.Text(body, height=6, width=54, wrap="word", relief="flat",
                   background="white", foreground=C["text_dark"],
                   font=("Segoe UI", 10), padx=12, pady=10, cursor="arrow")
    for parca in notlar.replace("; ", "\n").replace(" - ", "\n").split("\n"):
        parca = parca.strip(" -•\t")
        if parca:
            nbox.insert("end", f"•  {parca}\n")
    nbox.configure(state="disabled")
    nbox.pack(fill="both", expand=True)

    tk.Label(body,
             text="Onaylarsanız program kapanıp otomatik yeniden açılır — "
                  "verileriniz ve ayarlarınız korunur.",
             background=C["bg_main"], foreground=C["text_muted"],
             font=("Segoe UI", 9), wraplength=440, justify="left",
             anchor="w").pack(fill="x", pady=(10, 0))
    if zorunlu:
        tk.Label(body, text="⚠ Bu güncelleme zorunludur.", background=C["bg_main"],
                 foreground=C.get("accent_red", "#ef4444"),
                 font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x", pady=(4, 0))

    # --- Butonlar ---
    btns = tk.Frame(dlg, background=C["bg_main"])
    btns.pack(fill="x", padx=20, pady=(8, 18))

    def _yes():
        log.info("Güncelleme: kullanıcı ONAYLADI (%s)", surum)
        dlg.destroy()
        _start_download(root, m)

    def _later():
        # Sessiz kalmasın: "kutu görünmedi" ile "görüldü, ertelendi" log'da ayrılsın.
        log.info("Güncelleme: kullanıcı ERTELEDİ (%s)", surum)
        setattr(root, "_update_declined_build", int(m.get("build_no", 0)))
        dlg.destroy()

    ttk.Button(btns, text="⬇   Şimdi Güncelle", style="Accent.TButton",
               command=_yes).pack(side="right", ipady=5, ipadx=6)
    if not zorunlu:
        ttk.Button(btns, text="Sonra Hatırlat",
                   command=_later).pack(side="right", padx=(0, 8))

    dlg.protocol("WM_DELETE_WINDOW", (lambda: None) if zorunlu else _later)
    dlg.bind("<Return>", lambda e: _yes())
    if not zorunlu:
        dlg.bind("<Escape>", lambda e: _later())

    # Ortala + öne getir (tepside/otomatik açılışta da görünsün) + modal
    dlg.update_idletasks()
    try:
        if gizli:
            # Gizli pencerenin koordinatı anlamsızdır — EKRANIN ortasına al.
            px = (dlg.winfo_screenwidth() - dlg.winfo_width()) // 2
            py = (dlg.winfo_screenheight() - dlg.winfo_height()) // 3
        else:
            px = root.winfo_rootx() + (root.winfo_width() - dlg.winfo_width()) // 2
            py = root.winfo_rooty() + (root.winfo_height() - dlg.winfo_height()) // 3
        dlg.geometry(f"+{max(0, px)}+{max(0, py)}")
    except Exception:
        pass
    try:
        dlg.grab_set()
    except Exception:
        pass
    dlg.deiconify()
    dlg.lift()
    dlg.attributes("-topmost", True)
    dlg.after(400, lambda: dlg.attributes("-topmost", False))
    dlg.focus_force()
    # A1 — sessiz kalmasın: kutu GERÇEKTEN ekrana geldi mi, log'dan ölçülebilsin.
    try:
        dlg.update_idletasks()
        log.info("Güncelleme penceresi: tepsi=%s durum=%s ekranda=%s (uzak=%s)",
                 gizli, dlg.state(), bool(dlg.winfo_ismapped()), surum)
    except Exception:
        log.debug("Güncelleme penceresinin durumu okunamadı", exc_info=True)


def _start_download(root, m: dict) -> None:
    # Küçük "indiriliyor" durumu — kullanıcı beklediğini bilsin
    try:
        root.title(root.title() + "  —  Güncelleme indiriliyor…")
    except Exception:
        pass

    def _work():
        ok, err = _download_verify_extract(m)
        if ok:
            root.after(0, lambda: _apply_and_quit(root))
        else:
            def _fail():
                from tkinter import messagebox
                messagebox.showerror(
                    "Güncelleme Başarısız",
                    f"Güncelleme uygulanamadı:\n{err}\n\nProgram normal çalışmaya "
                    "devam ediyor; daha sonra tekrar denenecek.", parent=root)
            root.after(0, _fail)

    threading.Thread(target=_work, daemon=True).start()


def _download_verify_extract(m: dict) -> tuple[bool, str]:
    zip_url = m.get("zip_url") or (RAW_BASE + "/ilactarif_update.zip")
    want_sha = (m.get("sha256") or "").lower().strip()
    try:
        blob = _http_get(zip_url, timeout=60)
    except Exception as e:
        return False, f"İndirme hatası: {e}"

    if want_sha:
        got = hashlib.sha256(blob).hexdigest()
        if got != want_sha:
            return False, "Dosya bütünlüğü (sha256) doğrulanamadı."

    # Aç → staging
    try:
        if STAGING.exists():
            shutil.rmtree(STAGING, ignore_errors=True)
        STAGING.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            z.extractall(STAGING)
    except Exception as e:
        return False, f"Paket açılamadı: {e}"

    # Bozuk mu? Yeni App.pyw + src'yi byte-compile ile dene
    try:
        import py_compile
        app_new = STAGING / "App.pyw"
        if app_new.exists():
            py_compile.compile(str(app_new), doraise=True)
        for py in (STAGING / "src").rglob("*.py"):
            py_compile.compile(str(py), doraise=True)
    except Exception as e:
        shutil.rmtree(STAGING, ignore_errors=True)
        return False, f"Paket geçersiz (derlenemedi): {e}"

    return True, ""


def _apply_and_quit(root) -> None:
    """Harici uygulayıcıyı başlat, sonra programı kapat."""
    applier = APP_ROOT / "tools" / "apply_update.py"
    pyw = sys.executable  # pythonw.exe (konsolsuz)
    try:
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0x00000008) \
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
        subprocess.Popen(
            [pyw, str(applier), str(APP_ROOT), str(STAGING)],
            cwd=str(APP_ROOT), creationflags=flags, close_fds=True)
    except Exception as e:
        from tkinter import messagebox
        messagebox.showerror("Güncelleme", f"Uygulayıcı başlatılamadı:\n{e}",
                             parent=root)
        return
    # Programı kapat — uygulayıcı kapanmayı bekleyip dosyaları değiştirecek
    try:
        root.destroy()
    except Exception:
        pass
    os._exit(0)
