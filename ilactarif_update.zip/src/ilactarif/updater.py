"""İlaçTarif — uygulama içi otomatik güncelleyici (GitHub kanalı).

Akış:
  1. Açılışta arka planda GitHub'daki manifest'i (latest.json) çeker.
  2. Uzak BUILD_NO, yereldeki surum.BUILD_NO'dan büyükse kullanıcıya notlarla
     birlikte sorar ("Şimdi güncelle?").
  3. Onaylanırsa güncelleme paketini (ilactarif_update.zip) indirir, sha256
     doğrular, byte-compile ile bozuk mu diye bakar, {app}/_update_staging'e açar.
  4. Harici uygulayıcıyı (tools\apply_update.py) başlatır ve programı kapatır.
     Uygulayıcı: eski src+App.pyw'yi yedekler, yenisini kopyalar, yeniden açar.

Sadece stdlib kullanır (urllib/zipfile/hashlib) — ek paket gerekmez.
Geliştirme makinesinde ({app}/.git varsa) HİÇ çalışmaz.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import urllib.request
import zipfile
from pathlib import Path

log = logging.getLogger(__name__)

# --- Yayın kanalı (GitHub raw) ---------------------------------------------
#  Repo public: Emrelic/ilactarif-updates. Sabit ham (raw) URL'ler — değişmez.
RAW_BASE = "https://raw.githubusercontent.com/Emrelic/ilactarif-updates/main"
MANIFEST_URL = RAW_BASE + "/latest.json"

# updater.py → src/ilactarif/updater.py  ⇒  parents[2] = {app}
APP_ROOT = Path(__file__).resolve().parents[2]
STAGING = APP_ROOT / "_update_staging"
STAGING_ZIP = APP_ROOT / "_update_staging.zip"
BACKUP = APP_ROOT / "_update_backup"


def _local_build() -> int:
    try:
        from . import surum
        return int(getattr(surum, "BUILD_NO", 0))
    except Exception:
        return 0


def _is_dev() -> bool:
    """Geliştirme makinesi (git deposu) → güncelleyiciyi çalıştırma."""
    return (APP_ROOT / ".git").exists()


def _http_get(url: str, timeout: float = 20.0) -> bytes:
    # CDN önbelleğini atlamak için basit cache-buster (manifest tazeliği önemli)
    sep = "&" if "?" in url else "?"
    full = f"{url}{sep}cb={os.getpid()}"
    req = urllib.request.Request(
        full, headers={"User-Agent": "IlacTarif-Updater",
                       "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_manifest() -> dict | None:
    try:
        data = _http_get(MANIFEST_URL, timeout=15)
        m = json.loads(data.decode("utf-8"))
        if not isinstance(m, dict) or "build_no" not in m:
            return None
        return m
    except Exception as e:
        log.info("Güncelleme kontrolü yapılamadı: %s", e)
        return None


def cleanup_after_launch() -> None:
    """Önceki güncelleme başarıyla açıldıysa (bu process çalışıyorsa) yedek/staging
    artıklarını temizle. Açılışta çağrılır."""
    for p in (STAGING, BACKUP):
        try:
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)
        except Exception:
            pass
    try:
        if STAGING_ZIP.exists():
            STAGING_ZIP.unlink()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Açılıştan çağrılan tek giriş noktası
# ---------------------------------------------------------------------------
def check_async(root) -> None:
    """Arka planda güncelleme kontrolü başlatır. Güncelleme varsa Tk ana
    thread'inde kullanıcıya sorar. root = Tk uygulaması."""
    if _is_dev():
        log.info("Geliştirme makinesi — güncelleme kontrolü atlandı.")
        return

    def _work():
        m = fetch_manifest()
        if not m:
            return
        try:
            remote = int(m.get("build_no", 0))
        except Exception:
            return
        local = _local_build()
        log.info("Güncelleme kontrolü: yerel=%s uzak=%s", local, remote)
        if remote > local:
            try:
                root.after(0, lambda: _prompt(root, m))
            except Exception:
                pass

    threading.Thread(target=_work, daemon=True).start()


def _prompt(root, m: dict) -> None:
    from tkinter import messagebox
    surum = m.get("surum", str(m.get("build_no", "?")))
    notlar = (m.get("notlar") or "").strip() or "(not belirtilmemiş)"
    zorunlu = bool(m.get("zorunlu", False))
    msg = (f"Yeni sürüm hazır: {surum}\n\n"
           f"Değişiklikler:\n{notlar}\n\n"
           "Şimdi güncellensin mi? Program kapanıp otomatik yeniden açılacak.")
    if zorunlu:
        messagebox.showinfo("Zorunlu Güncelleme", msg + "\n\n(Bu güncelleme zorunludur.)",
                            parent=root)
        _start_download(root, m)
        return
    if messagebox.askyesno("Güncelleme Var", msg, parent=root):
        _start_download(root, m)


def _start_download(root, m: dict) -> None:
    # Küçük "indiriliyor" durumu — kullanıcı beklediğini bilsin
    try:
        root.title(root.title() + "  —  Güncelleme indiriliyor…")
    except Exception:
        pass

    def _work():
        ok, err = _download_verify_extract(m)
        if ok:
            root.after(0, lambda: _apply_and_quit(root))
        else:
            def _fail():
                from tkinter import messagebox
                messagebox.showerror(
                    "Güncelleme Başarısız",
                    f"Güncelleme uygulanamadı:\n{err}\n\nProgram normal çalışmaya "
                    "devam ediyor; daha sonra tekrar denenecek.", parent=root)
            root.after(0, _fail)

    threading.Thread(target=_work, daemon=True).start()


def _download_verify_extract(m: dict) -> tuple[bool, str]:
    zip_url = m.get("zip_url") or (RAW_BASE + "/ilactarif_update.zip")
    want_sha = (m.get("sha256") or "").lower().strip()
    try:
        blob = _http_get(zip_url, timeout=60)
    except Exception as e:
        return False, f"İndirme hatası: {e}"

    if want_sha:
        got = hashlib.sha256(blob).hexdigest()
        if got != want_sha:
            return False, "Dosya bütünlüğü (sha256) doğrulanamadı."

    # Aç → staging
    try:
        if STAGING.exists():
            shutil.rmtree(STAGING, ignore_errors=True)
        STAGING.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            z.extractall(STAGING)
    except Exception as e:
        return False, f"Paket açılamadı: {e}"

    # Bozuk mu? Yeni App.pyw + src'yi byte-compile ile dene
    try:
        import py_compile
        app_new = STAGING / "App.pyw"
        if app_new.exists():
            py_compile.compile(str(app_new), doraise=True)
        for py in (STAGING / "src").rglob("*.py"):
            py_compile.compile(str(py), doraise=True)
    except Exception as e:
        shutil.rmtree(STAGING, ignore_errors=True)
        return False, f"Paket geçersiz (derlenemedi): {e}"

    return True, ""


def _apply_and_quit(root) -> None:
    """Harici uygulayıcıyı başlat, sonra programı kapat."""
    applier = APP_ROOT / "tools" / "apply_update.py"
    pyw = sys.executable  # pythonw.exe (konsolsuz)
    try:
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0x00000008) \
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
        subprocess.Popen(
            [pyw, str(applier), str(APP_ROOT), str(STAGING)],
            cwd=str(APP_ROOT), creationflags=flags, close_fds=True)
    except Exception as e:
        from tkinter import messagebox
        messagebox.showerror("Güncelleme", f"Uygulayıcı başlatılamadı:\n{e}",
                             parent=root)
        return
    # Programı kapat — uygulayıcı kapanmayı bekleyip dosyaları değiştirecek
    try:
        root.destroy()
    except Exception:
        pass
    os._exit(0)
