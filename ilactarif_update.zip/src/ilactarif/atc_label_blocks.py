"""ATC kategorisi bazlı bilgi bloğu kütüphanesi.

Her indication_short kategorisi için 5-7 farklı blok içeriği tutar:
  - dikkat      (Kullanmadan önce dikkat — kontrendikasyon, gebelik, yaş, araç)
  - etkilesim   (İlaç-ilaç ve besin etkileşimleri)
  - yan_etki    (Sık görülenler + CİDDİ/ACİL belirtiler)
  - sonlandirma (Tedavi nasıl bırakılır: bitir / şikayet geçince / kademeli)
  - hatirlatma  (Genel hatırlatmalar: ameliyat öncesi bildir, başkası kullanmasın vb.)

Saklama, sıvı tüketimi ve hazırlama blokları FORM bazlı türetilir
(`generate_form_blocks()`).

Top 100 ilaç manuel doldurulmuş olduğu için INSERT OR IGNORE ile korunur;
buradaki içerikler kalan ~3686 ilaca uygulanır.
"""
from __future__ import annotations

from typing import TypedDict


class CategoryBlocks(TypedDict, total=False):
    dikkat: str
    etkilesim: str
    yan_etki: str
    sonlandirma: str
    hatirlatma: str


# Generic CIDDİ acil uyarı eki — tüm yan etki bloklarına eklenebilir
GENERIC_SEEK_HELP = (
    "\n• Şiddetli alerjik reaksiyon (yüzde şişme, nefes darlığı), yaygın ciltte "
    "döküntü/kabarcık görülürse ACİL doktora başvurun."
)


# ============================================================
# Kategori bazlı içerikler (indication_short anahtarı)
# ============================================================
CATEGORY_BLOCKS: dict[str, CategoryBlocks] = {
    # ============================ AĞRI KESİCİLER ============================
    "AĞRI KESİCİ": {
        "dikkat": (
            "• Aspirin veya NSAİİ alerjisi olanlar kullanmamalı.\n"
            "• Mide ülseri, ciddi karaciğer/böbrek/kalp yetmezliği olanlar kullanmamalı.\n"
            "• Gebeliğin son 3 ayında kesinlikle kullanılmaz; ilk 6 ayda doktora danışılmalı.\n"
            "• Emzirme döneminde doktor onayı gerekir.\n"
            "• Tok karnına, bir bardak su ile yutunuz.\n"
            "• Yaşlı hastalarda en düşük etkili doz tercih edilir."
        ),
        "etkilesim": (
            "• Aspirin, varfarin, klopidogrel ile birlikte kanama riski artar.\n"
            "• Lityum ve metotreksat kan seviyesini yükseltir.\n"
            "• Tansiyon ilaçlarının (ACE inhibitörü, ARB, diüretik) etkisini azaltır.\n"
            "• Alkol ile birlikte mide kanaması riski katlanır."
        ),
        "yan_etki": (
            "• Sık: bulantı, mide ağrısı, hazımsızlık, baş dönmesi.\n"
            "• CİDDİ YAN ETKİ: Mide kanaması (siyah dışkı, kan kusma), ani göğüs ağrısı "
            "(kalp krizi/inme), şiddetli alerjik reaksiyon, karaciğer hasarı (sarılık) → ACİL doktora.\n"
            "• Uzun süreli kullanım kalp krizi ve inme riskini hafifçe artırır."
        ),
        "sonlandirma": (
            "Ağrı geçtiğinde ilacı bırakabilirsiniz. 5 günden uzun düzenli kullanmayınız "
            "(mide ve böbrek riski artar)."
        ),
        "hatirlatma": (
            "• Bu ilaç sizin için yazılmıştır, başkası kullanmasın.\n"
            "• Diş çekimi veya ameliyat öncesi doktorunuza bildirin (kanama riski).\n"
            "• Aynı anda aspirin/başka NSAİİ ile kombinasyon yapmayınız."
        ),
    },
    "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ": {
        "dikkat": (
            "• Karaciğer ve böbrek yetmezliği olanlar doktor kontrolünde kullanmalı.\n"
            "• Diğer parasetamol içeren ilaçlarla birlikte kullanılmaz (doz aşımı tehlikesi).\n"
            "• Alkol alanlarda günlük 2 gramı aşmamalı.\n"
            "• Bir günde 4 dozdan fazla alınmaz, dozlar arası en az 4 saat olmalı.\n"
            "• Gebelik ve emzirmede güvenli kabul edilir, yine de doktora danışılmalı."
        ),
        "etkilesim": (
            "• Varfarin (kan sulandırıcı) etkisini artırabilir.\n"
            "• Alkol ile birlikte alındığında karaciğer hasarı riski artar.\n"
            "• Çok sayıda soğuk algınlığı ilacında bulunur; kombine kullanımda doz aşımına dikkat."
        ),
        "yan_etki": (
            "• Sık: nadiren bulantı, kusma, mide ağrısı.\n"
            "• CİDDİ YAN ETKİ (yüksek dozda): karaciğer hasarı, ciltte kabarcık/döküntü → ACİL doktora."
        ),
        "sonlandirma": "Ağrı ve ateş geçtiğinde ilacı bırakınız.",
        "hatirlatma": (
            "• Etiketleri okuyup parasetamol içeren başka ilaç kullanmadığınızdan emin olun.\n"
            "• Çocuklarda kg başına doz hesaplanır."
        ),
    },
    "AĞRI KESİCİ (KUVVETLİ)": {
        "dikkat": (
            "• Bu güçlü ağrı kesicidir, doktorun belirlediği dozu aşmayınız.\n"
            "• Solunum problemi, ciddi karaciğer/böbrek hastalığı olanlar dikkatli kullanmalı.\n"
            "• Gebelik ve emzirmede kullanılmaz.\n"
            "• Uyku hali yapar — araç ve makine kullanmayınız."
        ),
        "etkilesim": (
            "• Diğer uyku/sersemlik yapan ilaçlar, alkol ile birlikte tehlikeli solunum baskılanması.\n"
            "• MAO inhibitörleri ile birlikte kullanılmaz."
        ),
        "yan_etki": (
            "• Sık: uyku hali, bulantı, kabızlık, ağız kuruluğu.\n"
            "• CİDDİ YAN ETKİ: solunum baskılanması (yavaş/yüzeyel nefes), bilinç değişikliği → ACİL.\n"
            "• Bağımlılık riski mevcut, doktor takibinde kullanın."
        ),
        "sonlandirma": "Ani kesmek yoksunluk yapabilir; doktor önerisiyle kademeli azaltılır.",
        "hatirlatma": "Araç-makine kullanmayın. Alkol almayın. Reçetesiz ek doz almayın.",
    },
    "AĞRI KESİCİ (HARİCİ)": {
        "dikkat": (
            "• Sadece DIŞ KULLANIM içindir. Göz, ağız, açık yara, mukoza temasından kaçınınız.\n"
            "• Etkilenen bölgeye ince bir tabaka halinde sürünüz.\n"
            "• Geniş alana / uzun süreli kullanım sistemik yan etki yapabilir.\n"
            "• Güneşten korununuz (bazı NSAİİ kremler fotosensitivite yapar)."
        ),
        "etkilesim": (
            "• Aynı bölgeye başka cilt ilacı uygulamayınız.\n"
            "• Geniş alan uzun süreli kullanılırsa sistemik NSAİİ etkileşimleri (varfarin, aspirin) önemlidir."
        ),
        "yan_etki": (
            "• Sık: uygulama yerinde kızarıklık, kaşıntı, yanma.\n"
            "• CİDDİ YAN ETKİ: yaygın ciltte döküntü, kabarcık, şiddetli alerjik reaksiyon → ilacı bırakın, doktora başvurun."
        ),
        "sonlandirma": "Şikayet geçtiğinde bırakabilirsiniz. 7-10 günden uzun rutin kullanmayınız.",
        "hatirlatma": "Uygulamadan önce ve sonra ellerinizi yıkayınız.",
    },

    # ============================ ANTİBİYOTİKLER ============================
    "ANTİBİYOTİK": {
        "dikkat": (
            "• Penisilin/sefalosporin alerjisi olanlar kullanmamalı (bilinen alerji bildirin).\n"
            "• İlacı bitene kadar her gün düzenli kullanınız; iyileşme hissetseniz bile yarıda bırakmayınız.\n"
            "• Karaciğer veya böbrek yetmezliği olanlar doktor kontrolünde kullanmalı.\n"
            "• Mide şikayetini azaltmak için (üreticisinin belirttiği şekilde) aç veya tok alınır.\n"
            "• Gebelik ve emzirmede doktor onayı gerekir."
        ),
        "etkilesim": (
            "• Doğum kontrol haplarının etkisini azaltabilir; ek koruma önerilir.\n"
            "• Antiasit, demir, kalsiyum bazı antibiyotiklerin emilimini düşürür (2 saat ara).\n"
            "• Alkol ile birlikte yan etkiler artabilir (özellikle metronidazol/tinidazol grubu — KESİNLİKLE alkol almayın)."
        ),
        "yan_etki": (
            "• Sık: bulantı, ishal, mantar enfeksiyonu (özellikle vajinal), ciltte hafif döküntü.\n"
            "• CİDDİ YAN ETKİ: Anafilaksi (nefes darlığı, yüzde şişme), şiddetli ishal "
            "(C. difficile/psödomembranöz kolit — kanlı dışkı), yaygın ciltte döküntü → ACİL doktora."
        ),
        "sonlandirma": (
            "Tedaviyi reçetelenen GÜN SAYISINA göre TAMAMLAYINIZ. Erken bırakmak direnç gelişimine "
            "ve enfeksiyonun tekrarına yol açar."
        ),
        "hatirlatma": (
            "• Antibiyotik tedavisi süresince ve sonrasında 2 hafta probiyotik desteği faydalı olabilir.\n"
            "• Gribal enfeksiyonlarda antibiyotik etkisizdir, yalnızca bakteriyel enfeksiyonda kullanılır."
        ),
    },
    "ANTİBİYOTİK (İDRAR YOLU)": {
        "dikkat": (
            "• Bol su tüketiniz.\n"
            "• Genelde tek doz olarak yatmadan önce, idrarınızı tam boşalttıktan sonra alınır.\n"
            "• Böbrek yetmezliği olanlar doktor kontrolünde kullanmalı.\n"
            "• Gebelikte doktor onayı gerekir."
        ),
        "etkilesim": "Antiasit ve magnezyum emilimini azaltır, 2 saat ara verin.",
        "yan_etki": (
            "• Sık: bulantı, ishal, baş ağrısı.\n"
            "• CİDDİ YAN ETKİ: yaygın ciltte döküntü, şiddetli alerjik reaksiyon → doktora başvurun."
        ),
        "sonlandirma": "Reçetelenen şekilde tamamlayın (tek doz veya kısa kür).",
        "hatirlatma": "Hijyene dikkat: önden arkaya silinir, ilişki sonrası işeyiniz.",
    },

    # ============================ MİDE ============================
    "MİDE İLACI": {
        "dikkat": (
            "• Aç karnına, kahvaltıdan en az 30 dakika önce alınız.\n"
            "• Tableti/kapsülü çiğnemeden, bütün olarak yutunuz.\n"
            "• Karaciğer yetmezliği olanlar dikkatli kullanmalı.\n"
            "• Gebelik ve emzirmede doktora danışınız.\n"
            "• Uzun süreli kullanımda B12, magnezyum, kalsiyum eksikliği gelişebilir."
        ),
        "etkilesim": (
            "• Klopidogrel etkisini azaltabilir.\n"
            "• Bazı HIV ilaçlarının (atazanavir, nelfinavir), demir, ketokonazol emilimini düşürür.\n"
            "• Metotreksatın kan seviyesini artırabilir."
        ),
        "yan_etki": (
            "• Sık: baş ağrısı, ishal veya kabızlık, mide ağrısı.\n"
            "• CİDDİ YAN ETKİ: Uzun süreli kullanımda kemik kırığı riski, şiddetli ishal "
            "(C. difficile), düşük magnezyum (kas krampları, çarpıntı), B12 eksikliği belirtileri → doktora."
        ),
        "sonlandirma": (
            "Doktor önerisi ile kullanım süresi belirlenir. Uzun süreli (>8 hafta) kullanım için "
            "dönemsel değerlendirme gerekir. Ani kesim sıçrama (rebound) asit artışına yol açar — kademeli azaltın."
        ),
        "hatirlatma": "Yağlı/baharatlı yemekler, kahve, sigara, alkol şikayeti tetikler.",
    },
    "MİDE İLACI (REFLÜ)": {
        "dikkat": (
            "• Yemeklerden sonra ve yatmadan önce alınız.\n"
            "• Kullanmadan önce şişeyi çalkalayınız.\n"
            "• Diğer ilaçlarınızla en az 2 saat ara veriniz (emilim etkilenir).\n"
            "• Sodyum içerebilir; tuz kısıtlı diyettekiler doktora danışmalı."
        ),
        "etkilesim": "Demir, tetrasiklin, tiroid ilaçları, antibiyotik emilimini düşürür — 2 saat ara verin.",
        "yan_etki": "• Sık: nadiren bulantı, kabızlık veya ishal.\n• CİDDİ: şiddetli alerjik reaksiyon → ilacı bırakın.",
        "sonlandirma": "Şikayet geçince bırakılabilir; sık tekrarlıyorsa doktora başvurun.",
        "hatirlatma": "Yatağın baş tarafını yükseltin, yemekten sonra 2-3 saat yatmayın, yatmadan önce yemek yemeyin.",
    },
    "MİDE İLACI (ANTİASİT)": {
        "dikkat": "• Diğer ilaçlardan 2 saat ara veriniz.\n• Çiğneme tabletlerini iyice çiğneyin.",
        "etkilesim": "Bir çok ilacın (tetrasiklin, demir, kinolon, tiroid) emilimini azaltır.",
        "yan_etki": "Magnezyum içerikli: ishal. Alüminyum içerikli: kabızlık.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Yemeklerden 1 saat sonra ve yatmadan önce kullanılabilir.",
    },
    "KARIN GAZI İLACI": {
        "dikkat": "• Yemekten sonra ve yatmadan önce alınız.\n• Çiğneme tabletini iyice çiğneyin.",
        "etkilesim": "Bilinen önemli ilaç etkileşimi yoktur.",
        "yan_etki": "Çok nadiren ciltte döküntü görülebilir.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Yavaş yiyin, fasulye/lahana/karbonatlı içecek gibi gaz yapan gıdaları azaltın.",
    },
    "KARIN AĞRISI / KASILMA İLACI": {
        "dikkat": (
            "• Glokom, prostat büyümesi, mide-bağırsak tıkanıklığı olanlar kullanmamalı.\n"
            "• Ağız kuruluğu, görme bulanıklığı yapabilir — araç kullanırken dikkat."
        ),
        "etkilesim": "Diğer antikolinerjik ilaçlarla (bazı antidepresanlar) birlikte etkileri katlanır.",
        "yan_etki": (
            "• Sık: ağız kuruluğu, görme bulanıklığı, kabızlık, çarpıntı.\n"
            "• CİDDİ: ani şiddetli göz ağrısı (akut glokom), idrar yapamama → doktora."
        ),
        "sonlandirma": "Ağrı geçtiğinde ilacı bırakabilirsiniz.",
        "hatirlatma": "Yeterli sıvı tüketin.",
    },
    "BULANTI KESİCİ": {
        "dikkat": (
            "• 5 günden uzun süre kullanılmaz (uzun kullanım hareket bozuklukları yapabilir).\n"
            "• Parkinson, epilepsi, bağırsak tıkanıklığı olanlar kullanmamalı.\n"
            "• Uyku/sersemlik yapar; araç kullanmayınız.\n"
            "• 1 yaş altı bebeklerde kullanılmaz."
        ),
        "etkilesim": "Alkol ve uyku/sersemlik yapan ilaçlarla etkisi artar. Levodopa etkisini azaltır.",
        "yan_etki": (
            "• Sık: uyku hali, halsizlik, baş dönmesi.\n"
            "• CİDDİ YAN ETKİ: yüz/dil/boyunda istemsiz hareket (ekstrapiramidal), kas sertliği + ateş "
            "(nöroleptik malign sendrom) → ACİL doktora."
        ),
        "sonlandirma": "Bulantı geçtiğinde bırakılır.",
        "hatirlatma": "Yemekten 30 dakika önce alınır. Az ve sık beslenme bulantıyı azaltır.",
    },
    "KABIZLIK İLACI": {
        "dikkat": (
            "• Bağırsak tıkanıklığı şüphesinde kullanılmaz.\n"
            "• Bol su tüketiniz.\n"
            "• Şeker hastaları dikkatli kullanır (laktüloz içeriği bazı şekerlerden oluşur)."
        ),
        "etkilesim": "Antiasit ve bazı antibiyotikler etkisini azaltabilir.",
        "yan_etki": "• Sık: gaz, şişkinlik, kramp, ishal.\n• Uzun süreli kullanımda elektrolit dengesizliği.",
        "sonlandirma": "Bağırsak düzeni sağlanınca bırakılır. Etki 2-3 günde başlayabilir, sabırlı olun.",
        "hatirlatma": "Lifli beslenme, bol su, hareket alışkanlığı uzun vadeli çözümdür.",
    },
    "İSHAL / BAĞIRSAK": {
        "dikkat": (
            "• Kanlı veya ateşli ishalde kullanılmaz (doktor değerlendirsin).\n"
            "• Bol sıvı tüketiniz, oral rehidratasyon önemli.\n"
            "• 2 günden uzun süren ishalde doktora başvurun."
        ),
        "etkilesim": "Antibiyotikler ile birlikte 2 saat ara verin (probiyotik etkisini korumak için).",
        "yan_etki": "• Sık: nadiren kabızlık, hafif karın ağrısı.",
        "sonlandirma": "İshal geçince bırakılır.",
        "hatirlatma": "Hijyene dikkat. Yoğurt, muz, pirinç, elma rendesi destekleyici.",
    },

    # ============================ KALP / DAMAR ============================
    "TANSİYON İLACI": {
        "dikkat": (
            "• Ani kesmeyiniz (tansiyon yükselebilir, çarpıntı).\n"
            "• Her gün aynı saatte alınız.\n"
            "• İlk başlarda ayağa kalkarken baş dönmesi olabilir (yavaş kalkın).\n"
            "• Gebelik planı varsa doktora bildirin (bazıları gebelikte kullanılamaz).\n"
            "• Tuz alımına dikkat ediniz."
        ),
        "etkilesim": (
            "• NSAİİ ağrı kesicilerle birlikte etki azalır, böbrek riski artar.\n"
            "• Diğer tansiyon ilaçları ile birlikte aşırı düşüş.\n"
            "• Potasyum tutucu diüretik + ACE/ARB → yüksek potasyum riski.\n"
            "• Alkol tansiyon düşmesini şiddetlendirir.\n"
            "• Greyfurt suyu bazı kalsiyum kanal blokerleri ile etkileşir."
        ),
        "yan_etki": (
            "• Sık: baş dönmesi, ayaklarda hafif şişlik, kuru öksürük (ACE inhibitörlerinde), yorgunluk.\n"
            "• CİDDİ YAN ETKİ: yüzde/dilde şişme (anjiyoödem), bayılma, ani göğüs ağrısı, ayaklarda ani ödem → ACİL."
        ),
        "sonlandirma": "Doktor önerisi olmadan KESİNLİKLE BIRAKMAYIN; tansiyon dalgalanır.",
        "hatirlatma": (
            "• Tansiyonunuzu evde düzenli ölçüp not edin.\n"
            "• Diş çekimi / ameliyat öncesi doktora bildirin.\n"
            "• Tuzsuz/az tuzlu diyet, hareket, kilo kontrolü ilaç etkisini artırır."
        ),
    },
    "DİÜRETİK": {
        "dikkat": (
            "• Sabah erken alınız (gece tuvalete kalkmamak için).\n"
            "• Potasyum düşmesi yapabilir — muz, ıspanak, portakal gibi potasyumlu gıdalar.\n"
            "• Gut hastalığı, diyabet olanlar dikkatli kullanmalı."
        ),
        "etkilesim": "NSAİİ etkisini azaltır. Digoksin ile birlikte ritm bozukluğu riski.",
        "yan_etki": (
            "• Sık: sık idrara çıkma, baş dönmesi, ağız kuruluğu.\n"
            "• CİDDİ: ciddi elektrolit bozukluğu (halsizlik, kas krampları, çarpıntı), dehidratasyon → doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "Günlük tartılın, kilo değişimini takip edin.",
    },
    "KOLESTEROL İLACI": {
        "dikkat": (
            "• Akşam alınması daha etkilidir (kolesterol sentezi gece).\n"
            "• Karaciğer hastalığı olanlar kullanmamalı (kan tahlili takibi gerekir).\n"
            "• Kas ağrısı/güçsüzlüğü bildirin.\n"
            "• Gebelik ve emzirmede kullanılmaz."
        ),
        "etkilesim": (
            "• Greyfurt suyu ile birlikte alınmaz (kan seviyesi tehlikeli yükselir).\n"
            "• Makrolid antibiyotik, antimantar, klaritromisin ile kas hasarı riski artar.\n"
            "• Varfarin etkisini artırabilir."
        ),
        "yan_etki": (
            "• Sık: kas ağrısı, hafif sindirim şikayetleri.\n"
            "• CİDDİ YAN ETKİ: şiddetli kas ağrısı + koyu idrar (rabdomiyoliz), karaciğer enzimlerinde yükselme → ACİL doktora."
        ),
        "sonlandirma": "Ömür boyu tedavi gerekebilir; doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "Diyet ve egzersiz ilaç etkisini artırır.",
    },
    "KALP RİTM İLACI": {
        "dikkat": (
            "• Her gün aynı saatte alınız.\n"
            "• Nabzınızı düzenli kontrol edin.\n"
            "• Ciddi kalp blokları, çok düşük kalp atışı varsa kullanılmaz."
        ),
        "etkilesim": "Birçok ilaçla etkileşim mümkün — yeni ilaç kullanırken mutlaka doktora danışın.",
        "yan_etki": (
            "• Sık: yorgunluk, baş dönmesi, soğuk eller-ayaklar.\n"
            "• CİDDİ: ciddi yavaş kalp atışı (50 altı), bayılma, nefes darlığı, ayaklarda şişme → ACİL."
        ),
        "sonlandirma": "Ani kesilmez — kademeli azaltılır.",
        "hatirlatma": "Diş çekimi/ameliyat öncesi bildirin.",
    },
    "KAN SULANDIRICI": {
        "dikkat": (
            "• Diş çekimi, ameliyat, kanama testleri öncesi doktora bildirin (gerekirse önceden bırakılır).\n"
            "• Olağandışı morarma, burun/diş eti kanaması, kanlı idrar/dışkıyı bildirin.\n"
            "• Düşme-yaralanmadan kaçının.\n"
            "• Mide ülseri öyküsü olanlar dikkatli kullanmalı."
        ),
        "etkilesim": (
            "• NSAİİ ağrı kesicilerle birlikte ciddi kanama riski.\n"
            "• Antibiyotik, antimantar, omeprazol etkiyi etkileyebilir.\n"
            "• Alkol kanama riskini artırır.\n"
            "• Greyfurt suyu, K vitamini yüksek gıdalar (yeşil yapraklı sebze) etkisini değiştirir."
        ),
        "yan_etki": (
            "• Sık: olağandışı morarma, hafif burun/diş eti kanaması.\n"
            "• CİDDİ YAN ETKİ: Şiddetli kanama (siyah/kanlı dışkı, kan kusma, ani baş ağrısı), "
            "kanlı idrar, geçmeyen morluk → ACİL doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan KESİNLİKLE bırakmayın (pıhtı riski).",
        "hatirlatma": (
            "• Yumuşak diş fırçası kullanın, jiletle traş yerine elektrikli tıraş makinesi.\n"
            "• Ağrı kesici için parasetamol tercih edin (NSAİİ değil)."
        ),
    },
    "KAN SULANDIRICI (İĞNE)": {
        "dikkat": (
            "• Sağlık personeli veya eğitimli hasta tarafından cilt altına uygulanır.\n"
            "• Enjeksiyon yerini her seferinde değiştiriniz.\n"
            "• Heparin alerjisi, aktif kanama olanlar kullanmamalı.\n"
            "• Düşme/yaralanmadan kaçınınız."
        ),
        "etkilesim": "Diğer kan sulandırıcılar (aspirin, klopidogrel) ile birlikte kanama riski katlanır.",
        "yan_etki": (
            "• Sık: enjeksiyon yerinde morarma/kabarık.\n"
            "• CİDDİ YAN ETKİ: şiddetli kanama, ani baş ağrısı, trombositopeni (kan pulcuğu düşmesi) → ACİL."
        ),
        "sonlandirma": "Doktor önerisi ile sonlandırılır.",
        "hatirlatma": "Saklama koşullarına dikkat (genelde buzdolabı veya oda sıcaklığı — kutuda yazar).",
    },
    "ANEMİ TEDAVİSİ": {
        "dikkat": (
            "• Aç karnına emilim iyi; mide şikayeti olursa tok karnına.\n"
            "• Süt, çay, kahve ile birlikte alınmaz; arada en az 2 saat olmalı.\n"
            "• Hemokromatozis olanlar kullanmamalı.\n"
            "• Çocuklarda doz aşımı tehlikelidir — ulaşamayacağı yerde tutun."
        ),
        "etkilesim": "Levotiroksin, kinolon antibiyotik, antiasit emilimini etkiler — 2 saat ara.",
        "yan_etki": (
            "• Sık: bulantı, kabızlık veya ishal, dışkıda siyahlık (zararsız), karın ağrısı, dişlerde geçici renklenme.\n"
            "• CİDDİ: çocuk yutması → ACİL acil servis."
        ),
        "sonlandirma": "Kan değerleri normale gelince doktor sonlandırma kararı verir (genelde 3-6 ay).",
        "hatirlatma": "C vitamini ile birlikte alınması emilimi artırır.",
    },

    # ============================ ŞEKER ============================
    "ŞEKER HASTALIĞI İLACI": {
        "dikkat": (
            "• Her gün aynı saatlerde, doktorun belirlediği şekilde alınız.\n"
            "• Aç kalmak / öğün atlama düşük şeker yapar; daima taze meyve/şeker yanınızda olsun.\n"
            "• Röntgen/tomografide kontrast madde öncesi metformin bırakılmalı (doktor önerisiyle).\n"
            "• Ciddi enfeksiyon, ameliyat, hamileliği doktora bildirin."
        ),
        "etkilesim": (
            "• Alkol düşük şeker riskini artırır.\n"
            "• Kortizon, diüretik şekeri yükseltir.\n"
            "• Beta-blokerler düşük şeker belirtilerini (titreme, çarpıntı) maskeleyebilir."
        ),
        "yan_etki": (
            "• Sık: bulantı, ishal (metformin), düşük şeker (terleme, titreme, açlık), kilo değişimi.\n"
            "• CİDDİ YAN ETKİ: laktik asidoz (yorgunluk, kas ağrısı, hızlı nefes, karın ağrısı, halsizlik) — METFORMIN için; "
            "şiddetli düşük şeker (bilinç bulanması), diyabetik ketoasidoz (kusma, derin nefes, meyve kokusu) → ACİL."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": (
            "• Şeker ölçer ile düzenli takip.\n"
            "• Beslenme + egzersiz tedavinin ayrılmaz parçası.\n"
            "• Düşük şeker kartı taşıyın (acil müdahaleciler için)."
        ),
    },
    "İNSÜLİN": {
        "dikkat": (
            "• Cilt altına (göbek, uyluk, kol) enjekte edilir; bölge dönüşümlü kullanılır.\n"
            "• BUZDOLABINDA (2-8°C) saklanır — kullanımdaki kalem oda sıcaklığında 28 gün dayanır.\n"
            "• Donma yapmayınız.\n"
            "• Doz atlamayınız — aksi halde şeker yükselir."
        ),
        "etkilesim": (
            "• Alkol, beta-bloker, MAO inhibitörü düşük şeker etkisini artırır.\n"
            "• Kortizon, diüretik, hormonal doğum kontrol şekeri yükseltir."
        ),
        "yan_etki": (
            "• Sık: düşük şeker (terleme, titreme, çarpıntı), kilo artışı, enjeksiyon yerinde lipodistrofi.\n"
            "• CİDDİ: şiddetli hipoglisemi (bilinç bulanması) → ACİL şeker verin / acil servis."
        ),
        "sonlandirma": "ASLA kendi başına bırakmayın (Tip 1 diyabette ölümcül).",
        "hatirlatma": "Şeker ölçüm cihazı, glukagon kalemi, hızlı şeker kaynağı yanınızda olsun.",
    },

    # ============================ NÖROLOJİ / PSİKİYATRİ ============================
    "ANTİDEPRESAN": {
        "dikkat": (
            "• Tam etki için 2-6 hafta gerekebilir, sabırlı olunuz.\n"
            "• Doktor önerisi olmadan KESİNLİKLE bırakmayınız (kademeli azaltılır).\n"
            "• Alkol almayınız.\n"
            "• 25 yaş altında nadiren intihar düşüncesi artabilir — yakın takip.\n"
            "• Gebelik ve emzirme döneminde doktora danışınız."
        ),
        "etkilesim": (
            "• MAO inhibitörü antidepresanlar ile birlikte kullanılmaz (serotonin sendromu).\n"
            "• Tramadol, triptanlar, lityum ile serotonin sendromu riski.\n"
            "• NSAİİ, varfarin ile kanama riski artar.\n"
            "• St. John's wort (sarı kantaron) ile birlikte alınmaz."
        ),
        "yan_etki": (
            "• Sık (ilk haftalar): bulantı, baş ağrısı, uyku düzensizliği, cinsel istek azalması.\n"
            "• CİDDİ YAN ETKİ: serotonin sendromu (ateş, terleme, titreme, ajitasyon), intihar düşüncesi artışı, "
            "kanama belirtileri → ACİL doktora."
        ),
        "sonlandirma": "Kademeli azaltılır (haftalar içinde). Ani kesim yoksunluk belirtileri yapar.",
        "hatirlatma": (
            "• Düzenli uyku ve hareket etkiyi destekler.\n"
            "• Diş çekimi/ameliyat öncesi doktorunuza bildirin (kanama riski)."
        ),
    },
    "ANTİPSİKOTİK": {
        "dikkat": (
            "• Doktor önerisi olmadan ilacı bırakmayınız.\n"
            "• Alkol ile birlikte kullanmayınız.\n"
            "• Uyku/sersemlik yapabilir — araç kullanmayınız.\n"
            "• Şeker hastalığı, kolesterol yüksekliği takip edilmelidir.\n"
            "• Yaşlı demanslı hastalarda dikkatli kullanılır."
        ),
        "etkilesim": "Uyku/sersemlik yapan ilaçlar, alkol, opioidler ile etkileri artar.",
        "yan_etki": (
            "• Sık: uyku hali, kilo artışı, ağız kuruluğu, kabızlık, kan şekeri yükselmesi.\n"
            "• CİDDİ YAN ETKİ: nöroleptik malign sendrom (yüksek ateş + kas sertliği + bilinç bulanması), "
            "tardif diskinezi (istemsiz hareketler), QT uzaması → ACİL doktora."
        ),
        "sonlandirma": "ASLA aniden bırakmayın — doktor takibinde kademeli azaltılır.",
        "hatirlatma": "Kilo, kan şekeri, kolesterol düzenli takibi gerekir.",
    },
    "ANKSİYOLİTİK": {
        "dikkat": (
            "• Bağımlılık yapabilir, doktor önerisi olmadan uzun süre kullanmayınız.\n"
            "• Uyku/sersemlik yapar — araç kullanmayınız.\n"
            "• Alkol ile birlikte alınmaz (tehlikeli solunum baskılanması).\n"
            "• Gebelik/emzirmede kullanılmaz."
        ),
        "etkilesim": "Opioid, antipsikotik, antihistaminik, alkol ile birlikte tehlikeli solunum baskılanması.",
        "yan_etki": (
            "• Sık: uyku hali, halsizlik, hafıza güçlüğü, denge sorunu.\n"
            "• CİDDİ: solunum baskılanması, paradoks ajitasyon → doktora."
        ),
        "sonlandirma": "Doktor takibinde kademeli azaltılır (ani kesim nöbet, kaygı sıçraması yapar).",
        "hatirlatma": "Geçici kullanım önerilir, kalıcı çözüm için psikoterapi de değerlendirilmeli.",
    },
    "UYKU İLACI": {
        "dikkat": (
            "• Yatmadan 30 dakika önce alınız.\n"
            "• Bağımlılık yapabilir — uzun süre kullanmayınız.\n"
            "• Sabah uykululuk yapabilir — araç kullanırken dikkat.\n"
            "• Alkol ile alınmaz."
        ),
        "etkilesim": "Diğer uyku/sersemlik yapan ilaçlar, alkol ile etkisi artar.",
        "yan_etki": (
            "• Sık: sabah sersemliği, baş ağrısı, ağız kuruluğu.\n"
            "• CİDDİ: uyurgezerlik, hafıza boşlukları, paradoks ajitasyon → doktora."
        ),
        "sonlandirma": "Kademeli azaltılır (yoksunluk: uyku bozukluğu, kaygı).",
        "hatirlatma": "Uyku hijyeni (ekran kullanmama, kahveinsiz akşam, düzenli saat) ilacın yerini alabilir.",
    },
    "ANTİEPİLEPTİK": {
        "dikkat": (
            "• Doktor önerisi olmadan KESİNLİKLE BIRAKMAYIN (nöbete sebep olur).\n"
            "• Her gün aynı saatte alınız.\n"
            "• Gebelik planı varsa MUTLAKA doktora bildirin (bazılarının gebelikte riski yüksek).\n"
            "• Düzenli kan seviyesi takibi gerekir."
        ),
        "etkilesim": (
            "• Doğum kontrol haplarının etkisini azaltabilir.\n"
            "• Çok sayıda ilaçla etkileşir — yeni ilaç başlarken bildirin.\n"
            "• Alkol nöbet eşiğini düşürür."
        ),
        "yan_etki": (
            "• Sık: uyku hali, baş dönmesi, görme bulanıklığı, sindirim şikayetleri.\n"
            "• CİDDİ YAN ETKİ: yaygın ciltte döküntü (Stevens-Johnson sendromu), karaciğer hasarı, "
            "kan hücresi düşmesi, intihar düşüncesi → ACİL doktora."
        ),
        "sonlandirma": "ASLA aniden bırakmayın — doktor takibinde kademeli azaltılır.",
        "hatirlatma": "Nöbet kartı/bilekliği taşıyın, ehliyet için doktor onayı gerekir.",
    },
    "DEHB İLACI": {
        "dikkat": (
            "• Sabah, yemekten sonra alınır.\n"
            "• Akşam alımı uykusuzluk yapar.\n"
            "• Kalp hastalığı, ciddi anksiyete olanlar dikkatli kullanmalı.\n"
            "• Boy/kilo gelişimi takip edilir (çocuklarda)."
        ),
        "etkilesim": "MAO inhibitörü ile birlikte kullanılmaz. Tansiyon ilaçları etkisi azalabilir.",
        "yan_etki": (
            "• Sık: iştahsızlık, uykusuzluk, baş ağrısı, ağız kuruluğu, kilo kaybı.\n"
            "• CİDDİ: çarpıntı, ani göğüs ağrısı, psikoz, bağımlılık → doktora."
        ),
        "sonlandirma": "Tedavi planı doktor tarafından belirlenir, kademeli azaltılır.",
        "hatirlatma": "İlaç tatili (hafta sonu) bazen önerilebilir — doktor karar verir.",
    },
    "ALZHEİMER İLACI": {
        "dikkat": "• Her gün aynı saatte düzenli kullanınız.\n• Bulantı yapabilir, yemekle alınız.\n• Kalp ritm sorunu olanlar dikkatli kullanmalı.",
        "etkilesim": "Antikolinerjik ilaçlar etkisini azaltır. NSAİİ ile birlikte mide kanaması riski.",
        "yan_etki": "• Sık: bulantı, kusma, ishal, baş dönmesi.\n• CİDDİ: bayılma, ciddi yavaş kalp atışı → doktora.",
        "sonlandirma": "Doktor önerisi olmadan bırakılmaz.",
        "hatirlatma": "Bakıcı/aile desteği ile dozun doğru alındığını kontrol edin.",
    },
    "PARKİNSON İLACI": {
        "dikkat": (
            "• Her gün aynı saatlerde düzenli alınız.\n"
            "• Protein içeren yemeklerden 30 dk önce / sonra (emilim için).\n"
            "• Ani kesilmez (motor ve psikiyatrik belirtiler kötüleşir)."
        ),
        "etkilesim": "B6 vitamini, antipsikotikler, metoklopramid etkisini azaltır. MAO inhibitörü ile birlikte tehlikeli.",
        "yan_etki": (
            "• Sık: bulantı, baş dönmesi, ayağa kalkarken tansiyon düşmesi, istemsiz hareketler.\n"
            "• CİDDİ: ani uyku atakları, psikotik belirtiler, kumar/dürtüsel davranış → doktora."
        ),
        "sonlandirma": "Doktor takibinde kademeli ayarlanır.",
        "hatirlatma": "Araç kullanırken uyku ataklarına dikkat.",
    },
    "MİGREN İLACI": {
        "dikkat": (
            "• Atak başlangıcında erken alınız.\n"
            "• 24 saatte en fazla 2 doz.\n"
            "• Kalp hastalığı, hipertansiyon, geçirilmiş inme olanlar kullanmamalı.\n"
            "• Aurali migren tipi farklı tedavi gerekebilir."
        ),
        "etkilesim": "MAO inhibitörü, ergot türevleri ile birlikte kullanılmaz. Diğer triptanlardan 24 saat ara.",
        "yan_etki": "• Sık: göğüste sıkışma hissi, baş dönmesi, sıcaklık hissi.\n• CİDDİ: göğüs ağrısı, çarpıntı, görme kaybı → ACİL.",
        "sonlandirma": "Atak geçince bırakılır. Aylık 10+ kullanım kronik baş ağrısı (rebound) yapar.",
        "hatirlatma": "Migren günlüğü tutun, tetikleyicileri belirleyin.",
    },
    "NÖROLOJİ İLACI": {
        "dikkat": "• Her gün düzenli, aynı saatlerde alınız.\n• Doktor önerisi olmadan bırakmayın.",
        "etkilesim": "Yeni ilaç başlarken doktora bildirin.",
        "yan_etki": "• Sık: uyku hali, bulantı, baş dönmesi.\n• CİDDİ: yaygın döküntü, ruh hali değişikliği → doktora.",
        "sonlandirma": "Kademeli azaltılır.",
        "hatirlatma": "Düzenli uyku ve stresten uzak yaşam destekleyici.",
    },
    "KAS GEVŞETİCİ": {
        "dikkat": (
            "• Uyku hali yapar — araç kullanmayınız.\n"
            "• Tedavi 5-7 günden uzun sürmemelidir.\n"
            "• Alkol ile alınmaz.\n"
            "• Yaşlı hastalarda düşük doz."
        ),
        "etkilesim": "Diğer uyku/sersemlik yapan ilaçlar, alkol ile etkisi katlanır.",
        "yan_etki": "• Sık: uyku hali, baş dönmesi, ağız kuruluğu.\n• CİDDİ: şiddetli alerjik reaksiyon, idrar yapamama → doktora.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Sıcak duş, hafif egzersiz, masaj destekleyici.",
    },
    "OSTEOPOROZ İLACI": {
        "dikkat": (
            "• Aç karnına, bol su (200 ml) ile alınız.\n"
            "• Alındıktan sonra 30-60 dakika YATMAYIN, başka ilaç almayın, yiyecek tüketmeyin.\n"
            "• Yutma güçlüğü olanlar, özofajit, alt esophagus hastalığı olanlar kullanmamalı.\n"
            "• Diş işlemleri öncesi doktora bildirin (çene osteonekrozu nadir risk)."
        ),
        "etkilesim": "Kalsiyum, demir, antiasit aynı anda alınmaz (en az 30 dk ara).",
        "yan_etki": "• Sık: mide şikayetleri, yutkunma zorluğu.\n• CİDDİ: özofajit, çene osteonekrozu, atipik kemik kırığı → doktora.",
        "sonlandirma": "Tedavi süresi doktor tarafından belirlenir (genelde 3-5 yıl).",
        "hatirlatma": "Kalsiyum + D vitamini desteği eşlik etmeli.",
    },
    "ROMATİZMA İLACI": {
        "dikkat": (
            "• Doktorunuzun belirlediği dozda kullanınız.\n"
            "• Düzenli kan tahlilleri (karaciğer, böbrek, kan hücresi) ile takip edilir.\n"
            "• Canlı aşı yapılmaz (kızamık, suçiçeği, BCG).\n"
            "• Enfeksiyon belirtilerinde doktora bildirin."
        ),
        "etkilesim": "Diğer immün baskılayıcılar, canlı aşılar dikkat. Folik asit eksikliği (metotreksat) — destek gerekir.",
        "yan_etki": (
            "• Sık: ağız yarası, bulantı, halsizlik, saç dökülmesi.\n"
            "• CİDDİ: kan hücresi düşmesi (ateş, halsizlik), karaciğer/akciğer hasarı, enfeksiyon → ACİL."
        ),
        "sonlandirma": "Doktor takibinde — bırakmak alevlenmeye yol açar.",
        "hatirlatma": "Hijyene dikkat, kalabalık ortamlarda enfeksiyon riski.",
    },
    "İMMÜNOSUPRESİF": {
        "dikkat": (
            "• Bağışıklığı baskılar — enfeksiyon belirtilerinde doktora başvurun.\n"
            "• Canlı aşı yapılmaz.\n"
            "• Düzenli kan tahlili gerekir.\n"
            "• Gebelik/emzirmede doktor onayı."
        ),
        "etkilesim": "Pek çok ilaç ile etkileşim — yeni ilaç başlarken bildirin.",
        "yan_etki": "• Sık: enfeksiyon, sindirim şikayetleri.\n• CİDDİ: ciddi enfeksiyon, lenfoma, ciddi kan tablosu bozukluğu → ACİL.",
        "sonlandirma": "Doktor takibinde — ani bırakmak hastalık alevlenmesi yapar.",
        "hatirlatma": "Hijyen, kalabalık ortam dikkat, mevsim aşıları (canlı olmayan) önerilir.",
    },

    # ============================ HORMON / GUATR / KORTİZON ============================
    "GUATR İLACI": {
        "dikkat": (
            "• Sabah aç karnına, kahvaltıdan en az 30-60 dakika önce alınız.\n"
            "• Doktor önerisi olmadan dozu değiştirmeyiniz.\n"
            "• Düzenli kan tahlili (TSH) ile doz ayarı yapılır.\n"
            "• Kalp hastalığı olanlar düşük dozdan başlamalı."
        ),
        "etkilesim": (
            "• Demir, kalsiyum, magnezyum, antiasit, kolestiramin emilimini azaltır — 4 saat ara.\n"
            "• Varfarin etkisini artırır (kanama riski).\n"
            "• Şeker ilaçlarının dozu yeniden ayarlanmalı olabilir."
        ),
        "yan_etki": (
            "• Sık: ilk başlarda hafif çarpıntı, halsizlik (doz ayarı).\n"
            "• CİDDİ YAN ETKİ: çarpıntı, göğüs ağrısı, aşırı kilo kaybı, terleme (tirotoksikoz) → doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakılmaz (genelde ömür boyu).",
        "hatirlatma": "Soya ürünleri emilimini etkiler — aralarında 4 saat olsun.",
    },
    "HORMON": {
        "dikkat": (
            "• Doktor önerisi olmadan dozu değiştirmeyiniz, bırakmayınız.\n"
            "• Düzenli takip gerekir.\n"
            "• Gebelik ve emzirme için doktora danışın."
        ),
        "etkilesim": "Doğum kontrol hapı, diğer hormonlar, antiepileptikler etkileşim — bildirin.",
        "yan_etki": "• Sık: kilo değişimi, sıvı tutulumu, ruh hali değişikliği.\n• CİDDİ: pıhtılaşma, ciddi alerjik reaksiyon → doktora.",
        "sonlandirma": "Doktor takibinde kademeli sonlandırılır.",
        "hatirlatma": "Tütün hormonal tedavi riskini artırır.",
    },
    "KORTİZON TEDAVİSİ": {
        "dikkat": (
            "• Doktor önerisi olmadan KESİNLİKLE ANİ KESMEYİNİZ (adrenal yetmezlik).\n"
            "• Yemekle birlikte alınız (mide koruyucu).\n"
            "• Tuz alımına dikkat — ödem yapabilir.\n"
            "• Şeker hastalığı, tansiyon, osteoporoz, ülser, glokom olanlar dikkatli kullanmalı.\n"
            "• Enfeksiyona hassasiyet artar — temas hijyenine dikkat.\n"
            "• Canlı aşı yapılmaz."
        ),
        "etkilesim": "NSAİİ ile mide kanaması riski. Diüretikle potasyum düşmesi. Şeker ilaçları dozu artabilir.",
        "yan_etki": (
            "• Sık: kilo artışı, ay yüzü, kan şekeri yükselmesi, uyku düzensizliği, ruh hali değişikliği.\n"
            "• CİDDİ YAN ETKİ: ciddi enfeksiyon, mide kanaması, görme bozukluğu (katarakt), kemik erimesi → doktora.\n"
            "• Uzun süreli: osteoporoz, katarakt, şeker yükselmesi."
        ),
        "sonlandirma": "KADEMELİ AZALTILMALI — kesinlikle ani bırakılmaz.",
        "hatirlatma": (
            "• Kortizon kartı taşıyın (acil müdahaleciler için).\n"
            "• Yeterli kalsiyum + D vitamini.\n"
            "• Stres/enfeksiyon dönemlerinde doz artırılması gerekebilir."
        ),
    },

    # ============================ SOLUNUM ============================
    "ASTIM İLACI": {
        "dikkat": (
            "• Düzenli (korunma amaçlı) kullanılır, atak sırasında değil.\n"
            "• Doktor önerisi olmadan bırakmayın.\n"
            "• İnhaler tekniği önemli — eczacınızdan kontrol ettirin."
        ),
        "etkilesim": "Beta-bloker (göz damlası dahil) etkiyi azaltır. Kortizon ile birlikte mantar enfeksiyonu riski (ağız).",
        "yan_etki": "• Sık: ağızda mantar (kortizonlu inhaler), boğazda iritasyon, ses kısıklığı.\n• CİDDİ: paradoks bronkospazm → doktora.",
        "sonlandirma": "Doktor önerisi ile kademeli.",
        "hatirlatma": "Kullandıktan sonra ağzı çalkalayın. Atak ilacınızı yanınızda taşıyın.",
    },
    "ASTIM İLACI (BRONŞ AÇICI)": {
        "dikkat": (
            "• Atakta kurtarıcı olarak kullanılır.\n"
            "• Günde 8 puftan fazla = astım kontrolsüz, doktora başvurun.\n"
            "• Kalp hastalığı, tiroid sorunu, diyabet olanlar dikkatli kullanmalı."
        ),
        "etkilesim": "Beta-bloker etkiyi azaltır. Diüretik ile düşük potasyum.",
        "yan_etki": "• Sık: titreme, çarpıntı, baş ağrısı.\n• CİDDİ: çarpıntı, göğüs ağrısı, paradoks bronkospazm → ACİL.",
        "sonlandirma": "İhtiyaç duydukça kullanılır.",
        "hatirlatma": "Acil durumda yanında olmalı; yedek alın.",
    },
    "ASTIM İLACI (KORTİZON)": {
        "dikkat": "• Düzenli kullanılır, atakta değildir.\n• Kullandıktan sonra ağzı çalkalayın (mantar/ses kısıklığı).",
        "etkilesim": "Genelde sistemik etkileşim az; kortizon emilirse adrenal etki olabilir.",
        "yan_etki": "• Sık: ağız mantarı, ses kısıklığı, boğaz tahrişi.\n• CİDDİ: paradoks bronkospazm → doktora.",
        "sonlandirma": "Doktor önerisi olmadan bırakılmaz.",
        "hatirlatma": "Spacer (yardımcı tüp) kullanımı tekniği iyileştirir.",
    },
    "ASTIM/ALLERJİ İLACI": {
        "dikkat": "• Düzenli (akşam) kullanılır.\n• Atak için değildir.",
        "etkilesim": "Genelde önemli etkileşim yok.",
        "yan_etki": "• Sık: baş ağrısı, sindirim şikayetleri, uyku düzensizliği.\n• CİDDİ: ruh hali değişikliği, intihar düşüncesi (nadir) → doktora.",
        "sonlandirma": "Mevsim sonu / şikayet geçince doktor ile kararla bırakılır.",
        "hatirlatma": "Allerjen kaçınma destekleyici.",
    },
    "BALGAM SÖKÜCÜ": {
        "dikkat": "• Bol sıvı tüketiniz.\n• Şikayet 5 günden uzunsa doktora başvurun.\n• Çocuk dozu farklı.",
        "etkilesim": "Öksürük kesici ile birlikte alınmaz (balgam bağlar).",
        "yan_etki": "• Sık: nadiren bulantı, ciltte döküntü.",
        "sonlandirma": "Balgam azalınca bırakılır.",
        "hatirlatma": "Buhar/sıcak içecek balgam söktürmeyi destekler.",
    },
    "ÖKSÜRÜK KESİCİ": {
        "dikkat": (
            "• Balgamlı öksürükte balgam sökücü ile birlikte alınmaz.\n"
            "• 6 yaş altı çocuklarda doktor önerisi ile.\n"
            "• Uyku hali yapabilir."
        ),
        "etkilesim": "Sakinleştiriciler, alkol ile etkisi artar.",
        "yan_etki": "• Sık: uyku hali, baş dönmesi, kabızlık.\n• CİDDİ: solunum baskılanması (opioid türevlerinde) → doktora.",
        "sonlandirma": "Öksürük geçince bırakılır.",
        "hatirlatma": "Bol sıvı, nemli ortam destekleyici.",
    },
    "GRİP / SOĞUK ALGINLIĞINDA": {
        "dikkat": (
            "• Yüksek tansiyon, kalp hastalığı, glokom, prostat büyümesi olanlar kullanmamalı.\n"
            "• Diğer parasetamol içeren ilaçlarla birlikte alınmaz.\n"
            "• 12 yaş altı çocuklara doktor önerisi olmadan verilmez.\n"
            "• Uyku hali yapar — araç kullanmayınız.\n"
            "• Alkol ile alınmaz."
        ),
        "etkilesim": "MAO inhibitörü ile birlikte ciddi tansiyon yükselmesi. Diğer soğuk algınlığı ilaçları kombine kullanılmaz.",
        "yan_etki": "• Sık: uyku hali, ağız kuruluğu, çarpıntı, baş dönmesi.\n• CİDDİ: aşırı tansiyon yükselmesi, idrar yapamama → doktora.",
        "sonlandirma": "Şikayet geçince bırakılır, 5 günden uzun kullanmayınız.",
        "hatirlatma": "Bol sıvı, dinlenme, C vitamini destekleyici.",
    },

    # ============================ ALLERJİ ============================
    "ALLERJİ / KAŞINTI İLACI": {
        "dikkat": (
            "• 1. kuşak antihistaminikler uyku hali yapar — araç kullanmayınız.\n"
            "• Glokom, prostat büyümesi olanlar dikkatli kullanmalı.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": "Sakinleştiriciler, alkol ile uyku hali artar.",
        "yan_etki": "• Sık: uyku hali, ağız kuruluğu, baş ağrısı.\n• CİDDİ: kalp ritm bozukluğu (uzun QT) — bazılarında → doktora.",
        "sonlandirma": "Mevsim sonu / şikayet geçince bırakılır.",
        "hatirlatma": "Allerjen kaçınma (toz, polen, kedi-köpek tüyü) ilacın yerini alabilir.",
    },

    # ============================ BURUN ============================
    "BURUN AÇICI": {
        "dikkat": (
            "• 7 GÜNDEN uzun kullanılmaz (rebound burun tıkanıklığı yapar).\n"
            "• Yüksek tansiyon, kalp hastalığı, glokom, prostat büyümesi olanlar dikkatli kullanmalı.\n"
            "• Birden fazla kişi tarafından kullanılmamalıdır.\n"
            "• Bebek formu sadece bebekler için."
        ),
        "etkilesim": "MAO inhibitörü ile birlikte kullanılmaz. Tansiyon ilaçlarının etkisini azaltabilir.",
        "yan_etki": "• Sık: burunda yanma/kuruluk, çarpıntı, baş ağrısı.\n• CİDDİ: çocuk yutarsa zehirlenme → ACİL.",
        "sonlandirma": "Şikayet geçince bırakılır, 7 günü aşmayın.",
        "hatirlatma": "Tuzlu su spreyi yan etkisiz alternatiftir.",
    },
    "BURUN İLACI (KORTİZON)": {
        "dikkat": "• Düzenli (günlük) kullanılır.\n• Tam etki 1-2 hafta içinde başlar.\n• Birden fazla kişi kullanmamalıdır.",
        "etkilesim": "Önemli sistemik etkileşim azdır.",
        "yan_etki": "• Sık: burunda kuruluk, hafif burun kanaması, baş ağrısı.\n• CİDDİ: burun septum perforasyonu, görme problemi → doktora.",
        "sonlandirma": "Mevsim sonu / şikayet kontrolünde doktora danışılarak bırakılır.",
        "hatirlatma": "Spreyleme sırasında septuma (orta duvar) doğru sıkmayın, dış duvara doğru.",
    },
    "BURUN İLACI": {
        "dikkat": "• Birden fazla kişi kullanamaz.\n• Doktor önerisi olmadan uzun süre kullanmayın.",
        "etkilesim": "Genelde önemli sistemik etkileşim yok.",
        "yan_etki": "• Sık: burunda yanma, hapşırma, hafif tahriş.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Sümkürerek burnu temizleyip kullanın.",
    },

    # ============================ AĞIZ-DİŞ / BOĞAZ ============================
    "AĞIZ-DİŞ İLACI": {
        "dikkat": (
            "• YUTMAYINIZ (lokal kullanım).\n"
            "• Kullandıktan sonra ağzı suyla çalkalamayın, en az 30 dakika yiyip içmeyin.\n"
            "• Uzun süreli kullanım dişlerde geçici renklenme yapabilir.\n"
            "• 6 yaş altı çocuklarda doktor önerisi ile."
        ),
        "etkilesim": "Diş macunundaki bazı maddeler klorheksidini etkisizleştirir — 30 dk ara.",
        "yan_etki": "• Sık: dilde tat değişikliği, hafif yanma, dişlerde renklenme.",
        "sonlandirma": "Şikayet geçince bırakılır, 7-14 günden uzun rutin kullanmayın.",
        "hatirlatma": "Diş ipi, düzenli diş muayenesi önemli.",
    },
    "BOĞAZ İLACI": {
        "dikkat": "• Direkt boğaza sıkın, yutabilirsiniz.\n• Birden fazla kişi kullanmaz.\n• 6 yaş altı doktor onayı ile.",
        "etkilesim": "Önemli sistemik etkileşim yoktur.",
        "yan_etki": "• Sık: ağızda yanma, uyuşma, hafif acı tat.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Sıcak içecekler, tuzlu su gargarası destekleyici.",
    },

    # ============================ CİLT (DERMATOLOJİK) ============================
    "MANTAR İLACI (DIŞ KULLANIM)": {
        "dikkat": "• Sadece DIŞ KULLANIM.\n• Etkilenen bölgeye ince tabaka.\n• Şikayet geçtikten sonra 1-2 hafta devam edin (nüks önlemek için).",
        "etkilesim": "Aynı bölgeye başka cilt ilacı uygulamayın.",
        "yan_etki": "• Sık: uygulama yerinde kızarıklık, kaşıntı.\n• CİDDİ: şiddetli alerjik reaksiyon → bırakın.",
        "sonlandirma": "Şikayet + 1-2 hafta.",
        "hatirlatma": "Bölgeyi kuru tutun, havlu/iç çamaşırı paylaşmayın.",
    },
    "CİLT KORTİZONU": {
        "dikkat": (
            "• Sadece DIŞ KULLANIM.\n"
            "• Yüz, koltukaltı, kasık bölgesine uzun süreli kullanmayın (cilt incelmesi).\n"
            "• Bol miktarda sürmeyin.\n"
            "• Geniş alana uzun süreli kullanım sistemik etki yapabilir."
        ),
        "etkilesim": "Aynı bölgeye başka kortizon kremi uygulamayın.",
        "yan_etki": "• Sık: cilt incelmesi, kılcal damar görünümü, akne benzeri döküntü.\n• CİDDİ: yaygın kullanım Cushing benzeri yan etki → doktora.",
        "sonlandirma": "Kısa süreli (1-2 hafta) kullanılır, kademeli azaltılır.",
        "hatirlatma": "Sterile pansuman önerilmediği sürece kapatmayın.",
    },
    "YARA İYİLEŞTİRİCİ": {
        "dikkat": "• Sadece dış kullanım.\n• Temiz cilt bölgesine uygulayın.",
        "etkilesim": "Önemli sistemik etkileşim yoktur.",
        "yan_etki": "• Sık: nadiren kızarıklık, kaşıntı.",
        "sonlandirma": "Yara iyileşince bırakılır.",
        "hatirlatma": "Hijyen kuralları, gerekirse pansuman.",
    },
    "SİVİLCE İLACI": {
        "dikkat": (
            "• Güneşten korunun, koruyucu krem kullanın.\n"
            "• Gebelik ve emzirmede bazıları kesinlikle kullanılmaz (oral retinoidler — gebelik testi gerekir).\n"
            "• Cilt kuruluğu/iritasyon yaygındır."
        ),
        "etkilesim": "Diğer aşındırıcı ürünler (peeling, retinoid) ile birlikte aşırı tahriş.",
        "yan_etki": "• Sık: ciltte kuruluk, kızarıklık, kaşıntı, soyulma.\n• CİDDİ (oral retinoid): karaciğer enzim yüksekliği, ruh hali değişikliği → doktora.",
        "sonlandirma": "Tedavi planı doktor tarafından belirlenir (3-6 ay).",
        "hatirlatma": "Yağsız nemlendirici, oil-free güneş koruyucu destekleyici.",
    },
    "CİLT NEMLENDİRİCİ": {
        "dikkat": "• Sadece dış kullanım.\n• Açık yaraya doğrudan uygulamayın.",
        "etkilesim": "Genelde önemli sistemik etkileşim yok.",
        "yan_etki": "• Sık: nadiren kızarıklık, kaşıntı.",
        "sonlandirma": "İhtiyaca göre.",
        "hatirlatma": "Banyo sonrası nemli cilde uygulanırsa daha etkili.",
    },
    "CİLT ANTİBİYOTİĞİ": {
        "dikkat": "• Sadece dış kullanım.\n• İnce tabaka, etkilenen bölgeye.\n• Geniş alanda kullanmayın.",
        "etkilesim": "Aynı bölgede başka cilt ilacı kullanmayın.",
        "yan_etki": "• Sık: kızarıklık, kaşıntı, yanma.",
        "sonlandirma": "Enfeksiyon geçince bırakılır.",
        "hatirlatma": "Uygulamadan önce ve sonra ellerinizi yıkayın.",
    },
    "CİLT İLACI": {
        "dikkat": "• Sadece dış kullanım.\n• Göz ve ağız temasından kaçının.",
        "etkilesim": "Aynı bölgede başka ilaç kullanırken doktora danışın.",
        "yan_etki": "• Sık: uygulama bölgesinde kızarıklık, kaşıntı.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Uygulama sonrası ellerinizi yıkayın.",
    },
    "ANTİSEPTİK": {
        "dikkat": "• Sadece DIŞ KULLANIM, yutmayın.\n• Açık yaraya temasında doktor onayı.",
        "etkilesim": "Önemli sistemik etkileşim yoktur.",
        "yan_etki": "• Sık: ciltte kuruluk, hafif tahriş.",
        "sonlandirma": "İhtiyaç bitince bırakılır.",
        "hatirlatma": "Bebek/çocuk bezi altına bol kullanmayın.",
    },

    # ============================ KADIN HASTALIKLARI / DOĞUM KONTROL ============================
    "KADIN HASTALIKLARI": {
        "dikkat": (
            "• Yatmadan önce vajinaya yerleştirin.\n"
            "• Adet döneminde devam edilir (doktor aksi belirtmedikçe).\n"
            "• Eşinizle birlikte tedavi gerekebilir (cinsel yolla bulaşan ise)."
        ),
        "etkilesim": "Aynı bölgede başka vajinal ürün kullanmayın.",
        "yan_etki": "• Sık: uygulama bölgesinde yanma, kaşıntı.\n• CİDDİ: yaygın alerjik reaksiyon → bırakın.",
        "sonlandirma": "Tedavi süresini tamamlayın (genelde 3-7 gün).",
        "hatirlatma": "Pamuklu iç çamaşırı, ilişki sırasında kondom önerilebilir.",
    },
    "DOĞUM KONTROL": {
        "dikkat": (
            "• Her gün AYNI SAATTE alınız.\n"
            "• Hap unutulursa kutu içindeki talimata göre devam edin veya ek koruma kullanın.\n"
            "• Sigara + doğum kontrol = pıhtı riski katlanır.\n"
            "• Kuyruk ucu migren, geçirilmiş pıhtı, karaciğer hastalığı olanlar kullanmamalı."
        ),
        "etkilesim": (
            "• Antibiyotik, antiepileptik, St. John's wort etkisini azaltır — ek koruma kullanın.\n"
            "• Bazı antikoagülanlar etkilenebilir."
        ),
        "yan_etki": (
            "• Sık: bulantı, baş ağrısı, ara kanama (ilk aylar), göğüs hassasiyeti.\n"
            "• CİDDİ YAN ETKİ: bacakta tek taraflı şişlik (DVT), ani şiddetli baş ağrısı / görme değişikliği, "
            "göğüs ağrısı + nefes darlığı (pulmoner emboli) → ACİL."
        ),
        "sonlandirma": "Kutu sonu veya doktor önerisi.",
        "hatirlatma": "Yıllık jinekoloji muayenesi, tansiyon takibi.",
    },
    # G04BE — sildenafil/tadalafil/vardenafil (PDE5) + alprostadil. En kritik
    # bilgi nitratlı kalp ilacı etkileşimi: hasta "kalp ilacı" dediğinde anlasın.
    "EREKSİYON (SERTLEŞME) İLACI": {
        "dikkat": (
            "• KALP HASTALIĞINIZ varsa veya KALP İLACI kullanıyorsanız doktorunuza DANIŞMADAN kullanmayın.\n"
            "• Cinsel ilişkiden 30-60 dk önce alınız; etki için cinsel uyarı gerekir.\n"
            "• 24 saat içinde 1 dozdan fazla ALMAYIN."
        ),
        "etkilesim": (
            "• NİTRAT içeren kalp ilaçları (dilaltı tablet/sprey, İsordil, Nitroderm) ile ASLA kullanmayın — tansiyon ölümcül düşebilir.\n"
            "• Tansiyon ve prostat (alfa-bloker) ilaçlarıyla baş dönmesi / tansiyon düşmesi olabilir.\n"
            "• Greyfurt suyu yan etkiyi artırabilir."
        ),
        "yan_etki": (
            "• Sık: baş ağrısı, yüzde kızarma/sıcaklık, burun tıkanıklığı, hazımsızlık, baş dönmesi.\n"
            "• CİDDİ: göğüs ağrısı, 4 saatten uzun ereksiyon (priapizm), ani görme/işitme kaybı → ACİL."
        ),
        "sonlandirma": "İhtiyaç halinde kullanılır; bağımlılık yapmaz.",
        "hatirlatma": "Ağır yağlı yemek etkiyi geciktirir. Alkol ile dikkat.",
    },
    "ÜROLOJİ İLACI": {
        "dikkat": (
            "• Her gün aynı saatte düzenli kullanınız.\n"
            "• İlk dozlarda ayağa kalkarken baş dönmesi (yavaş kalkın).\n"
            "• Katarakt ameliyatı öncesi göz doktoruna bildirin (iris floppy sendromu)."
        ),
        "etkilesim": "Tansiyon ilaçları ile birlikte aşırı düşüş. Ereksiyon ilaçları kombinasyonu dikkat.",
        "yan_etki": "• Sık: baş dönmesi, ejakülasyon problemi, burun tıkanıklığı.\n• CİDDİ: bayılma, uzamış ereksiyon (priapizm) → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "Yatağa otururken yavaş hareket edin.",
    },

    # ============================ GÖZ / KULAK ============================
    "GÖZ İLACI": {
        "dikkat": (
            "• Şişe ucu göze değmemeli.\n"
            "• Birden fazla kişi kullanmamalıdır.\n"
            "• Lens varsa damlatmadan önce çıkarın, 15 dk sonra takın."
        ),
        "etkilesim": "Aynı göze birden fazla damla varsa aralarında 5 dk olsun.",
        "yan_etki": "• Sık: gözde yanma, hafif bulanık görme.\n• CİDDİ: göz ağrısı, kızarıklığı artıyorsa → doktora.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Damlattıktan sonra 1 dk göz iç köşesine bastırın (sistemik emilim azalır).",
    },
    "GLOKOM İLACI": {
        "dikkat": "• Her gün AYNI saatte damlatın.\n• Şişe ucu göze değmemeli.\n• 1 dk göz iç köşesine bastırın.",
        "etkilesim": "Beta-bloker damlalar sistemik emilirse — astım/kalp hastalarında dikkat.",
        "yan_etki": "• Sık: gözde yanma, kirpik uzaması/koyulaşması, ciltte koyulaşma.\n• CİDDİ: nefes darlığı, yavaş kalp atışı → doktora.",
        "sonlandirma": "Doktor önerisi olmadan bırakılmaz (görme kaybı riski).",
        "hatirlatma": "Yıllık göz muayenesi, göz tansiyon takibi şart.",
    },
    "KURU GÖZ İLACI": {
        "dikkat": "• Şişe ucu göze değmemeli.\n• Açıldıktan sonra 1 ay içinde tüketin.\n• Tek dozluk olanlar açıldıktan 12 saat içinde tüketilir.",
        "etkilesim": "Aynı göze damlalar arası 5 dk.",
        "yan_etki": "• Sık: gözde geçici yanma, hafif bulanık görme.",
        "sonlandirma": "İhtiyaca göre.",
        "hatirlatma": "Ekran kullanırken sık gözlerinizi kırpıştırın, mola verin.",
    },
    "KULAK İLACI": {
        "dikkat": (
            "• Şişeyi avucunuzda 1-2 dakika ısıtın (soğuk damla baş dönmesi yapar).\n"
            "• Yan yatın, damlattıktan sonra 5 dk daha yatın.\n"
            "• Kulak zarı delik olanlar kullanmamalı (doktor onayı)."
        ),
        "etkilesim": "Aynı kulağa başka damla varsa aralarında 30 dk olsun.",
        "yan_etki": "• Sık: kulakta hafif yanma, kaşıntı.\n• CİDDİ: ani işitme kaybı, baş dönmesi → doktora.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Birden fazla kişi kullanmamalıdır.",
    },

    # ============================ VİTAMİN / MİNERAL ============================
    "D VİTAMİNİ": {
        "dikkat": (
            "• Doktor önerisi olmadan yüksek doz kullanmayın (toksik olabilir).\n"
            "• Hiperkalsemi, böbrek taşı, ciddi böbrek yetmezliği olanlar kullanmamalı.\n"
            "• Damla formunda dozu damla ile doğru ölçün.\n"
            "• Bebeklerde doz aşımına dikkat."
        ),
        "etkilesim": "Tiyazid diüretikler ile kalsiyum yükselir. Digoksin ile ritm bozukluğu riski.",
        "yan_etki": "• Sık (normal dozda): nadirdir.\n• CİDDİ (yüksek dozda): iştahsızlık, susama, sık idrar, kabızlık, kas güçsüzlüğü → doktora.",
        "sonlandirma": "Kan değeri normale gelince doz ayarlanır.",
        "hatirlatma": "Güneş ışığı doğal D vitamini kaynağıdır (haftada 2-3 kez 15-20 dk).",
    },
    "B VİTAMİNİ DESTEĞİ": {
        "dikkat": "• Önerilen dozdan fazla kullanmayın.\n• İdrarda sarımsı renk yapar (B2 — zararsız).\n• Levodopa kullananlar B6 için doktora danışmalı.",
        "etkilesim": "B6 levodopa etkisini azaltır. Fenitoin, izoniazid ile etkileşim.",
        "yan_etki": "• Sık: nadiren bulantı, hafif ishal.\n• CİDDİ (yüksek doz B6): el-ayakta uyuşma → doktora.",
        "sonlandirma": "Eksiklik düzelince bırakılır.",
        "hatirlatma": "Et, tahıl, baklagil, yumurta doğal kaynaklardır.",
    },
    "VİTAMİN": {
        "dikkat": "• Önerilen dozda kullanın.\n• Gebelik için özel formüller mevcut.",
        "etkilesim": "Vitamin tabletleri demir, kalsiyum içerebilir — diğer ilaçlardan 2 saat ara.",
        "yan_etki": "• Sık: nadiren bulantı, sindirim şikayetleri.",
        "sonlandirma": "İhtiyaç bitince bırakılır.",
        "hatirlatma": "Çeşitli beslenme her zaman tercih edilir.",
    },
    "MİNERAL DESTEĞİ": {
        "dikkat": "• Aç karnına bulantı yapabilir, yemekle alın.\n• Önerilen dozdan fazla kullanmayın.",
        "etkilesim": "Tetrasiklin, kinolon, tiroid ilacı emilimini azaltır — 2 saat ara.",
        "yan_etki": "• Sık: bulantı, ishal veya kabızlık.",
        "sonlandirma": "Eksiklik düzelince bırakılır.",
        "hatirlatma": "Çeşitli ve dengeli beslenme tercih edilir.",
    },
    "KALSİYUM DESTEĞİ": {
        "dikkat": "• Bol su ile alınız.\n• Demir/tiroid ilaçlarınızdan 2 saat ayrı alınız.",
        "etkilesim": "Levotiroksin, tetrasiklin, kinolon, demir emilimini azaltır — 2 saat ara.",
        "yan_etki": "• Sık: kabızlık, gaz.",
        "sonlandirma": "İhtiyaç bitince bırakılır.",
        "hatirlatma": "D vitamini ile birlikte alındığında emilimi artar.",
    },

    # ============================ DİĞER ============================
    "HEMOROİD İLACI": {
        "dikkat": (
            "• REKTAL kullanım içindir — makat bölgesine uygulanır, YUTULMAZ.\n"
            "• Tuvaletten sonra bölgeyi temizleyip kurulayarak uygulayınız.\n"
            "• Makattan kanama sürerse veya 1 haftada düzelme olmazsa doktora başvurunuz."
        ),
        "etkilesim": "Lokal etkilidir, sistemik etkileşim azdır.",
        "yan_etki": "• Sık: uygulama bölgesinde yanma, batma, kaşıntı.",
        "sonlandirma": "Şikayet geçince bırakılır; kortizonlular uzun süre kullanılmaz.",
        "hatirlatma": "Lifli beslenme, bol su, hareket kabızlığı önler; tuvalette uzun süre ıkınmayın.",
    },
    "VARİS / HEMOROİD İLACI": {
        "dikkat": "• Tuvaletten sonra temizlik sonrası uygulayınız.\n• Sadece dış kullanım (genelde).",
        "etkilesim": "Lokal etkilidir, sistemik etkileşim azdır.",
        "yan_etki": "• Sık: uygulama bölgesinde yanma, kaşıntı.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "Lifli beslenme, bol su, hareket kabızlığı önler.",
    },
    "VARİS / DOLAŞIM İLACI": {
        "dikkat": "• Her gün düzenli alınız.\n• Bol su için.\n• Gebelik için doktora danışın.",
        "etkilesim": "Diğer dolaşım ilaçları ile birlikte alınırken doktora danışın.",
        "yan_etki": "• Sık: nadiren mide şikayetleri, baş ağrısı.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "Ayaklarınızı yüksekte tutun, varis çorabı destekleyici.",
    },
    "RADYOLOJİK KONTRAST": {
        "dikkat": "Sağlık ocağı / hastane ortamında uygulanır. İşlem öncesi açlık gerekebilir.",
        "etkilesim": "Metformin geçici olarak bırakılmalı (laktik asidoz riski).",
        "yan_etki": "• Sık: işlem sonrası halsizlik, hafif bulantı.\n• CİDDİ: alerjik reaksiyon, böbrek hasarı → doktora.",
        "sonlandirma": "Tek seferlik veya işlem süresince.",
        "hatirlatma": "İşlem öncesi alerji geçmişi ve böbrek değeri bildirin.",
    },
    "BESLENME ÜRÜNÜ": {
        "dikkat": "Doktor önerisi ile, belirtilen miktar ve sıklıkta.\n• Mikrodalga ile ısıtmayın.\n• Açıldıktan sonra buzdolabında 24 saat içinde tüketin.",
        "etkilesim": "Antibiyotik ve demir emilimini etkileyebilir.",
        "yan_etki": "• Sık: nadiren ishal, bulantı.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "Yutma güçlüğü olanlar için hazırlık önerileri var (kıvam ayarı).",
    },
}

# drug_guess isim listesi "EREKSİYON İLACI" döndürür (Viagra/Cialis vb. marka
# tahmini); DB indication_short ise "EREKSİYON (SERTLEŞME) İLACI". İkisi de
# aynı bloklara gitsin.
CATEGORY_BLOCKS["EREKSİYON İLACI"] = CATEGORY_BLOCKS["EREKSİYON (SERTLEŞME) İLACI"]


# Generic fallback — tanımlı kategori bulunmazsa
FALLBACK_BLOCKS: CategoryBlocks = {
    "dikkat": (
        "• Doktorunuzun önerdiği doz ve süreye uyunuz.\n"
        "• Gebelik, emzirme ve diğer kronik hastalıklarınızı doktora bildirin.\n"
        "• Bilinen alerjinizi söyleyin.\n"
        "• Karaciğer ve böbrek yetmezliği olanlar doktor kontrolünde kullanmalı."
    ),
    "etkilesim": (
        "• Diğer kullandığınız ilaçları (reçeteli veya reçetesiz) doktor / eczacıya bildirin.\n"
        "• Alkol ile birlikte kullanmamaya özen gösterin."
    ),
    "yan_etki": (
        "• Sık görülen yan etkileri için prospektüsü okuyunuz.\n"
        "• Şiddetli alerjik reaksiyon (yüzde şişme, nefes darlığı) görülürse ACİL doktora başvurun."
    ),
    "sonlandirma": "Doktorunuzun belirlediği süre boyunca kullanınız.",
    "hatirlatma": (
        "• Bu ilaç sizin için yazılmıştır, başkasına vermeyiniz.\n"
        "• Çocukların ulaşamayacağı yerde tutunuz.\n"
        "• Son kullanma tarihi geçmiş ilaçları kullanmayınız."
    ),
}


# ============================================================
# Form bazlı bloklar: saklama, sıvı tüketimi, hazırlama
# ============================================================

# Form anahtarı → saklama metni (varsayılan oda sıcaklığı)
FORM_STORAGE: dict[str, str] = {
    # Buzdolabı gerektiren özel formlar (ATC ile override edilebilir)
    # Genel kural: tüm formlar 25°C altında saklanır
}

GENERIC_STORAGE = (
    "25°C altında, oda sıcaklığında, kuru yerde saklayınız. "
    "Çocukların ulaşamayacağı yerde tutunuz."
)

LIGHT_PROTECTED_STORAGE = (
    "25°C altında, oda sıcaklığında, ışıktan korunarak saklayınız. "
    "Çocukların ulaşamayacağı yerde tutunuz."
)

REFRIGERATED_STORAGE = (
    "Buzdolabında (2-8°C) saklayınız, DONDURMAYINIZ. "
    "Çocukların ulaşamayacağı yerde tutunuz."
)

SUSPENSION_STORAGE = (
    "Açılmadan önce 25°C altında, oda sıcaklığında saklayınız. "
    "Sulandırıldıktan sonra BUZDOLABINDA saklayınız, üreticinin belirttiği süre "
    "(genelde 7-14 gün) içinde tüketiniz. Çocukların ulaşamayacağı yerde tutunuz."
)


# Form anahtarı → sıvı tüketimi metni
FORM_LIQUID: dict[str, str] = {
    "tablet_normal":              "Bir bardak (200 ml) su ile yutunuz.",
    "tablet_chewable":             "Çiğneme tabletidir, su gerekmez.",
    "tablet_sublingual":           "Dilaltında eriyene kadar bekleyiniz, su içmeyiniz.",
    "tablet_effervescent":         "Bir bardak (200 ml) suya eritip içiniz.",
    "tablet_enteric_or_extended":  "Bir bardak (200 ml) su ile, çiğnemeden bütün olarak yutunuz.",
    "capsule_normal":              "Bir bardak (200 ml) su ile yutunuz.",
    "capsule_pellet_open":         "Bir bardak su ile yutunuz veya kapsülü açıp gıdaya karıştırınız.",
    "syrup_or_suspension":         "Kullanmadan önce çalkalayınız, verilen ölçek ile alınız.",
    "powder_for_suspension":       "Sulandırma sonrası kullanmadan önce çalkalayınız, ölçek ile alınız.",
    "oral_drop":                   "Belirtilen damla sayısını ağıza veya bir kaşığa damlatınız.",
    "sachet_oral":                 "Bir bardak (200 ml) suya boşaltıp karıştırınız ve hemen içiniz.",
    "nutritional_supplement_oral": "Doğrudan içiniz, SULANDIRMAYINIZ. Açılan şişeyi buzdolabında saklayıp 24 saat içinde tüketiniz.",
    "nutritional_powder_oral":     "Kutusundaki tarife göre su ile hazırlayıp içiniz.",
}


# Form anahtarı → hazırlama metni (boşsa hazırlama bloğu eklenmez)
FORM_PREP: dict[str, str] = {
    "powder_for_suspension": (
        "Şişenin işaretine kadar kaynamış-soğutulmuş su ekleyip iyice çalkalayınız. "
        "Gerekirse 2 aşamada yapın. Her kullanım öncesi yeniden çalkalayınız. "
        "Hazırlandıktan sonra BUZDOLABINDA saklanır."
    ),
    "ear_drop": "Şişeyi avucunuzda 1-2 dakika ısıtınız (soğuk damla baş dönmesi yapar).",
    "suppository_rectal": (
        "Buzdolabındaysa 1-2 dakika dışarıda bekletip yumuşamasını bekleyiniz. "
        "Uygulama öncesi ellerinizi yıkayınız."
    ),
    "enema_rectal": (
        "Süspansiyon ise kullanmadan önce iyice çalkalayınız. "
        "Uygulama öncesi ve sonrası ellerinizi yıkayınız."
    ),
    "cream_rectal": (
        "Tuvaletten sonra makat bölgesini temizleyip kurulayınız. "
        "Uygulama öncesi ve sonrası ellerinizi yıkayınız."
    ),
    "vaginal_ovule_or_cream": (
        "Yatmadan önce, sırtüstü yatıp dizleri çekilmiş pozisyonda uygulayınız. "
        "Uygulama öncesi ve sonrası ellerinizi yıkayınız."
    ),
    "inhaler_pmdi": (
        "İlk kullanımdan önce ve uzun aradan sonra hava boşa 2-3 puf sıkın. "
        "Şişeyi 4-5 kez çalkalayın."
    ),
    "nebule": (
        "Ampulü nebülizatör haznesine boşaltın. Gerekirse fizyolojik tuzlu su ile "
        "seyreltin (doktor önerisine göre). Açılan ampul 24 saat içinde kullanılmalı."
    ),
    "injection_sc": (
        "Ellerinizi yıkayın, enjeksiyon bölgesini alkol ile silin (göbek çevresi 5 cm uzak, "
        "uyluk dış yüzü, üst kol). Bölgeleri dönüşümlü kullanın."
    ),
}


# ATC sınıfı → buzdolabında (2-8°C) saklanan ilaçlar. Yalnız BÜTÜNÜYLE parenteral
# biyolojik/hormon grupları; oral muadili olan karışık gruplar (A10BJ oral
# semaglutid, H01BA02 desmopresin tablet, B02BX05 eltrombopag) burada DEĞİL —
# onlar cold_chain_badge() içinde forma göre guard'lanır (bkz. label_from_db).
REFRIGERATED_ATC_PREFIXES = [
    "A10A",    # İnsülin
    "J07",     # Aşılar
    "J06BA", "J06BB",  # İmmünoglobulinler (IVIG/SCIG, spesifik Ig)
    "L01F", "L01XC",   # Monoklonal antikorlar (kanser/biyolojik)
    "L03AA",   # Koloni uyarıcı faktörler (filgrastim)
    "L03AB",   # İnterferonlar
    "L03AC",   # İnterlökinler
    "L04AA",   # Bazı immünomodülatörler (biyolojik)
    "L04AB",   # TNF inhibitörleri (biyolojik)
    "L04AC",   # IL inhibitörleri (biyolojik)
    "L04AG",   # Monoklonal immünsüpresanlar
    "B02BD",   # Pıhtılaşma faktörleri (hemofili)
    "B03XA",   # Eritropoietin (epoetin/darbepoetin)
    "H01AC",   # Büyüme hormonu (somatropin)
    "H01AX01", # Pegvisomant
    "H01CB",   # Somatostatin analogları (oktreotid/lanreotid)
    "H05AA",   # Paratiroid hormonu / teriparatid
    "H05BA",   # Kalsitonin
    "M03AX01", # Botulinum toksini
    "S01LA",   # Anti-VEGF intravitreal
    "G03GA",   # Gonadotropinler (FSH/hCG)
]


def _is_refrigerated(atc_code: str) -> bool:
    code = (atc_code or "").upper()
    return any(code.startswith(p) for p in REFRIGERATED_ATC_PREFIXES)


def _is_suspension_for_storage(form: str | None) -> bool:
    return form == "powder_for_suspension"


def _is_light_protected(atc_code: str, form: str | None) -> bool:
    """Bazı ilaçlar ışıktan korunarak saklanır (NSAİİ, hormon, antiepileptik, vb.)."""
    code = (atc_code or "").upper()
    return code.startswith(("M01", "M02", "N03", "N05A", "N06A", "G03", "C10AA",
                            "L02", "H02", "H03", "A11C"))


def get_storage_for(form: str | None, atc_code: str | None) -> str:
    if _is_refrigerated(atc_code or ""):
        return REFRIGERATED_STORAGE
    if _is_suspension_for_storage(form):
        return SUSPENSION_STORAGE
    if _is_light_protected(atc_code or "", form):
        return LIGHT_PROTECTED_STORAGE
    return GENERIC_STORAGE


def get_liquid_for(form: str | None) -> str | None:
    if not form:
        return None
    return FORM_LIQUID.get(form)


def get_prep_for(form: str | None) -> str | None:
    if not form:
        return None
    return FORM_PREP.get(form)


def get_category_blocks(indication_short: str | None) -> CategoryBlocks:
    """indication_short anahtarından CategoryBlocks içeriği — yoksa fallback."""
    if indication_short and indication_short in CATEGORY_BLOCKS:
        return CATEGORY_BLOCKS[indication_short]
    return FALLBACK_BLOCKS


def generate_all_blocks(
    indication_short: str | None,
    form: str | None,
    atc_code: str | None,
) -> dict[str, str]:
    """Tüm bilgi bloklarını tek seferde üretir.

    Döner: dict[block_type, content]. Boş/None değerli bloklar atlanır
    (drug_label_blocks'a yazılmaz).
    """
    out: dict[str, str] = {}

    cat = get_category_blocks(indication_short)
    for bt in ("dikkat", "etkilesim", "yan_etki", "sonlandirma", "hatirlatma"):
        content = cat.get(bt)  # type: ignore[call-arg]
        if content:
            out[bt] = content

    storage = get_storage_for(form, atc_code)
    if storage:
        out["saklama"] = storage

    liquid = get_liquid_for(form)
    if liquid:
        out["sivi"] = liquid

    prep = get_prep_for(form)
    if prep:
        out["hazirlama"] = prep

    return out
