"""KATALOG SENKRONU — etiket BİLGİSİNİ diğer bilgisayarlara taşır.

Neden: kod güncellemesi (ilactarif_update.zip) yalnız `App.pyw + src/` taşır.
Etiket bilgisindeki düzeltmeler (ilaç FORMU, uygulama YOLU/route_class, öğün
ilişkisi, doz birimi, günlük sıklık, etiket blok METİNLERİ) veritabanında
durur ve kurulu bilgisayarlara HİÇ ulaşmıyordu — kurulumdaki DB
`onlyifdoesntexist` ile bir kez yazılır, sonra asla güncellenmez.

Bu modül güncelleme kanalındaki `ilactarif_katalog.db.gz` dosyasını indirir ve
YEREL DB'ye işler. İŞLEME KURALLARI:

  • `drug_label_blocks`, `drug_labels` → tamamen YENİLENİR (saf bilgi).
  • `drugs` → SATIR SATIR güncellenir; eczaneye ait sayaçlar KORUNUR
    (sales_count, rank, stock). Yerelde olmayan satır eklenir, yerelde fazla
    olan satıra DOKUNULMAZ.
  • `magistral_hammadde`, `magistral_ambalaj` → eksikler eklenir, var olanlar
    güncellenir; eczanenin kendi eklediği kayıt SİLİNMEZ.
  • Hiç dokunulmayan tablolar: recete_hasta, kargo_alici, settings,
    drug_label_prefs (eczacının kendi etiket düzenlemeleri),
    label_review_status, emanet_records, botanik_katalog.

Güvenlik: işlem öncesi DB'nin yedeği alınır, tek transaction'da yazılır,
sonunda `PRAGMA integrity_check` yapılır; hata olursa yedek geri konur.
"""
from __future__ import annotations

import gzip
import hashlib
import logging
import shutil
import sqlite3
import tempfile
import urllib.request
from pathlib import Path

log = logging.getLogger(__name__)

# Tamamen yenilenen (saf bilgi) tablolar
REPLACE_TABLES = ("drug_label_blocks", "drug_labels")
# Satır satır birleştirilen tablolar: (tablo, anahtar kolon)
MERGE_TABLES = (("drugs", "id"),
                ("magistral_hammadde", "id"),
                ("magistral_ambalaj", "id"))
# drugs tablosunda ECZANEYE AİT olan ve ASLA ezilmeyen kolonlar
LOCAL_COLUMNS = {"sales_count", "rank", "stock"}

SETTING_KEY = "katalog_build"


def yerel_katalog_build(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute("SELECT value FROM settings WHERE key=?",
                           (SETTING_KEY,)).fetchone()
        return int(row[0]) if row and str(row[0]).strip().isdigit() else 0
    except sqlite3.Error:
        return 0


def _yaz_katalog_build(conn: sqlite3.Connection, build: int) -> None:
    conn.execute(
        "INSERT INTO settings(key, value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (SETTING_KEY, str(build)))


def _indir(url: str, hedef: Path, timeout: float = 120.0) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "IlacTarif"})
    with urllib.request.urlopen(req, timeout=timeout) as r, \
            open(hedef, "wb") as f:
        shutil.copyfileobj(r, f, length=1 << 20)


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _kolonlar(conn: sqlite3.Connection, tablo: str) -> list[str]:
    return [r[1] for r in conn.execute(f'PRAGMA table_info("{tablo}")')]


def isle(db_path: Path, katalog_db: Path) -> dict[str, int]:
    """Katalog DB'sini yerel DB'ye işler; {tablo: etkilenen satır} döner."""
    sonuc: dict[str, int] = {}
    conn = sqlite3.connect(db_path)
    try:
        conn.execute("PRAGMA foreign_keys=OFF")
        conn.execute("ATTACH DATABASE ? AS kat", (str(katalog_db),))
        kat_tablolar = {r[0] for r in conn.execute(
            "SELECT name FROM kat.sqlite_master WHERE type='table'")}
        with conn:                      # tek transaction
            for t in REPLACE_TABLES:
                if t not in kat_tablolar:
                    continue
                kols = [c for c in _kolonlar(conn, t)
                        if c in set(_kolonlar_kat(conn, t))]
                if not kols:
                    continue
                alan = ", ".join(f'"{c}"' for c in kols)
                conn.execute(f'DELETE FROM main."{t}"')
                cur = conn.execute(
                    f'INSERT INTO main."{t}" ({alan}) '
                    f'SELECT {alan} FROM kat."{t}"')
                sonuc[t] = cur.rowcount if cur.rowcount >= 0 else 0

            for t, anahtar in MERGE_TABLES:
                if t not in kat_tablolar:
                    continue
                yerel = set(_kolonlar(conn, t))
                uzak = set(_kolonlar_kat(conn, t))
                ortak = [c for c in _kolonlar_kat(conn, t) if c in yerel]
                if anahtar not in ortak:
                    continue
                guncel = [c for c in ortak
                          if c != anahtar and c not in LOCAL_COLUMNS]
                n = 0
                if guncel:
                    sets = ", ".join(
                        f'"{c}" = (SELECT k."{c}" FROM kat."{t}" k '
                        f'WHERE k."{anahtar}" = main."{t}"."{anahtar}")'
                        for c in guncel)
                    cur = conn.execute(
                        f'UPDATE main."{t}" SET {sets} WHERE EXISTS '
                        f'(SELECT 1 FROM kat."{t}" k '
                        f'WHERE k."{anahtar}" = main."{t}"."{anahtar}")')
                    n += max(cur.rowcount, 0)
                alan = ", ".join(f'"{c}"' for c in ortak)
                cur = conn.execute(
                    f'INSERT INTO main."{t}" ({alan}) '
                    f'SELECT {alan} FROM kat."{t}" k WHERE NOT EXISTS '
                    f'(SELECT 1 FROM main."{t}" m '
                    f'WHERE m."{anahtar}" = k."{anahtar}")')
                n += max(cur.rowcount, 0)
                sonuc[t] = n
        conn.execute("DETACH DATABASE kat")
        bozuk = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if str(bozuk).lower() != "ok":
            raise sqlite3.DatabaseError(f"integrity_check: {bozuk}")
    finally:
        conn.close()
    return sonuc


def _kolonlar_kat(conn: sqlite3.Connection, tablo: str) -> list[str]:
    return [r[1] for r in conn.execute(f'PRAGMA kat.table_info("{tablo}")')]


def senkronla(db_path: str | Path, manifest: dict) -> str | None:
    """Manifest'teki katalog yeni ise indirip işler.

    Dönen: kısa özet metni (başarılıysa) ya da None (yapılacak iş yok).
    Hata durumunda istisna YUTULUR (log'a yazılır) — güncelleme kanalı
    bozuksa program normal çalışmaya devam etmeli.
    """
    kat = (manifest or {}).get("katalog") or {}
    url = kat.get("url")
    try:
        uzak_build = int(kat.get("build", 0))
    except (TypeError, ValueError):
        uzak_build = 0
    if not url or uzak_build <= 0:
        return None

    db_path = Path(db_path)
    conn = sqlite3.connect(db_path)
    try:
        yerel = yerel_katalog_build(conn)
    finally:
        conn.close()
    if uzak_build <= yerel:
        return None

    log.info("Katalog güncellemesi: yerel=%s uzak=%s", yerel, uzak_build)
    yedek = db_path.with_suffix(db_path.suffix + ".katalog-yedek")
    with tempfile.TemporaryDirectory(prefix="ilactarif_kat_") as tmp:
        gz = Path(tmp) / "katalog.db.gz"
        ham = Path(tmp) / "katalog.db"
        try:
            _indir(url, gz)
            beklenen = (kat.get("sha256") or "").lower().strip()
            if beklenen and _sha256(gz) != beklenen:
                log.warning("Katalog sha256 uyuşmadı — işlem iptal.")
                return None
            with gzip.open(gz, "rb") as f, open(ham, "wb") as o:
                shutil.copyfileobj(f, o, length=1 << 20)
            shutil.copy2(db_path, yedek)
            sonuc = isle(db_path, ham)
            conn = sqlite3.connect(db_path)
            try:
                with conn:
                    _yaz_katalog_build(conn, uzak_build)
            finally:
                conn.close()
            ozet = ", ".join(f"{t}:{n}" for t, n in sonuc.items())
            log.info("Katalog işlendi (build %s) → %s", uzak_build, ozet)
            try:
                yedek.unlink()
            except OSError as e:
                # Yedek silinemedi (dosya kilidi): zararsız, yalnız disk payı.
                log.debug("Katalog yedeği silinemedi: %s (%s)", yedek, e)
            return f"katalog build {uzak_build} işlendi ({ozet})"
        except Exception:
            log.exception("Katalog güncellemesi BAŞARISIZ — yedek geri konuyor")
            try:
                if yedek.exists():
                    shutil.copy2(yedek, db_path)
            except Exception:
                log.exception("Yedek geri konamadı: %s", yedek)
            return None
