"""PERİYOT — günlük olmayan ilaçların sıklık kilidi.

Niçin var
---------
`drugs` tablosunda **periyot sütunu yoktur**: yalnız `daily_freq`,
`hours_apart`, `treatment_days` var. "Günde mi / haftada mı / ayda mı"
bilgisi **yalnız Medula reçetesinden** gelir. Reçetenin olmadığı her akış
(Botanik perakende satış · İTS karekod · ETİKET KONTROL sekmesi · veri
düzenleyici önizlemesi) bu bilgiyi taşımaz ve sıklık sessizce **günlüğe**
düşer:

    PROLIA        6 ayda 1   -> "GÜNDE 1 DEFA"   = 180 kat
    SKYRIZI      12 haftada 1-> "SABAH-AKŞAM"    = 168 kat
    METOART/METOJECT haftada 1 -> "SABAH-AKŞAM"  =  14 kat   (metotreksat)
    FOSAMAX      haftada 1   -> "GÜNDE 1 DEFA"   =   7 kat

Metotreksatın günlük alınması kemik iliğini baskılar; öldürücüdür.

İki katmanlı çalışır
--------------------
1. **AD + GÜÇ katmanı** — marka adı ve dozu birlikte eşleşirse periyot
   KESİN bilinir ("FOSAMAX 70MG" → haftada 1). Bu katman ATC bilmeyen
   akışlarda da çalışır; etikete ilaç adı her akışta gelir.
2. **ATC + FORM katmanı** — marka listede yoksa ama sınıf günlük-olmayan
   ise (depo enjeksiyon, biyolojik iğne) periyot **BELİRSİZ** döner:
   aralık iddia edilmez, ama **günlük cümle de üretilmez.**

🔴 Kural MOLEKÜLE değil, **ATC + FORM (+ güç)** üçlüsüne bakar. Sebebi
ölçüldü: DOZ denetçisinin ham taramasının **%63'ü yanlış alarmdı** ve
sebebi tekti — aynı ATC'de molekülün *günlük ağızdan* formu ile *depo*
formu birlikte bulunur:

    N05AX08  RISPERDAL 1MG TABLET      → GÜNLÜK   (dokunulmaz)
    N05AX08  RISPERDAL CONSTA FLAKON   → 2 HAFTADA BİR
    L02AE02  LUCRIN 5MG/ML FLAKON      → GÜNLÜK   (IVF downregülasyon)
    L02AE02  LUCRIN DEPOT 1 AY 3.75MG  → AYDA BİR
    A11CC05  TERA-D3 50.000IU DAMLA    → GÜNLÜK damla (şişe)
    A11CC05  TERA-D3 300000IU AMPUL    → TEK DOZ

`AMAC.md` birinci kural: *tarifte asla hata olmamalı.* Bu yüzden emin
olunmayan yerde **boş bırakmak** yanlış yazmaya tercih edilir — kalıp
depoda zaten var (`route_class="0"` → boş cümle).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Optional

__all__ = ["Periyot", "periyot_bul", "gunluk_mu", "gunluk_cumle_yasak"]


# ---------------------------------------------------------------------------
# Sonuç tipi
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Periyot:
    """Bir ilacın günlük OLMAYAN kullanım aralığı.

    metin : etiket ızgarasının okuduğu periyot ifadesi.
            "Haftada" | "2 Haftada" | "8 Haftada" | "12 Haftada" |
            "Ayda" | "3 Ayda" | "6 Ayda" | "Yılda" | "TEK DOZ" | "BELİRSİZ"
    kez   : periyot içindeki kullanım sayısı (haftada 1 → 1).
    kural : hangi kuralın ateşlediği — izlenebilirlik için, rapora yazılır.
    guc   : "KESIN" (marka+güç eşleşti) | "BELIRSIZ" (sınıf günlük değil,
            aralık iddia edilmiyor).
    """

    metin: str
    kez: int = 1
    kural: str = ""
    guc: str = "KESIN"

    @property
    def tek_doz(self) -> bool:
        return self.metin == "TEK DOZ"

    @property
    def belirsiz(self) -> bool:
        return self.metin == "BELİRSİZ"


# ---------------------------------------------------------------------------
# Ad normalleştirme — "300.000IU" ile "300000IU" aynı ilaçtır
# ---------------------------------------------------------------------------
def _norm(ad: str) -> str:
    """Adı karşılaştırılabilir tek biçime indirger.

    🔴 Ölçüldü: aynı ilaç veritabanında iki yazımla duruyor —
    "FOSAMAX 70MG 4 TABLET" (satış 40) ve "FOSAMAX 70 MG 4 TABLET" (satış 0).
    Boşluk/nokta/virgül normalleştirilmezse kural birinde ateşler öbüründe
    ateşlemez; **aynı ilaç iki farklı etiket basar.**

        "FOSAMAX 70 MG"        → "FOSAMAX 70MG"
        "TERA-D3 300.000IU/ML" → "TERA-D3 300000IU/ML"
        "ZOLADEX 3,6MG"        → "ZOLADEX 36MG"
    """
    s = (ad or "").upper()
    s = s.replace("İ", "I").replace("Ş", "S").replace("Ğ", "G")
    s = s.replace("Ü", "U").replace("Ö", "O").replace("Ç", "C")
    # Ondalık virgül → nokta ("1,5 MG" ile "1.5 MG" aynı ilaç)
    s = re.sub(r"(\d),(\d)", r"\1.\2", s)
    # 300.000 → 300000 · 1.200.000 → 1200000 · 3.6 → 36  (rakam-ayraç-rakam)
    while re.search(r"\d[.\s]\d", s):
        s = re.sub(r"(\d)[.\s](\d)", r"\1\2", s)
    # "70 MG" → "70MG" · "100 ML" → "100ML" (sayı ile birimi birleştir)
    s = re.sub(r"(\d)\s+(MG|MCG|IU|ML|GR|G)\b", r"\1\2", s)
    return s


def _adet(ad_n: str, birim: str) -> Optional[int]:
    """Kutudaki birim sayısı: "FLUCAN 150MG 12 KAPSUL" → 12.
    Kutu büyüklüğü periyodu ele verir: 1-2 kapsül tek doz, 12 kapsül haftalık."""
    m = re.search(r"(\d+)\s+" + birim, ad_n)
    return int(m.group(1)) if m else None


_ENJEKSIYON_FORMLARI = {"injection_im", "injection_iv", "injection_sc"}
# Form sütunu 17.740 kaydın ancak üçte birinde dolu; boşsa addan anlaşılır.
_ENJEKSIYON_AD_IZI = (
    "ENJEKS", "ENJEKT", "AMPUL", "FLAKON", "SIRINGA", "SIRINGASI",
    "IMPLANT", "SC.", "IM ", "IM/", "/IM", "SUBKUTAN", "INFUZYON",
)


def _enjeksiyon_mu(ad_n: str, form: str) -> bool:
    if (form or "") in _ENJEKSIYON_FORMLARI:
        return True
    return any(iz in ad_n for iz in _ENJEKSIYON_AD_IZI)


# Depo/uzun salımlı enjeksiyonu, aynı ATC'deki günlük ağızdan formdan ayıran
# işaretler. 🔴 Bunlar TEK BAŞINA yetmez — her zaman ATC + enjeksiyon formuyla
# birlikte aranır (aksi hâlde "DEPOT" geçen her ad yakalanırdı).
_DEPO_IZI = (
    "DEPOT", "DEPO ", "CONSTA", "MAINTENA", "TREVICTA", "XEPLION",
    "DEKANOAT", "DECANOAT", "DEKANOAS", "ACUPHASE", "UZUN SALIMLI",
)


# ---------------------------------------------------------------------------
# 1. KATMAN — marka adı + güç (KESİN)
#
# Her satır: (kural_adı, [adda BULUNMASI gereken parçalar], periyot, kez)
# Parçaların HEPSİ bulunmalıdır; biri bile yoksa kural ateşlemez. Güç değeri
# ("70MG", "150MG") kuralın parçasıdır — aynı markanın günlük sunumu vardır.
# ---------------------------------------------------------------------------
_AD_KURALLARI: tuple[tuple[str, tuple[str, ...], str, int], ...] = (
    # --- Metotreksat: haftada bir. Günlük alım öldürücüdür. -----------------
    ("mtx-sc-metoart",      ("METOART",),            "Haftada", 1),
    ("mtx-sc-metoject",     ("METOJECT",),           "Haftada", 1),
    ("mtx-sc-meksratu",     ("MEKSRATU",),           "Haftada", 1),
    ("mtx-sc-submex",       ("SUBMEX",),             "Haftada", 1),
    ("mtx-tablet-ebewe",    ("METHOTREXATE", "TABLET"), "Haftada", 1),
    ("mtx-tablet-emthex",   ("EMTHEXATE", "TABLET"), "Haftada", 1),
    # 🔴 "TREXAN" adı kural olarak KONMADI: bu depoda metotreksat (L04AX03),
    #    ama başka ülkelerde naltrekson markasıdır ve o GÜNLÜKTÜR. ATC katmanı
    #    zaten yakalıyor — ada değil ATC'ye güvenilir.

    # --- Bifosfonatlar: güç periyodu söyler --------------------------------
    # 🔴 Alendronatın 10 MG'lık sunumu GÜNLÜKTÜR (FOSAMAX 10 MG, VEGABON 10 MG,
    #    ANDANTE/BONEMAX/OSTEOMAX 10 MG) — bu yüzden güç kuralın parçasıdır ve
    #    ayrıca _gunluk_istisna() ile ikinci kez korunur.
    ("alendronat-70",       ("FOSAMAX", "70MG"),     "Haftada", 1),
    ("alendronat-70-fosav", ("FOSAVANCE",),          "Haftada", 1),
    ("alendronat-70-vegab", ("VEGABON", "70MG"),     "Haftada", 1),
    ("alendronat-70-vegab-plus", ("VEGABON", "PLUS"), "Haftada", 1),
    ("alendronat-70-jenerik", ("ALENDRO", "70MG"),   "Haftada", 1),
    ("risedronat-35",       ("RISEDRO", "35MG"),     "Haftada", 1),
    ("ibandronat-150",      ("BONVIVA", "150MG"),    "Ayda", 1),
    ("ibandronat-150-ibanos", ("IBANOS", "150MG"),   "Ayda", 1),
    ("risedronat-150-bonep", ("BONEPLUS", "150MG"),  "Ayda", 1),
    ("risedronat-150-femar", ("FEMARIS", "150MG"),   "Ayda", 1),
    ("ibandronat-iv-3mg",   ("IBANOS", "3MG/3ML"),   "3 Ayda", 1),
    ("zoledronik-yillik-aclasta", ("ACLASTA", "5MG/100ML"),   "Yılda", 1),
    ("zoledronik-yillik-ronidro", ("RONIDRO", "5MG/100ML"),   "Yılda", 1),
    ("zoledronik-yillik-zodinasil", ("ZODINASIL", "5MG/100ML"), "Yılda", 1),
    ("zoledronik-yillik-osteores", ("OSTEORES", "5MG/100ML"), "Yılda", 1),

    # --- Kemik: denosumab / romosozumab / teriparatid ----------------------
    # 🔴 PROLIA 60MG 6 ayda bir, XGEVA 120MG ayda bir — AYNI MOLEKÜL.
    ("denosumab-prolia",    ("PROLIA",),             "6 Ayda", 1),
    ("denosumab-xgeva",     ("XGEVA",),              "Ayda", 1),
    ("romosozumab-evenity", ("EVENITY",),            "Ayda", 1),
    # FORSTEO (teriparatid) GÜNLÜKTÜR — bilerek listede yok (negatif kontrol).

    # --- Depo antipsikotikler (ağızdan formları GÜNLÜK, listede yok) -------
    ("depo-risperidon",     ("RISPERDAL", "CONSTA"), "2 Haftada", 1),
    ("depo-aripiprazol",    ("ABILIFY", "MAINTENA"), "Ayda", 1),
    ("depo-paliperidon-1ay", ("XEPLION",),           "Ayda", 1),
    ("depo-paliperidon-3ay", ("TREVICTA",),          "3 Ayda", 1),
    ("depo-haloperidol",    ("NORODOL", "DEKANOAT"), "Ayda", 1),

    # --- GnRH analogları: depo sunum ayda/3 ayda; flakon sunumu GÜNLÜK -----
    ("gnrh-lucrin-3ay",     ("LUCRIN", "3M"),        "3 Ayda", 1),
    ("gnrh-lucrin-3ay-guc", ("LUCRIN", "1125MG"),    "3 Ayda", 1),
    ("gnrh-lucrin-1ay",     ("LUCRIN", "DEPOT", "375MG"), "Ayda", 1),
    ("gnrh-zoladex-3ay",    ("ZOLADEX", "108MG"),    "3 Ayda", 1),
    ("gnrh-zoladex-1ay",    ("ZOLADEX", "36MG"),     "Ayda", 1),
    ("gnrh-eligard-1ay",    ("ELIGARD", "75MG"),     "Ayda", 1),
    ("gnrh-eligard-3ay",    ("ELIGARD", "225MG"),    "3 Ayda", 1),
    ("gnrh-eligard-6ay",    ("ELIGARD", "45MG"),     "6 Ayda", 1),

    # --- Biyolojik SC iğneler ----------------------------------------------
    # 🔴 ENBREL 50 MG haftada BİR, 25 MG haftada İKİ kez uygulanır — aynı marka,
    #    aynı ATC, farklı periyot. Güç okunmadan "ENBREL → haftada 1" demek
    #    25 MG kullanan hastaya yarım doz yazdırır.
    ("biyo-etanersept-50",  ("ENBREL", "50MG"),      "Haftada", 1),
    ("biyo-etanersept-25",  ("ENBREL", "25MG"),      "Haftada", 2),
    ("biyo-adalimumab-humira", ("HUMIRA",),          "2 Haftada", 1),
    ("biyo-adalimumab-amgevita", ("AMGEVITA",),      "2 Haftada", 1),
    ("biyo-adalimumab-hyrimoz", ("HYRIMOZ",),        "2 Haftada", 1),
    ("biyo-adalimumab-imraldi", ("IMRALDI",),        "2 Haftada", 1),
    ("biyo-golimumab",      ("SIMPONI",),            "Ayda", 1),
    ("biyo-ustekinumab",    ("STELARA",),            "12 Haftada", 1),
    ("biyo-risankizumab",   ("SKYRIZI",),            "12 Haftada", 1),
    ("biyo-guselkumab",     ("TREMFYA",),            "8 Haftada", 1),

    # --- Testosteron depo (jel/saşe GÜNLÜKTÜR, listede yok) ----------------
    ("testosteron-sustanon", ("SUSTANON", "AMPUL"),  "3 Haftada", 1),
    ("testosteron-tesroject", ("TESROJECT", "ENJEKS"), "3 Haftada", 1),

    # --- Aralığı KESİN bilinmeyen ama GÜNLÜK OLMADIĞI kesin olanlar --------
    # 🔴 Bunlar ad katmanında duruyor çünkü ATC'siz akışlar (Botanik perakende,
    #    İTS) kimliği yalnız addan okuyabiliyor; ATC katmanı orada çalışmıyor.
    ("depo-zuklopentiksol",  ("CLOPIXOL", "DEPOT"),   "BELİRSİZ", 1),
    ("zuklopentiksol-acuphase", ("CLOPIXOL", "ACUPHASE"), "BELİRSİZ", 1),
    ("testosteron-undekanoat", ("NEBIDO",),           "BELİRSİZ", 1),
    ("onkoloji-mtx-flakon",  ("METHOTREXATE", "FLAKON"), "BELİRSİZ", 1),

    # --- Depo kontraseptif enjeksiyonlar -----------------------------------
    ("depo-provera",        ("DEPO-PROVERA",),       "3 Ayda", 1),
    ("depo-mesigyna",       ("MESIGYNA",),           "Ayda", 1),

    # --- D vitamini: yüksek doz sunumlar (damla/şişe GÜNLÜKTÜR) ------------
    ("dvit-300000-ampul",   ("300000IU", "AMPUL"),   "TEK DOZ", 1),
    ("dvit-300000-amp",     ("300000IU", "AMP"),     "TEK DOZ", 1),
    ("dvit-50000-kapsul",   ("50000IU", "KAPSUL"),   "Haftada", 1),

    # (Tek dozluk tedaviler — fosfomisin/flukonazol/benzatin — kutu büyüklüğüne
    #  ve uygulama yoluna baktığı için aşağıda _kutu_kurallari() içinde.)
)


# ---------------------------------------------------------------------------
# 1b. KATMAN — kutu büyüklüğü / uygulama yolu okunarak karar verilenler
#
# Bunlar sabit listeye sığmaz: aynı marka + aynı güç, farklı kutu = farklı
# periyot. "FLUCAN 150MG 2 KAPSÜL" tek dozdur, "FLUCAN 150MG 12 KAPSÜL"
# tırnak mantarı için HAFTALIKTIR.
# ---------------------------------------------------------------------------
_ORAL_FOSFOMISIN_IZI = ("SASE", "SASESI", "GRANUL", "EFERVESAN", "ORAL", "3GR", "3G ")

# ATC'siz akışlar için marka → aile eşlemesi. Etikete ilaç adı HER akışta gelir,
# ATC gelmez (Botanik perakende satışta yalnız barkod + ad + adet vardır).
_MARKA_AILESI: tuple[tuple[str, str], ...] = (
    ("MONUROL", "J01XX01"), ("UROCARE", "J01XX01"), ("UROMISIN", "J01XX01"),
    ("URODAY", "J01XX01"), ("DISPARI", "J01XX01"), ("PHOSMYCIN", "J01XX01"),
    ("FOSDAY", "J01XX01"), ("FOSFONE", "J01XX01"), ("UROBEL", "J01XX01"),
    ("ZERONAT", "J01XX01"),
    ("FLUCAN", "J02AC01"), ("FLUZOLE", "J02AC01"), ("CANDIMAX", "J02AC01"),
    ("FUNGAN", "J02AC01"), ("ZOLAX", "J02AC01"), ("TRIFLUCAN", "J02AC01"),
    ("FLUZAMED", "J02AC01"),
    ("ELLA", "G03AD"), ("ERTES", "G03AD"), ("POSTPILL", "G03AD"),
    ("JOSEI", "G03AD"), ("NORLEVO", "G03AD"), ("ABALEVO", "G03AD"),
    ("ULPISAD", "G03AD"),
    ("DEPOSILIN 1200000IU", "J01CE08"), ("DEPOSILIN 2400000IU", "J01CE08"),
    ("BENZAPEN-LA", "J01CE08"), ("PENTIN -LA", "J01CE08"), ("PENTIN-LA", "J01CE08"),
)


@lru_cache(maxsize=512)
def _desen(token: str) -> re.Pattern:
    return re.compile(r"(?<![0-9A-Z])" + re.escape(token) + r"(?![0-9A-Z])")


def _icerir(ad_n: str, token: str) -> bool:
    """Marka/güç parçasını **kelime sınırıyla** arar.

    🔴 Ölçülmüş kusur: düz `in` araması "KWELLADA LOTION %5" (629 satış,
    uyuz losyonu) içinde ertesi-gün hapı markası "ELLA"yı buldu ve losyonu
    "TEK DOZ — TEKRARLANMAZ" diye etiketledi. Bir markanın adı, başka bir
    markanın adının İÇİNDE geçebilir; alt-dize eşleşmesi kural değildir.
    """
    return _desen(token).search(ad_n) is not None


def _aile(ad_n: str, atc: str) -> str:
    """ATC varsa odur; yoksa marka adından aile tahmin edilir."""
    a = (atc or "").upper().strip()
    if a:
        return a
    for marka, aile in _MARKA_AILESI:
        if _icerir(ad_n, marka):
            return aile
    return ""


def _kutu_kurallari(ad_n: str, atc: str) -> Optional[Periyot]:
    a = _aile(ad_n, atc)

    # --- Fosfomisin: SAŞE tek dozdur; IV perfüzyon (FOSIT) GÜNDE 2-3 KEZ ----
    # 🔴 Yanlış ateşleme yakalandı: "FOSIT 4 G IV PERF." saşe sanılıp tek doz
    #    etiketlenmişti. IV sunum bu kuralın dışındadır.
    if a.startswith("J01XX01"):
        if any(_icerir(ad_n, iz) for iz in ("IV", "PERF", "INFUZYON", "LIYO")):
            return None
        if any(iz in ad_n for iz in _ORAL_FOSFOMISIN_IZI):
            return Periyot("TEK DOZ", 1, "fosfomisin-oral-sase", "KESIN")
        return None

    # --- Flukonazol 150 mg: kutuda 1-2 kapsül tek doz, 4+ kapsül haftalık ---
    if a.startswith("J02AC01") and _icerir(ad_n, "150MG"):
        n = _adet(ad_n, "KAPSUL") or _adet(ad_n, "TABLET")
        if n is not None and n >= 4:
            return Periyot("Haftada", 1, "flukonazol-150-haftalik-kutu", "KESIN")
        return Periyot("TEK DOZ", 1, "flukonazol-150-tek-doz", "KESIN")

    # --- Zoledronik asit 5 mg/100 ml = YILLIK osteoporoz infüzyonu ---------
    # (4 mg/5 ml onkoloji sunumu 3-4 haftada birdir → aşağıda BELİRSİZ kalır.)
    if a.startswith("M05BA08") and "5MG/100ML" in ad_n:
        return Periyot("Yılda", 1, "zoledronik-5mg-100ml-yillik", "KESIN")

    # --- Ustekinumab: SC idame 12 haftada bir; 130 mg IV yükleme TEK seferlik
    if _icerir(ad_n, "STELARA") and (_icerir(ad_n, "INFUZYON") or _icerir(ad_n, "130MG")):
        return Periyot("BELİRSİZ", 1, "stelara-iv-yukleme", "BELIRSIZ")

    # --- Acil kontrasepsiyon: 1,5 mg tek tablet TEK DOZ; 750 mcg'lik iki
    #     tabletli eski sunum 12 saat arayla iki doz olabilir → iddia yok.
    if a.startswith("G03AD"):
        if _icerir(ad_n, "750MCG") or _icerir(ad_n, "075MG"):
            return Periyot("BELİRSİZ", 1, "acil-kontrasepsiyon-750mcg-ikili", "BELIRSIZ")
        return Periyot("TEK DOZ", 1, "acil-kontrasepsiyon-tek-tablet", "KESIN")

    # --- Benzatin penisilin (J01CE08): akut tedavide tek doz, romatizmal
    #     profilakside 3-4 haftada bir. İkisi de günlük DEĞİL; hangisi olduğu
    #     etiketten bilinemez → aralık iddia edilmez.
    #     🔴 J01CE30 kombinasyonları (IECILLINE, DEVAPEN, DEPOSILIN 6.3.3)
    #     BİLEREK dışarıda: prokain penisilin GÜNDE BİR uygulanabilir.
    if a.startswith("J01CE08"):
        return Periyot("BELİRSİZ", 1, "benzatin-penisilin-J01CE08", "BELIRSIZ")

    return None


# ---------------------------------------------------------------------------
# GÜNLÜK İSTİSNALARI — "bu sınıf günlük değildir" genellemesinin delikleri
#
# 🔴 İki yönlü sınavın kalbi burasıdır: aşağıdaki ilaçlar GERÇEKTEN günlüktür
# ve hiçbir kural onlara dokunmamalıdır. Sınav bunları listede görürse kural
# bozuk demektir.
# ---------------------------------------------------------------------------
def _gunluk_istisna(ad_n: str, atc: str) -> bool:
    a = (atc or "").upper()
    # Alendronat 10 mg — GÜNLÜK sunum (70 mg haftalıktır).
    if a.startswith("M05BA04") and _icerir(ad_n, "10MG"):
        return True
    # Etidronat (DIDRONAT 200/400 mg) — 14 gün ARDIŞIK GÜNLÜK siklik şema.
    if a.startswith("M05BA01"):
        return True
    # 🔴 Anakinra (KINERET) — biyolojik SC iğnelerin tek GÜNLÜK üyesi.
    #    "L04AC enjeksiyon → günlük değildir" genellemesinin deliği; ölçümde
    #    yakalandı (ATC katmanı onu da susturuyordu).
    if a.startswith("L04AC03") or _icerir(ad_n, "KINERET"):
        return True
    # Risedronat 5 mg — günlük sunum (35 mg haftalık, 150 mg aylık).
    if a.startswith(("M05BA07", "M05BB07")) and _icerir(ad_n, "5MG") and not _icerir(ad_n, "35MG") and not _icerir(ad_n, "150MG"):
        return True
    return False


# ---------------------------------------------------------------------------
# 2. KATMAN — ATC + FORM (marka listede yoksa: BELİRSİZ, yani "günlük deme")
# ---------------------------------------------------------------------------
def _atc_katmani(ad_n: str, atc: str, form: str) -> Optional[Periyot]:
    a = (atc or "").upper().strip()
    if not a:
        return None
    enj = _enjeksiyon_mu(ad_n, form)
    depo = any(iz in ad_n for iz in _DEPO_IZI)

    # Metotreksat — romatoloji/psoriazis sunumlarının HEPSİ haftalıktır.
    if a.startswith("L04AX03"):
        return Periyot("Haftada", 1, "atc-L04AX03-metotreksat", "KESIN")
    # Onkoloji metotreksatı (L01BA01): şema protokole göre değişir → iddia yok.
    if a.startswith("L01BA01") and enj:
        return Periyot("BELİRSİZ", 1, "atc-L01BA01-onkoloji-mtx", "BELIRSIZ")

    # Bifosfonatlar + denosumab/romosozumab: marka eşleşmediyse aralığı iddia
    # etme, günlük de deme. (Günlük sunumlar _gunluk_istisna()'da elenmiştir:
    # alendronat 10 mg, risedronat 5 mg, etidronat.)
    if a.startswith("M05B"):
        return Periyot("BELİRSİZ", 1, "atc-M05B-kemik", "BELIRSIZ")

    # Depo antipsikotikler — YALNIZ enjeksiyon + depo işareti birlikteyken.
    if a.startswith(("N05AX08", "N05AX12", "N05AX13", "N05AD01", "N05AF05")) and enj and depo:
        return Periyot("BELİRSİZ", 1, "atc-N05A-depo-enjeksiyon", "BELIRSIZ")

    # GnRH analogları — depo sunum (flakon/ampul sunumu GÜNLÜK olabilir).
    if a.startswith("L02AE") and enj and (depo or _icerir(ad_n, "IMPLANT") or _icerir(ad_n, "ELIGARD")):
        return Periyot("BELİRSİZ", 1, "atc-L02AE-gnrh-depo", "BELIRSIZ")

    # Biyolojik iğneler (anti-TNF / interlökin) — hiçbiri günlük değildir.
    if a.startswith(("L04AB", "L04AC")) and enj:
        return Periyot("BELİRSİZ", 1, "atc-L04AB-AC-biyolojik", "BELIRSIZ")

    # Testosteron enjeksiyonları (jel/saşe GÜNLÜKTÜR — enj şartı onu eler).
    if a.startswith("G03BA03") and enj:
        return Periyot("BELİRSİZ", 1, "atc-G03BA03-testosteron-enj", "BELIRSIZ")

    # Depo kontraseptifler (label_from_db.py:2271'deki kalıbın genelleştirmesi).
    if a.startswith("G03AC06"):
        return Periyot("3 Ayda", 1, "atc-G03AC06-depo-provera", "KESIN")
    if a.startswith("G03AA") and enj:
        return Periyot("Ayda", 1, "atc-G03AA-enjektabl-kontraseptif", "KESIN")

    # (Tek dozluk tedaviler — fosfomisin · flukonazol · benzatin penisilin ·
    #  acil kontrasepsiyon — kutu/yol okuyan _kutu_kurallari()'nda.)

    # Yüksek doz D vitamini — 300.000 IU ampul tek dozdur; damla/şişe DEĞİL.
    if a.startswith("A11CC") and _icerir(ad_n, "300000IU") and _enjeksiyon_mu(ad_n, form):
        return Periyot("TEK DOZ", 1, "atc-A11CC-dvit-300000", "KESIN")

    return None


# ---------------------------------------------------------------------------
# Genel kapı
# ---------------------------------------------------------------------------
def periyot_bul(ad: str, atc: str = "", form: str = "", route_class: str = "") -> Optional[Periyot]:
    """İlacın günlük OLMAYAN periyodunu döndürür; kural yoksa None.

    None = "bu ilaç hakkında kuralım yok" demektir; **günlük olduğu anlamına
    gelmez**. Çağıran taraf mevcut davranışını sürdürür.
    """
    ad_n = _norm(ad)
    if not ad_n:
        return None

    # 0. GÜNLÜK İSTİSNASI — sınıfı günlük-olmayan ama KENDİSİ günlük olan
    #    sunumlar (alendronat 10 mg…). Her şeyden önce elenir.
    if _gunluk_istisna(ad_n, atc):
        return None

    # 1. katman — kutu büyüklüğü / uygulama yolu (ATC yoksa markadan).
    # 🔴 Marka kuralından ÖNCE koşar: aynı markanın istisnası burada yakalanır.
    #    Ölçüldü — "STELARA 130 MG INFUZYONLUK" (IV yükleme, tek seferlik) marka
    #    kuralına takılıp "12 HAFTADA" etiketleniyordu; sıra düzeltildi.
    p = _kutu_kurallari(ad_n, atc)
    if p is not None:
        return p

    # 2. katman — marka + güç (KESİN)
    for kural, parcalar, metin, kez in _AD_KURALLARI:
        if all(_icerir(ad_n, p) for p in parcalar):
            return Periyot(metin, kez, kural,
                           "BELIRSIZ" if metin == "BELİRSİZ" else "KESIN")

    # 2. katman — ATC + form (aralık iddia edilmez, günlük de denmez)
    return _atc_katmani(ad_n, atc, form)


def gunluk_mu(ad: str, atc: str = "", form: str = "", route_class: str = "") -> Optional[bool]:
    """Üç değerli cevap:
        False → günlük DEĞİL (periyodik/tek doz)  → günlük cümle üretme
        None  → bilinmiyor                        → çağıranın varsayılanı sürer
        True  → hiç dönmez; bu tablo yalnız günlük-olmayanı tanır.
    """
    return False if periyot_bul(ad, atc, form, route_class) else None


def gunluk_cumle_yasak(ad: str, atc: str = "", form: str = "", route_class: str = "") -> bool:
    """`True` ise "GÜNDE N DEFA" / "SABAH-AKŞAM" cümlesi ÜRETİLMEZ."""
    return periyot_bul(ad, atc, form, route_class) is not None
