"""Farmasötik form bazlı kullanım tekniği şablonları.

Her şablon, drug_label_blocks tablosunda block_type='teknik' bloğuna varsayılan
içerik üretir. İlaca özgü farklılık (örn. spesifik bir inhaler markası için ek
adım) varsa DB'de override edilir; o zaman ilgili satırın `reviewed=2` (düzeltilmiş)
işaretlenmesi tercih edilir.

Kullanım:
    from ilactarif.application_techniques import TECHNIQUES, infer_form
    tpl = TECHNIQUES["tablet_normal"]
    print(tpl["content"])

infer_form() ilaç adı + uygulama yolundan form anahtarını tahmin eder.
"""
from __future__ import annotations

import re

from typing import TypedDict


class TechniqueTemplate(TypedDict):
    label: str        # İnsan dilinde form adı (UI gösterimi)
    route: str        # Varsayılan uygulama yolu
    dose_unit: str    # Varsayılan doz birimi
    content: str      # Hastanın görmesi gereken teknik talimat


TECHNIQUES: dict[str, TechniqueTemplate] = {
    # ============================ TABLET / KAPSÜL ============================
    "tablet_normal": {
        "label": "Tablet",
        "route": "ağızdan",
        "dose_unit": "tablet",
        "content": (
            "Bir bardak su ile, çiğnemeden bütün olarak yutunuz. "
            "Yutmakta zorluk yaşıyorsanız ikiye bölüp arka arkaya yutabilirsiniz."
        ),
    },
    "tablet_chewable": {
        "label": "Çiğnenebilir tablet",
        "route": "ağızdan",
        "dose_unit": "tablet",
        "content": (
            "Tableti ağızda iyice çiğneyiniz, suya ihtiyaç yoktur. "
            "Çiğnemeden yutmayınız (etki azalır)."
        ),
    },
    "tablet_sublingual": {
        "label": "Dilaltı tableti",
        "route": "dilaltı",
        "dose_unit": "tablet",
        "content": (
            "Dilin altına koyup eriyene kadar bekleyiniz. "
            "YUTMAYINIZ; eriyene kadar konuşmamaya, su içmemeye dikkat ediniz."
        ),
    },
    "tablet_effervescent": {
        "label": "Efervesan tablet",
        "route": "ağızdan",
        "dose_unit": "tablet",
        "content": (
            "Bir bardak (200 ml) suya atın, kabarcıkların tamamen bitmesini bekleyin, "
            "dipte tortu kalmayacak şekilde içiniz."
        ),
    },
    "tablet_enteric_or_extended": {
        "label": "Enterik / uzatılmış salımlı tablet",
        "route": "ağızdan",
        "dose_unit": "tablet",
        "content": (
            "Bir bardak su ile, ÇİĞNEMEDEN, KIRMADAN, EZMEDEN bütün olarak yutunuz. "
            "Kapsül/tabletin yapısı bozulursa ilaç doğru çalışmaz."
        ),
    },
    "capsule_normal": {
        "label": "Kapsül",
        "route": "ağızdan",
        "dose_unit": "kapsül",
        "content": (
            "Bir bardak su ile bütün olarak yutunuz, açmayınız."
        ),
    },
    "capsule_pellet_open": {
        "label": "Mikropellet kapsül (açılabilir)",
        "route": "ağızdan",
        "dose_unit": "kapsül",
        "content": (
            "Yutamıyorsanız kapsülü açıp içindeki granülleri 1 kaşık soğuk yumuşak "
            "gıdaya (yoğurt, elma püresi) karıştırıp HEMEN yutunuz, çiğnemeyiniz."
        ),
    },

    # ============================ SIVI ============================
    "syrup_or_suspension": {
        "label": "Şurup / süspansiyon",
        "route": "ağızdan",
        "dose_unit": "ml",
        "content": (
            "Kullanmadan önce şişeyi iyice ÇALKALAYINIZ. Verilen ölçü kabı veya "
            "şırınga ile ölçünüz; kaşık tahmini ölçü değildir. "
            "Açıldıktan sonra üreticinin belirttiği süre içinde tüketiniz."
        ),
    },
    "powder_for_suspension": {
        "label": "Süspansiyon (kuru toz, sulandırılarak)",
        "route": "ağızdan",
        "dose_unit": "ml",
        "content": (
            "Hazırlama: Şişenin işaretine kadar kaynamış-soğutulmuş su ekleyip "
            "iyice çalkalayınız (gerekirse 2 aşamada). Her kullanım öncesi yeniden "
            "çalkalayınız. Hazırlandıktan sonra BUZDOLABINDA saklayınız, 7-14 gün "
            "içinde tüketiniz (kutuda belirtilen sürede)."
        ),
    },
    "oral_drop": {
        "label": "Oral damla",
        "route": "ağızdan",
        "dose_unit": "damla",
        "content": (
            "Belirtilen damla sayısını doğrudan ağıza YA DA bir miktar içeceğe "
            "(su, meyve suyu) damlatıp içiniz. Göze/buruna damlatmayınız — "
            "bu bir AĞIZDAN damladır. Şişeyi sallamayınız (doz değişir). "
            "Açıldıktan sonra kutuda belirtilen sürede tüketiniz."
        ),
    },

    # ============================ DIŞ KULLANIM ============================
    "cream_or_ointment_topical": {
        "label": "Krem / pomad",
        "route": "cilt üzerine",
        "dose_unit": "uygulama",
        "content": (
            "Etkilenen bölgeye İNCE BİR TABAKA halinde sürünüz, hafifçe ovuşturarak "
            "emilmesini sağlayınız. Uygulamadan önce ve sonra ellerinizi yıkayınız. "
            "Göz, ağız ve açık yaraya temas ettirmeyiniz."
        ),
    },
    "gel_topical": {
        "label": "Jel (cilt)",
        "route": "cilt üzerine",
        "dose_unit": "uygulama",
        "content": (
            "Etkilenen bölgeye ince bir tabaka halinde sürüp emilene kadar "
            "ovuşturunuz. Kullanım sonrası ellerinizi yıkayınız."
        ),
    },
    "transdermal_patch": {
        "label": "Bant / flaster (transdermal)",
        "route": "cilt üzerine",
        "dose_unit": "bant",
        "content": (
            "Temiz, kuru, tüysüz cilt bölgesine yapıştırınız (kol, göğüs, sırt). "
            "Her seferinde aynı yere yapıştırmayın; bölgeleri dönüşümlü kullanın. "
            "Bant düşerse yenisini yapıştırın, çift uygulamayın."
        ),
    },

    # ============================ GÖZ / KULAK / BURUN ============================
    "eye_drop": {
        "label": "Göz damlası",
        "route": "göze",
        "dose_unit": "damla",
        "content": (
            "1) Ellerinizi yıkayın. 2) Başı geriye atın, alt göz kapağını parmakla "
            "aşağı çekerek küçük bir cep oluşturun. 3) Şişeyi göze değdirmeden, "
            "alt göz kapağının içine 1 damla damlatın. "
            "4) 1 dakika gözü kapalı tutun, gözün iç köşesine (burun tarafına) "
            "parmakla hafifçe bastırın. Birden fazla damla varsa 5 dk arayla. "
            "Açıldıktan sonra 1 AY içinde tüketin. Birden fazla kişi kullanmaz."
        ),
    },
    "eye_ointment": {
        "label": "Göz pomadı",
        "route": "göze",
        "dose_unit": "uygulama",
        "content": (
            "Alt göz kapağını aşağı çekip ince bir şerit halinde uygulayınız. "
            "Tüpün ucu göze değmemeli. Uyguladıktan sonra 1-2 dk göz kırpıştırınız."
        ),
    },
    "ear_drop": {
        "label": "Kulak damlası",
        "route": "kulağa",
        "dose_unit": "damla",
        "content": (
            "Şişeyi avucunuzda 1-2 dk ısıtın (soğuk damlatmak baş dönmesi yapar). "
            "Yan yatın, kulak kepçesini geri-yukarı çekip damlatın. 5 dk daha "
            "yatın. Birden fazla kişi kullanmaz."
        ),
    },
    "nasal_spray": {
        "label": "Burun spreyi",
        "route": "buruna",
        "dose_unit": "puf",
        "content": (
            "Sümkürerek burnunuzu temizleyin. Başı hafif eğin (geriye yatırmayın). "
            "Bir burun deliğini parmakla kapatın, ucu diğerine yerleştirip nefes "
            "alırken sıkın. Sonra burnu çekmeden 30 sn nefes alın. "
            "Birden fazla kişi kullanmaz."
        ),
    },
    "nasal_drop": {
        "label": "Burun damlası",
        "route": "buruna",
        "dose_unit": "damla",
        "content": (
            "Sırtüstü yatıp başı geriye sarkıtın. Burun deliğine belirtilen damla "
            "sayısını damlatın. 1-2 dk pozisyonu koruyun. Birden fazla kişi kullanmaz."
        ),
    },

    # ============================ AĞIZ / BOĞAZ ============================
    "oral_spray_throat": {
        "label": "Boğaz spreyi",
        "route": "boğaza",
        "dose_unit": "puf",
        "content": (
            "Pompayı ilk kullanımda boşa 2-3 kez sıkın. Ağzı geniş açıp dili "
            "aşağı doğru bastırıp boğaza doğru sıkın. Boğazda kalan kısmı "
            "yutabilirsiniz, fazlasını tükürebilirsiniz. Birden fazla kişi kullanmaz."
        ),
    },
    "sublingual_spray": {
        "label": "Dilaltı sprey (nitrat)",
        "route": "ağıza",
        "dose_unit": "puf",
        "content": (
            "OTURARAK kullanın (tansiyon düşmesi/baygınlık olabilir). Dilinizi "
            "kaldırıp spreyi DİL ALTINA sıkın; yutmayın, 1-2 dk ağzı kapalı "
            "tutun. Ağrı geçmezse 5 dk arayla tekrarlayın; 15 dakikada 3 dozdan "
            "fazla KULLANMAYIN — ağrı sürüyorsa 112'yi arayın."
        ),
    },
    "gargara_mouthwash": {
        "label": "Gargara (ağız çalkalama)",
        "route": "ağıza",
        "dose_unit": "ml",
        "content": (
            "Verilen ölçek ile bir miktar alın, ağızda 30 sn - 1 dk gezdirin, "
            "sonra TÜKÜRÜN, yutmayın. Sonrasında en az 30 dakika yiyip içmeyiniz. "
            "Diş macunundan en az 30 dk uzak kullanın."
        ),
    },
    "oromucosal_gel": {
        "label": "Ağız içi jel",
        "route": "ağıza",
        "dose_unit": "uygulama",
        "content": (
            "Etkilenen bölgeye temiz parmakla veya pamuklu çubukla ince bir "
            "tabaka sürün. Sonrasında 30 dk yiyip içmeyiniz."
        ),
    },

    # ============================ SOLUNUM ============================
    "inhaler_pmdi": {
        "label": "Basınçlı ölçülü doz inhaler (pMDI)",
        "route": "solunum",
        "dose_unit": "puf",
        "content": (
            "1) Cihazı 4-5 kez çalkalayın, kapağı açın. "
            "2) Önce nefesinizi tamamen VERİN. "
            "3) Ağızlığı sarın; YAVAŞ derin nefesle 1 puf sıkın. "
            "4) Nefesinizi 10 sn tutun, yavaşça verin. "
            "5) İkinci puf için 30 sn-1 dk bekleyin. "
            "6) Kortizonlu ise ağzınızı çalkalayın (hazne tercih edin)."
        ),
    },
    "inhaler_dpi": {
        "label": "Kuru toz inhaler (DPI)",
        "route": "solunum",
        "dose_unit": "puf",
        "content": (
            "1) Dozu hazırlayın (çevir/yükle). "
            "2) Önce nefesinizi VERİN; cihazdan UZAĞA, içine üflemeyin. "
            "3) Ağızlığı sarıp DERİN-HIZLI tek nefeste güçlü çekin. "
            "4) Nefesinizi 10 sn tutun, yavaşça verin. "
            "5) Kortizonlu ise ağzınızı su ile çalkalayın."
        ),
    },
    "nebule": {
        "label": "Nebülizatör ampulü",
        "route": "solunum",
        "dose_unit": "ampul",
        "content": (
            "1) Ampulü hazneye boşaltın. "
            "2) Maskeyi/ağızlığı takıp dik oturun. "
            "3) Cihazı çalıştırıp sakin nefes alıp verin. "
            "4) Buhar bitene kadar sürdürün (5-10 dk). "
            "5) Açılan ampulü 24 saatte kullanın; kortizonlu ise yüzü yıkayın."
        ),
    },

    # ============================ REKTAL / VAJİNAL ============================
    "suppository_rectal": {
        "label": "Fitil (rektal)",
        "route": "rektal",
        "dose_unit": "fitil",
        "content": (
            "YUTMAYINIZ — FİTİLDİR; MAKATTAN UYGULANIR. "
            "Buzdolabında saklanıyorsa 1-2 dk dışarıda yumuşamasını bekleyin. "
            "Sivri ucu öne gelecek şekilde, yan yatıp dizleri karna çekin, "
            "fitili makata yerleştirin. 15 dakika boyunca yatın ki erimesin. "
            "Uygulamadan önce ve sonra ellerinizi yıkayın."
        ),
    },
    # Lavman / rektal süspansiyon / rektal krem (aplikatörlü) — FİTİL DEĞİLDİR;
    # "fitil şeklinde" ibaresi yanlış olur, "makattan uygulanır" yeterlidir.
    "enema_rectal": {
        "label": "Rektal lavman / süspansiyon",
        "route": "rektal",
        "dose_unit": "uygulama",
        "content": (
            "YUTMAYINIZ — MAKATTAN UYGULANIR. "
            "Süspansiyon ise kullanmadan önce şişeyi iyice çalkalayın. "
            "Yan yatıp dizleri karna çekin, aplikatör/kanül ucunu makata "
            "yerleştirip içeriği yavaşça sıkın. İlacın etki etmesi için "
            "mümkün olduğunca içeride tutun (laksatif lavman 2-5 dk içinde "
            "etki eder, tuvalete yakın kullanın). "
            "Uygulamadan önce ve sonra ellerinizi yıkayın."
        ),
    },
    # Hemoroid/anal fissür kremi-merhemi (Proctoglyvenol, Kortos, Anrecta...) —
    # cilde değil MAKAT bölgesine sürülür; iç uygulama kanülle yapılır.
    "cream_rectal": {
        "label": "Rektal krem / merhem",
        "route": "rektal",
        "dose_unit": "uygulama",
        "content": (
            "YUTMAYINIZ — MAKAT BÖLGESİNE SÜRÜLÜR. "
            "Tuvaletten sonra bölgeyi temizleyip kurulayın. "
            "Dış uygulama: parmakla makat çevresine ince tabaka sürün. "
            "İç uygulama (doktor önerdiyse): kutudan çıkan kanülü/aplikatörü "
            "tüpe takıp makata yerleştirin ve hafifçe sıkarak uygulayın; "
            "kanülü her kullanımdan sonra yıkayın. "
            "Uygulamadan önce ve sonra ellerinizi yıkayın."
        ),
    },
    "vaginal_ovule_or_cream": {
        "label": "Vajinal ovül / krem",
        "route": "vajinal",
        "dose_unit": "ovül",
        "content": (
            "YUTMAYINIZ — VAJİNAL YOLDAN UYGULANIR. "
            "YATMADAN ÖNCE uygulayın (etki artar). Sırtüstü yatıp dizleri çekin, "
            "ovülü/aplikatörü mümkün olduğunca derine yerleştirin. "
            "Adet döneminde tedavi kesilmez (doktor önermediyse). "
            "Tedavi sırasında pamuklu iç çamaşırı, ilişki için doktora danışın."
        ),
    },

    # ============================ DİĞER FORMLAR ============================
    "shampoo_medicated": {
        "label": "Medikal şampuan",
        "route": "cilt üzerine",
        "dose_unit": "uygulama",
        "content": (
            "Saç ve saç derisini ıslatın. Yeterince ürünü saç derisine sürün, "
            "köpürtün. 3-5 DAKİKA bekledikten sonra bol su ile durulayın. "
            "Haftada 2-3 kez tekrarlayın (kutuya göre değişir). "
            "Göz teması durumunda bol su ile yıkayın."
        ),
    },
    "sachet_oral": {
        "label": "Saşe (oral toz/granül)",
        "route": "ağızdan",
        "dose_unit": "saşe",
        "content": (
            "Saşenin içeriğini bir bardak (200 ml) suya boşaltın, çubuğla "
            "karıştırın ve hemen içiniz. Hazırlandıktan sonra bekletmeyiniz."
        ),
    },
    "nutritional_supplement_oral": {
        "label": "Beslenme ürünü (oral, hazır sıvı)",
        "route": "ağızdan",
        "dose_unit": "ml",
        "content": (
            "Açmadan önce şişeyi çalkalayın. Soğuk veya oda sıcaklığında "
            "tüketebilirsiniz. AÇILDIKTAN sonra BUZDOLABINDA saklayın, 24 SAAT "
            "içinde tüketin. Mikrodalga ile ısıtmayınız (yapı bozulur)."
        ),
    },
    "nutritional_powder_oral": {
        "label": "Beslenme ürünü (toz/mama)",
        "route": "ağızdan",
        "dose_unit": "ölçek",
        "content": (
            "Kutusundaki HAZIRLAMA TARİFİNE tam uyunuz (ölçek sayısı / su "
            "miktarı) — fazla sulandırma besini yetersiz bırakır, az sulandırma "
            "böbreği yorar. Kaynatılıp ılıtılmış su kullanınız. Hazırlananı "
            "bekletmeyiniz, artanı atınız. Açılan kutuyu kuru yerde saklayınız."
        ),
    },

    # ============================ ENJEKSİYON ============================
    "injection_sc": {
        "label": "Cilt altı enjeksiyon (subkutan, evde)",
        "route": "cilt altı",
        "dose_unit": "doz",
        "content": (
            "1) Ellerinizi yıkayın, enjeksiyon bölgesini (göbek çevresi 5 cm uzak, "
            "uyluk dış yüzü, üst kol) alkol ile silin, kuruyana kadar bekleyin. "
            "2) Cildi başparmak-işaretle bir kıvrım yapın, 90° açıyla iğneyi "
            "batırın. 3) Yavaşça ilacı verin. 4) İğneyi çıkarın, ovuşturmayın, "
            "pamukla hafifçe 10 sn basın. Her seferinde BÖLGE DEĞİŞTİRİN."
        ),
    },
    "injection_im": {
        "label": "Kas içi enjeksiyon (sağlık personeli)",
        "route": "kas içi",
        "dose_unit": "doz",
        "content": (
            "Sağlık ocağı / hastane ortamında sağlık personeli tarafından uygulanır."
        ),
    },
    "injection_iv": {
        "label": "Damar içi enjeksiyon (sağlık personeli)",
        "route": "damar içi",
        "dose_unit": "doz",
        "content": (
            "Hastane ortamında sağlık personeli tarafından uygulanır."
        ),
    },
}


# Enjektabl adlarındaki açık uygulama yolu ibareleri. Harf sınırı korumalı:
# "OPTIMARK" IM, "KIOVIG" IV, "ENJEKSIYONLUK" SC sayılmaz.
_B = "A-ZÇĞİÖŞÜ"
_RX_SC = re.compile(rf"(?<![{_B}])S\.?C\.?(?![{_B}])|SUBKUTAN|SUBKÜTAN"
                    rf"|SUBCUTAN|C[İI]LT ALTI")
_RX_IM = re.compile(rf"(?<![{_B}])[İI]\.?M\.?(?![{_B}])|[İI]NTRAMUSK")
_RX_IV = re.compile(rf"(?<![{_B}])[İI]\.?V\.?(?![{_B}])|[İI]NTRAVEN"
                    rf"|[İIE]NF[ÜU]ZYON")


# Anahtar kelime → form anahtarı eşleşmesi (sıralama önemli: spesifik önce)
_NAME_PATTERNS = [
    # solunum
    ("NEBUL", "nebule"), ("NEBÜL", "nebule"),
    ("INHALER", "inhaler_pmdi"), ("İNHALER", "inhaler_pmdi"),  # pMDI varsayılan
    ("AEROSOL", "inhaler_pmdi"),
    ("TURBUHALER", "inhaler_dpi"), ("DISKUS", "inhaler_dpi"),
    ("HANDIHALER", "inhaler_dpi"), ("BREEZHALER", "inhaler_dpi"),
    ("ELLIPTA", "inhaler_dpi"), ("RESPIMAT", "inhaler_pmdi"),
    # ovül / vajinal
    ("OVÜL", "vaginal_ovule_or_cream"), ("VAJİNAL", "vaginal_ovule_or_cream"),
    ("OVUL", "vaginal_ovule_or_cream"), ("VAJINAL", "vaginal_ovule_or_cream"),
    # ASCII yazımlar (NUVARING VAGINAL, VAGIFEM) ve "VAG." kısaltması
    ("VAGİNAL", "vaginal_ovule_or_cream"), ("VAGINAL", "vaginal_ovule_or_cream"),
    ("VAG.", "vaginal_ovule_or_cream"),
    # fitil
    ("FİTİL", "suppository_rectal"), ("SUPPOZ", "suppository_rectal"),
    ("SUPOZ", "suppository_rectal"),
    # insülin / GLP-1 kalemler (önce çünkü FLAKON ile çakışabilir)
    ("KALEM", "injection_sc"), ("FLEXPEN", "injection_sc"),
    ("SOLOSTAR", "injection_sc"), ("KWIKPEN", "injection_sc"),
    # " PEN " başında boşluk şart: LARGOPEN/FLOXAPEN/REGAPEN/SARCOPEN/KLAVUPEN
    # gibi adı PEN ile biten tablet/kapsül/jel/süspansiyonlar enjeksiyon sanılmasın
    (" PEN ", "injection_sc"), ("PENFILL", "injection_sc"),
    ("KARTUŞ", "injection_sc"), ("KARTUS", "injection_sc"),
    # cilt altı / IM
    ("HAZIR ENJEKTÖR", "injection_sc"),  # düşük molekül ağırlıklı heparin
    ("HAZIR ENJEKTOR", "injection_sc"),
    ("ENJEKSIYONLUK", "injection_im"), ("ENJEKSİYONLUK", "injection_im"),
    ("AMPUL", "injection_im"), ("FLAKON", "injection_im"),
    ("AMP.", "injection_im"), ("AMP ", "injection_im"),
    # rektal lavman / enema — krem kalıplarından ÖNCE: "REKTAL JEL ... LAVMAN"
    # (Libalaks) krem değil lavmandır; fitiller yukarıdaki FİTİL/SUPOZ'da
    ("ENEMA", "enema_rectal"), ("LAVMAN", "enema_rectal"),
    # rektal krem/merhem/pomad (Anrecta/Rectoderm "REKTAL MERHEM"...) —
    # lavman DEĞİL, makat bölgesine sürülür; genel REKTAL kalıbından önce
    ("REKTAL KREM", "cream_rectal"), ("RECTAL KREM", "cream_rectal"),
    ("REKTAL MERHEM", "cream_rectal"), ("RECTAL MERHEM", "cream_rectal"),
    ("REKTAL POMAD", "cream_rectal"), ("REKTAL POMAT", "cream_rectal"),
    ("REKTAL JEL", "cream_rectal"),
    # diğer REKTAL ürünler (rektal süspansiyon vb.) → lavman tekniği
    ("REKTAL", "enema_rectal"),
    # göz
    ("GOZ DAMLA", "eye_drop"), ("GÖZ DAMLA", "eye_drop"),
    ("GOZ JEL", "eye_ointment"), ("GÖZ JEL", "eye_ointment"),
    # kulak
    ("KULAK DAMLA", "ear_drop"),
    # burun
    ("BURUN SPREY", "nasal_spray"), ("NAZAL SPREY", "nasal_spray"),
    ("BURUN DAMLA", "nasal_drop"),
    # boğaz / gargara
    ("GARGARA", "gargara_mouthwash"),
    ("ORAL SPREY", "oral_spray_throat"),
    ("ORAL JEL", "oromucosal_gel"),
    # şampuan (medikal) — KREM'den önce çünkü "ŞAMPUAN" daha spesifik
    ("ŞAMPUAN", "shampoo_medicated"), ("SAMPUAN", "shampoo_medicated"),
    # losyon
    ("LOSYON", "cream_or_ointment_topical"), ("LOTION", "cream_or_ointment_topical"),
    # bant — DERMAL kalıbından ÖNCE ("TRANSDERMAL" içinde DERMAL geçer;
    # Durogesic/Exelon/Neupro flasterleri krem sanılmasın)
    ("BANT", "transdermal_patch"), ("FLASTER", "transdermal_patch"),
    ("TRANSDERM", "transdermal_patch"),
    # topikal/dermal işaretli ürünler — ÇÖZELTİ/SOLÜSYON ve SPREY kalıplarından
    # ÖNCE gelmeli: "DERİ SPREYİ ÇÖZELTİ" içilir sanılmasın, burun sanılmasın.
    # JEL'li olanlar gel_topical kalır (JEL kalıbı bunlardan sonra geldiğinden
    # burada spesifik olarak verilir).
    ("TOPİKAL JEL", "gel_topical"), ("TOPIKAL JEL", "gel_topical"),
    ("DERMAL JEL", "gel_topical"),
    ("DERİ SPREY", "cream_or_ointment_topical"), ("DERI SPREY", "cream_or_ointment_topical"),
    ("DERİYE UYGULA", "cream_or_ointment_topical"), ("DERIYE UYGULA", "cream_or_ointment_topical"),
    ("DERMAL", "cream_or_ointment_topical"),
    ("TOPİKAL", "cream_or_ointment_topical"), ("TOPIKAL", "cream_or_ointment_topical"),
    # tablet türleri
    ("DİLALTI", "tablet_sublingual"), ("SUBLINGUAL", "tablet_sublingual"),
    ("EFERVESAN", "tablet_effervescent"),
    ("ÇİĞNEME", "tablet_chewable"), ("ÇİĞNENEBİLİR", "tablet_chewable"),
    ("ENTERIK", "tablet_enteric_or_extended"), ("ENTERİK", "tablet_enteric_or_extended"),
    ("UZATILMIŞ SALI", "tablet_enteric_or_extended"),
    ("RETARD", "tablet_enteric_or_extended"),
    ("KONTROLLU SAL", "tablet_enteric_or_extended"),
    ("CR DIVITAB", "tablet_enteric_or_extended"),
    ("MİKROPELLET", "capsule_pellet_open"), ("MIKROPELLET", "capsule_pellet_open"),
    ("PELLET", "capsule_pellet_open"),
    # kapsül
    ("KAPSÜL", "capsule_normal"), ("KAPSUL", "capsule_normal"),
    # sıvılar
    ("SÜSPANSIYON HAZIRLAMAK", "powder_for_suspension"),
    ("KURU TOZ", "powder_for_suspension"),
    ("SÜSPANSİYON", "syrup_or_suspension"), ("SÜSPANSIYON", "syrup_or_suspension"),
    ("SUSPANSIYON", "syrup_or_suspension"), ("SUSPANSİYON", "syrup_or_suspension"),
    ("ORAL SUSP", "syrup_or_suspension"),
    ("ORAL SUS.", "syrup_or_suspension"), ("SUS.", "syrup_or_suspension"),
    ("ŞURUP", "syrup_or_suspension"), ("SURUP", "syrup_or_suspension"),
    ("ORAL SOLÜSYON", "syrup_or_suspension"), ("ORAL SOL", "syrup_or_suspension"),
    ("SOLÜSYON", "syrup_or_suspension"), ("SOLUSYON", "syrup_or_suspension"),
    ("ÇÖZELTİ", "syrup_or_suspension"), ("COZELTI", "syrup_or_suspension"),
    ("ORAL DAMLA", "oral_drop"),
    # "DAMLA" tek başına (göz/kulak/burun yok) → tipik göz damlası
    ("DAMLA", "eye_drop"),
    # saşe / kaşe (poşet halinde toz/granül)
    ("SAŞE", "sachet_oral"), ("SAŞ.", "sachet_oral"),
    ("KAŞE", "sachet_oral"), ("KASE", "sachet_oral"),
    ("POŞET", "sachet_oral"), ("GRANUL", "sachet_oral"), ("GRANÜL", "sachet_oral"),
    # emülsiyon (genelde harici)
    ("EMÜLSİYON", "cream_or_ointment_topical"), ("EMULSIYON", "cream_or_ointment_topical"),
    # LIQUID
    ("LIQUID", "syrup_or_suspension"),
    # SPREY (en sonda fallback — BURUN/NAZAL/ORAL ile yakalanmadıysa nasal varsay)
    ("SPREY", "nasal_spray"), ("SPRAY", "nasal_spray"),
    # AER. (aerosol/inhaler kısaltma)
    ("AER.", "inhaler_pmdi"), ("DISCAIR", "inhaler_dpi"), ("AIRPACK", "inhaler_dpi"),
    # beslenme ürünleri infer_form başında nutrition_form_for_name ile yakalanır
    # (marka listesi: NUTRITION_BRANDS) — buraya marka eklemeyin.
    # dış
    ("KREM", "cream_or_ointment_topical"), ("MERHEM", "cream_or_ointment_topical"),
    ("POMAD", "cream_or_ointment_topical"), ("POMAT", "cream_or_ointment_topical"),
    ("JEL", "gel_topical"),
    ("TIRNAK CİLASI", "cream_or_ointment_topical"),
    # tablet jeneric (en son — en az spesifik)
    ("DRAJE", "tablet_normal"),
    ("TABLET", "tablet_normal"), ("FİLM TB", "tablet_normal"),
    ("FILM TB", "tablet_normal"),
    ("FTB", "tablet_normal"), ("TB.", "tablet_normal"),
]


# Enteral/oral beslenme ürünü (mama) marka adları. ATC V06* zaten bağlayıcıdır;
# bu liste ATC'si boş kayıtlar için güvenlik ağıdır. "VITAL"/"BOOST" gibi başka
# ilaç adlarının içinde geçen kısa kelimeler BİLEREK yok (MAGVITAL, DESMOVITAL,
# MEMOBOOST, ZINVITAL, BECOVITAL, OSVITAL tuzakları). "DIBEN "/"IMPACT " sonuna
# boşluk: DIBENZYRAN gibi adlarla karışmasın.
NUTRITION_BRANDS: tuple[str, ...] = (
    "GLUCERNA", "ENSURE", "NUTREN", "RESOURCE", "FORTIMEL", "FRESUBIN",
    "PEPTAMEN", "INFATRINI", "INFASOURCE", "ISOSOURCE", "NOVASOURCE",
    "SUPPORTAN", "DIBEN ", "FREBINI", "FORTINI", "NUTRINI", "NUTRISON",
    "OSMOLITE", "JEVITY", "PULMOCARE", "NEPRO", "MODULEN", "KETOCAL",
    "ALITRAQ", "INTESTAMIN", "CUBITAN", "PROSURE", "FORTICARE",
    "PEDIASURE", "IMPACT ", "NUTRIDRINK", "DIASIP", "CALSHAKE",
    "FANTOMALT", "RENILON", "SOUVENAID", "MONOGEN", "ABOUND",
    "SÜPLENA", "SUPLENA", "KCAL", "ENTERAL BES", "BESLENME",
    # bebek/metabolik mamalar (perakende reçetede sık görülenler)
    "HUMANA", "APTAMIL", "BEBELAC", "MILUPA", "NEOCATE", "SIMILAC",
    "ALFAMINO", "ALTHERA", "COMIDA", "EVOLVIA", "PHENYLDON", "GALACTOMIN",
    "GLYCOSADE", "LOPHLEX", "LOPROFIN", "ANAMIX", "PROZERO", "EASIPHEN",
    "RENASTEP", "RESPIFOR", "BIOSORB", "PROTIFAR", "NUTRIVIGOR",
    "SURVIMED", "RECONVAN", "OXEPA", "PERATIVE", " MAMA",
    # DİKKAT: "KKAL" ASLA eklenmesin — "BUKKAL" (EFFENTORA fentanil bukkal
    # tablet) içinde geçer ve ölümcül "DOĞRUDAN İÇİLİR" hatası üretir.
)

# Toz/mama göstergeleri: "400 GR", "300 G.", "400GR", TOZ/SAŞE/POŞET/MAMA...
_RX_NUTRITION_POWDER = re.compile(r"\d\s*G(?:R\.?|\.)?(?![A-ZÇĞİÖŞÜ0-9])")
_NUTRITION_POWDER_WORDS = ("TOZ", "SAŞE", "SASE", "POŞET", "POSET",
                           "GRANÜL", "GRANUL", "POUCH", "MAMA")
# Hazır sıvı göstergeleri ("200ML", "200 ML.", DRINK, ENERJİ İÇECEĞİ)
_RX_NUTRITION_LIQUID = re.compile(r"\d\s*ML\b")
_NUTRITION_LIQUID_WORDS = ("DRINK", "İÇECE", "ICECE", "YOCREME", "RTD",
                           "SISE", "ŞİŞE", "TETRA")


def nutrition_form_for_name(drug_name: str, atc_code: str | None = None) -> str | None:
    """Beslenme ürünü (enteral/oral mama) ise form anahtarını döndür, değilse None.

    ATC V06* bağlayıcıdır; ATC yoksa marka adı (NUTRITION_BRANDS) yakalar.
    Hazır sıvı → "nutritional_supplement_oral" (doğrudan içilir, SULANDIRILMAZ),
    toz/mama  → "nutritional_powder_oral"     (tarife göre su ile hazırlanır).

    Bu ürünler ASLA tablet/şurup kalıplarına düşmemeli: "INFASOURCE 200ML" gibi
    adlar aksi halde "BİR BARDAK SUYLA YUTULUR" hatası üretir.
    """
    name = (drug_name or "").upper()
    code = (atc_code or "").upper()
    if not (code.startswith("V06")
            or any(k in name for k in NUTRITION_BRANDS)):
        return None
    # Parenteral tuzağı: "PARENTERAL BESLENME" / TPN infüzyon emülsiyonları
    # (Kabiven, Oliclinomel) ve "... KCAL" içeren serumlar AĞIZDAN DEĞİLDİR.
    if any(k in name for k in ("PARENTERAL", "İNFÜZYON", "INFUZYON",
                               "INFÜZYON", "İNFUZYON", "FLAKON", "AMPUL",
                               "ENJEK", "PERFÜZYON", "PERFUZYON")):
        return None
    # Tablet/kapsül tuzağı: V06DD ketoanalog tabletleri (KETOSTERIL,
    # KETONEPHRO) gerçek yutulan tabletlerdir — beslenme içeceği DEĞİL.
    if any(k in name for k in ("TABLET", "KAPSÜL", "KAPSUL", "DRAJE")):
        return None
    if _RX_NUTRITION_LIQUID.search(name) or any(
            k in name for k in _NUTRITION_LIQUID_WORDS):
        return "nutritional_supplement_oral"
    # V06C (bebek/metabolik formüla) ve V06DE (metabolik amino asit) sıvı
    # ibaresi yoksa TOZ mamadır ("PKU 1", "MSUD 2" gibi boyutsuz adlar).
    if code.startswith(("V06C", "V06DE")):
        return "nutritional_powder_oral"
    if _RX_NUTRITION_POWDER.search(name) or any(
            k in name for k in _NUTRITION_POWDER_WORDS):
        return "nutritional_powder_oral"
    return "nutritional_supplement_oral"


def infer_form(
    drug_name: str,
    route_hint: str = "",
    atc_code: str | None = None,
) -> str | None:
    """İlaç adından farmasötik form anahtarını tahmin et.

    Öncelik sırası:
      1. ATC kodu bazlı zorlamalar (S01* → göz, R01AA → burun spreyi, S02 → kulak)
         — isim parse'ı yanlış sonuç verse bile ATC daha güvenilir.
      2. İlaç adındaki anahtar kelime eşleşmesi.

    route_hint: Medula'dan veya SKRS'den gelen "Kullanım Şekli" alanı (opsiyonel).
    atc_code:   WHO ATC kodu (varsa). Spesifik formları zorlar.
    """
    name = (drug_name or "").upper()
    code = (atc_code or "").upper()

    # 0) Beslenme ürünleri (ATC V06* / marka adı) — EN ÖNCE: "200ML SOLÜSYON"
    #    gibi adlar şurup/saşe/tablet kalıplarına düşüp "BİR BARDAK SUYLA
    #    YUTULUR" hatası üretmesin.
    nf = nutrition_form_for_name(name, code)
    if nf:
        return nf

    # 1) ATC bazlı override — isim yanlış olsa bile bunlar bağlayıcı
    if code:
        # Hemoroid/anal fissür preparatları (C05A) — REKTAL kullanım.
        # Adda "REKTAL" geçmese bile (PROCTO-GLYVENOL 30 GR KREM, KORTOS
        # KREM) krem/merhem cilde değil makata sürülür; fitiller fitildir.
        if code.startswith("C05A"):
            if any(k in name for k in ("FİTİL", "FITIL", "SUPOZ", "SUPPOZ",
                                       "SUPP.", "SUPP ")):
                return "suppository_rectal"
            if any(k in name for k in ("KREM", "MERHEM", "POMAD", "POMAT")) \
                    or ("JEL" in name and "JELATİN" not in name
                        and "JELATIN" not in name):
                return "cream_rectal"
        # Göz
        if code.startswith("S01"):
            # Göz pomadı/jeli ayrımı (S01* + adında JEL/POMAD/MERHEM varsa pomad)
            if any(k in name for k in ("POMAD", "MERHEM", "JEL")):
                return "eye_ointment"
            return "eye_drop"
        # Kulak
        if code.startswith("S02"):
            return "ear_drop"
        # Burun — R01AA (lokal burun açıcı), R01AD (kortikosteroid)
        if code.startswith("R01A"):
            if "SPREY" in name or "SPRAY" in name:
                return "nasal_spray"
            if "DAMLA" in name:
                return "nasal_drop"
            return "nasal_spray"  # varsayılan modern form
        # Boğaz / ağız (R02 + A01AD)
        if code.startswith("R02"):
            if "SPREY" in name or "SPRAY" in name:
                return "oral_spray_throat"
            if "GARGARA" in name:
                return "gargara_mouthwash"
            return "oral_spray_throat"
        # SPREY ≠ burun spreyi! "SPREY" fallback'i nasal varsayar; oysa birçok
        # sprey topikal (cilde püskürtülür). ATC bağlayıcıdır:
        #   D*  dermatolojik (oral alt-sınıflar D01B/D05B/D10B hariç):
        #       antifungal spreyler (Oxezole/Oceral/Lamisil), minoksidil vb.
        #   M02A topikal kas-eklem NSAİİ (Rheumon/Majezik sprey)
        #   B02BC lokal hemostatik (Gelfix)
        #   N01BB topikal/mukozal lokal anestezik (Vemcaine/Xylocaine pump)
        #   C01DA nitrat sprey (Nitrolingual) → DİL ALTINA (asla burun!)
        if "SPREY" in name or "SPRAY" in name:
            if code.startswith("C01DA"):
                return "sublingual_spray"
            if (code.startswith("D")
                    and not code.startswith(("D01B", "D05B", "D10B"))) \
                    or code.startswith(("M02A", "B02BC", "N01BB")):
                return "cream_or_ointment_topical"
        # Ağız/diş tedavisi (A01A: TANTUM VERDE, DENCOL, KETOBER…) — adında
        # SPREY geçse bile burun DEĞİL ağız ürünüdür; nasal fallback'e düşmesin
        if code.startswith("A01A"):
            if "GARGARA" in name:
                return "gargara_mouthwash"
            if "SPREY" in name or "SPRAY" in name:
                return "oral_spray_throat"
            if any(k in name for k in ("JEL", "POMAD", "PASTA", "PAT")):
                return "oromucosal_gel"
            # diğerleri (pastil vb.) isim kalıplarına düşsün
        # R03 tek dozluk flakon = NEBÜL (Combivent/Atrovent), enjeksiyon değil.
        # Adı ENJEK içerenler (Xolair hazır enjektör) bu daldan muaf.
        if (code.startswith("R03") and "ENJEK" not in name
                and any(k in name for k in ("FLAKON", "NEBUL", "NEBÜL",
                                            "TEK DOZ"))):
            return "nebule"
        # Aşılar (J07) kas içine uygulanır; "KULLANIMA HAZIR ENJEKTÖR" kalıbı
        # cilt altı (LMWH şablonu) sanmasın. Oral aşılar (rotavirüs J07BH)
        # hariç; canlı aşılar (kızamık/KKK/suçiçeği/zona/sarı humma) cilt altı.
        if (code.startswith("J07") and not code.startswith("J07BH")
                and "ORAL" not in name):
            if _RX_IM.search(name):
                return "injection_im"  # SHINGRIX vb. ad açıkça IM
            if (code.startswith(("J07BD", "J07BE", "J07BJ", "J07BK", "J07BL"))
                    or _RX_SC.search(name)):
                return "injection_sc"
            return "injection_im"
        # İnsülinler (A10A) ve enjektabl GLP-1 (A10BJ) cilt altı — flakon
        # formu bile SC'dir (Humulin N flakon "AMPUL/FLAKON→IM" tuzağına düşmesin)
        if code.startswith("A10A") and any(k in name for k in (
                "FLAKON", "KARTUŞ", "KARTUS", "KALEM", "PEN", "ENJEK")):
            return "injection_sc"
        if code.startswith("A10BJ") and "TABLET" not in name:
            return "injection_sc"
        # Düşük molekül ağırlıklı heparinler cilt altı (ampul formu bile)
        if code.startswith(("B01AB04", "B01AB05", "B01AB06", "B01AB07",
                            "B01AB10", "B01AB12")):
            return "injection_sc"

    # 1.5) Enjektabl üründe adı geçen AÇIK yol ibaresi (IV/IM/SC) isim
    # kalıplarından önce bağlayıcıdır: "AMPUL/FLAKON→injection_im" varsayılanı
    # IV flakonları kas içi, IM aşıları cilt altı sanmasın.
    if any(k in name for k in ("ENJEK", "AMPUL", "FLAKON", "AMP.",
                                "ŞIRINGA", "SIRINGA", "İĞNE",
                                "INFUZYON", "İNFÜZYON", "ENFUZYON", "PERF")):
        # Belirsiz kombinasyonda (IM/IV, IV/SC) güvenli taraf: "sağlık
        # personeli" şablonu. SC (evde kendi kendine enjeksiyon adımları)
        # yalnız ad SADECE cilt altı derken seçilir.
        if _RX_IM.search(name):
            return "injection_im"
        if _RX_IV.search(name):
            return "injection_iv"
        if _RX_SC.search(name):
            return "injection_sc"

    # 2) İsim bazlı pattern eşleşmesi
    for kw, form_key in _NAME_PATTERNS:
        if kw in name:
            return form_key
    return None


def get_technique(form_key: str) -> TechniqueTemplate | None:
    """Form anahtarına karşılık gelen şablonu döner."""
    return TECHNIQUES.get(form_key)


# Block type sabitleri (drug_label_blocks.block_type değerleri)
BLOCK_ENDIKASYON   = "endikasyon"
BLOCK_TEKNIK       = "teknik"
BLOCK_HAZIRLAMA    = "hazirlama"
BLOCK_SIVI         = "sivi"
BLOCK_SONLANDIRMA  = "sonlandirma"
BLOCK_DIKKAT       = "dikkat"
BLOCK_ETKILESIM    = "etkilesim"
BLOCK_YAN_ETKI     = "yan_etki"
BLOCK_SAKLAMA      = "saklama"
BLOCK_HATIRLATMA   = "hatirlatma"

BLOCK_TYPES = (
    BLOCK_ENDIKASYON, BLOCK_TEKNIK, BLOCK_HAZIRLAMA, BLOCK_SIVI,
    BLOCK_SONLANDIRMA, BLOCK_DIKKAT, BLOCK_ETKILESIM, BLOCK_YAN_ETKI,
    BLOCK_SAKLAMA, BLOCK_HATIRLATMA,
)

BLOCK_LABEL_TR = {
    BLOCK_ENDIKASYON:  "Endikasyon",
    BLOCK_TEKNIK:      "Kullanım tekniği",
    BLOCK_HAZIRLAMA:   "Hazırlama",
    BLOCK_SIVI:        "Sıvı tüketimi",
    BLOCK_SONLANDIRMA: "Tedavi süresi ve sonlandırma",
    BLOCK_DIKKAT:      "Kullanmadan önce dikkat",
    BLOCK_ETKILESIM:   "Etkileşimler",
    BLOCK_YAN_ETKI:    "Yan etkiler",
    BLOCK_SAKLAMA:     "Saklama",
    BLOCK_HATIRLATMA:  "Genel hatırlatmalar",
}
