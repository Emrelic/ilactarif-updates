"""Gprinter GP-1125D (veya diğer Windows yazıcı) ile etiket basma.

Strateji: Pillow ile üretilen PNG'leri pywin32 üzerinden yazıcının
sürücüsüne raster bitmap olarak gönderir. Yazıcı sürücüsünde 60x40 mm
etiket boyutu varsayılan olarak tanımlı olmalıdır.

Eğer Gprinter sürücüsünün varsayılan kağıt boyutu farklıysa, kullanıcı
"Aygıt ve Yazıcılar → Gprinter GP-1125D → Yazıcı Özellikleri" sekmesinde
60×40 mm boyutunu ayarlamalı.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import tempfile
import threading
from pathlib import Path
from typing import Optional

from PIL import Image

# pywin32 yalnızca Windows GDI yazdırma için gerekli; ağ (TCP) yazdırma onsuz da
# çalışsın diye import'u opsiyonel tutuyoruz.
try:
    import win32print
    import win32ui
    from PIL import ImageWin
    _HAS_WIN32 = True
except Exception:                       # pragma: no cover
    _HAS_WIN32 = False

log = logging.getLogger("printer")

# ===========================================================================
# İLACTARİF YAZDIRMA KÖPRÜSÜ (Bridge) — port 9200
# ===========================================================================
# Yazıcısı olan bilgisayarda ilactarif TCP sunucusu olarak dinler; yazıcısı
# olmayan bilgisayar PNG + parametrelerini gönderir, sunucu yerel yazıcıya iletir.
#
# Protokol (client → server):
#   b"ILACTARIF_BRIDGE_1\n"                      ← sihirli satır
#   {params_json}\n                              ← kopya/boyut/dpi vs.
#   {image_byte_sayısı}\n                        ← ör. "45231"
#   <ham PNG baytları>
# Yanıt (server → client):
#   {"ok": true}\n   veya   {"ok": false, "error": "..."}\n

PRINT_BRIDGE_PORT = 9200
_BRIDGE_MAGIC = b"ILACTARIF_BRIDGE_1\n"


def _bridge_readline(sock: socket.socket, max_bytes: int = 4096) -> bytes:
    buf = b""
    while len(buf) < max_bytes:
        ch = sock.recv(1)
        if not ch or ch == b"\n":
            return buf
        buf += ch
    return buf


def _bridge_recv_all(sock: socket.socket, n: int) -> bytes:
    data = b""
    while len(data) < n:
        chunk = sock.recv(min(65536, n - len(data)))
        if not chunk:
            break
        data += chunk
    return data


def _bridge_handle(conn: socket.socket, printer_cfg_fn) -> None:
    """Tek bir köprü bağlantısını işle (sunucu tarafı)."""
    try:
        magic = conn.recv(len(_BRIDGE_MAGIC))
        if magic != _BRIDGE_MAGIC:
            conn.sendall(b'{"ok":false,"error":"bad magic"}\n')
            return
        params_line = _bridge_readline(conn)
        try:
            params = json.loads(params_line)
        except Exception:
            conn.sendall(b'{"ok":false,"error":"invalid params json"}\n')
            return
        size_line = _bridge_readline(conn)
        try:
            img_size = int(size_line.strip())
        except ValueError:
            conn.sendall(b'{"ok":false,"error":"invalid size"}\n')
            return
        img_data = _bridge_recv_all(conn, img_size)
        if len(img_data) != img_size:
            conn.sendall(b'{"ok":false,"error":"truncated image"}\n')
            return
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            f.write(img_data)
            tmp_path = f.name
        try:
            cfg = printer_cfg_fn()
            send_image(
                tmp_path, cfg,
                copies=int(params.get("copies", 1)),
                label_mm=tuple(params.get("label_mm", [60.0, 40.0])),
                dpi=int(params.get("dpi", 203)),
                gap_mm=float(params.get("gap_mm", 2.0)),
                direction=int(params.get("direction", 0)),
            )
            conn.sendall(b'{"ok":true}\n')
        except Exception as e:
            err = json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False)
            conn.sendall((err + "\n").encode("utf-8"))
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
    except Exception as e:
        log.warning("Köprü bağlantı hatası: %s", e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


class PrintBridgeServer:
    """İlacTarif ağ yazdırma köprüsü sunucusu.

    Bu bilgisayarda çalışan ilactarif örneğini bir yazdırma köprüsüne dönüştürür.
    Ağdaki diğer ilactarif örnekleri (tip "bridge") bu sunucuya bağlanarak
    etiketi yerel yazıcıya bastırabilir.

    printer_cfg_fn: çağrıldığında aktif yazıcı cfg dict'ini döndüren fonksiyon.
    """

    def __init__(self, port: int = PRINT_BRIDGE_PORT, printer_cfg_fn=None):
        self._port = port
        self._printer_cfg_fn = printer_cfg_fn or (lambda: {})
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_evt = threading.Event()

    def start(self) -> None:
        if self._sock:
            return
        self._stop_evt.clear()
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("", self._port))
        srv.listen(8)
        srv.settimeout(1.0)
        self._sock = srv

        def _loop():
            log.info("İlacTarif Köprüsü dinliyor: port %s", self._port)
            while not self._stop_evt.is_set():
                try:
                    conn, addr = srv.accept()
                    log.info("Köprü bağlantısı: %s", addr)
                    t = threading.Thread(
                        target=_bridge_handle,
                        args=(conn, self._printer_cfg_fn),
                        daemon=True,
                    )
                    t.start()
                except socket.timeout:
                    continue
                except OSError:
                    break
            log.info("İlacTarif Köprüsü durduruldu.")

        self._thread = threading.Thread(target=_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_evt.set()
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None

    @property
    def running(self) -> bool:
        return self._sock is not None


# ===========================================================================
# AĞ YAZDIRMA — GPrinter (TSPL) ham TCP 9100
# ===========================================================================
# GPrinter GP-1125D bir TSC-uyumlu (TSPL) termal etiket yazıcısıdır. Ağ
# üzerinden (ör. 192.168.1.172:9100) ham TSPL komutu kabul eder. Windows
# sürücüsü kurulu olmasa bile doğrudan IP'ye basabiliriz.
#
# TSPL BITMAP bit anlamı: 0 = siyah nokta (yakılır/basılır), 1 = beyaz (basılmaz).
# Etiket sarı zeminli üretilse de termal yazıcı sadece SİYAH metni basar
# (sarı, luminansı yüksek olduğu için "basılmaz" sayılır) — fiziksel sarı etiket
# stoğuyla birebir uyumlu.

def _fit_image(img: Image.Image, width_dots: int, height_dots: int) -> Image.Image:
    """Görüntüyü en-boy oranını KORUYARAK hedef alana sığdırır (letterbox).

    Hedef alan beyaz (255) arka planla doldurulur; içerik sol-üst köşeye
    hizalanır. Bu sayede farklı en-boy oranlı etiket stoklarında içerik
    uzamaz / sıkışmaz.
    """
    src_w, src_h = img.size
    scale = min(width_dots / src_w, height_dots / src_h)
    new_w = round(src_w * scale)
    new_h = round(src_h * scale)
    resized = img.resize((new_w, new_h), Image.LANCZOS)
    canvas = Image.new("L", (width_dots, height_dots), 255)  # beyaz zemin
    canvas.paste(resized.convert("L"), (0, 0))
    return canvas


def _image_to_tspl_bitmap(img: Image.Image, width_dots: int, height_dots: int):
    """PIL görselini TSPL BITMAP verisine çevirir → (bytes, width_bytes)."""
    img = _fit_image(img, width_dots, height_dots)
    px = img.load()
    width_bytes = (width_dots + 7) // 8
    data = bytearray()
    for y in range(height_dots):
        for xb in range(width_bytes):
            b = 0
            for bit in range(8):
                x = xb * 8 + bit
                v = 1                       # varsayılan: beyaz (basılmaz)
                if x < width_dots:
                    v = 0 if px[x, y] < 128 else 1   # koyu piksel → bas (0)
                b = (b << 1) | v
            data.append(b)
    return bytes(data), width_bytes


# ===========================================================================
# AĞ YAZICISI KEŞFİ — isimden / IP'den yazıcı bulma
# ===========================================================================

def get_local_ip() -> str:
    """Bu makinenin LAN IP'sini döndür (yoksa 127.0.0.1)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))     # paket göndermez, sadece arayüz seçtirir
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def port_open(host: str, port: int = 9100, timeout: float = 0.3) -> bool:
    """host:port'a TCP bağlantısı kurulabiliyor mu?"""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def resolve_host(name: str) -> Optional[str]:
    """Bir yazıcı adını / hostname'i IP'ye çözer (DNS / NetBIOS)."""
    try:
        return socket.gethostbyname(name)
    except Exception:
        return None


def reverse_name(ip: str, timeout: float = 0.5) -> Optional[str]:
    """IP için ters DNS adı (varsa) döndürür."""
    old = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try:
        return socket.gethostbyaddr(ip)[0]
    except Exception:
        return None
    finally:
        socket.setdefaulttimeout(old)


def scan_network_printers(
    port: int = 9100,
    timeout: float = 0.3,
    subnet: Optional[str] = None,
) -> list[dict]:
    """LAN /24 alt ağını tarayıp belirtilen portu (varsayılan 9100) açık olan
    cihazları döndürür. Her biri: {"ip": str, "name": str|None}.

    subnet verilmezse yerel IP'nin /24'ü (ör. 192.168.1.) taranır.
    """
    from concurrent.futures import ThreadPoolExecutor

    if subnet is None:
        parts = get_local_ip().split(".")
        if len(parts) != 4:
            return []
        subnet = ".".join(parts[:3]) + "."
    elif not subnet.endswith("."):
        subnet = subnet + "."

    hosts = [f"{subnet}{i}" for i in range(1, 255)]

    def _check(ip: str):
        return ip if port_open(ip, port, timeout) else None

    found = []
    with ThreadPoolExecutor(max_workers=64) as ex:
        for ip in ex.map(_check, hosts):
            if ip:
                found.append(ip)

    # Bulunanlar için (yavaş) ters DNS adını ekle
    out = []
    for ip in found:
        out.append({"ip": ip, "name": reverse_name(ip)})
    return out


def print_image_tcp(
    image_path: Path | str,
    host: str = "192.168.1.172",
    port: int = 9100,
    *,
    copies: int = 1,
    label_mm: tuple[float, float] = (60.0, 40.0),
    dpi: int = 203,
    gap_mm: float = 2.0,
    direction: int = 0,
    timeout: float = 8.0,
) -> None:
    """Bir etiket görselini ağ üzerinden GPrinter'a (TSPL, ham TCP 9100) gönderir.

    direction: 0 normal, 1 = 180° döndürülmüş (etiket ters çıkarsa 1 yap).
    gap_mm:    etiketler arası boşluk (die-cut etiket için tipik 2-3 mm).
    """
    payload = build_tspl_payload(
        image_path, copies=copies, label_mm=label_mm, dpi=dpi,
        gap_mm=gap_mm, direction=direction,
    )
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.sendall(payload)
    log.info("Ağ yazıcıya gönderildi: %s:%s (%d bayt)", host, port, len(payload))


def build_tspl_payload(
    image_path: Path | str,
    *,
    copies: int = 1,
    label_mm: tuple[float, float] = (60.0, 40.0),
    dpi: int = 203,
    gap_mm: float = 2.0,
    direction: int = 0,
) -> bytes:
    """Bir etiket görselinden TSPL ham komut paketi (bytes) üretir.

    Görsel her zaman etiketin FİZİKSEL dot boyutuna (ör. 60×40 mm @ 203 DPI =
    480×320) yeniden boyutlanır; bu yüzden Windows sürücüsünün kağıt boyutu
    ayarından (ör. yanlışlıkla 90×60 mm) BAĞIMSIZDIR.
    """
    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(image_path)

    w_mm, h_mm = label_mm
    width_dots = round(w_mm / 25.4 * dpi)    # 60 mm @ 203 DPI ≈ 480
    height_dots = round(h_mm / 25.4 * dpi)   # 40 mm @ 203 DPI ≈ 320

    img = Image.open(image_path)
    bitmap, width_bytes = _image_to_tspl_bitmap(img, width_dots, height_dots)

    def _mm(v: float) -> str:
        return str(int(v)) if float(v).is_integer() else str(v)

    header = (
        f"SIZE {_mm(w_mm)} mm,{_mm(h_mm)} mm\r\n"
        f"GAP {_mm(gap_mm)} mm,0 mm\r\n"
        f"DIRECTION {direction}\r\n"
        f"REFERENCE 0,0\r\n"
        f"CLS\r\n"
        f"BITMAP 0,0,{width_bytes},{height_dots},0,"
    ).encode("ascii")
    footer = f"\r\nPRINT 1,{copies}\r\n".encode("ascii")
    return header + bitmap + footer


def _reconnect_smb_session(printer_name: str, timeout: float = 6.0) -> bool:
    r"""Paylaşılan yazıcının host'una SMB oturumunu zorla yeniden kur.

    Error 64 (ERROR_NETNAME_DELETED) genelde host'a giden SMB oturumunun
    (uyku / Wi-Fi dalgalanması / boşta zaman aşımı) kopmasından kaynaklanır;
    Windows yazıcı kuyruğu ölü oturumu önbellekte tutar. Host'un IPC$ paylaşımına
    dokunmak oturumu tazeler, böylece sonraki OpenPrinter başarılı olur.

    \\HOST\pay biçiminde olmayan (yerel) yazıcılarda hiçbir şey yapmaz.
    Döndürür: yeniden bağlanma denendi mi (True) yoksa atlandı mı (False).
    """
    host, _ = parse_unc(printer_name)
    if not host:
        return False
    import subprocess
    unc = f"\\\\{host}\\IPC$"
    try:
        # Önce varsa ölü/asılı bağlantıyı bırak, sonra yenisini kur.
        subprocess.run(["net", "use", unc, "/delete", "/y"],
                       capture_output=True, timeout=timeout)
    except Exception:
        pass
    try:
        subprocess.run(["net", "use", unc, "/persistent:no"],
                       capture_output=True, timeout=timeout)
        log.info("SMB oturumu tazelendi: %s", unc)
        return True
    except Exception as e:
        log.warning("SMB oturumu tazelenemedi (%s): %s", unc, e)
        return False


def print_image_tspl_win(
    image_path: Path | str,
    printer_name: str,
    *,
    copies: int = 1,
    label_mm: tuple[float, float] = (60.0, 40.0),
    dpi: int = 203,
    gap_mm: float = 2.0,
    direction: int = 0,
) -> None:
    """Etiketi, Windows kuyruğundaki bir yazıcıya HAM TSPL olarak gönderir.

    GDI/sürücü rasterizasyonunu (ve yanlış kağıt boyutu ölçeklemesini) atlar;
    veriyi doğrudan TSPL yazıcısına (ör. paylaşılan \\PC\\Gprinter GP-1125D)
    iletir. Böylece etiket her zaman doğru 60×40 mm basılır.
    """
    payload = build_tspl_payload(
        image_path, copies=copies, label_mm=label_mm, dpi=dpi,
        gap_mm=gap_mm, direction=direction,
    )
    # PRINTER_ACCESS_USE (8) — ağ paylaşımlarında PRINTER_ALL_ACCESS yerine
    # sadece USE yetki iste; error 64 (netname deleted) riskini azaltır.
    import time
    last_err = None
    attempts = 4
    for attempt in range(attempts):
        try:
            h = win32print.OpenPrinter(
                printer_name,
                {"DesiredAccess": win32print.PRINTER_ACCESS_USE},
            )
            try:
                win32print.StartDocPrinter(h, 1, ("ilactarif etiket", None, "RAW"))
                win32print.StartPagePrinter(h)
                win32print.WritePrinter(h, payload)
                win32print.EndPagePrinter(h)
                win32print.EndDocPrinter(h)
            finally:
                win32print.ClosePrinter(h)
            log.info("Ham TSPL Windows kuyruğuna gönderildi: %s (%d bayt)",
                     printer_name, len(payload))
            return
        except Exception as e:
            last_err = e
            log.warning("Yazıcı denemesi %d/%d başarısız: %s",
                        attempt + 1, attempts, e)
            if attempt < attempts - 1:
                # Ağ adı koptuysa (64) ya da erişim/yol hatasıysa SMB oturumunu
                # tazeleyip yeniden dene — kör beklemekten çok daha etkili.
                winerr = getattr(e, "winerror", None)
                if winerr in (64, 53, 1219, 1326, 5, None):
                    _reconnect_smb_session(printer_name)
                time.sleep(0.5 * (attempt + 1))   # 0.5s, 1.0s, 1.5s
    raise last_err


def print_image_via_bridge(
    image_path: Path | str,
    host: str,
    port: int = PRINT_BRIDGE_PORT,
    *,
    copies: int = 1,
    label_mm: tuple[float, float] = (60.0, 40.0),
    dpi: int = 203,
    gap_mm: float = 2.0,
    direction: int = 0,
    timeout: float = 15.0,
) -> None:
    """Etiketi, çalışan bir İlacTarif Köprüsüne gönderir (istemci tarafı).

    Köprüyü çalıştıran bilgisayarın kendi yazıcısı etiketi basar.
    """
    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(image_path)
    img_data = image_path.read_bytes()
    params = json.dumps({
        "copies": copies,
        "label_mm": list(label_mm),
        "dpi": dpi,
        "gap_mm": gap_mm,
        "direction": direction,
    }).encode("utf-8")
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.sendall(_BRIDGE_MAGIC)
        sock.sendall(params + b"\n")
        sock.sendall(str(len(img_data)).encode() + b"\n")
        sock.sendall(img_data)
        resp = b""
        while not resp.endswith(b"\n"):
            chunk = sock.recv(1024)
            if not chunk:
                break
            resp += chunk
    result = json.loads(resp.strip())
    if not result.get("ok"):
        raise RuntimeError(result.get("error", "Köprü bilinmeyen hata"))
    log.info("Köprü aracılığıyla yazdırıldı: %s:%s (%d bayt)", host, port, len(img_data))


def print_many_tcp(image_paths, host: str = "192.168.1.172", port: int = 9100, **kwargs) -> None:
    """Birden çok görseli sırayla ağ yazıcıya gönderir."""
    for p in image_paths:
        print_image_tcp(p, host, port, **kwargs)


def list_printers() -> list[dict]:
    """Tüm yüklü yazıcıları listele."""
    out = []
    for flags, desc, name, comment in win32print.EnumPrinters(
        win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    ):
        out.append({"name": name, "description": desc, "comment": comment})
    return out


# net view çıktısında yazıcı paylaşımını işaret eden "Tür" sütunu sözcükleri
# (farklı Windows dilleri için). Türkçe = "Yazdır".
_PRINT_TYPE_TOKENS = {
    "yazdır", "yazdir", "print", "druck", "drucken", "imprimer",
    "impresión", "impresion", "impresora", "stampa", "печать", "afdrukken",
}


def parse_unc(name: str) -> tuple[Optional[str], Optional[str]]:
    r"""\\HOST\Paylaşım → (host, paylaşım). UNC değilse (None, name)."""
    if name and name.startswith("\\\\"):
        rest = name[2:]
        if "\\" in rest:
            host, share = rest.split("\\", 1)
            return host, share
        return rest, None
    return None, name


def list_network_printers() -> list[dict]:
    r"""Bu bilgisayarın tanıdığı tüm AĞ yazıcılarını (UNC \\host\pay) döndürür.

    Her biri: {"win_name", "host", "share", "description"}.
    """
    out = []
    for flags, desc, name, comment in win32print.EnumPrinters(
        win32print.PRINTER_ENUM_CONNECTIONS
    ):
        host, share = parse_unc(name)
        if host:
            out.append({
                "win_name": name, "host": host, "share": share or name,
                "description": desc,
            })
    return out


def list_printers_on_host(host: str, timeout: float = 6.0) -> list[dict]:
    r"""Belirtilen IP veya bilgisayar adındaki paylaşılan yazıcıları döndürür.

    `net view \\host /all` çıktısı ayrıştırılır; "Tür" sütunu yazıcıyı işaret
    eden paylaşımlar seçilir. Ayrıca bu host için zaten bağlı (CONNECTIONS)
    yazıcılar da eklenir (net view erişemese bile görünsünler).

    Her biri: {"win_name": \\host\pay, "host", "share"}.
    """
    import re
    import subprocess

    host = host.strip().lstrip("\\")
    results: dict[str, dict] = {}

    # 1) Zaten bağlı ağ yazıcıları (kesin yazıcı oldukları biliniyor)
    try:
        for p in list_network_printers():
            if p["host"].lower() == host.lower():
                results[p["win_name"].lower()] = {
                    "win_name": p["win_name"], "host": p["host"], "share": p["share"],
                }
    except Exception:
        pass

    # 2) net view ile paylaşımları tara
    try:
        cp = subprocess.run(
            ["net", "view", f"\\\\{host}", "/all"],
            capture_output=True, timeout=timeout,
        )
        text = cp.stdout.decode("cp857", errors="replace")
        if cp.returncode != 0 and not results:
            err = cp.stdout.decode("cp857", errors="replace") or \
                  cp.stderr.decode("cp857", errors="replace")
            raise RuntimeError(err.strip() or f"net view başarısız (kod {cp.returncode})")
        for line in text.splitlines():
            if not line.strip() or line.startswith("-") or "$" in line:
                continue
            cols = re.split(r"\s{2,}", line.strip())
            if len(cols) < 2:
                continue
            share, typ = cols[0].strip(), cols[1].strip().lower()
            if typ in _PRINT_TYPE_TOKENS:
                win_name = f"\\\\{host}\\{share}"
                results.setdefault(win_name.lower(), {
                    "win_name": win_name, "host": host, "share": share,
                })
    except FileNotFoundError:
        pass   # net.exe yok (olmaz ama) — sadece bağlı olanları döndür

    return list(results.values())


# TSPL/termal etiket yazıcısı olduğunu işaret eden ad parçaları. Bu yazıcılarda
# Windows sürücüsü (GDI) yerine HAM TSPL gönderilir → sürücünün kağıt boyutu
# ayarından (ör. yanlış 90×60 mm) bağımsız, her zaman doğru 60×40 mm baskı.
_TSPL_NAME_HINTS = ("gprinter", "gp-11", "gp11", "gp-12", "tsc", "tspl", "tt04",
                    "label", "etiket", "barcode", "xprinter", "godex", "zebra")


def is_tspl_printer(cfg: dict) -> bool:
    """cfg bir TSPL termal etiket yazıcısına mı işaret ediyor?"""
    if not cfg:
        return False
    if "tspl" in cfg:                       # kullanıcı açıkça belirtmişse ona uy
        return bool(cfg["tspl"])
    name = (cfg.get("win_name") or cfg.get("name") or "").lower()
    return any(h in name for h in _TSPL_NAME_HINTS)


def list_local_printers() -> list[dict]:
    """Bu bilgisayara YEREL kurulu yazıcılar (USB / paylaşılan dahil; ağ
    bağlantıları HARİÇ). 'Yazıcı bu PC'ye fiziksel bağlı mı?' tespiti için.

    Her biri: {"name", "description", "comment"}.
    """
    out = []
    for flags, desc, name, comment in win32print.EnumPrinters(
        win32print.PRINTER_ENUM_LOCAL
    ):
        out.append({"name": name, "description": desc, "comment": comment})
    return out


def detect_local_label_printers() -> list[dict]:
    """Bu bilgisayara bağlı termal etiket (TSPL) yazıcılarını bulur.

    Her biri köprübaşı için hazır bir Windows-yazıcı cfg'i olarak döner:
      {"name", "type": "windows", "win_name", "tspl": True}
    """
    out = []
    try:
        locals_ = list_local_printers()
    except Exception:
        log.warning("Yerel yazıcılar listelenemedi", exc_info=True)
        return out
    for p in locals_:
        name = p.get("name", "")
        if name and is_tspl_printer({"name": name}):
            out.append({"name": name, "type": "windows",
                        "win_name": name, "tspl": True})
    return out


def scan_bridge_servers(
    timeout: float = 0.3,
    subnet: Optional[str] = None,
    exclude_local: bool = True,
) -> list[dict]:
    """Ağda İlacTarif köprü sunucusu (port 9200) çalıştıran bilgisayarları bulur.

    Her biri: {"ip": str, "name": str|None}. exclude_local True ise bu makinenin
    kendi IP'si listeden çıkarılır (köprübaşı kendini istemci olarak seçmesin).
    """
    found = scan_network_printers(port=PRINT_BRIDGE_PORT, timeout=timeout,
                                  subnet=subnet)
    if exclude_local:
        my_ip = get_local_ip()
        found = [f for f in found if f.get("ip") != my_ip]
    return found


def local_override_path() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "IlacTarif", "printer_local.json")


def local_printer_override() -> dict:
    path = local_override_path()
    try:
        if os.path.exists(path):
            # utf-8-sig: Not Defteri / PowerShell'in yazdığı BOM'lu dosyaları da kabul et
            with open(path, encoding="utf-8-sig") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
    except Exception:
        log.warning("printer_local.json okunamadı: %s", path, exc_info=True)
    return {}


def apply_local_override(cfg: dict) -> dict:
    ov = local_printer_override()
    if not ov:
        return cfg
    merged = dict(cfg or {})
    merged.update(ov)
    return merged


def send_image(image_path, cfg: dict, copies: int = 1, **tcp_kwargs) -> None:
    """Bir etiket görselini, cfg'de tanımlı yazıcıya gönderen tek giriş noktası.

    cfg:
      {"type": "windows", "win_name": r"\\\\host\\pay"}  → Windows yazıcısı.
          TSPL etiket yazıcısıysa ham TSPL (doğru boyut); değilse GDI raster.
      {"type": "tcp", "host": "192.168.1.172", "port": 9100}  → ham TSPL/TCP
    """
    cfg = apply_local_override(cfg)
    ptype = (cfg or {}).get("type", "tcp")
    if ptype == "windows":
        name = cfg.get("win_name") or cfg.get("name")
        if is_tspl_printer(cfg):
            # Ham TSPL → sürücü kağıt boyutu ölçeklemesini atla
            print_image_tspl_win(image_path, name, copies=copies,
                                 label_mm=tcp_kwargs.get("label_mm", (60.0, 40.0)),
                                 dpi=tcp_kwargs.get("dpi", 203),
                                 gap_mm=tcp_kwargs.get("gap_mm", 2.0))
        else:
            print_image(image_path, printer_name=name, copies=copies)
    elif ptype == "bridge":
        host = cfg.get("host", "127.0.0.1")
        try:
            port = int(cfg.get("port", PRINT_BRIDGE_PORT))
        except (TypeError, ValueError):
            port = PRINT_BRIDGE_PORT
        print_image_via_bridge(image_path, host, port, copies=copies, **tcp_kwargs)
    else:
        host = cfg.get("host", "192.168.1.172")
        try:
            port = int(cfg.get("port", 9100))
        except (TypeError, ValueError):
            port = 9100
        print_image_tcp(image_path, host, port, copies=copies, **tcp_kwargs)


def cfg_label(cfg: dict) -> str:
    """Bir yazıcı yapılandırmasının kısa, okunur adresi (durum çubuğu için)."""
    if not cfg:
        return "(yazıcı yok)"
    if cfg.get("type") == "windows":
        return cfg.get("win_name") or cfg.get("name") or "(windows yazıcı)"
    if cfg.get("type") == "bridge":
        return f"köprü:{cfg.get('host', '?')}:{cfg.get('port', PRINT_BRIDGE_PORT)}"
    return f"{cfg.get('host', '?')}:{cfg.get('port', 9100)}"


def find_printer(pattern: str = "Gprinter") -> Optional[str]:
    """İsmi pattern içeren ilk yazıcının tam adını döndür."""
    pat = pattern.lower()
    for p in list_printers():
        if pat in p["name"].lower():
            return p["name"]
    return None


def get_default_printer() -> str:
    return win32print.GetDefaultPrinter()


def print_image(
    image_path: Path | str,
    *,
    printer_name: Optional[str] = None,
    copies: int = 1,
    fit: str = "fit",   # "fit" (sığdır), "stretch" (kapla), "actual" (1:1)
) -> None:
    """Bir görsel dosyasını yazıcıya gönder.

    fit:
      "fit":     yazıcı sayfasına orantılı sığdır (boşluk olabilir).
      "stretch": kenardan kenara doldur (orantı bozulabilir).
      "actual":  1:1 piksel = 1 nokta (yazıcı DPI'sine göre).
    """
    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(image_path)

    printer_name = printer_name or find_printer("Gprinter") or get_default_printer()
    log.info("Yazıcı: %s", printer_name)

    img = Image.open(image_path)
    if img.mode != "RGB":
        img = img.convert("RGB")

    hDC = win32ui.CreateDC()
    hDC.CreatePrinterDC(printer_name)
    try:
        # Yazıcı sayfasının fiziksel boyutu (piksel)
        page_w = hDC.GetDeviceCaps(110)   # HORZRES — yazılabilir alan
        page_h = hDC.GetDeviceCaps(111)   # VERTRES
        dpi_x  = hDC.GetDeviceCaps(88)    # LOGPIXELSX
        dpi_y  = hDC.GetDeviceCaps(90)    # LOGPIXELSY
        log.info("Yazıcı alan: %dx%d  DPI: %dx%d", page_w, page_h, dpi_x, dpi_y)

        # Sayfa boyutuna sığdır
        if fit == "stretch":
            target = (0, 0, page_w, page_h)
        elif fit == "actual":
            target = (0, 0, img.width, img.height)
        else:  # fit
            # Görüntüyü oranlı yazıcı sayfasına sığdır
            ratio = min(page_w / img.width, page_h / img.height)
            w = int(img.width * ratio)
            h = int(img.height * ratio)
            x = (page_w - w) // 2
            y = (page_h - h) // 2
            target = (x, y, x + w, y + h)

        for c in range(copies):
            hDC.StartDoc(f"ilactarif_{image_path.stem}")
            hDC.StartPage()
            dib = ImageWin.Dib(img)
            dib.draw(hDC.GetHandleOutput(), target)
            hDC.EndPage()
            hDC.EndDoc()
            log.info("Bask kopyası %d/%d gönderildi", c + 1, copies)
    finally:
        hDC.DeleteDC()


def print_many(image_paths, **kwargs) -> None:
    """Birden çok görseli sırayla bas."""
    for p in image_paths:
        print_image(p, **kwargs)


# ---------------------------------------------------------------------------
# Yazıcı önizleme — fiziksel basılacak görüntünün simülasyonu
# ---------------------------------------------------------------------------
def get_printer_page_info(printer_name: Optional[str] = None) -> dict:
    """Yazıcının fiziksel sayfa boyutunu ve DPI'sını döndür.

    Yazıcı erişilemezse Gprinter GP-1125D 60x40mm @ 203 DPI varsayılanları
    kullanılır.
    """
    info = {
        "name": "(yazıcı bulunamadı)",
        "page_w": 480,   # 60mm @ 203 DPI ≈ 479px
        "page_h": 320,   # 40mm @ 203 DPI ≈ 319px
        "dpi_x": 203,
        "dpi_y": 203,
        "mm_w": 60.0,
        "mm_h": 40.0,
        "ok": False,
        "error": "",
    }
    try:
        pname = printer_name or find_printer("Gprinter") or get_default_printer()
        info["name"] = pname
        hDC = win32ui.CreateDC()
        hDC.CreatePrinterDC(pname)
        try:
            page_w = hDC.GetDeviceCaps(110)
            page_h = hDC.GetDeviceCaps(111)
            dpi_x = hDC.GetDeviceCaps(88)
            dpi_y = hDC.GetDeviceCaps(90)
        finally:
            hDC.DeleteDC()
        info["page_w"] = page_w
        info["page_h"] = page_h
        info["dpi_x"] = dpi_x
        info["dpi_y"] = dpi_y
        info["mm_w"] = round(page_w / dpi_x * 25.4, 1) if dpi_x else 0.0
        info["mm_h"] = round(page_h / dpi_y * 25.4, 1) if dpi_y else 0.0
        info["ok"] = True
    except Exception as e:
        info["error"] = str(e)
    return info


def render_print_preview(
    image_path: Path | str,
    *,
    printer_name: Optional[str] = None,
    fit: str = "fit",
    bg: str = "white",
):
    """Yazıcıya gönderildiğinde fiziksel olarak çıkacak görüntüyü simüle eder.

    Döndürür: (PIL.Image, info_dict)
      - Image: yazıcının fiziksel sayfası kadar bir tuval, etiket sığdırılmış
      - info: get_printer_page_info() çıktısı (yazıcı adı, sayfa boyut, DPI)
    """
    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(image_path)

    img = Image.open(image_path)
    if img.mode != "RGB":
        img = img.convert("RGB")

    info = get_printer_page_info(printer_name)
    page_w, page_h = info["page_w"], info["page_h"]

    canvas = Image.new("RGB", (page_w, page_h), bg)
    if fit == "stretch":
        scaled = img.resize((page_w, page_h), Image.LANCZOS)
        canvas.paste(scaled, (0, 0))
    elif fit == "actual":
        # Köşeye yapıştır; taşma olursa kırpılır
        x = max(0, (page_w - img.width) // 2)
        y = max(0, (page_h - img.height) // 2)
        canvas.paste(img.crop((0, 0, min(img.width, page_w), min(img.height, page_h))),
                     (x, y))
    else:  # fit
        ratio = min(page_w / img.width, page_h / img.height)
        w = int(img.width * ratio)
        h = int(img.height * ratio)
        x = (page_w - w) // 2
        y = (page_h - h) // 2
        canvas.paste(img.resize((w, h), Image.LANCZOS), (x, y))
    return canvas, info
