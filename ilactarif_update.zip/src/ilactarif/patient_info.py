"""Hasta etiketi için ek bilgileri ana programın (Botanik/Medula) WinForms
etiketlerinden okur — UI Automation (pywinauto) ile.

Tarih ve hasta ad-soyad bilgisi Medula HTML'inden zaten parse edilir
(`PrescriptionCapture.recete_tarihi` / `.hasta_ad`). Telefon ve ödeme tutarları
ise HTML'de DEĞİL, ana programın WinForms ekranındaki etiketlerde durur. Bu
etiketler kararlı AutomationId taşır; onlardan okunur:

    lblMusteriTelefonu  → hasta telefonu        (örn. "C:(534) 394 2339")
    lblHastaBorcu       → ödeme tutarı (varsa)   (örn. "0,84")
    lblOdemeTutari      → reçete toplam tutarı   (örn. "0,84 Hes (Fiş:0,84)")

Yalnız OKUMA yapar; hiçbir tuşa basmaz / pencere değiştirmez. Bir şey
bulunamazsa boş alanlı `PatientExtra` döner (asla exception fırlatmaz).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# Okunacak WinForms etiketlerinin AutomationId'leri
_AUTO_IDS = ("lblMusteriTelefonu", "lblHastaBorcu", "lblOdemeTutari")

# TR para biçimi: "0,84" / "2193,43" / "1.234,56" / "120,69". Binlik ayıracı
# (nokta) varsa onu, yoksa düz tamsayıyı al; ardından virgüllü ondalık (varsa).
_AMOUNT_RX = re.compile(r"(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?")


@dataclass
class PatientExtra:
    telefon: str = ""
    recete_odeme: str = ""     # REÇETE ÖDEME TUTARI = lblOdemeTutari "(Fiş:" ÖNCESİ
                                # ("Yok"→"0,00"). Reçete için ödenecek tutar; etikette
                                # "REÇETE TUTARI" olarak gösterilir.
    veresiye: str = ""         # VERESİYE TOPLAM TUTARI = lblHastaBorcu. Etikette
                                # "TOPLAM BORÇ" olarak gösterilir.
    toplam: str = ""           # TOPLAM TUTAR = lblOdemeTutari "(Fiş:…)" içi. Etikette
                                # GÖSTERİLMEZ; reçete ödeme ile karşılaştırma/yedek için.


def _clean_phone(raw: str) -> str:
    """'C:(534) 394 2339' → '(534) 394 2339' (baştaki 'C:'/'E:' türü öneki atar)."""
    t = (raw or "").strip()
    t = re.sub(r"^[A-Za-zÇĞİÖŞÜ]\s*:\s*", "", t).strip()
    return t


def _first_amount(raw: str, drop_zero: bool = True) -> str:
    """'0,84 Hes (Fiş:0,84)' → '0,84'. Sıfır (0 / 0,00) ise drop_zero ile boş döner."""
    m = _AMOUNT_RX.search(raw or "")
    if not m:
        return ""
    val = m.group(0)
    if drop_zero:
        try:
            if float(val.replace(".", "").replace(",", ".")) == 0:
                return ""
        except ValueError:
            pass
    return val


def _amount_to_float(s: str):
    """'1.234,56' → 1234.56; '0,00' → 0.0; 'Yok'/'' → None."""
    m = _AMOUNT_RX.search(s or "")
    if not m:
        return None
    try:
        return float(m.group(0).replace(".", "").replace(",", "."))
    except ValueError:
        return None


def _parse_odeme_label(raw: str) -> tuple[str, str]:
    """lblOdemeTutari'yi (REÇETE ÖDEME, TOPLAM) olarak ayır.

    Biçim: '<reçete ödeme> [Hes] (Fiş:<toplam>)'. Örnekler:
      'Yok (Fiş:19,32)'         → ('0,00', '19,32')   ('Yok' = ödenecek yok)
      '120,69 Hes (Fiş:313,83)' → ('120,69', '313,83')
      '0,84 Hes (Fiş:0,84)'     → ('0,84', '0,84')
    """
    raw = raw or ""
    mt = re.search(r"Fi[şs]\s*:\s*([0-9][0-9.,]*)", raw)
    toplam = mt.group(1) if mt else ""
    before = re.sub(r"\bHes\b", "", raw.split("(")[0], flags=re.IGNORECASE)
    mr = _AMOUNT_RX.search(before)
    recete = mr.group(0) if mr else "0,00"   # sayı yoksa ('Yok'/boş) → 0,00
    return recete, toplam


def is_recete_paid(extra: "PatientExtra") -> bool:
    """Reçete ödeme tutarı veresiye toplam tutarından DAHA FAZLA ise ÖDENMİŞ sayılır."""
    ro = _amount_to_float(getattr(extra, "recete_odeme", ""))
    ve = _amount_to_float(getattr(extra, "veresiye", ""))
    return ro is not None and ve is not None and ro > ve


def label_amounts(extra: "PatientExtra | None") -> dict:
    """Etiket render'ı için hazır tutarlar:
        recete_tutari : reçete ödeme tutarı (ham, örn. '120,69' / '0,00')
        recete_paid   : True → kutuda tutar yerine 'ÖDENMİŞ' yazılır
        toplam_borc   : veresiye (0 ise '' → TOPLAM BORÇ satırı gizli)
    """
    if extra is None:
        return {"recete_tutari": "", "recete_paid": False, "toplam_borc": ""}
    ve = (getattr(extra, "veresiye", "") or "").strip()
    ve_disp = "" if _amount_to_float(ve) in (None, 0.0) else ve
    return {
        "recete_tutari": (getattr(extra, "recete_odeme", "") or "").strip(),
        "recete_paid": is_recete_paid(extra),
        "toplam_borc": ve_disp,
    }


def _norm_name(s: str) -> str:
    """İsmi karşılaştırma için normalize et (büyük harf, tek boşluk, kenar boşluksuz)."""
    return re.sub(r"\s+", " ", (s or "").upper().strip())


def read_screen_identity() -> tuple[str, str]:
    """Ekranda (ana Botanik/Medula penceresinde) YÜKLÜ reçetenin kimliği:
    (recete_no, hasta_ad). WinForms tutarlarıyla AYNI ekrana ait kimlik anchoru —
    okunan tutarın HANGİ hastaya ait olduğunu doğrulamak için kullanılır.

    Ön plandaki Medula penceresini, yoksa bulunan ilk Medula penceresini okur.
    Bulunamazsa ('', '') döner (kimlik doğrulanamadı → eşleşme reddedilir).
    """
    try:
        import comtypes
        ok = False
        try:
            comtypes.CoInitialize()
            ok = True
        except Exception:
            ok = False
        try:
            import ctypes
            from .medula_capture import find_medula_windows, capture_one
            from .medula_parser import parse_html
            wins = find_medula_windows()
            if not wins:
                return "", ""
            fg = ctypes.windll.user32.GetForegroundWindow()
            w = next((x for x in wins if x.hwnd == fg), wins[0])
            for ie in (w.ie_servers or []):
                info = capture_one(ie)
                if "error" in info or not info.get("html"):
                    continue
                cap = parse_html(info["html"], document_url=info.get("url", ""))
                rno = (cap.recete_no or "").strip()
                ad = (cap.hasta_ad or "").strip()
                if rno or ad:
                    return rno, ad
            return "", ""
        finally:
            if ok:
                try:
                    comtypes.CoUninitialize()
                except Exception:
                    pass
    except Exception:
        return "", ""


def identity_matches(screen_rno: str, screen_ad: str,
                     target_rno: str, target_ad: str) -> bool:
    """Ekrandaki reçete (screen) etiketin ait olduğu hasta (target) ile aynı mı?

    Önce reçete no (kesin) ile; her ikisi de doluysa karar onunla verilir. Reçete
    no yoksa normalize edilmiş hasta adı ile. Hiçbiri doğrulanamazsa GÜVENLİ taraf:
    False (tutar uygulanmaz) — yanlış hastanın tutarı asla etikete geçmesin.
    """
    sr, tr = (screen_rno or "").strip(), (target_rno or "").strip()
    if sr and tr:
        return sr == tr
    sa, ta = _norm_name(screen_ad), _norm_name(target_ad)
    if sa and ta:
        return sa == ta
    return False


def _target_pids() -> set[int]:
    """Başlığında MEDULA/BOTANIK geçen top-level pencerelerin süreç (pid) kümesi."""
    try:
        from .medula_capture import enum_top_windows
    except Exception:
        return set()
    pids: set[int] = set()
    for _hwnd, title, _cls, pid in enum_top_windows():
        up = (title or "").upper()
        if "MEDULA" in up or "BOTANIK" in up:
            pids.add(pid)
    return pids


def _read_native(found: dict) -> None:
    """Yerel UIAutomation COM API ile AutomationId'ye göre doğrudan arama.

    Ağaç yürümesini UIA'nın C++ motoru yapar (FindFirst) → pywinauto'nun Python
    seviyesindeki yavaş/eksik kalabilen `descendants()` taramasından çok daha
    güvenilir. Süreç filtresine gerek yok; AutomationId yeterince ayırt edicidir.
    """
    import comtypes.client

    _AUTOMATIONID_PROP = 30011   # UIA_AutomationIdPropertyId
    _SCOPE_DESCENDANTS = 4       # TreeScope_Descendants

    mod = comtypes.client.GetModule("UIAutomationCore.dll")
    iuia = comtypes.client.CreateObject(mod.CUIAutomation, interface=mod.IUIAutomation)
    root = iuia.GetRootElement()
    for aid in _AUTO_IDS:
        if found.get(aid):
            continue
        try:
            cond = iuia.CreatePropertyCondition(_AUTOMATIONID_PROP, aid)
            el = root.FindFirst(_SCOPE_DESCENDANTS, cond)
            if el:
                found[aid] = (el.CurrentName or "").strip()
        except Exception:
            pass


def _collect(els, found: dict) -> None:
    """Eleman listesinde aranan AutomationId'leri topla."""
    for el in els:
        try:
            aid = el.element_info.automation_id
        except Exception:
            continue
        if aid in _AUTO_IDS and not found.get(aid):
            try:
                found[aid] = (el.window_text() or "").strip()
            except Exception:
                pass


def _scan_window(win, found: dict) -> None:
    """Pencerede aranan etiketleri bul: önce hızlı (control_type='Text') tara;
    eksik kalırsa TÜM torunlarda dene (WinForms ağacı her zaman 'Text' filtresine
    düşmeyebilir)."""
    try:
        _collect(win.descendants(control_type="Text"), found)
    except Exception:
        pass
    if all(found.get(a) for a in _AUTO_IDS):
        return
    try:
        _collect(win.descendants(), found)
    except Exception:
        pass


def has_extra_data(extra: "PatientExtra") -> bool:
    """Ekrandan GERÇEKTEN veri okundu mu? (recete_odeme parse'tan hep '0,00' gelir,
    güvenilmez; ham okunan telefon/veresiye/toplam'a bakılır)."""
    return bool(extra and (extra.telefon or extra.veresiye or extra.toplam))


def read_patient_extra(fast: bool = False) -> PatientExtra:
    """WinForms etiketlerini UIA ile okuyup PatientExtra döndür (hata → boş alanlar).

    fast=True: yalnız HIZLI yerel UIA FindFirst kullanılır (yavaş pywinauto
    descendants taraması ATLANIR) — poll/retry için uygundur. fast=False:
    native eksik kalırsa pywinauto taraması da denenir (tek seferlik baskıda).
    """
    found: dict[str, str] = {}
    try:
        import comtypes
        com_ok = False
        try:
            comtypes.CoInitialize()
            com_ok = True
        except Exception:
            com_ok = False
        try:
            # 1) En güvenilir + hızlı: yerel UIA FindFirst (AutomationId ile doğrudan)
            try:
                _read_native(found)
            except Exception:
                pass

            # 2) Eksik kalırsa yedek: pywinauto descendants taraması (YAVAŞ — fast'te atlanır)
            if not fast and not all(found.get(a) for a in _AUTO_IDS):
                from pywinauto import Desktop

                pids = set(_target_pids())
                dsk = Desktop(backend="uia")
                wins = list(dsk.windows())

                def _pid(w):
                    try:
                        return w.element_info.process_id
                    except Exception:
                        return None

                # Başlığı MEDULA/BOTANIK olan pencerelerin pid'lerini de havuza ekle
                titled = []
                for w in wins:
                    try:
                        up = str(w.window_text() or "").upper()
                    except Exception:
                        up = ""
                    if "MEDULA" in up or "BOTANIK" in up:
                        titled.append(w)
                        p = _pid(w)
                        if p:
                            pids.add(p)

                # Önce başlığı eşleşenler, sonra aynı süreçteki tüm diğer pencereler
                same_pid = [w for w in wins if w not in titled and _pid(w) in pids]
                for w in titled + same_pid:
                    if all(found.get(a) for a in _AUTO_IDS):
                        break
                    _scan_window(w, found)
        finally:
            if com_ok:
                try:
                    comtypes.CoUninitialize()
                except Exception:
                    pass
    except Exception:
        pass

    recete_odeme, toplam = _parse_odeme_label(found.get("lblOdemeTutari", ""))
    return PatientExtra(
        telefon=_clean_phone(found.get("lblMusteriTelefonu", "")),
        recete_odeme=recete_odeme,
        veresiye=_first_amount(found.get("lblHastaBorcu", ""), drop_zero=False),
        toplam=toplam,
    )
