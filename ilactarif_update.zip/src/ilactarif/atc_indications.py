"""WHO ATC kodundan ve atc_name'den otomatik endikasyon üretici.

WHO ATC kodu hiyerarşik:
    1 karakter: Anatomik ana grup (A=sindirim, J=anti-infektif, M=kas-iskelet, ...)
    2 karakter: Terapötik alt grup
    3 karakter: Farmakolojik alt grup
    4 karakter: Kimyasal alt grup
    5 karakter: Kimyasal madde

generate_indication(atc_code, atc_name) → (short, long)
    short: Etiket başlığı için CAPS Türkçe (örn. "ANTİBİYOTİK")
    long:  Hastaya yönelik 1-2 cümle açıklama
"""
from __future__ import annotations


# Sık etken maddelerin İngilizce → Türkçe + sade açıklama eşlemesi.
# Anahtar: lowercase trimmed atc_name veya ilk kelime.
ACTIVE_INGREDIENT_TR: dict[str, tuple[str, str]] = {
    # (Türkçe ad, hasta diline kısa açıklama)
    "amoxicillin":                ("amoksisilin", "geniş spektrumlu antibiyotik"),
    "amoxicillin and enzyme inhibitor": ("amoksisilin + klavulanat", "antibiyotik (beta-laktamaz dirençli)"),
    "ampicillin":                 ("ampisilin", "antibiyotik"),
    "cefazolin":                  ("sefazolin", "1. kuşak sefalosporin antibiyotik"),
    "cefuroxime":                 ("sefuroksim", "2. kuşak sefalosporin antibiyotik"),
    "ceftriaxone":                ("seftriakson", "3. kuşak sefalosporin antibiyotik"),
    "cefixime":                   ("sefiksim", "3. kuşak sefalosporin antibiyotik"),
    "cefdinir":                   ("sefdinir", "3. kuşak sefalosporin antibiyotik"),
    "clarithromycin":             ("klaritromisin", "makrolid antibiyotik"),
    "azithromycin":               ("azitromisin", "makrolid antibiyotik"),
    "erythromycin":               ("eritromisin", "makrolid antibiyotik"),
    "spiramycin":                 ("spiramisin", "makrolid antibiyotik"),
    "clindamycin":                ("klindamisin", "linkozamid antibiyotik"),
    "ciprofloxacin":              ("siprofloksasin", "kinolon antibiyotik"),
    "levofloxacin":               ("levofloksasin", "kinolon antibiyotik"),
    "moxifloxacin":               ("moksifloksasin", "kinolon antibiyotik"),
    "metronidazole":              ("metronidazol", "anaerob/parazit antibiyotiği"),
    "ornidazole":                 ("ornidazol", "anaerob/parazit antibiyotiği"),
    "tinidazole":                 ("tinidazol", "anaerob/parazit antibiyotiği"),
    "fosfomycin":                 ("fosfomisin", "idrar yolu antibiyotiği"),
    "nitrofurantoin":              ("nitrofurantoin", "idrar yolu antibiyotiği"),
    "fusidic acid":               ("fusidik asit", "antibiyotik (stafilokok)"),
    "doxycycline":                ("doksisiklin", "tetrasiklin antibiyotik"),
    "vancomycin":                 ("vankomisin", "hastane antibiyotiği"),
    "linezolid":                  ("linezolid", "antibiyotik"),
    "trimethoprim and sulfamethoxazole": ("trimetoprim/sülfametoksazol", "antibiyotik (kotrimoksazol)"),
    "oseltamivir":                ("oseltamivir", "grip antiviral ilacı"),
    "acyclovir":                  ("asiklovir", "uçuk/zona antiviral"),
    "valacyclovir":               ("valasiklovir", "uçuk/zona antiviral"),

    # NSAID
    "ibuprofen":                  ("ibuprofen", "ağrı kesici - ateş düşürücü (NSAİİ)"),
    "ibuprofen, combinations":    ("ibuprofen kombinasyonu", "ağrı kesici - grip kombinasyonu"),
    "naproxen":                   ("naproksen", "ağrı kesici (NSAİİ)"),
    "diclofenac":                 ("diklofenak", "ağrı kesici - iltihap önleyici (NSAİİ)"),
    "etodolac":                   ("etodolak", "ağrı kesici (NSAİİ)"),
    "dexketoprofen":              ("deksketoprofen", "ağrı kesici (NSAİİ)"),
    "ketoprofen":                 ("ketoprofen", "ağrı kesici (NSAİİ)"),
    "flurbiprofen":               ("flurbiprofen", "ağrı kesici (NSAİİ)"),
    "nimesulide":                 ("nimesülid", "ağrı kesici (NSAİİ)"),
    "meloxicam":                  ("meloksikam", "ağrı kesici - iltihap önleyici"),
    "celecoxib":                  ("selekoksib", "ağrı kesici (COX-2 selektif)"),
    "acemetacin":                 ("asemetazin", "ağrı kesici (NSAİİ)"),
    "indomethacin":               ("indometazin", "ağrı kesici (NSAİİ)"),
    "piroxicam":                  ("piroksikam", "ağrı kesici (NSAİİ)"),

    # Parasetamol / analjezik
    "paracetamol":                ("parasetamol", "ağrı kesici - ateş düşürücü"),
    "paracetamol, combinations excl. psycholeptics": ("parasetamol kombinasyonu", "ağrı kesici / grip kombinasyonu"),
    "acetylsalicylic acid":       ("asetilsalisilik asit (aspirin)", "ağrı kesici / kan sulandırıcı (dozaja göre)"),
    "metamizole sodium":          ("metamizol", "güçlü ağrı kesici"),

    # Kas gevşetici
    "thiocolchicoside":           ("tiyokolşikosid", "kas gevşetici"),
    "thiocolchicoside, combinations": ("tiyokolşikosid kombinasyonu", "kas gevşetici kombinasyon"),
    "chlorzoxazone":              ("klorzoksazon", "kas gevşetici"),
    "chlorzoxazone, combinations excl. psycholeptics": ("klorzoksazon kombinasyonu", "kas gevşetici kombinasyon"),

    # PPI / Mide
    "pantoprazole":               ("pantoprazol", "mide asidi azaltıcı (PPI)"),
    "lansoprazole":               ("lansoprazol", "mide asidi azaltıcı (PPI)"),
    "esomeprazole":               ("esomeprazol", "mide asidi azaltıcı (PPI)"),
    "omeprazole":                 ("omeprazol", "mide asidi azaltıcı (PPI)"),
    "rabeprazole":                ("rabeprazol", "mide asidi azaltıcı (PPI)"),
    "alginic acid":               ("aljinik asit", "reflü / mide yanması"),
    "ordinary salt combinations": ("aljinik asit kombinasyonu", "reflü / mide yanması"),
    "ranitidine":                 ("ranitidin", "mide asidi azaltıcı (H2)"),
    "famotidine":                 ("famotidin", "mide asidi azaltıcı (H2)"),

    # Antiemetik / motilite
    "domperidone":                ("domperidon", "bulantı kesici / mide hareket düzenleyici"),
    "metoclopramide":             ("metoklopramid", "bulantı kesici"),
    "ondansetron":                ("ondansetron", "güçlü bulantı kesici"),

    # Tansiyon / Kalp
    "metoprolol":                 ("metoprolol", "beta-bloker (tansiyon/kalp)"),
    "nebivolol":                  ("nebivolol", "beta-bloker (tansiyon)"),
    "bisoprolol":                 ("bisoprolol", "beta-bloker (tansiyon/kalp)"),
    "atenolol":                   ("atenolol", "beta-bloker (tansiyon)"),
    "carvedilol":                 ("karvedilol", "beta-bloker (kalp yetmezliği)"),
    "amlodipine":                 ("amlodipin", "kalsiyum kanal blokeri (tansiyon)"),
    "nifedipine":                 ("nifedipin", "kalsiyum kanal blokeri (tansiyon)"),
    "diltiazem":                  ("diltiazem", "kalsiyum kanal blokeri"),
    "verapamil":                  ("verapamil", "kalsiyum kanal blokeri / kalp ritim"),
    "ramipril":                   ("ramipril", "ACE inhibitörü (tansiyon)"),
    "enalapril":                  ("enalapril", "ACE inhibitörü (tansiyon)"),
    "lisinopril":                 ("lisinopril", "ACE inhibitörü (tansiyon)"),
    "perindopril":                ("perindopril", "ACE inhibitörü (tansiyon)"),
    "perindopril and diuretics":  ("perindopril + diüretik", "tansiyon kombinasyonu"),
    "valsartan":                  ("valsartan", "anjiyotensin reseptör blokeri (tansiyon)"),
    "valsartan and diuretics":    ("valsartan + diüretik", "tansiyon kombinasyonu"),
    "candesartan":                ("kandesartan", "anjiyotensin reseptör blokeri (tansiyon)"),
    "candesartan and diuretics":  ("kandesartan + diüretik", "tansiyon kombinasyonu"),
    "losartan":                   ("losartan", "anjiyotensin reseptör blokeri (tansiyon)"),
    "losartan and diuretics":     ("losartan + diüretik", "tansiyon kombinasyonu"),
    "telmisartan":                ("telmisartan", "anjiyotensin reseptör blokeri (tansiyon)"),
    "irbesartan":                 ("irbesartan", "anjiyotensin reseptör blokeri (tansiyon)"),
    "olmesartan medoxomil":       ("olmesartan", "anjiyotensin reseptör blokeri (tansiyon)"),
    "furosemide":                 ("furosemid", "diüretik (idrar söktürücü)"),
    "hydrochlorothiazide":        ("hidroklorotiazid", "diüretik"),
    "spironolactone":             ("spironolakton", "diüretik (potasyum tutucu)"),
    "indapamide":                 ("indapamid", "diüretik (tansiyon)"),

    # Statin / Lipid
    "atorvastatin":               ("atorvastatin", "kolesterol düşürücü (statin)"),
    "rosuvastatin":               ("rosuvastatin", "kolesterol düşürücü (statin)"),
    "simvastatin":                ("simvastatin", "kolesterol düşürücü (statin)"),
    "pravastatin":                ("pravastatin", "kolesterol düşürücü (statin)"),
    "ezetimibe":                  ("ezetimib", "kolesterol düşürücü"),
    "fenofibrate":                ("fenofibrat", "trigliserid düşürücü"),

    # Şeker hastalığı
    "metformin":                  ("metformin", "şeker hastalığı ilacı (biguanid)"),
    "metformin and vildagliptin": ("metformin + vildagliptin", "şeker hastalığı kombinasyonu"),
    "metformin and saxagliptin":  ("metformin + saksagliptin", "şeker hastalığı kombinasyonu"),
    "metformin and linagliptin":  ("metformin + linagliptin", "şeker hastalığı kombinasyonu"),
    "metformin and sitagliptin":  ("metformin + sitagliptin", "şeker hastalığı kombinasyonu"),
    "metformin and dapagliflozin": ("metformin + dapagliflozin", "şeker hastalığı kombinasyonu"),
    "metformin and empagliflozin": ("metformin + empagliflozin", "şeker hastalığı kombinasyonu"),
    "gliclazide":                 ("gliklazid", "şeker hastalığı ilacı (sülfonilüre)"),
    "glimepiride":                ("glimepirid", "şeker hastalığı ilacı (sülfonilüre)"),
    "empagliflozin":              ("empagliflozin", "şeker hastalığı ilacı (SGLT2 inh.)"),
    "dapagliflozin":              ("dapagliflozin", "şeker hastalığı ilacı (SGLT2 inh.)"),
    "vildagliptin":               ("vildagliptin", "şeker hastalığı ilacı (DPP-4 inh.)"),
    "sitagliptin":                ("sitagliptin", "şeker hastalığı ilacı (DPP-4 inh.)"),
    "linagliptin":                ("linagliptin", "şeker hastalığı ilacı (DPP-4 inh.)"),
    "insulin glargine":           ("insülin glarjin", "uzun etkili insülin"),
    "insulin aspart":             ("insülin aspart", "hızlı etkili insülin"),
    "insulin lispro":             ("insülin lispro", "hızlı etkili insülin"),
    "insulin (human)":             ("insülin (human)", "insülin"),

    # Kan sulandırıcı / Antikoagülan
    "warfarin":                   ("varfarin", "kan sulandırıcı (oral antikoagülan)"),
    "clopidogrel":                ("klopidogrel", "kan sulandırıcı (antiplatelet)"),
    "ticagrelor":                 ("tikagrelor", "kan sulandırıcı (antiplatelet)"),
    "rivaroxaban":                ("rivaroksaban", "yeni nesil oral antikoagülan"),
    "apixaban":                   ("apiksaban", "yeni nesil oral antikoagülan"),
    "dabigatran etexilate":       ("dabigatran", "yeni nesil oral antikoagülan"),
    "enoxaparin":                 ("enoksaparin", "kan sulandırıcı (LMW heparin)"),

    # Antihistaminik
    "cetirizine":                 ("setirizin", "allerji ilacı (antihistaminik)"),
    "levocetirizine":             ("levosetirizin", "allerji ilacı (antihistaminik)"),
    "loratadine":                 ("loratadin", "allerji ilacı (antihistaminik)"),
    "desloratadine":              ("desloratadin", "allerji ilacı (antihistaminik)"),
    "fexofenadine":               ("feksofenadin", "allerji ilacı (antihistaminik)"),
    "hydroxyzine":                ("hidroksizin", "allerji / sedatif antihistaminik"),
    "rupatadine":                 ("rupatadin", "allerji ilacı (antihistaminik)"),
    "ebastine":                   ("ebastin", "allerji ilacı (antihistaminik)"),

    # Solunum
    "salbutamol":                 ("salbutamol", "bronş açıcı (kısa etkili)"),
    "salmeterol":                 ("salmeterol", "bronş açıcı (uzun etkili)"),
    "formoterol":                 ("formoterol", "bronş açıcı (uzun etkili)"),
    "salmeterol and other drugs for obstructive airway diseases": ("salmeterol kombinasyonu", "astım kombinasyonu"),
    "formoterol and other drugs for obstructive airway diseases": ("formoterol kombinasyonu", "astım kombinasyonu"),
    "budesonide":                 ("budesonid", "inhale kortikosteroid (astım)"),
    "fluticasone":                ("flutikazon", "inhale kortikosteroid"),
    "mometasone":                 ("mometazon", "kortikosteroid"),
    "beclometasone":              ("beklometazon", "inhale kortikosteroid"),
    "ipratropium bromide":        ("ipratropyum", "bronş açıcı (antikolinerjik)"),
    "tiotropium bromide":         ("tiotropyum", "bronş açıcı (uzun etkili)"),
    "montelukast":                ("montelukast", "astım/alerji ilacı (lökotrien antagonisti)"),
    "montelukast, combinations":  ("montelukast kombinasyonu", "astım/alerji kombinasyonu"),
    "acetylcysteine":             ("asetilsistein", "balgam sökücü"),
    "ambroxol":                   ("ambroksol", "balgam sökücü"),
    "bromhexine":                 ("bromheksin", "balgam sökücü"),
    "erdosteine":                 ("erdostein", "balgam sökücü"),
    "carbocisteine":              ("karbosistein", "balgam sökücü"),
    "butamirate":                 ("butamirat", "öksürük kesici"),
    "levodropropizine":           ("levodropropizin", "öksürük kesici"),
    "dextromethorphan":           ("dekstrometorfan", "öksürük kesici"),
    "guaifenesin":                ("guaifenesin", "balgam sökücü"),
    "other cold preparations":    ("soğuk algınlığı kombinasyonu", "grip / soğuk algınlığı"),
    "combinations":               ("kombinasyon", "kombinasyon ilacı"),

    # Burun
    "xylometazoline":             ("ksilometazolin", "burun açıcı (kısa etkili)"),
    "oxymetazoline":              ("oksimetazolin", "burun açıcı (kısa etkili)"),

    # Antidepresan / SSRI
    "sertraline":                 ("sertralin", "antidepresan (SSRI)"),
    "escitalopram":               ("essitalopram", "antidepresan (SSRI)"),
    "citalopram":                 ("sitalopram", "antidepresan (SSRI)"),
    "fluoxetine":                 ("fluoksetin", "antidepresan (SSRI)"),
    "paroxetine":                 ("paroksetin", "antidepresan (SSRI)"),
    "duloxetine":                 ("duloksetin", "antidepresan (SNRI)"),
    "venlafaxine":                ("venlafaksin", "antidepresan (SNRI)"),
    "mirtazapine":                ("mirtazapin", "antidepresan"),
    "trazodone":                  ("trazodon", "antidepresan / uyku"),

    # Antipsikotik / Anksiyolitik
    "quetiapine":                 ("ketiapin", "antipsikotik / uyku"),
    "olanzapine":                 ("olanzapin", "antipsikotik"),
    "risperidone":                ("risperidon", "antipsikotik"),
    "aripiprazole":               ("aripiprazol", "antipsikotik"),
    "alprazolam":                 ("alprazolam", "anksiyolitik (benzodiazepin)"),
    "lorazepam":                  ("lorazepam", "anksiyolitik (benzodiazepin)"),
    "diazepam":                   ("diazepam", "anksiyolitik (benzodiazepin)"),
    "zolpidem":                   ("zolpidem", "uyku ilacı"),

    # Antiepileptik / Sinir ağrısı
    "carbamazepine":              ("karbamazepin", "antiepileptik / sinir ağrısı"),
    "valproic acid":              ("valproik asit", "antiepileptik"),
    "levetiracetam":              ("levetirasetam", "antiepileptik"),
    "lamotrigine":                ("lamotrijin", "antiepileptik"),
    "pregabalin":                 ("pregabalin", "sinir ağrısı / antiepileptik"),
    "gabapentin":                 ("gabapentin", "sinir ağrısı / antiepileptik"),

    # Tiroid / Hormon
    "levothyroxine sodium":       ("levotiroksin", "tiroid hormonu (guatr)"),

    # Kortizon
    "methylprednisolone":         ("metilprednizolon", "kortizon (iltihap önleyici)"),
    "prednisolone":               ("prednizolon", "kortizon"),
    "dexamethasone":              ("deksametazon", "kortizon (güçlü)"),
    "betamethasone":              ("betametazon", "kortizon"),
    "hydrocortisone":             ("hidrokortizon", "kortizon (hafif)"),
    "clobetasol":                 ("klobetazol", "güçlü cilt kortizonu"),

    # Mantar
    "fluconazole":                ("flukonazol", "antimantar"),
    "itraconazole":               ("itrakonazol", "antimantar"),
    "terbinafine":                ("terbinafin", "antimantar"),
    "ketoconazole":               ("ketokonazol", "antimantar"),
    "oxiconazole":                ("oksikonazol", "antimantar (dış kullanım)"),
    "miconazole":                 ("mikonazol", "antimantar (dış kullanım)"),
    "clotrimazole":               ("klotrimazol", "antimantar (dış kullanım)"),

    # Vitamin / Mineral
    "colecalciferol":             ("kolekalsiferol", "D3 vitamini"),
    "ergocalciferol":             ("ergokalsiferol", "D2 vitamini"),
    "cyanocobalamin":             ("siyanokobalamin", "B12 vitamini"),
    "folic acid":                 ("folik asit", "B9 vitamini"),
    "vitamin b1 in combination with vitamin b6 and/or vitamin b12": (
        "B1+B6+B12 kombinasyonu", "B kompleks vitamini desteği"),
    "zinc sulfate":               ("çinko sülfat", "çinko desteği"),
    "magnesium oxide":             ("magnezyum oksid", "magnezyum desteği"),
    "calcium":                    ("kalsiyum", "kalsiyum desteği"),
    "iron":                       ("demir", "demir desteği"),
    "ferrous sulfate":            ("ferro sülfat", "demir desteği"),
    "fat/carbohydrates/proteins/minerals/vitamins, combinations": (
        "multivitamin", "multivitamin / mineral desteği"),

    # Ağız - boğaz - göz
    "benzydamine":                ("benzidamin", "ağız/boğaz iltihap önleyici"),
    "chlorhexidine":              ("klorheksidin", "ağız antiseptiği"),
    "various":                    ("ağız bakımı", "ağız ve diş eti bakım ürünü"),
    "other agents for local oral treatment": ("ağız bakımı", "ağız ve diş eti bakım ürünü"),
    "artificial tears and other indifferent preparations": (
        "yapay göz yaşı", "kuru göz tedavisi (yapay göz yaşı)"),

    # Sindirim - laksatif
    "lactulose":                  ("laktüloz", "kabızlık ilacı"),
    "sodium phosphate":           ("sodyum fosfat", "barsak temizleyici / laksatif"),
    "macrogol":                   ("makrogol", "kabızlık ilacı"),

    # Parazit / cilt
    "hydroxychloroquine":         ("hidroksiklorokin", "romatizma / lupus ilacı"),
    "chloroquine":                ("klorokin", "sıtma ilacı"),
    "albendazole":                ("albendazol", "solucan / bağırsak paraziti ilacı"),
    "mebendazole":                ("mebendazol", "solucan / bağırsak paraziti ilacı"),
    "permethrin":                 ("permetrin", "bit / uyuz ilacı"),
    "lindane":                    ("lindan", "uyuz ilacı"),
    "silver sulfadiazine":        ("gümüş sülfadiazin", "yanık antibiyotiği"),
    "fusidic acid (topical)":     ("fusidik asit", "cilt antibiyotiği"),

    # Anestezik / lokal
    "lidocaine":                  ("lidokain", "lokal anestezik"),
    "centella asiatica herba":    ("kantarella ekstresi", "yara iyileştirici (bitkisel)"),
    "carbamide":                  ("üre (karbamid)", "cilt nemlendirici"),

    # Doğum kontrol
    "drospirenone and ethinylestradiol": ("drospirenon + etinilestradiol", "doğum kontrol hapı"),
    "gestodene and ethinylestradiol":    ("gestodene + etinilestradiol", "doğum kontrol hapı"),
    "levonorgestrel and ethinylestradiol": ("levonorgestrel + etinilestradiol", "doğum kontrol hapı"),

    # İmidazol kombinasyonu cilt
    "imidazoles/triazoles in combination with corticosteroids": (
        "antimantar + kortizon kombinasyon", "antimantar + iltihap önleyici cilt kremi"),
    "silicones":                  ("simetikon", "gaz giderici / şişkinlik"),
    "preparations with salicylic acid derivatives": (
        "salisilik asit", "ağrı kesici cilt preparatı"),
    "other dermatologicals":      ("cilt bakım ürünü", "cilt bakım / koruma ürünü"),
}


# ATC ön ekleri → (kısa CAPS etiket başlığı, jenerik uzun metin).
# Daha spesifik prefix önce gelir.
ATC_PREFIX_CATEGORIES: list[tuple[str, str, str]] = [
    # (prefix, short_caps, long_generic)
    # === J: Anti-infektifler ===
    ("J01XC", "ANTİBİYOTİK", "Steroid yapılı antibakteriyel."),
    ("J01XX01", "ANTİBİYOTİK (İDRAR YOLU)", "İdrar yolu enfeksiyonu antibiyotiği."),
    ("J01XX", "ANTİBİYOTİK", "Diğer antibakteriyel."),
    ("J01XB", "ANTİBİYOTİK", "Polimiksin antibakteriyel."),
    ("J01XA", "ANTİBİYOTİK", "Glikopeptid antibakteriyel."),
    ("J01XE", "ANTİBİYOTİK", "Nitrofuran antibakteriyel (idrar yolu)."),
    ("J01DC", "ANTİBİYOTİK", "2. kuşak sefalosporin grubu antibiyotik."),
    ("J01DD", "ANTİBİYOTİK", "3. kuşak sefalosporin grubu antibiyotik."),
    ("J01DE", "ANTİBİYOTİK", "4. kuşak sefalosporin grubu antibiyotik."),
    ("J01DB", "ANTİBİYOTİK", "1. kuşak sefalosporin grubu antibiyotik."),
    ("J01DH", "ANTİBİYOTİK", "Karbapenem antibakteriyel."),
    ("J01D",  "ANTİBİYOTİK", "Beta-laktam antibakteriyel (sefalosporin grubu)."),
    ("J01CR", "ANTİBİYOTİK", "Penisilin + beta-laktamaz inhibitörü kombinasyonu."),
    ("J01CA", "ANTİBİYOTİK", "Geniş spektrumlu penisilin."),
    ("J01CE", "ANTİBİYOTİK", "Beta-laktamaz duyarlı penisilin."),
    ("J01CF", "ANTİBİYOTİK", "Beta-laktamaz dirençli penisilin."),
    ("J01C",  "ANTİBİYOTİK", "Penisilin grubu antibiyotik."),
    ("J01FA", "ANTİBİYOTİK", "Makrolid antibakteriyel."),
    ("J01FF", "ANTİBİYOTİK", "Linkozamid antibakteriyel."),
    ("J01F",  "ANTİBİYOTİK", "Makrolid / linkozamid antibakteriyel."),
    ("J01MA", "ANTİBİYOTİK", "Kinolon antibakteriyel."),
    ("J01M",  "ANTİBİYOTİK", "Kinolon antibakteriyel."),
    ("J01EE", "ANTİBİYOTİK", "Sülfonamid + trimetoprim kombinasyonu."),
    ("J01E",  "ANTİBİYOTİK", "Sülfonamid grubu antibiyotik."),
    ("J01AA", "ANTİBİYOTİK", "Tetrasiklin antibakteriyel."),
    ("J01A",  "ANTİBİYOTİK", "Tetrasiklin grubu antibiyotik."),
    ("J01G",  "ANTİBİYOTİK", "Aminoglikozid antibakteriyel."),
    ("J01B",  "ANTİBİYOTİK", "Amfenikol antibakteriyel."),
    ("J01",   "ANTİBİYOTİK", "Sistemik antibakteriyel ilaç."),
    ("J02",   "ANTİMANTAR (SİSTEMİK)", "Sistemik antimantar."),
    # Rifamisin SV ampul (RIF/Rifocin) pratikte lokal/bölgesel antibakteriyel —
    # hastaya "VEREM İLACI" yazmak yanıltır; "ANTİBİYOTİK" yeterli.
    ("J04AB03", "ANTİBİYOTİK", "Rifamisin SV — antibakteriyel (antibiyotik)."),
    ("J04",   "VEREM İLACI", "Tüberküloz tedavisi."),
    ("J05A",  "ANTİVİRAL", "Sistemik antiviral ilaç."),
    ("J05",   "ANTİVİRAL", "Sistemik antiviral."),
    ("J06",   "İMMÜN SERUM / İLAÇ", "İmmünoglobülin / antikor preparatı."),
    ("J07",   "AŞI", "Aşı."),

    # === M: Kas-iskelet ===
    ("M01AE", "AĞRI KESİCİ", "Propiyonik asit türevi NSAİİ (ağrı kesici)."),
    ("M01AB", "AĞRI KESİCİ", "Asetik asit türevi NSAİİ (ağrı kesici)."),
    ("M01AC", "AĞRI KESİCİ", "Oksikam grubu NSAİİ (ağrı kesici)."),
    ("M01AH", "AĞRI KESİCİ", "Koksib (COX-2 selektif) NSAİİ."),
    ("M01AX", "AĞRI KESİCİ", "Diğer NSAİİ ağrı kesici."),
    ("M01C",  "ROMATİZMA İLACI", "Hastalık modifiye edici antiromatizmal (DMARD)."),
    ("M02AA", "AĞRI KESİCİ (HARİCİ)", "Dış kullanım için ağrı kesici (NSAİİ kremi)."),
    ("M02AC", "CİLT İLACI (AĞRI)", "Salisilik asit içeren dış kullanım."),
    ("M02",   "AĞRI KESİCİ (HARİCİ)", "Dış kullanım için ağrı kesici."),
    ("M03BX", "KAS GEVŞETİCİ", "Santral etkili kas gevşetici."),
    ("M03B",  "KAS GEVŞETİCİ", "Santral etkili kas gevşetici."),
    ("M03",   "KAS GEVŞETİCİ", "Kas gevşetici."),
    ("M04",   "GUT İLACI", "Gut (ürik asit) tedavisi."),
    ("M05B",  "OSTEOPOROZ İLACI", "Kemik erimesi tedavisi (bisfosfonat / denosumab)."),
    ("M05",   "OSTEOPOROZ İLACI", "Kemik erimesi tedavisi."),
    ("M01",   "AĞRI KESİCİ", "Ağrı kesici / iltihap önleyici."),

    # === N: Sinir sistemi ===
    ("N02BE", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ", "Parasetamol grubu ağrı kesici / ateş düşürücü."),
    ("N02BA", "AĞRI KESİCİ", "Salisilat (aspirin) grubu ağrı kesici."),
    ("N02BB", "AĞRI KESİCİ", "Pirazolon grubu ağrı kesici."),
    ("N02B",  "AĞRI KESİCİ", "Ağrı kesici / ateş düşürücü."),
    ("N02A",  "AĞRI KESİCİ (KUVVETLİ)", "Opioid grubu kuvvetli ağrı kesici."),
    ("N02C",  "MİGREN İLACI", "Migren tedavisi."),
    ("N03",   "ANTİEPİLEPTİK", "Epilepsi / sinir ağrısı ilacı."),
    ("N04",   "PARKİNSON İLACI", "Parkinson hastalığı ilacı."),
    ("N05AH", "ANTİPSİKOTİK", "Atipik antipsikotik."),
    ("N05A",  "ANTİPSİKOTİK", "Antipsikotik."),
    ("N05BA", "ANKSİYOLİTİK", "Benzodiazepin grubu anksiyolitik."),
    ("N05B",  "ANKSİYOLİTİK", "Anksiyolitik / sakinleştirici."),
    ("N05C",  "UYKU İLACI", "Uyku ilacı."),
    ("N06AB", "ANTİDEPRESAN", "SSRI grubu antidepresan."),
    ("N06AX", "ANTİDEPRESAN", "Diğer antidepresan (SNRI vb.)."),
    ("N06A",  "ANTİDEPRESAN", "Antidepresan."),
    ("N06B",  "DEHB İLACI", "Dikkat eksikliği / uyanıklık ilacı."),
    ("N06D",  "ALZHEİMER İLACI", "Demans / Alzheimer ilacı."),
    ("N07",   "NÖROLOJİ İLACI", "Sinir sistemi ilacı."),

    # === A: Sindirim sistemi ===
    ("A02BC", "MİDE İLACI", "Proton pompası inhibitörü (PPI)."),
    ("A02BA", "MİDE İLACI", "H2 reseptör blokeri."),
    ("A02BX", "MİDE İLACI (REFLÜ)", "Reflü / mide yanması ilacı."),
    ("A02B",  "MİDE İLACI", "Mide asidi azaltıcı."),
    ("A02A",  "MİDE İLACI (ANTİASİT)", "Antiasit / mide koruyucu."),
    ("A03AX", "KARIN GAZI İLACI", "Gaz giderici / sindirim sistemi."),
    ("A03B",  "KARIN AĞRISI / KASILMA İLACI", "Karın krampı / antispazmodik."),
    ("A03F",  "BULANTI KESİCİ", "Mide hareket düzenleyici / bulantı kesici."),
    ("A04",   "BULANTI KESİCİ", "Bulantı / kusma kesici."),
    ("A06",   "KABIZLIK İLACI", "Kabızlık ilacı / laksatif."),
    # A07AA02 nistatin (Mikostatin/Fungostatin/Niosta) MANTAR ilacıdır
    # (pamukçuk) — "ishal ilacı" yanlıştı. Diğer A07AA'lar (rifaksimin
    # Colidur/Normix, fidaksomisin Dificlir) bağırsak antibiyotiğidir.
    ("A07AA02", "MANTAR İLACI (PAMUKÇUK)", "Ağız içi/bağırsak mantar tedavisi (nistatin)."),
    ("A07AA", "BAĞIRSAK ANTİBİYOTİĞİ", "Bağırsakta etkili antibiyotik."),
    # A07FA probiyotikler (Biogaia/Reflor/Enterogermina...) — hastaya "ishal
    # ilacı" değil bilinen adıyla "probiyotik" denir.
    ("A07FA", "PROBİYOTİK", "Probiyotik (yararlı bağırsak bakterisi)."),
    ("A07",   "İSHAL / BAĞIRSAK", "İshal kesici / bağırsak ilacı."),
    ("A09",   "SİNDİRİM ENZİMİ", "Sindirim enzimi."),
    ("A10A",  "İNSÜLİN", "İnsülin preparatı."),
    ("A10B",  "ŞEKER HASTALIĞI İLACI", "Oral şeker hastalığı ilacı."),
    ("A11C",  "D VİTAMİNİ", "D vitamini preparatı."),
    ("A11D",  "B VİTAMİNİ DESTEĞİ", "B kompleks vitamini desteği."),
    ("A11",   "VİTAMİN", "Vitamin preparatı."),
    ("A12C",  "MİNERAL DESTEĞİ", "Mineral / iz element desteği."),
    ("A12A",  "KALSİYUM DESTEĞİ", "Kalsiyum desteği."),
    ("A12B",  "POTASYUM DESTEĞİ", "Potasyum desteği."),
    ("A01",   "AĞIZ-DİŞ İLACI", "Ağız ve diş bakım preparatı."),
    ("A05",   "KARACİĞER İLACI", "Karaciğer / safra yolları ilacı."),
    ("A08",   "ZAYIFLAMA İLACI", "Kilo verme yardımcı ilacı."),

    # === C: Kalp-damar ===
    # Trimetazidin (Vastarel) ve nitratlar (Monoket/İsordil/Nitroderm)
    # antiANGİNALdir, ritim ilacı değil — "KALP RİTM İLACI" yanlıştı.
    ("C01EB15", "GÖĞÜS AĞRISI (ANGİNA) İLACI", "Kalp kası enerji metabolizması düzenleyici (trimetazidin)."),
    ("C01DA",   "GÖĞÜS AĞRISI (ANGİNA) İLACI", "Nitrat — kalp damarlarını genişletir."),
    ("C01",   "KALP RİTM İLACI", "Kalp ritm bozukluğu / kalp ilacı."),
    ("C02",   "TANSİYON İLACI", "Tansiyon düşürücü."),
    ("C03",   "DİÜRETİK", "İdrar söktürücü (diüretik)."),
    ("C07A",  "TANSİYON İLACI", "Beta-bloker (tansiyon / kalp)."),
    ("C07",   "TANSİYON İLACI", "Beta-bloker."),
    ("C08",   "TANSİYON İLACI", "Kalsiyum kanal blokeri (tansiyon)."),
    ("C09AA", "TANSİYON İLACI", "ACE inhibitörü (tansiyon)."),
    ("C09BA", "TANSİYON İLACI", "ACE inhibitörü + diüretik kombinasyonu."),
    ("C09BB", "TANSİYON İLACI", "ACE inhibitörü + kalsiyum kanal blokeri."),
    ("C09CA", "TANSİYON İLACI", "Anjiyotensin reseptör blokeri (ARB)."),
    ("C09DA", "TANSİYON İLACI", "ARB + diüretik kombinasyonu."),
    ("C09DB", "TANSİYON İLACI", "ARB + kalsiyum kanal blokeri."),
    ("C09",   "TANSİYON İLACI", "Tansiyon ilacı."),
    ("C10AA", "KOLESTEROL İLACI", "Statin (kolesterol düşürücü)."),
    ("C10",   "KOLESTEROL İLACI", "Kan yağı düşürücü."),
    ("C04",   "VARİS / DOLAŞIM İLACI", "Periferik damar genişletici."),
    # C05BA topikal heparinoid (Hirudoid/Hironil jel-krem): hemoroid DEĞİL —
    # künt travma (vuruk/ezik), hematom (morluk), şişlik, yüzeysel flebit.
    # C05BX (Doxium) ve C05BB (skleroterapi) genel C05 metninde kalır.
    ("C05BA", "VURUK / MORLUK / ŞİŞLİK İLACI", "Künt travma, morluk (hematom), şişlik, yüzeysel flebit."),
    # C05A topikal hemoroid/anal fissür preparatları (Proctoglyvenol, Kortos,
    # Proctolog, Anrecta...): varis İLE İLGİSİ YOK — makata uygulanır.
    ("C05A",  "HEMOROİD İLACI", "Hemoroid (basur) ilacı — makat bölgesine uygulanır."),
    ("C05",   "VARİS / HEMOROİD İLACI", "Damar koruyucu / hemoroid ilacı."),

    # === B: Kan ===
    ("B01AC", "KAN SULANDIRICI", "Antiplatelet kan sulandırıcı."),
    ("B01AB", "KAN SULANDIRICI (İĞNE)", "Heparin grubu kan sulandırıcı."),
    ("B01AA", "KAN SULANDIRICI", "Varfarin grubu oral antikoagülan."),
    ("B01AF", "KAN SULANDIRICI", "Yeni nesil oral antikoagülan."),
    ("B01AE", "KAN SULANDIRICI", "Trombin inhibitörü antikoagülan."),
    ("B01",   "KAN SULANDIRICI", "Antitrombotik."),
    ("B02",   "KANAMA DURDURUCU", "Hemostatik (kanama durdurucu)."),
    ("B03",   "ANEMİ TEDAVİSİ", "Demir / B12 / folik asit / EPO."),
    # B05D periton diyalizi / B05Z hemodiyaliz konsantresi — "İV SOLÜSYON"
    # yanlış ve tehlikeli (damar içine de verilmez, içilmez de).
    ("B05D",  "PERİTON DİYALİZ SOLÜSYONU", "Periton (karın) diyalizi çözeltisi."),
    ("B05Z",  "DİYALİZ SOLÜSYONU", "Hemodiyaliz/hemofiltrasyon çözeltisi."),
    ("B05",   "İV SOLÜSYON", "Damar içi infüzyon solüsyonu."),

    # === D: Cilt (dermatolojik) ===
    ("D01AC", "MANTAR İLACI (DIŞ KULLANIM)", "Antimantar cilt preparatı."),
    ("D01A",  "MANTAR İLACI (DIŞ KULLANIM)", "Antimantar cilt preparatı."),
    ("D02AE", "CİLT NEMLENDİRİCİ", "Üreli cilt nemlendirici."),
    ("D02",   "CİLT NEMLENDİRİCİ", "Cilt bakım / nemlendirici."),
    ("D03AX", "YARA İYİLEŞTİRİCİ", "Yara iyileştirici cilt preparatı."),
    ("D03",   "YARA İYİLEŞTİRİCİ", "Yara iyileştirici."),
    ("D04A",  "KAŞINTI / CİLT İLACI", "Cilt kaşıntı giderici / lokal anestezik."),
    ("D05A",  "SEDEF İLACI", "Sedef hastalığı (psoriasis) ilacı."),
    ("D06A",  "CİLT ANTİBİYOTİĞİ", "Dış kullanım için cilt antibiyotiği."),
    ("D06B",  "ANTİVİRAL / ANTİSEPTİK (CİLT)", "Cilt antiviral / antiseptik."),
    ("D07A",  "CİLT KORTİZONU", "Dış kullanım için cilt kortizonu."),
    ("D08",   "ANTİSEPTİK", "Cilt antiseptiği."),
    ("D10",   "SİVİLCE İLACI", "Sivilce (akne) tedavisi."),
    # Hidrokinon (Expigment) — "cilt bakım ürünü" değil leke tedavisi ilacıdır.
    ("D11AX11", "CİLT LEKE AÇICI", "Koyu lekeleri açan (hidrokinon) krem."),
    ("D11AX", "CİLT BAKIM ÜRÜNÜ", "Cilt bakım / koruyucu preparat."),
    ("D11",   "CİLT İLACI", "Diğer dermatolojik preparat."),

    # === G: Ürogenital + hormon ===
    # Vajinal MANTAR (antifungal) ovül/krem: azol türevleri (klotrimazol/mikonazol/
    # ketokonazol/fentikonazol... ve MIXOVUL/Neo-Penotran gibi imidazol kombinleri),
    # natamisin (G01AA02), siklopiroks (G01AX12). HASTAYA "mantar ilacı" denir.
    # DİKKAT: G01AF06 = ornidazol bir nitroimidazoldür — antifungal DEĞİL, vajinal
    # antibakteriyel/antiprotozoaldir (Biteral/Ornisid); MANTAR kapsamından çıkarılır.
    ("G01AF06", "KADIN HASTALIKLARI", "Vajinal antibakteriyel/antiprotozoal (ornidazol)."),
    ("G01AF",   "MANTAR İLACI", "Vajinal mantar (antifungal) ovül/krem/tablet."),
    ("G01AA02", "MANTAR İLACI", "Vajinal mantar ilacı (natamisin)."),
    ("G01AX12", "MANTAR İLACI", "Vajinal mantar ilacı (siklopiroks)."),
    ("G01",   "KADIN HASTALIKLARI", "Vajinal preparat."),
    ("G02",   "KADIN DOĞUM İLACI", "Jinekoloji preparatı."),
    ("G03A",  "DOĞUM KONTROL", "Doğum kontrol hapı."),
    ("G03",   "HORMON", "Cinsiyet hormonu preparatı."),
    # G04BE erektil disfonksiyon (sildenafil/tadalafil/vardenafil/alprostadil) —
    # "ÜROLOJİ İLACI" hastaya hiçbir şey anlatmıyor; halk diliyle adlandırılır.
    ("G04BE", "EREKSİYON (SERTLEŞME) İLACI", "Sertleşme sorunu (ereksiyon) ilacı."),
    ("G04",   "ÜROLOJİ İLACI", "Üroloji ilacı (prostat / mesane)."),

    # === H: Sistemik hormon ===
    ("H01",   "HORMON (HİPOFİZ)", "Hipofiz hormon preparatı."),
    ("H02AB", "KORTİZON TEDAVİSİ", "Sistemik kortizon."),
    ("H02",   "KORTİZON TEDAVİSİ", "Sistemik kortizon."),
    ("H03AA", "GUATR İLACI", "Tiroid hormonu (levotiroksin)."),
    ("H03",   "GUATR İLACI", "Tiroid ilacı."),
    ("H04",   "GLUKAGON", "Pankreas hormonu."),
    ("H05",   "PARATİROİD / KEMİK", "Kalsiyum-paratiroid metabolizması."),

    # === L: Antineoplastik / immün ===
    ("L01",   "KANSER İLACI", "Kanser kemoterapi ilacı."),
    ("L02",   "HORMON TEDAVİSİ", "Endokrin kanser tedavisi."),
    ("L03",   "BAĞIŞIKLIK SİSTEMİ İLACI", "Bağışıklık modülatörü."),
    ("L04",   "İMMÜNOSUPRESİF", "Bağışıklık baskılayıcı."),

    # === P: Antiparazitik ===
    # P01AB nitroimidazoller (metronidazol/ornidazol/seknidazol) pratikte
    # anaerob enfeksiyon antibiyotiğidir — hastaya "parazit ilacı" denmez.
    ("P01AB", "ANTİBİYOTİK", "Anaerob/parazit antibiyotiği (metronidazol grubu)."),
    # Hidroksiklorokin pratikte romatizma/lupus, klorokin sıtma ilacıdır.
    ("P01BA02", "ROMATİZMA / İLTİHAP İLACI", "Romatizma / lupus tedavisi (hidroksiklorokin)."),
    ("P01BA01", "SITMA İLACI", "Sıtma tedavisi (klorokin)."),
    ("P01",   "PARAZİT İLACI", "Bağırsak parazit tedavisi."),
    ("P02",   "BAĞIRSAK PARAZİTİ", "Solucan / bağırsak parazit ilacı."),
    ("P03AC", "BİT / UYUZ İLACI", "Bit / uyuz tedavisi."),
    ("P03",   "BİT / UYUZ İLACI", "Bit / uyuz tedavisi."),

    # === R: Solunum ===
    ("R01AA", "BURUN AÇICI", "Lokal burun açıcı (kısa etkili)."),
    ("R01AD", "BURUN İLACI (KORTİZON)", "Burun kortikosteroidi."),
    ("R01A",  "BURUN İLACI", "Lokal burun preparatı."),
    ("R02",   "BOĞAZ İLACI", "Boğaz preparatı (sprey / pastil)."),
    ("R03AC", "ASTIM İLACI (BRONŞ AÇICI)", "Beta-2 agonisti (inhaler)."),
    ("R03AK", "ASTIM İLACI", "Beta-2 agonisti + kortikosteroid (inhaler)."),
    ("R03BA", "ASTIM İLACI (KORTİZON)", "İnhale kortikosteroid."),
    ("R03BB", "ASTIM İLACI", "Antikolinerjik bronş açıcı (inhaler)."),
    ("R03DC", "ASTIM/ALLERJİ İLACI", "Lökotrien antagonisti (montelukast)."),
    ("R03",   "ASTIM İLACI", "Astım / KOAH ilacı."),
    ("R05CB", "BALGAM SÖKÜCÜ", "Mukolitik (balgam sökücü)."),
    ("R05DB", "ÖKSÜRÜK KESİCİ", "Periferik öksürük kesici."),
    ("R05DA", "ÖKSÜRÜK KESİCİ", "Opioid türevi öksürük kesici."),
    ("R05X",  "GRİP / SOĞUK ALGINLIĞINDA", "Soğuk algınlığı kombinasyonu."),
    ("R05",   "ÖKSÜRÜK / SOĞUK ALGINLIĞI", "Öksürük / soğuk algınlığı ilacı."),
    ("R06A",  "ALLERJİ / KAŞINTI İLACI", "Antihistaminik (allerji)."),
    ("R07",   "SOLUNUM İLACI", "Solunum sistemi ilacı."),

    # === S: Duyu organları ===
    ("S01AA", "GÖZ İLACI (ANTİBİYOTİK)", "Göz antibiyotiği."),
    ("S01A",  "GÖZ İLACI (ANTİ-İNFEKTİF)", "Göz anti-infektif preparat."),
    ("S01B",  "GÖZ İLACI (KORTİZON)", "Göz kortikosteroidi."),
    ("S01E",  "GLOKOM İLACI", "Glokom (göz tansiyonu) ilacı."),
    ("S01XA", "KURU GÖZ İLACI", "Yapay göz yaşı / kuru göz tedavisi."),
    ("S01X",  "GÖZ İLACI", "Diğer göz preparatı."),
    ("S01",   "GÖZ İLACI", "Göz ilacı."),
    ("S02",   "KULAK İLACI", "Kulak preparatı."),

    # === V: Çeşitli ===
    ("V03",   "ANTİDOT / DESTEK", "Antidot / detoksifikasyon."),
    ("V06",   "BESLENME ÜRÜNÜ", "Beslenme desteği / klinik nütrisyon."),
    ("V07",   "TEKNİK YARDIMCI", "Teknik tıbbi yardımcı."),
    ("V08",   "RADYOLOJİK KONTRAST", "Radyolojik kontrast madde."),

    # === Ana grup fallback'leri ===
    ("J",     "ANTİ-İNFEKTİF", "Enfeksiyon tedavisi."),
    ("M",     "KAS-İSKELET İLACI", "Kas-iskelet sistemi ilacı."),
    # N01B lokal anestezikler (Vemcaine/Emla/Jetokain/Marcaine...) — jenerik
    # "SİNİR SİSTEMİ İLACI" hastaya bilgi vermiyor. Kapsaisin (N01BX04)
    # anestezik değil haricî ağrı kremidir, ayrı tutulur.
    ("N01BX04", "AĞRI KESİCİ (HARİCİ)", "Kapsaisinli haricî ağrı kremi."),
    ("N01B",  "LOKAL ANESTEZİK", "Bölgesel uyuşturma (lokal anestezi) ilacı."),
    # Flunarizin (Sibelium) — migren profilaksisi + vertigo; "nöroloji ilacı"
    # hastaya bilgi vermiyor.
    ("N07CA03", "MİGREN ÖNLEYİCİ / VERTİGO İLACI", "Migren koruyucusu / baş dönmesi (flunarizin)."),
    ("N",     "SİNİR SİSTEMİ İLACI", "Sinir sistemi ilacı."),
    ("A",     "SİNDİRİM SİSTEMİ İLACI", "Sindirim sistemi / metabolizma ilacı."),
    ("C",     "KALP-DAMAR İLACI", "Kalp-damar sistemi ilacı."),
    ("B",     "KAN İLACI", "Kan ile ilgili ilaç."),
    ("D",     "CİLT İLACI", "Dış kullanım için cilt preparatı."),
    ("G",     "ÜROGENİTAL / HORMON", "Ürogenital / cinsiyet hormonu."),
    ("H",     "HORMON", "Sistemik hormon preparatı."),
    ("L",     "KANSER / İMMÜN İLACI", "Antineoplastik / immün modülatör."),
    ("P",     "PARAZİT / BÖCEK İLACI", "Antiparazitik."),
    ("R",     "SOLUNUM İLACI", "Solunum sistemi ilacı."),
    ("S",     "GÖZ-KULAK İLACI", "Duyu organları ilacı."),
    ("V",     "ÇEŞİTLİ", "Çeşitli ilaç."),
]


def _category_for(atc_code: str) -> tuple[str, str]:
    """ATC kodundan en spesifik kategori eşleşmesini bulur. (short, long)"""
    code = (atc_code or "").upper()
    for prefix, short, long_ in ATC_PREFIX_CATEGORIES:
        if code.startswith(prefix):
            return short, long_
    return "İLAÇ", "İlaç preparatı."


def generate_indication(atc_code: str, atc_name: str) -> tuple[str, str]:
    """ATC kodu + atc_name → (kısa CAPS başlık, uzun hasta-dili açıklama).

    Mantık:
      1. atc_name'in lowercase hali ACTIVE_INGREDIENT_TR'da varsa → spesifik Türkçe
         etken madde + açıklamayı kullan.
      2. Yoksa ATC kodu prefix'inden kategoriyi çıkar.
      3. Kısa form: kategori CAPS.
      4. Uzun form: "<Türkçe etken madde>. <kategori açıklaması>"
    """
    cat_short, cat_long = _category_for(atc_code)

    if atc_name:
        key = atc_name.strip().lower()
        if key in ACTIVE_INGREDIENT_TR:
            tr_name, tr_desc = ACTIVE_INGREDIENT_TR[key]
            # İlk harfi büyüt — .capitalize() Türkçe İ harfini bozar
            tr_desc_cap = tr_desc[:1].upper() + tr_desc[1:] if tr_desc else tr_desc
            long_text = f"Etken madde: {tr_name}. {tr_desc_cap}."
            return cat_short, long_text

    # Spesifik etken madde tanınmadıysa: ATC adını sade olarak ek
    if atc_name:
        long_text = f"Etken madde: {atc_name}. {cat_long}"
    else:
        long_text = cat_long
    return cat_short, long_text
