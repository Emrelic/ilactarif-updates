"""ilaçtarif — İlaç kullanım talimatı etiketi üreten ve basan uygulama."""

__version__ = "1.0"
