"""E-reçete yakalama → etiket görsellerine dönüştürme (ortak modül).

CLI watcher (`scripts/watch_medula.py`) ve GUI (`manual_label_ui.py`) bu
modülü kullanır. Geriye yakalanan her ilaç için PNG dosya yolları ve meta
bilgi (DB eşleşmesi, etiket label objeleri) döner.
"""
from __future__ import annotations

import datetime
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .db import (
    get_connection,
    init_schema,
    lookup_recete_hasta,
    save_recete_hasta,
)
from .drug_guess import (
    build_kullanim_talimati,
    format_dose_amount,
    guess_form,
    guess_kategori,
    guess_unit,
    is_eye_ear_drop_name,
    is_topical_surulen,
    medula_dose_display,
    talimat_route_conflict,
)
from .label_render import (
    render_glucose_guide_label,
    render_preparation_label,
    render_usage_label,
    render_warning_label,
)
from .label_from_db import (
    _MEAL_BADGE_MAP,
    _anthelmintic_repeat_oneri,
    _atc_oneri_satiri,
    _bonus_oneri_satiri,
    _critical_badge_for_atc,
    _cycle_start_oneri,
    _fetch_block,
    _instruction_line,
    _is_throat_spray,
    _is_topical_spray,
    _topical_spray_puf_doz,
    _TOPICAL_SURULEN_FORMS,
    _topical_surulen_kez_doz,
    _is_puff_inhaler,
    _drop_damla_doz,
    is_diluted_gargara,
    _dialysis_a_overrides,
    _dialysis_kind,
    _nail_a_overrides,
    _nail_kind,
    _parasite_a_overrides,
    _parasite_kind,
    _is_scar_gel,
    _wart_a_overrides,
    _wart_kind,
    _progesterone_route_override,
    _sedating_antihistamine_oneri,
    _simple_storage_badge,
    cold_chain_badge,
    _spray_fis_doz,
    _technique_line,
    _topical_derm_instruction,
    DEVICE_LABEL_CONTENT,
    GLUCOSE_GUIDE_CAVEATS,
    GLUCOSE_GUIDE_STEPS,
    GLUCOSE_GUIDE_TITLE,
    GUIDE_DEVICE_KINDS,
    build_label_plan,
    classify_medical_device,
)
from .medula_parser import PrescriptionCapture
from .models import PreparationLabel, UsageLabel, WarningLabel


@dataclass
class LabelItem:
    drug_ad: str
    barkod: str
    db_matched: bool
    p1: Path                 # kullanım etiketi (zorunlu)
    p2: Optional[Path]       # hazırlama / kullanım tekniği (varsa)
    p3: Optional[Path]       # ciddi uyarı (varsa)
    p4: Optional[Path] = None  # astım/inhaler — dikkat edilecek hususlar (varsa)
    drug_id: Optional[int] = None      # DB eşleşmesi (kalıcı baskı tercihi için)
    # Her etiket tipinin baskı kutusu VARSAYILAN durumu: kind ('A'/'B'/'C'/'D') → bool.
    # A=kullanım (her zaman True), B=hazırlama, C=ciddi uyarı (şiddete göre), D=dikkat.
    # Kullanıcının sağ-tık ile koyduğu kalıcı 'işaretsiz' tercihi UI'da ayrıca uygulanır.
    label_default_print: dict = field(default_factory=dict)
    # --- Canlı doz/zaman düzenleme (kullanım etiketi p1) için ---
    # usage doluysa UI'da etiket altındaki "Doz/Zaman" düzenleyici p1'i yeniden
    # üretebilir. render_ctx render_usage_label'ın diğer argümanlarını taşır.
    # Cihaz/glukoz-kılavuzu etiketlerinde usage None'dır (düzenleme kapalı).
    usage: Optional["UsageLabel"] = None
    render_ctx: Optional[dict] = None
    doz_adet: Optional[float] = None   # düzenlenebilir doz adedi (NxM'deki M)
    doz_birim: str = ""                # "tane" / "kez" / "ölçek" ...
    geri_odeme_yok: bool = False       # SGK ödemez (reçete başında yine basılır)
    kutu_adet: Optional[int] = None   # Reçetedeki kutu/paket adedi (sağ alt köşe)
    stok: Optional[int] = None        # Kayıt sonrası eczane stoğu (Stk/Raf); eksiyse
                                       # elde o kadar ilaç yok demektir (baskı kararı)


@dataclass
class BuiltRecete:
    recete_no: str
    hasta_ad: str
    hasta_tc: str
    recete_tarihi: str
    dr_ad: str
    items: list[LabelItem]


def _adet_to_int(s: str) -> Optional[int]:
    try:
        return int((s or "").strip())
    except Exception:
        return None


def _lookup_db_drug(conn, barkod: str, ad: str):
    if barkod:
        row = conn.execute(
            "SELECT * FROM drugs WHERE barcode = ?", (barkod,)
        ).fetchone()
        if row:
            return row
    first_word = (ad or "").split(" ")[0]
    if not first_word:
        return None
    return conn.execute(
        "SELECT * FROM drugs WHERE name LIKE ? ORDER BY sales_count DESC LIMIT 1",
        (f"{first_word}%",),
    ).fetchone()


def _db_label(conn, drug_id: int, label_type: int):
    row = conn.execute(
        "SELECT content_json FROM drug_labels WHERE drug_id=? AND label_type=?",
        (drug_id, label_type),
    ).fetchone()
    if not row:
        return None
    try:
        return json.loads(row["content_json"])
    except Exception:
        return None


def _enrich_usage_from_db(usage: UsageLabel, db_row, conn,
                          parenteral_route_mode: str = "") -> None:
    """Reçeteden üretilmiş UsageLabel'i DB'nin yapısal kolonları + bloklarıyla zenginleştirir.

    Reçeteden gelen GERÇEK doz ve sıklık (usage.doz / usage.gunluk_kez) KORUNUR;
    DB yalnızca form bazlı talimat, kategori, öğün/saklama rozeti ve kullanım zamanı
    gibi alanları doldurur. Yapısal kolon boşsa ilgili alan dokunulmadan kalır.
    """
    try:
        form = db_row["form"] or ""
    except (IndexError, KeyError):
        form = ""
    atc = None
    try:
        atc = db_row["atc_code"]
    except (IndexError, KeyError):
        atc = None

    # Kategori ← indication_short (DB'de varsa tahminin yerine geçer)
    try:
        ind = (db_row["indication_short"] or "").strip()
    except (IndexError, KeyError):
        ind = ""
    if ind:
        usage.kategori = ind.upper()

    try:
        name_u = (db_row["name"] or "").upper()
    except (IndexError, KeyError):
        name_u = ""

    # Form bazlı sağ-sütun talimat + teknik notu
    ti = _instruction_line(form, name_u)
    if ti:
        usage.talimat_satiri = ti
    # Topikal dermatolojik (cilt/saç/tırnak) → içilir/buruna DEĞİL; bölgeye sürülür.
    # (Oceral çözelti, Exoderil dermal sprey, tırnak solüsyonu vb. düzeltir.)
    try:
        _route = db_row["route"] or ""
    except (IndexError, KeyError):
        _route = ""
    _td = _topical_derm_instruction(atc, name_u, _route, ind)
    if _td:
        usage.talimat_satiri = _td
    # Ağız/boğaz spreyi → buruna DEĞİL, boğaza sıkılır; kategori "boğaz spreyi".
    if _is_throat_spray(atc, name_u):
        usage.talimat_satiri = "AĞIZ İÇİNDEN BOĞAZA SIKINIZ"
        usage.kategori = "BOĞAZ / AĞIZ-DİŞ İLACI"
    tk = _technique_line(form, name_u, atc)
    if tk:
        usage.teknik_satiri = tk
    # Hem göze HEM kulağa uygulanan damlalar (örn. Onadron Simple GÖZ/KULAK) →
    # form 'göz' veya 'kulak'tan birine sabitlendiğinden ada bakıp düzeltiriz.
    if is_eye_ear_drop_name(name_u):
        usage.talimat_satiri = "GÖZE VEYA KULAĞA DAMLATINIZ"
    # Ereksiyon ilaçları (G04BE) yol düzeltmeleri (DB akışıyla aynı):
    # alprostadil enjeksiyonu kavernöz içine ("KAS İÇİNE" yanlış); sildenafil
    # oral jel saşesi yutulur ("AĞIZ İÇİNE SÜRÜNÜZ" yanıltıcı).
    _atc_g = (atc or "").upper()
    if _atc_g.startswith("G04BE01") and form.startswith("injection"):
        usage.talimat_satiri = "DOKTORUNUZUN ÖĞRETTİĞİ ŞEKİLDE PENİS İÇİNE UYGULANIR"
    elif _atc_g.startswith("G04BE") and "FILM" in name_u.replace("İ", "I") and (
            "DAGILAN" in name_u or "DAĞILAN" in name_u):
        # Ağızda dağılan film (Icarus): suda çözülmez, dil üstünde eritilir.
        usage.talimat_satiri = "FİLMİ DİLİNİZİN ÜZERİNE KOYUN, ERİYİNCE YUTKUNUN"
    elif _atc_g.startswith("G04BE") and ("SAŞE" in name_u or "SASE" in name_u):
        usage.talimat_satiri = "SAŞE İÇERİĞİNİ AĞZINIZA BOŞALTIP YUTUNUZ"

    # Öğün ilişkisi → yemek + ters renkli rozet (TOK/AÇ)
    try:
        meal_rel = (db_row["meal_relation"] or "").strip()
    except (IndexError, KeyError):
        meal_rel = ""
    # İnsülin (ATC A10A*) cilt altına uygulanır; aç/tok rozeti anlamsız.
    try:
        if (db_row["atc_code"] or "").upper().startswith("A10A"):
            meal_rel = ""
            if not usage.teknik_satiri:
                usage.teknik_satiri = "GÖBEK ÇEVRESİNİN 5 CM UZAĞINA UYGULAYIN"
    except (IndexError, KeyError):
        pass
    # "AÇ TOK FARKETMEZ" rozeti bilgi taşımıyor; geniş kutu sağ sütunu kısaltıp
    # kritik öneri satırını kırpıyor → öneri taşıyan sınıflarda bastırılır
    # (G04BE kalp uyarısı, C10AA/C10BA statin gece önerisi). Reçeteden gelmiş
    # "fark etmez" değeri de temizlenir (render rozeti usage.yemek'ten türetir).
    if (atc or "").upper().startswith(("G04BE", "C10AA", "C10BA", "M03BX02", "N02CC", "N02CA", "N07CA03")):
        if meal_rel.strip().lower() == "fark etmez":
            meal_rel = ""
        if (usage.yemek or "").strip().lower() == "fark etmez":
            usage.yemek = ""
        if (usage.meal_badge or "").strip().upper() == "AÇ TOK FARKETMEZ":
            usage.meal_badge = ""
    if meal_rel:
        if not usage.yemek:
            usage.yemek = meal_rel
        mb = _MEAL_BADGE_MAP.get(meal_rel.lower(), "")
        if mb and not usage.meal_badge:
            usage.meal_badge = mb

    # Saklama rozeti (soğuk zincir vb.) ← saklama bloğu
    try:
        sak = _fetch_block(conn, db_row["id"], "saklama")
    except Exception:
        sak = ""
    sb = _simple_storage_badge(sak, form)
    if sb and not usage.saklama_badge:
        usage.saklama_badge = sb
    # Soğuk zincir ATC/form fallback: saklama bloğu yoksa/soğuk demiyorsa, ilacın
    # ATC grubuna göre buzdolabı rozetini üret (insülin, aşı, biyolojikler,
    # immünoglobulinler, gonadotropinler, sulandırılan antibiyotik süspansiyonları).
    if not usage.saklama_badge:
        ccb = cold_chain_badge(atc, form, name_u)
        if ccb:
            usage.saklama_badge = ccb

    # Kullanım zamanı önerisi (sağ sütun): günde 1 alınan ilaçta ATC tercih saati
    # (örn. statin → akşam) sol dozaj ızgarasına değil, sağa metin olarak yazılır.
    if not usage.oneri_satiri:
        os_ = _atc_oneri_satiri(atc, usage.gunluk_kez, form, name_u)
        if os_:
            usage.oneri_satiri = os_

    atc_u = (atc or "").upper()
    # Antidepresanlar (N06A) — etkisi gecikmeli başlar (uyum için kritik). Canlı
    # Medula akışında da göster (DB akışındaki _build_usage_label ile aynı bilgi).
    if atc_u.startswith("N06A"):
        usage.oneri_satiri = "ETKİSİ 2-3 HAFTADA BAŞLAR"
    # Ereksiyon ilaçları (G04BE) — kalp ilacı kullanan hasta İÇMEMELİ,
    # önce doktora sormalı. DB akışındaki _build_usage_label ile aynı bilgi.
    elif atc_u.startswith("G04BE"):
        usage.oneri_satiri = "KALP İLACI KULLANIYORSANIZ KULLANMAYIN, DOKTORUNUZA DANIŞIN"
    # Oftalmik siklosporin (Restasis/Depores) — etki aylar içinde birikir.
    elif atc_u.startswith("S01XA18"):
        usage.oneri_satiri = "ETKİSİ 3-6 AYDA YAVAŞ YAVAŞ ÇIKAR — DÜZENLİ, DİSİPLİNLİ KULLANIN"
    # Hidrokinon leke kremi (Expigment) — güneş açılan lekeyi geri koyulaştırır.
    elif atc_u.startswith("D11AX11"):
        usage.oneri_satiri = "GÜNEŞTEN KORUNUN — GÜNDÜZ GÜNEŞ KORUYUCU KULLANIN"
    # Triptanlar (N02CC) — ATAK ilacı: ağrı başlar başlamaz; koruyucu değil.
    elif atc_u.startswith("N02CC"):
        usage.oneri_satiri = "AĞRI BAŞLAR BAŞLAMAZ ALIN — KORUYUCU İLAÇ DEĞİLDİR"
    # Ergotaminli kombinasyonlar (N02CA: Avmigran/Cafergot) — krizin ilk belirtisinde.
    elif atc_u.startswith("N02CA"):
        usage.oneri_satiri = "KRİZİN İLK BELİRTİSİNDE ALIN — DOZ SINIRINI AŞMAYIN"
    # Oral demir. İki türü vardır ve öğün ilişkisi ZIT:
    #   • Demir-III hidroksit polimaltoz kompleksi (B03AB ve polimaltoz kombinleri,
    #     ör. Ferifer/Maltofer/Santafer Fort) → besinler emilimini ETKİLEMEZ;
    #     mide toleransı için YEMEKLE/yemekten hemen sonra alınır → TOK.
    #   • İki-değerli Fe²⁺ tuzları (ferro sülfat/glisin sülfat, B03AA ve ferro
    #     kombinleri) → AÇ karnına en iyi emilir; süt/çay azaltır, C vit. artırır.
    # Hangisi olduğunu B03AB (kesin polimaltoz) + DB öğün ilişkisi belirler; bu
    # sayede polimaltoz B03AD (Santafer/Maltofer Fol) yanlışlıkla aç olmaz.
    elif atc_u.startswith("B03A") and "ENJ" not in name_u and "AMPUL" not in name_u:
        _is_poly = atc_u.startswith("B03AB")
        _meal_tok = (usage.meal_badge == "TOK") or (usage.yemek or "").strip().lower() == "tok"
        if _is_poly or _meal_tok:
            usage.oneri_satiri = "YEMEKLE VEYA YEMEKTEN HEMEN SONRA"
            usage.teknik_satiri = ""
            usage.meal_badge = "TOK"
            usage.yemek = "tok"
        else:
            usage.oneri_satiri = "AÇ KARNINA — YEMEKTEN 1 SAAT ÖNCE"
            # "C VİTAMİNİ İLE ALMAK EMİLİMİ ARTIRIR" sağ kolonda (rmax≈286) 2 satıra
            # sarıp 3. teknik satırını dikey sınıra kırptırıyordu; "İLE ALMAK" örtük
            # olduğundan çıkarıldı → tek satır, tam sığar (anahtar "EMİLİMİ ARTIRIR" korunur).
            usage.teknik_satiri = "ÇAY VE SÜTLE ALMAYINIZ\nC VİTAMİNİ EMİLİMİ ARTIRIR"
            if not usage.meal_badge:
                usage.meal_badge = "AÇ"
            usage.yemek = "aç"
    # Tetrasiklinler (J01AA: doksisiklin Monodoks/Tetradox) — yemek borusu tahrişi:
    # bol su ile DİK durarak alınır, içtikten sonra yatılmaz. (Güneş hassasiyeti
    # ayrıca "GÜNEŞTEN KORUN" rozetiyle verilir.)
    elif atc_u.startswith("J01AA"):
        usage.oneri_satiri = "İÇTİKTEN SONRA 1 SAAT DİK OTURUN, YATMAYIN"
    # Diğer antibiyotikler (J01) — belirtiler geçse de kür tamamlanmalı (direnç/
    # nüks). Tetrasiklin (J01AA) üstteki daha kritik "dik oturun" ibaresini korur.
    elif atc_u.startswith("J01"):
        usage.oneri_satiri = "BİTİRENE KADAR DÜZENLİ KULLANINIZ"
    # Montelukast + antihistaminik kombinleri (R03DC53: Desmont/Levmont) → gece.
    elif atc_u.startswith("R03DC53"):
        usage.oneri_satiri = "TERCİHEN GECE YATMADAN ÖNCE KULLANINIZ"
    # Bağırsak antiparaziterleri (P02C: albendazol/pirantel/pirvinyum/piperazin/
    # levamizol/ivermektin) — yumurtadan çıkan solucanlar için 2. doz/kür gerekebilir.
    # DB akışındaki _build_usage_label ile aynı bilgi.
    elif _rep := _anthelmintic_repeat_oneri(atc, name_u):
        usage.oneri_satiri = _rep
    # Menstrüel döngüye bağlı başlangıç: doğum kontrol hapı (adetin 1. günü +
    # 21+7 ara / aralıksız 28 şeması), ertesi gün hapı (en kısa sürede),
    # klomifen (adetin 2-5. günü). Ayrıntı: label_from_db._cycle_start_oneri.
    elif _cyc := _cycle_start_oneri(atc, name_u):
        usage.oneri_satiri = _cyc
    # Sedatif antihistaminik (Sipraktin/Allerset vb.) — günde tek doz ise gece.
    elif (usage.gunluk_kez in (None, 1)):
        _sah = _sedating_antihistamine_oneri(atc, form, name_u)
        if _sah:
            usage.oneri_satiri = _sah

    # Yukarıdaki gruplardan hiçbiri yakalamamışsa sağ sütunu doldurmak için
    # ATC bazlı bonus bilgi satırı (yan etki / etkileşim / kullanım ipucu).
    if not usage.oneri_satiri:
        usage.oneri_satiri = _bonus_oneri_satiri(atc, form, name_u)

    # Kritik ATC güvenlik rozeti (sol sütun, hep görünür): GÜNEŞTEN KORUN /
    # KAN SULANDIRICI / ARAÇ KULLANMA / GEBELİKTE YASAK vb. DB akışı bunu
    # _build_usage_label'da basıyordu; CANLI Medula akışında eksikti → burada
    # ekleniyor (zaten bir rozet atanmışsa dokunulmaz).
    if not usage.kritik_rozet:
        try:
            _rc = db_row["route_class"] or ""
        except (IndexError, KeyError):
            _rc = ""
        # form/route_class kilidi: deriye sürülen üründe sistemik rozet
        # (tiyokolşikosid JEL → "ARAÇ KULLANMA") bastırılır.
        cb = _critical_badge_for_atc(atc, form, _rc)
        if cb:
            usage.kritik_rozet = cb

    # Kritik rozet saklama çerçevesiyle aynı bilgiyi veriyorsa saklama çerçevesini kaldır.
    if (usage.kritik_rozet and usage.saklama_badge and
            usage.kritik_rozet.upper() in usage.saklama_badge.upper()):
        usage.saklama_badge = ""

    # Burun/boğaz spreyi → doz "N FIS" (reçetedeki sayı kadar püskürtme).
    if form in ("nasal_spray", "oral_spray_throat") and usage.doz:
        usage.doz = _spray_fis_doz(usage.doz)
    # Topikal/dermal sprey (Oceral/Exoderil/Lamisil sprey) → 'tane' OLMAZ; her
    # sıkış 1 PUF. Form cream_or_ointment_topical'a düştüğü için adda SPREY + D ATC
    # ile tespit edilir; "SABAH 1 PUF / GÜNDE 2 KEZ 1 PUF" çıkar.
    elif _is_topical_spray(atc, name_u, form, _route) and usage.doz:
        usage.doz = _topical_spray_puf_doz(usage.doz)
    # Cilde SÜRÜLEN topikal (krem/merhem/losyon/emülsiyon/jel/şampuan) → uygulanan
    # 'ml'/'gram' anlamsız; sıklık "KEZ" ile verilir ("SABAH 1 KEZ / GÜNDE 2 KEZ").
    # DB formu yetkili; göz/oral/IV emülsiyonları bu kümeye girmediği için etkilenmez.
    elif form in _TOPICAL_SURULEN_FORMS and usage.doz:
        usage.doz = _topical_surulen_kez_doz(usage.doz)
    # Göz/kulak/burun DAMLASI → birim daima "damla". "OFTALMİK ÇÖZELTİ" gibi adlarda
    # guess_unit boş/ml dönüp birimi düşürebiliyor (OFNOL "SABAH 1" birimsiz çıkıyordu);
    # form eye/ear/nasal_drop ise "SABAH 1 DAMLA" olarak sabitlenir (Lotemax/Fullfresh ile aynı).
    elif form in ("eye_drop", "ear_drop", "nasal_drop") and usage.doz:
        usage.doz = _drop_damla_doz(usage.doz)

    # Tedavi süresi (bitiş tarihi için): reçetede yoksa DB'den
    try:
        td = db_row["treatment_days"]
    except (IndexError, KeyError):
        td = None
    if not usage.sure_gun and td:
        usage.sure_gun = td
        if not usage.sure:
            usage.sure = f"{td} gün"

    # Gargara / ağız antiseptiği (A01AD: benzidamin, klorheksidin vb.) ya da adında
    # GARGARA geçen ürün ASLA YUTULMAZ. DB form'u boş/yanlış olsa bile (örn. ANDOREX
    # "SPREY, COZELTI" form=None → yanlışlıkla "YUTULUR" çıkıyordu) sağ talimatı
    # "yutmadan çalkala-tükür" olarak zorla; YUTULUR fallback'i (kullanim_talimati) ezilir.
    try:
        _nm = (db_row["name"] or "").upper()
    except (IndexError, KeyError):
        _nm = ""
    if "GARGARA" in _nm or (atc or "").upper().startswith("A01AD"):
        usage.talimat_satiri = "YUTMADAN AĞIZDA ÇALKALANIP TÜKÜRÜLÜR"
        usage.kullanim_talimati = ""
        # Gargaralarda (sprey/jel değil) ayrıca her sıklıkta görünen
        # "YUTMAYINIZ" güvenlik rozeti — şurup sanılıp içilmesin.
        if not usage.kritik_rozet and (
                "GARGARA" in _nm or form == "gargara_mouthwash"):
            usage.kritik_rozet = "YUTMAYINIZ"
        # Sulandırma talimatı YALNIZ konsantre gargaralarda (flurbiprofen %0.25:
        # Majezik/Maximus/Maxiflu/Flurend). Benzidamin/klorheksidinli hazır
        # gargaralarda (Andorex/Kloroben/Tanflex...) sulandırma YANLIŞTI.
        if "GARGARA" in _nm or form == "gargara_mouthwash":
            usage.teknik_satiri = ("1 ÖLÇEK + YARI BARDAK SU"
                                   if is_diluted_gargara(_nm) else "")

    # Beslenme ürünü (mama/enteral solüsyon): büyük cümle reçete ad-fallback'i
    # ile üretildiğinden, marka NUTRITION_BRANDS'te yoksa (HUMANA, APTAMIL,
    # MILUPA...) "BİR BARDAK SUYLA YUTULUR" kalır; rc=1 kilidi de yakalamaz
    # (yutmak da oraldır). DB form'u beslenme diyorsa cümleyi formla yeniden üret.
    if form in ("nutritional_supplement_oral", "nutritional_powder_oral") and \
            ("YUTULUR" in (usage.kullanim_talimati or "")
             or "BARDAK" in (usage.kullanim_talimati or "")):
        _periyot = (usage.periyot or "").strip().lower()
        _is_gunluk = (not _periyot) or _periyot.startswith(("gün", "gun"))
        usage.kullanim_talimati = build_kullanim_talimati(
            drug_name=name_u,
            gunluk_kez=usage.gunluk_kez if _is_gunluk else None,
            saat_arasi=None,
            kullanim_zamani=usage.kullanim_zamani,
            yemek=usage.yemek,
            doz_str=usage.doz,
            kullanim_sekli=usage.kullanim_sekli,
            form=form,
        )

    # Uyuz/bit topikalleri (P03): "ETKİLENEN BÖLGEYE SÜRÜNÜZ" uyuzda YANLIŞ —
    # boyundan aşağı TÜM vücuda uygulanır; şampuanlar bit içindir. DB akışındaki
    # _build_usage_label ile aynı düzeltme; TİP B protokolü build_label_plan'dan gelir.
    _pk = _parasite_kind(atc, name_u, form)
    if _pk:
        _pkat, _ptal, _pon = _parasite_a_overrides(_pk)
        usage.kategori = _pkat
        usage.talimat_satiri = _ptal
        usage.oneri_satiri = _pon
        if not usage.kritik_rozet:
            usage.kritik_rozet = "YUTMAYIN"

    # Tırnak mantarı cilası/solüsyonu (Opilox/Nibulen/Loceryl/Dermo-Trosyd):
    # DB akışındaki _build_usage_label ile aynı düzeltme; ayrıntılı adımlar
    # TİP B protokolüyle build_label_plan'dan gelir.
    _nk = _nail_kind(atc, name_u)
    if _nk:
        _nkat, _ntal, _non = _nail_a_overrides(_nk)
        usage.kategori = _nkat
        usage.talimat_satiri = _ntal
        usage.oneri_satiri = _non
        usage.teknik_satiri = ""

    # Siğil/nasır solüsyonları (Duoderm/Verrutol): yalnız siğil üzerine.
    # DB akışıyla aynı; TİP B protokolü build_label_plan'dan gelir.
    _wk = _wart_kind(atc, name_u)
    if _wk:
        _wkat, _wtal, _won = _wart_a_overrides(_wk)
        usage.kategori = _wkat
        usage.talimat_satiri = _wtal
        usage.oneri_satiri = _won
        usage.teknik_satiri = ""

    # Yara izi jeli (Contractubex/Noskar): kapanmış iz dokusuna masajla.
    # DB akışıyla aynı; TİP B protokolü build_label_plan'dan gelir.
    if _is_scar_gel(name_u):
        usage.kategori = "YARA İZİ (NEDBE) JELİ"
        usage.talimat_satiri = "YARA İZİNE HAFİF MASAJLA, EMİLENE KADAR SÜRÜNÜZ"
        usage.oneri_satiri = "YARA TAM KAPANDIKTAN SONRA BAŞLANIR"
        usage.teknik_satiri = ""

    # Nistatin oral süspansiyon (Mikostatin/Fungostatin — pamukçuk):
    # "ağızda gezdir, sonra yut". DB akışıyla aynı.
    if (atc or "").upper().startswith("A07AA02") and form in ("syrup_or_suspension", ""):
        usage.talimat_satiri = "AĞIZDA İYİCE GEZDİRİP SONRA YUTUNUZ"

    # Diyaliz çözeltileri (Physioneal/Extraneal/CAPD...): yanlış formdan gelen
    # "İÇİNİZ" talimatı basılmaz. DB akışındaki _build_usage_label ile aynı.
    _dk = _dialysis_kind(atc, name_u)
    if _dk:
        _dkat, _dtal = _dialysis_a_overrides(_dk)
        usage.kategori = _dkat
        usage.talimat_satiri = _dtal
        usage.kullanim_talimati = ""
        usage.oneri_satiri = ""
        usage.teknik_satiri = ""
        usage.yemek = ""
        usage.meal_badge = ""
        if not usage.kritik_rozet:
            usage.kritik_rozet = "İÇMEYİNİZ"

    # --- route_class güvenlik kilidi ---
    # Reçeteden ad-fallback ile üretilen büyük cümlenin kanalı, DB'deki kullanım
    # yolu sınıfıyla çelişiyorsa (göz damlasına "İÇİLİR", dilaltına "YUTULUR",
    # banda "YUTULUR"...) cümleyi sınıfa uygun bitiş fiiliyle yeniden üret.
    try:
        _rc = db_row["route_class"] or ""
    except (IndexError, KeyError):
        _rc = ""
    if _rc and usage.kullanim_talimati and \
            talimat_route_conflict(usage.kullanim_talimati, _rc):
        _periyot = (usage.periyot or "").strip().lower()
        _is_gunluk = (not _periyot) or _periyot.startswith(("gün", "gun"))
        usage.kullanim_talimati = build_kullanim_talimati(
            drug_name=db_row["name"] or "",
            gunluk_kez=usage.gunluk_kez if _is_gunluk else None,
            saat_arasi=None,
            kullanim_zamani=usage.kullanim_zamani,
            yemek=usage.yemek,
            doz_str=usage.doz,
            kullanim_sekli=usage.kullanim_sekli,
            form=form,
            route_class=_rc,
            parenteral_route_mode=parenteral_route_mode,
        )


def _b12_schedule_label(db_row, drug, hasta_adi, eczane_adi, eczane_telefon):
    """DODEX ve B12 iğnesi muadilleri (ATC B03BA ampul) için 3-KUTU yükleme→idame
    şeması etiketi üretir. Yalnız reçetede **3 kutu** yazıldığında döner; aksi
    halde None (normal kullanım etiketi yeterlidir).

    Şema (klasik B12 yükleme): 1. kutu HER GÜN, 2. kutu HAFTADA bir, 3. kutu AYDA
    bir → birer ampul. Bir kutu = 5 ampul olduğundan yükleme (5 gün) → haftalık
    (5 hafta) → aylık (5 ay) idameye karşılık gelir.
    """
    if db_row is None:
        return None
    try:
        atc = (db_row["atc_code"] or "").upper()
    except (IndexError, KeyError):
        atc = ""
    try:
        form = db_row["form"] or ""
    except (IndexError, KeyError):
        form = ""
    name_u = (drug.ad or "").upper()
    is_b12_ampul = atc.startswith("B03BA") and (
        form.startswith("injection") or "AMPUL" in name_u
    )
    if not is_b12_ampul:
        return None
    # Kutu (paket) sayısı — Medula "Adet" sütunu. Yalnız 3 kutu reçetede şema uygula.
    m = re.match(r"\s*(\d+)", drug.adet or "")
    if not m or int(m.group(1)) != 3:
        return None
    steps = [
        "KUTU — HER GÜN 1 AMPUL",     # 1. kutu (yükleme, ~5 gün)
        "KUTU — HAFTADA 1 AMPUL",     # 2. kutu (~5 hafta)
        "KUTU — AYDA 1 AMPUL",        # 3. kutu (idame, ~5 ay)
    ]
    caveats = [
        "Bir kutu = 5 ampul; kas içine (IM) uygulanır.",
        "Şema hekim önerisine göre değişebilir.",
    ]
    return render_glucose_guide_label(
        hasta_adi=hasta_adi, ilac_adi=drug.ad,
        title="B12 İĞNESİ KULLANIM ŞEMASI",
        steps=steps, caveats=caveats,
        eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
    )


def build_patient_label(
    cap: PrescriptionCapture,
    *,
    preview_dir: Path,
    extra=None,
    show_debt: bool = True,
    eczane_adi: Optional[str] = None,
    eczane_telefon: Optional[str] = None,
) -> Optional[Path]:
    """Hasta bilgi etiketini (tarih/ad/telefon/ödeme/toplam) üretip PNG yolu döndürür.

    `extra` = patient_info.PatientExtra (telefon + ödeme + reçete toplam); None ise
    yalnız Medula'dan gelen tarih + ad-soyad basılır. Basacak hiçbir bilgi yoksa
    None döner.
    """
    from .label_render import render_patient_label
    from .patient_info import label_amounts

    hasta_ad = (cap.hasta_ad or "").strip()
    tarih = (cap.recete_tarihi or "").strip()
    telefon = getattr(extra, "telefon", "") or ""
    amt = label_amounts(extra)

    if not any((hasta_ad, tarih, telefon, amt["recete_tutari"],
                amt["recete_paid"], amt["toplam_borc"])):
        return None

    if eczane_adi is None or eczane_telefon is None:
        with get_connection() as conn:
            init_schema(conn)
            s = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}
            if eczane_adi is None:
                eczane_adi = s.get("eczane_adi", "")
            if eczane_telefon is None:
                eczane_telefon = s.get("eczane_telefon", "")

    preview_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = re.sub(r"[^0-9A-Za-z]+", "_", (cap.recete_no or "hasta")).strip("_") or "hasta"
    out = preview_dir / f"{slug}_{ts}_hasta.png"
    render_patient_label(
        hasta_adi=hasta_ad,
        tarih=tarih,
        telefon=telefon,
        recete_tutari=amt["recete_tutari"],
        recete_paid=amt["recete_paid"],
        toplam_borc=amt["toplam_borc"],
        recete_no=(cap.recete_no or "").strip(),
        show_debt=show_debt,
        eczane_adi=eczane_adi or "",
        eczane_telefon=eczane_telefon or "",
    ).save(out)
    return out


def build_labels_for_capture(
    cap: PrescriptionCapture,
    *,
    preview_dir: Path,
    eczane_adi: Optional[str] = None,
    eczane_telefon: Optional[str] = None,
) -> BuiltRecete:
    """Yakalanan reçete için tüm etiket görsellerini üretir."""
    preview_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    with get_connection() as conn:
        init_schema(conn)

        # Hasta adı kalıcılığı: bu sayfada hasta adı GÖRÜNÜYORSA reçete no ile
        # DB'ye yaz (Reçete Başı sayfası genelde dolu gelir). GÖRÜNMÜYORSA
        # (Reçete Sonu sayfası bazen boş gelir) DB'den reçete no ile geri al.
        if (cap.hasta_ad or "").strip():
            save_recete_hasta(conn, cap.recete_no, cap.hasta_ad, cap.hasta_tc)
        elif (cap.recete_no or "").strip():
            db_ad, db_tc = lookup_recete_hasta(conn, cap.recete_no)
            if db_ad and not (cap.hasta_ad or "").strip():
                cap.hasta_ad = db_ad
            if db_tc and not (cap.hasta_tc or "").strip():
                cap.hasta_tc = db_tc

        s = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}
        if eczane_adi is None:
            eczane_adi = s.get("eczane_adi", "")
        if eczane_telefon is None:
            eczane_telefon = s.get("eczane_telefon", "")

        # Parenteral uygulama yolu politikası (ayar): AÇIK → e-reçetedeki
        # IM/IV/SC yolu spesifik yazılır; KAPALI (varsayılan) → yol gizli,
        # yalnız "SAĞLIK PERSONELİ TARAFINDAN UYGULANIR".
        _par_mode = ("recete" if s.get("erecete_parenteral_route", "0") == "1"
                     else "generic")

        # İlaç grubu etiket varsayılanları: [{"atc": "J01", "A": true, "B": true, ...}]
        try:
            _group_defaults: list[dict] = json.loads(s.get("group_label_defaults") or "[]")
        except Exception:
            _group_defaults = []

        try:
            d, m, y = cap.recete_tarihi.split("/")
            r_date = datetime.date(int(y), int(m), int(d))
        except Exception:
            r_date = datetime.date.today()

        items: list[LabelItem] = []
        for drug in cap.drugs:
            # Çöp/ayraç satırlarını atla: Medula tablosunda bazı satırlar
            # barkod ve ad olarak yalnızca "/" gibi noktalama içerir; bunlar
            # gerçek ilaç değildir, etiket üretilmemelidir.
            if not re.search(r"[0-9A-Za-zÇĞİÖŞÜçğıöşü]", drug.ad or ""):
                continue
            # DB kaydını doz hesabından ÖNCE çek: muadil ad düzeltmesi (aşağıda) ve
            # ölçek hacmi (olcek_ml) doz birimini etkiler. (Aşağıda yeniden çekilmez.)
            db_row = _lookup_db_drug(conn, drug.barkod, drug.ad)
            db_matched = db_row is not None
            # MUADİL DEĞİŞİKLİĞİ: reçetedeki barkod, VERİLEN (dispense edilen) muadilin
            # barkodudur. Barkod DB'de TAM eşleşiyorsa etiket adını DB adına çevir →
            # muadil değiştiyse etiket verilen muadili gösterir (doz hesabı da düzelir).
            if (db_row is not None and drug.barkod
                    and (db_row["barcode"] or "") == drug.barkod
                    and (db_row["name"] or "").strip()):
                drug.ad = db_row["name"].strip()
            # Oral sıvının bir ölçeğinin ml hacmi (Duphalac vb. ~30 ml; çoğu 5 ml).
            _olcek_ml = None
            if db_row is not None:
                try:
                    _olcek_ml = db_row["olcek_ml"]
                except (KeyError, IndexError):
                    _olcek_ml = None
            # Cilde sürülen formlarda (krem/jel/merhem...) Medula'nın verdiği
            # "GRAM" gibi miktar hastaya bir şey ifade etmez; miktar yerine
            # sıklığı "kez" olarak göster (SABAH 1 KEZ / AKŞAM 1 KEZ).
            if is_topical_surulen(drug.ad, drug.kullanim_sekli):
                birim = "kez"
                adet = drug.doz_birim_adedi
            else:
                # Medula birim-doz ("Adet/Periyot/Doz" sütunundaki '5 Mililitre',
                # '0,04 Mililitre', '1 Adet', '10 Mililitre', '1 Gram') "2x1"deki
                # 1'in NE olduğunu söyler → ölçek/damla/tane/ml/gram doğru hesaplanır.
                dd = medula_dose_display(drug.birim_doz_miktari, drug.doz_birim,
                                         drug.doz_birim_adedi, drug.ad,
                                         olcek_ml=_olcek_ml)
                if dd is not None:
                    adet, birim = dd
                else:
                    # Birim-doz yoksa eski tahmin: süspansiyon/şurup → ölçek.
                    birim = drug.doz_birim or guess_unit(drug.ad, drug.kullanim_sekli)
                    if (birim or "").strip().lower() in ("ml", "mililitre") and \
                            guess_unit(drug.ad, drug.kullanim_sekli) == "ölçek":
                        birim = "ölçek"
                    adet = drug.doz_birim_adedi
            # Gargara → her zaman ÖLÇEK ile yaz (kapak = 1 ölçek). Medula birim ne
            # bildirirse bildirsin (ml/Adet) "SABAH 1 ÖLÇEK / AKŞAM 1 ÖLÇEK" çıksın;
            # ml/tane sızması engellenir. Ölçek sayısı = her seferki adet (NxM'deki M).
            if "GARGARA" in (drug.ad or "").upper() and (birim or "").strip().lower() != "ölçek":
                birim = "ölçek"
                adet = drug.doz_birim_adedi if drug.doz_birim_adedi not in (None, "") else 1
            # İnhalasyon (astım/KOAH) inhaler → doz 'tane'/'kapsül' OLMAZ; her uygulama
            # bir 'SEFER' derin nefestir. Reçete kaydı formsuz olabildiğinden addan
            # tespit edilir (NEBÜL hariç). "GÜNDE 4 KEZ İKİ SEFER" / "2 SEFER ... İÇE
            # ÇEKİLİR"; A ızgarasında birim düşer (sade "SABAH 2"), B'de "İKİ SEFER".
            if _is_puff_inhaler(drug.ad):
                birim = "sefer"
                adet = drug.doz_birim_adedi if drug.doz_birim_adedi not in (None, "") else 1
            doz_str = ""
            if adet is not None:
                try:
                    _f = float(adet)
                except (TypeError, ValueError):
                    _f = None
                # Ölçek/damla/ml birimlerinde sayısal göster ("1,5 ölçek", "7,5 ml").
                # Yazı biçimi ("BİR BUÇUK ölçek") etikette uzun/kırpık görünür.
                if birim in ("ölçek", "ml", "damla") and _f is not None:
                    # Şurup ölçeğinde yarım/çeyrek hastaya daha anlaşılır: 0,5→YARIM,
                    # 0,25→ÇEYREK (ml/damla'da "çeyrek damla" anlamsız → sadece ölçek).
                    if birim == "ölçek" and _f == 0.5:
                        adet_s = "YARIM"
                    elif birim == "ölçek" and _f == 0.25:
                        adet_s = "ÇEYREK"
                    elif _f.is_integer():
                        adet_s = str(int(_f))
                    else:
                        adet_s = f"{_f:.1f}".replace(".", ",").rstrip("0").rstrip(",")
                else:
                    # Tablet/tane/kapsül → Türkçe yazı biçimi ("BİR", "YARIM" ...)
                    adet_s = format_dose_amount(adet)
                doz_str = f"{adet_s} {birim}".strip() if birim else adet_s
            if not doz_str:
                doz_str = drug.doz_ham

            kategori = guess_kategori(drug.ad, drug.kullanim_sekli) or guess_form(drug.ad).upper()
            # Periyot "Günde" değilse (Haftada/Ayda/Yılda) doz_gunluk_kez bir GÜNLÜK
            # sıklık DEĞİLDİR (örn. "Haftada 2") — talimat cümlesine "günde N" olarak
            # geçirmeyelim; periyota özel ifade etiket ızgarasında üretilir.
            _periyot = (drug.periyot or "").strip()
            _is_gunluk = (not _periyot) or _periyot.lower().startswith("gün") or _periyot.lower().startswith("gun")
            talimat = build_kullanim_talimati(
                drug_name=drug.ad,
                gunluk_kez=drug.doz_gunluk_kez if _is_gunluk else None,
                saat_arasi=None,
                kullanim_zamani=[],
                yemek="",
                doz_str=doz_str,
                kullanim_sekli=drug.kullanim_sekli,
                parenteral_route_mode=_par_mode,
            )

            usage = UsageLabel(
                kategori=kategori,
                kullanim_talimati=talimat,
                uyari_metni="",
                ilac_turu=guess_form(drug.ad),
                doz=doz_str,
                gunluk_kez=drug.doz_gunluk_kez,
                periyot=drug.periyot or "",
                yemek="",
                kullanim_zamani=[],
                kullanim_sekli=drug.kullanim_sekli,
            )
            # Reçetede o ilaca düşülen doktor notu (Medula 'Açıklama' sütunu) —
            # etiketin en altına basılır. DB zenginleştirmesi bu alanı ezmez.
            usage.doktor_notu = (drug.aciklama or "").strip()
            prep = PreparationLabel(gerekli=False)
            warn = WarningLabel(gerekli=False)
            # Her etiket tipinin baskı kutusu varsayılanı (kind → bool).
            # Kullanım (A) her zaman varsayılan işaretli; diğerleri aşağıda dolar.
            label_default_print: dict = {"A": True}

            # (db_row + muadil ad düzeltmesi yukarıda, doz hesabından önce yapıldı.)
            if db_row:
                u1 = _db_label(conn, db_row["id"], 1)
                u2 = _db_label(conn, db_row["id"], 2)
                u3 = _db_label(conn, db_row["id"], 3)
                if u1:
                    if u1.get("kategori"):           usage.kategori = u1["kategori"]
                    if u1.get("kullanim_talimati"):  usage.kullanim_talimati = u1["kullanim_talimati"]
                    if u1.get("uyari_metni"):        usage.uyari_metni = u1["uyari_metni"]
                    if u1.get("sure_gun"):           usage.sure_gun = u1["sure_gun"]
                    usage.ilac_turu = u1.get("ilac_turu") or usage.ilac_turu
                    if not usage.yemek:           usage.yemek = u1.get("yemek", "")
                    if not usage.ek_not:          usage.ek_not = u1.get("ek_not", "")
                    if not usage.kullanim_zamani: usage.kullanim_zamani = u1.get("kullanim_zamani", []) or []
                    if not usage.sure:            usage.sure = u1.get("sure", "")
                if u2:
                    prep = PreparationLabel(**{**PreparationLabel().__dict__, **u2})
                if u3:
                    warn = WarningLabel(**{**WarningLabel().__dict__, **u3})

                # Yapısal kolonlar + drug_label_blocks ile kullanım etiketini
                # zenginleştir (reçetenin gerçek doz/sıklığı korunur).
                _enrich_usage_from_db(usage, db_row, conn,
                                      parenteral_route_mode=_par_mode)

            # PROGESTAN/PROGYNEX (mikronize progesteron kapsül) — kullanım YOLU
            # ilaçtan değil REÇETEDEN gelir: e-reçete "Kullanım Şekli" vajinal ise
            # VAJİNAYA YERLEŞTİRİNİZ, ağızdan ise BİR BARDAK SU İLE YUTUNUZ; kağıt
            # reçete / reçete-sonu ekranında (kullanim_sekli boş) iki yol birden
            # "doktorunuzun önerdiği şekilde" yazılır. _enrich'in route_class
            # kilidinden SONRA uygulanmalı (rc='1' oral kilidi vajinal cümleyi
            # geri YUTULUR'a çevirmesin).
            _row_atc = db_row["atc_code"] if db_row is not None else None

            # Antibiyotikler (J01*): A Tipi varsayılan, saat aralığı notu sol ızgarada.
            if _row_atc and _row_atc.upper().startswith("J01"):
                periyot_i = (usage.periyot or "").strip().lower()
                if not periyot_i or periyot_i.startswith("gün") or periyot_i.startswith("gun"):
                    usage.antibiotic_interval = True

            _progesterone_route_override(usage, _row_atc, drug.ad)

            # Medikal malzeme / cihaz (kan şekeri ölçüm çubuğu, lanset, glukometre
            # vb.): bunlar İLAÇ DEĞİLDİR. Medula'dan gelen "günde N kez" + form
            # tahmininden üretilen "SABAH-ÖĞLE-AKŞAM 1 BİR BARDAK SUYLA YUTULUR"
            # talimatı yanlıştır. Türüne uygun talimatla değiştir ve dozaj
            # matrisini/öğün-saklama rozetlerini/2.-3. etiketi kaldır.
            dev_atc = _row_atc
            dev_kind = classify_medical_device(drug.ad, dev_atc)
            if dev_kind:
                kat, talimat_dev, uyari_dev = DEVICE_LABEL_CONTENT[dev_kind]
                usage.kategori = kat
                usage.kullanim_talimati = ""
                usage.talimat_satiri = talimat_dev
                usage.teknik_satiri = ""
                usage.oneri_satiri = ""
                usage.uyari_metni = uyari_dev
                usage.doz = ""
                usage.gunluk_kez = None
                usage.saat_arasi = None
                usage.kullanim_zamani = []
                usage.zaman_satirlari = []
                usage.meal_badge = ""
                usage.yemek = ""
                usage.saklama_badge = ""
                prep = PreparationLabel(gerekli=False)
                warn = WarningLabel(gerekli=False)

            bitis_date = None
            sure_gun = usage.sure_gun
            if sure_gun:
                bitis_date = r_date + datetime.timedelta(days=int(sure_gun))

            # Dosya adında yol ayıracı (/ \) veya başka geçersiz karakter
            # OLMAMALI; aksi halde kayıt var olmayan bir klasöre düşer ve
            # tüm reçetenin etiket üretimi çöker. Güvenli slug üret.
            raw_id = drug.barkod or drug.ad[:8]
            safe_recete = re.sub(r"[^0-9A-Za-z]", "", cap.recete_no or "") or "noid"
            safe_id = re.sub(r"[^0-9A-Za-z]", "", raw_id or "") or "x"
            slug = f"{ts}_{safe_recete}_{safe_id}"
            p1 = preview_dir / f"{slug}_label1.png"
            editable_usage = None
            render_ctx = None
            dev_guide_caveats_path = None
            if dev_kind in GUIDE_DEVICE_KINDS:
                # Kan şekeri ölçüm çubuğu/cihazı: adımlar + dikkat hususları TEK
                # etikette çok küçük puntoyla sığıyordu. İKİ ayrı etikete böl —
                # A: "KAN ŞEKERİ NASIL ÖLÇÜLÜR?" (adımlar), B: "DİKKAT EDİLECEK
                # HUSUSLAR" (uyarılar). Her biri tek konuya ayrıldığından renderer
                # daha büyük punto seçer (steps-only fs≈11, caveats-only fs≈13).
                render_glucose_guide_label(
                    hasta_adi=cap.hasta_ad, ilac_adi=drug.ad,
                    title=GLUCOSE_GUIDE_TITLE,
                    steps=GLUCOSE_GUIDE_STEPS, caveats=[],
                    eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    full_name=True,
                ).save(p1)
                dev_guide_caveats_path = preview_dir / f"{slug}_label2.png"
                render_glucose_guide_label(
                    hasta_adi=cap.hasta_ad, ilac_adi=drug.ad,
                    title="DİKKAT EDİLECEK HUSUSLAR",
                    steps=[], caveats=GLUCOSE_GUIDE_CAVEATS,
                    eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    full_name=True,
                ).save(dev_guide_caveats_path)
            else:
                _kutu_early = _adet_to_int(drug.adet or "")
                render_usage_label(
                    hasta_adi=cap.hasta_ad, ilac_adi=drug.ad, label=usage,
                    recete_tarihi=r_date, bitis_tarihi=bitis_date,
                    eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    kutu_adet=_kutu_early,
                ).save(p1)
                # Canlı doz/zaman düzenleme için usage + render bağlamını sakla
                editable_usage = usage
                render_ctx = {
                    "hasta_adi": cap.hasta_ad, "ilac_adi": drug.ad,
                    "recete_tarihi": r_date, "bitis_tarihi": bitis_date,
                    "eczane_adi": eczane_adi, "eczane_telefon": eczane_telefon,
                    "kutu_adet": _kutu_early,
                }

            p2 = None
            # Kan şekeri cihazı: 2. etiket = "DİKKAT EDİLECEK HUSUSLAR" (yukarıda üretildi).
            if dev_guide_caveats_path is not None:
                p2 = dev_guide_caveats_path
                label_default_print["B"] = True
            elif prep.gerekli:
                p2 = preview_dir / f"{slug}_label2.png"
                render_preparation_label(
                    hasta_adi=cap.hasta_ad, ilac_adi=drug.ad, label=prep,
                    eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                ).save(p2)
                label_default_print["B"] = True

            # DODEX / B12 iğnesi (B03BA ampul): 3 KUTU yazıldıysa yükleme→idame
            # şeması ek etiketi (1. kutu her gün, 2. haftada bir, 3. ayda bir).
            if p2 is None:
                b12_img = _b12_schedule_label(
                    db_row, drug, cap.hasta_ad, eczane_adi, eczane_telefon
                )
                if b12_img is not None:
                    p2 = preview_dir / f"{slug}_label2.png"
                    b12_img.save(p2)
                    label_default_print["B"] = True

            p3 = None
            if warn.gerekli:
                p3 = preview_dir / f"{slug}_label3.png"
                render_warning_label(
                    hasta_adi=cap.hasta_ad, ilac_adi=drug.ad, label=warn,
                    eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                ).save(p3)
                label_default_print["C"] = True

            p4 = None

            # drug_label_blocks'tan 2./3./4. etiket (hazırlama-teknik + ciddi uyarı +
            # astım/inhaler dikkat hususları). drug_labels (içerik JSON) boş olduğunda
            # asıl kaynak budur. İnhaler ilaçlarda 4. etiket (D) her zaman üretilir;
            # kullanıcı tercihleri (suppress/custom) build_label_plan içinde uygulanır.
            _is_inhaler = db_row is not None and (
                (db_row["form"] or "") in ("inhaler_pmdi", "inhaler_dpi", "nebule")
            )
            if db_matched and not dev_kind and (p2 is None or p3 is None or _is_inhaler):
                try:
                    plan = build_label_plan(
                        db_row["id"], cap.hasta_ad, r_date, conn=conn
                    )
                except Exception:
                    plan = []
                for spec in plan:
                    if spec.kind == "B" and p2 is None:
                        p2 = preview_dir / f"{slug}_label2.png"
                        spec.image.save(p2)
                        label_default_print["B"] = spec.default_print
                    elif spec.kind == "C" and p3 is None:
                        p3 = preview_dir / f"{slug}_label3.png"
                        spec.image.save(p3)
                        label_default_print["C"] = spec.default_print
                    elif spec.kind == "D" and p4 is None:
                        p4 = preview_dir / f"{slug}_label4.png"
                        spec.image.save(p4)
                        label_default_print["D"] = spec.default_print

            # İlaç grubu etiket varsayılanlarını uygula (settings → group_label_defaults).
            # Sadece o ilaç için ÜRETİLMİŞ etiket kind'larını etkiler (p2→B, p3→C, p4→D).
            if _group_defaults and _row_atc:
                atc_up = _row_atc.upper()
                for gd in _group_defaults:
                    pfx = (gd.get("atc") or "").upper().strip()
                    if pfx and atc_up.startswith(pfx):
                        if "A" in gd:
                            label_default_print["A"] = bool(gd["A"])
                        if "B" in gd and p2 is not None:
                            label_default_print["B"] = bool(gd["B"])
                        if "C" in gd and p3 is not None:
                            label_default_print["C"] = bool(gd["C"])
                        if "D" in gd and p4 is not None:
                            label_default_print["D"] = bool(gd["D"])
                        break

            _kutu = _adet_to_int(drug.adet or "")
            items.append(LabelItem(
                drug_ad=drug.ad, barkod=drug.barkod, db_matched=db_matched,
                p1=p1, p2=p2, p3=p3, p4=p4,
                drug_id=(db_row["id"] if db_row is not None else None),
                label_default_print=label_default_print,
                usage=editable_usage, render_ctx=render_ctx,
                doz_adet=adet, doz_birim=birim,
                geri_odeme_yok=bool(getattr(drug, "geri_odeme_yok", False)),
                kutu_adet=_kutu,
                stok=getattr(drug, "stok", None),
            ))

    return BuiltRecete(
        recete_no=cap.recete_no or "",
        hasta_ad=cap.hasta_ad or "",
        hasta_tc=cap.hasta_tc or "",
        recete_tarihi=cap.recete_tarihi or "",
        dr_ad=cap.dr_ad or "",
        items=items,
    )
