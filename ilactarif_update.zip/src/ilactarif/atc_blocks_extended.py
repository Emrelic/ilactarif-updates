"""Genişletilmiş ATC bazlı bilgi bloğu kütüphanesi (general_knowledge kaynağı).

Mevcut atc_label_blocks.py'daki kategori şablonlarına ek olarak, daha detaylı
ve eczanedeki ATC kodu olan ilaçların tamamını kapsayan içerikler içerir.

İçerik kaynağı: TITCK KÜB/KT yapısı eğitim verisi.
Etiketleme: source='general_knowledge', reviewed=0.

Üreten fonksiyon: generate_general_blocks(atc_code, atc_name)
Döner: {block_type: content} dict — 5 blok (saklama+sıvı+hazırlama hariç).
"""
from __future__ import annotations


# ATC sınıf prefiksi (en spesifik önce) → 5 blok detaylı içerik.
# Eşleşme: drug.atc_code o prefix ile başlıyorsa kullanılır.
ATC_PREFIX_BLOCKS: list[tuple[str, dict[str, str]]] = [

    # ============================================================
    # J01 — ANTİBİYOTİKLER
    # ============================================================
    ("J01CR", {  # Penisilin + beta-laktamaz inhibitörü (amoksisilin-klavulanat)
        "dikkat": (
            "• Penisilin veya sefalosporin grubu antibiyotiklere alerjisi olanlar kullanmamalı (anafilaksi riski).\n"
            "• Mononükleoz, lenfositik lösemi şüphesi varsa kullanılmaz (yüksek döküntü riski).\n"
            "• Mide şikayetini azaltmak için YEMEK BAŞLANGICINDA alınız.\n"
            "• Ciddi karaciğer/böbrek yetmezliği olanlar doz ayarlaması ile kullanmalı.\n"
            "• İlacı bitene kadar her gün düzenli, doktorun belirlediği süre boyunca kullanınız.\n"
            "• Gebelik ve emzirme döneminde doktor onayı gerekir.\n"
            "• Tedavi 14 günü aşmamalı (doktor önermedikçe)."
        ),
        "etkilesim": (
            "• Doğum kontrol haplarının etkisini azaltabilir; ek koruma yöntemi önerilir.\n"
            "• Allopurinol ile birlikte ciltte döküntü riski artar.\n"
            "• Varfarin etkisini artırabilir (kanama riski).\n"
            "• Probenesid amoksisilin atılımını azaltır.\n"
            "• Metotreksat toksisitesini artırabilir.\n"
            "• Canlı tifo aşısının etkisini azaltır."
        ),
        "yan_etki": (
            "• Sık: ishal, bulantı, kusma, karın ağrısı, mantar enfeksiyonu (özellikle vajinal), "
            "ciltte hafif döküntü, ağız yarası.\n"
            "• CİDDİ YAN ETKİ: Şiddetli alerjik reaksiyon (anafilaksi — yüzde/boğazda şişme, nefes "
            "darlığı), şiddetli ishal (psödomembranöz kolit — kanlı dışkı), kolestatik sarılık, "
            "şiddetli ciltte döküntü (Stevens-Johnson sendromu) → ACİL doktora başvurun."
        ),
        "sonlandirma": (
            "Tedaviyi reçetelenen GÜN SAYISINA göre TAMAMLAYINIZ. İyileşme hissetseniz bile "
            "erken bırakmak direnç gelişimine ve enfeksiyon nüksüne yol açar."
        ),
        "hatirlatma": (
            "• Antibiyotik tedavisi sırasında ve sonrasında 2 hafta probiyotik desteği bağırsak florasını korur.\n"
            "• Süspansiyon formu sulandırıldıktan sonra BUZDOLABINDA saklanır, 7 gün içinde tüketilir.\n"
            "• Yan etki olarak ishal olursa bol sıvı tüketin, devam ederse doktora bildirin."
        ),
    }),
    ("J01CA", {  # Geniş spektrumlu penisilin (amoksisilin)
        "dikkat": (
            "• Penisilin/sefalosporin alerjisi olanlar kullanmamalı.\n"
            "• Mononükleoz şüphesi varsa kullanılmaz (döküntü riski).\n"
            "• Böbrek yetmezliği olanlar doz ayarlaması ile kullanmalı.\n"
            "• Yemek başlangıcında veya aç karnına alınabilir.\n"
            "• Tedaviyi düzenli ve tamamlayınız."
        ),
        "etkilesim": (
            "• Doğum kontrol haplarının etkisini azaltabilir.\n"
            "• Allopurinol ile döküntü riski.\n"
            "• Varfarin etkisini artırabilir.\n"
            "• Canlı aşılarla etkileşim."
        ),
        "yan_etki": (
            "• Sık: ishal, bulantı, ağız yarası, ciltte döküntü, mantar enfeksiyonu.\n"
            "• CİDDİ YAN ETKİ: anafilaksi, psödomembranöz kolit, ciddi ciltte döküntü → ACİL doktora."
        ),
        "sonlandirma": "Tedavi süresini TAMAMLAYINIZ; erken bırakmak direnç yapar.",
        "hatirlatma": "• Probiyotik destek faydalı olabilir.\n• Bol su tüketin.",
    }),
    ("J01D", {  # Tüm sefalosporinler
        "dikkat": (
            "• Sefalosporin veya penisilin alerjisi olanlar kullanmamalı.\n"
            "• Böbrek yetmezliği olanlar doz ayarlaması ile kullanmalı.\n"
            "• K vitamini eksikliği olanlar dikkatli kullanmalı (kanama riski).\n"
            "• Tedaviyi tamamlayınız.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": (
            "• Aminoglikozid antibiyotikler ile birlikte böbrek toksisitesi artar.\n"
            "• Güçlü diüretikler (furosemid) böbrek toksisitesini artırır.\n"
            "• Probenesid atılımını azaltır.\n"
            "• Antikoagülan (varfarin) etkisini artırabilir.\n"
            "• ALKOL ile birlikte disülfiram benzeri reaksiyon (özellikle sefalosporin grubunda)."
        ),
        "yan_etki": (
            "• Sık: ishal, bulantı, ciltte döküntü, enjeksiyon yerinde reaksiyon.\n"
            "• CİDDİ YAN ETKİ: anafilaksi, şiddetli ishal, kan tablosu bozukluğu (hemolitik anemi), "
            "Stevens-Johnson sendromu → ACİL doktora."
        ),
        "sonlandirma": "Tedavi süresi doktor tarafından belirlenir; tamamlanmadan bırakılmaz.",
        "hatirlatma": "• IM/IV formlar sağlık ocağı veya hastane ortamında uygulanır.\n• Alkolden uzak durun.",
    }),
    ("J01FA", {  # Makrolid (azitromisin, klaritromisin, eritromisin)
        "dikkat": (
            "• Makrolid alerjisi olanlar kullanmamalı.\n"
            "• Kalp ritm bozukluğu (uzun QT), elektrolit dengesizliği olanlar dikkatli kullanmalı.\n"
            "• Ciddi karaciğer hastalığı olanlar kullanmamalı.\n"
            "• Miyastenia gravis olanlar dikkatli kullanmalı.\n"
            "• Tedaviyi tamamlayınız.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": (
            "• Astemizol, sisaprid, pimozid, terfenadin ile KULLANILMAZ (ölümcül kalp ritm bozukluğu).\n"
            "• Statinler ile birlikte rabdomiyoliz (kas erimesi) riski.\n"
            "• Varfarin, digoksin, karbamazepin, teofilin, siklosporin kan seviyelerini yükseltir.\n"
            "• Kolşisin ile birlikte toksisite riski.\n"
            "• Ergotamin ile birlikte ergot zehirlenmesi."
        ),
        "yan_etki": (
            "• Sık: bulantı, kusma, ishal, karın ağrısı, ağızda tat değişikliği, baş ağrısı.\n"
            "• CİDDİ YAN ETKİ: kalp ritm bozukluğu (çarpıntı, baygınlık), karaciğer hasarı (sarılık), "
            "psödomembranöz kolit (şiddetli ishal), işitme kaybı (geçici) → ACİL doktora."
        ),
        "sonlandirma": "Reçetelenen süreyi tamamlayınız.",
        "hatirlatma": "• Yeni başlanan herhangi bir ilacı doktora bildirin (etkileşim çok).",
    }),
    ("J01FF", {  # Linkozamid (klindamisin)
        "dikkat": (
            "• Klindamisin/linkomisin alerjisi olanlar kullanmamalı.\n"
            "• Bağırsak iltihabı (ülseratif kolit, Crohn) öyküsü olanlar dikkatli kullanmalı.\n"
            "• Karaciğer/böbrek yetmezliği olanlar doktor kontrolünde.\n"
            "• Bol su ile alınız.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": (
            "• Eritromisin ile birlikte etkisi azalır, kullanılmaz.\n"
            "• Kas gevşeticiler etkisini artırır (cerrahi sırasında dikkat).\n"
            "• Diğer antibiyotikler/antifungaller ile etkileşim."
        ),
        "yan_etki": (
            "• Sık: bulantı, kusma, karın ağrısı, ishal, ciltte döküntü.\n"
            "• CİDDİ YAN ETKİ: ŞİDDETLİ İSHAL — sulu veya kanlı (psödomembranöz kolit, hayati tehlikeli) → "
            "İLACI BIRAKIN, ACİL doktora başvurun.\n"
            "• Karaciğer hasarı, kan tablosu bozukluğu, Stevens-Johnson sendromu nadir."
        ),
        "sonlandirma": "Tedaviyi tamamlayınız ama şiddetli ishalde DURDURUN.",
        "hatirlatma": "• İshal başlarsa hemen doktora bildirin, kendi kendinize ishal kesici ilaç almayın.",
    }),
    ("J01MA", {  # Kinolon (siprofloksasin, levofloksasin, moksifloksasin)
        "dikkat": (
            "• 18 yaş altı çocuklarda (kıkırdak hasarı), gebelik ve emzirmede genellikle kullanılmaz.\n"
            "• Tendon hasarı/yırtılma riski (özellikle yaşlılarda, kortizon kullananlarda).\n"
            "• Kalp ritm bozukluğu (uzun QT) olanlar kullanmamalı.\n"
            "• Miyastenia gravis olanlar kullanmamalı.\n"
            "• Epilepsi öyküsü olanlar dikkatli kullanmalı (nöbet eşiğini düşürür).\n"
            "• Bol su tüketin (kristal idrar oluşumu önlenir)."
        ),
        "etkilesim": (
            "• Antiasit, demir, kalsiyum, magnezyum, çinko ile emilim DRAMATİK düşer — en az 2 saat ara.\n"
            "• Varfarin etkisini artırır (kanama).\n"
            "• Teofilin, kafein kan seviyelerini yükseltir.\n"
            "• NSAİİ ile birlikte nöbet riski artar.\n"
            "• Kortizon ile birlikte tendon hasarı riski."
        ),
        "yan_etki": (
            "• Sık: bulantı, ishal, baş ağrısı, baş dönmesi, uykusuzluk.\n"
            "• CİDDİ YAN ETKİ: TENDON YIRTILMASI (Aşil tendonu — kullanım sırasında ve sonrasında), "
            "kalp ritm bozukluğu, periferik nöropati (kalıcı uyuşma-karıncalanma), kan şekeri dalgalanması, "
            "psikiyatrik belirtiler, ciddi karaciğer hasarı → İLACI BIRAKIN ve ACİL doktora."
        ),
        "sonlandirma": "Tendon ağrısı / uyuşma olursa derhal bırakın.",
        "hatirlatma": (
            "• Güneşten korunun (fotosensitivite).\n"
            "• Tedavi süresince sert egzersizden kaçının (tendon riski).\n"
            "• Süt/yoğurt ile birlikte alınmaz."
        ),
    }),
    ("P01AB", {  # Nitroimidazol (metronidazol, ornidazol, tinidazol)
        "dikkat": (
            "• Tedavi süresince ve İLAÇ KESİLDİKTEN sonra EN AZ 3 GÜN ALKOL ALINMAZ (disülfiram reaksiyonu).\n"
            "• Sinir sistemi hastalığı (epilepsi, MS), ciddi karaciğer hastalığı olanlar dikkatli kullanmalı.\n"
            "• Gebeliğin ilk 3 ayında ve emzirme döneminde kullanılmaz.\n"
            "• Kan diskrazisi öyküsü olanlar dikkatli kullanmalı.\n"
            "• Uzun süreli kullanımda periferik nöropati riski."
        ),
        "etkilesim": (
            "• ALKOL ile birlikte disülfiram benzeri reaksiyon (kızarıklık, bulantı, çarpıntı, kusma).\n"
            "• Varfarin etkisini artırır (kanama riski).\n"
            "• Lityum kan seviyesini yükseltir.\n"
            "• Fenobarbital/fenitoin metronidazol etkisini azaltır.\n"
            "• Siklosporin, takrolimus seviyelerini etkileyebilir."
        ),
        "yan_etki": (
            "• Sık: bulantı, ağızda metalik tat, baş ağrısı, uyku hali, iştahsızlık, koyu idrar.\n"
            "• CİDDİ YAN ETKİ: el-ayaklarda uyuşma/karıncalanma (periferik nöropati — uzun kullanımda), "
            "nöbet, karaciğer fonksiyon bozukluğu, kan hücresi düşmesi, şiddetli alerjik reaksiyon → doktora."
        ),
        "sonlandirma": "Tedaviyi tamamlayınız.",
        "hatirlatma": "• Alkollü kolonya, bazı ağız bakım ürünleri bile reaksiyon yapabilir.\n• Eşle birlikte tedavi gerekebilir (trikomonas).",
    }),
    ("J01XX01", {  # Fosfomisin (özel idrar yolu antibiyotiği)
        "dikkat": (
            "• Saşeyi 1 bardak (200 ml) suya boşaltıp karıştırın, hemen içiniz.\n"
            "• Yatmadan önce, idrarınızı tam boşalttıktan sonra alınız.\n"
            "• Bol su tüketin.\n"
            "• Ciddi böbrek yetmezliği olanlar kullanmamalı.\n"
            "• Gebelikte doktor onayı gerekir."
        ),
        "etkilesim": "Metoklopramid emilimini azaltır, 2 saat ara verin.",
        "yan_etki": (
            "• Sık: ishal, bulantı, baş ağrısı.\n"
            "• CİDDİ YAN ETKİ: şiddetli alerjik reaksiyon, astım atağı, anafilaksi → ACİL doktora."
        ),
        "sonlandirma": "Tek doz tedavi.",
        "hatirlatma": "• Bol su, kızılcık suyu destekleyici.\n• Hijyene dikkat.",
    }),
    ("J05", {  # Antiviral
        "dikkat": (
            "• Şikayet başlangıcından itibaren EN KISA SÜREDE kullanmaya başlayın.\n"
            "• Böbrek/karaciğer yetmezliği olanlar doktor kontrolünde.\n"
            "• Gebelik ve emzirmede doktor onayı.\n"
            "• Bol sıvı tüketin.\n"
            "• Tedaviyi tamamlayınız."
        ),
        "etkilesim": "Çok sayıda ilaçla etkileşim — yeni ilaç başlarken doktor/eczacıya bildirin.",
        "yan_etki": (
            "• Sık: bulantı, baş ağrısı, ishal, yorgunluk.\n"
            "• CİDDİ YAN ETKİ: ciddi alerjik reaksiyon, karaciğer/böbrek hasarı, psikiyatrik belirtiler → doktora."
        ),
        "sonlandirma": "Reçeteyi tamamlayınız.",
        "hatirlatma": "• Dinlenme, bol sıvı destekleyici.",
    }),

    # ============================================================
    # M — KAS-İSKELET / AĞRI KESİCİLER
    # ============================================================
    ("M01AE", {  # Propiyonik asit türevi NSAİİ (ibuprofen, naproksen, ketoprofen)
        "dikkat": (
            "• Aspirin/NSAİİ alerjisi, aktif mide ülseri, ciddi kalp/karaciğer/böbrek yetmezliği olanlar kullanmamalı.\n"
            "• Astım hastalarında dikkat (nadir broncho spazm).\n"
            "• Gebeliğin SON 3 AYINDA kesinlikle kullanılmaz; ilk 6 ayda doktora danışılmalı.\n"
            "• Emzirme döneminde kısa süreli kullanılabilir, doktor onayı.\n"
            "• Yaşlılarda en düşük etkili doz tercih edilir.\n"
            "• Tok karnına alınız."
        ),
        "etkilesim": (
            "• Aspirin (kalp koruyucu doz dahil), varfarin, klopidogrel ile kanama riski.\n"
            "• ACE inhibitörü, ARB, diüretik etkisini azaltır; böbrek yetmezliği riski.\n"
            "• Lityum, metotreksat kan seviyesini yükseltir.\n"
            "• SSRI antidepresanlar ile mide kanaması riski.\n"
            "• Siklosporin, takrolimus ile böbrek toksisitesi.\n"
            "• Alkol mide kanama riskini artırır."
        ),
        "yan_etki": (
            "• Sık: bulantı, mide ağrısı, hazımsızlık, baş ağrısı, baş dönmesi, ödem.\n"
            "• CİDDİ YAN ETKİ: Mide kanaması (siyah dışkı, kan kusma), ani göğüs ağrısı (kalp krizi/inme), "
            "karaciğer hasarı (sarılık), böbrek yetmezliği, şiddetli ciltte döküntü (Stevens-Johnson) → ACİL doktora.\n"
            "• Uzun süreli kullanım kalp krizi ve inme riskini artırır."
        ),
        "sonlandirma": "Ağrı geçtiğinde bırakabilirsiniz; 5-7 günden uzun düzenli kullanmayın.",
        "hatirlatma": (
            "• Diş çekimi/ameliyat öncesi doktora bildirin.\n"
            "• Mide koruyucu (PPI) eşlik etmeli (yüksek risk grubunda).\n"
            "• Bol su tüketin (böbrek koruması)."
        ),
    }),
    ("M01AB", {  # Asetik asit türevi NSAİİ (diklofenak, etodolak, indometazin)
        "dikkat": (
            "• Aspirin/NSAİİ alerjisi, aktif ülser, ciddi kalp/karaciğer/böbrek yetmezliği olanlar kullanmamalı.\n"
            "• Kalp-damar hastalığı, geçirilmiş inme öyküsü olanlar dikkatli (kardiyovasküler risk yüksek).\n"
            "• Gebeliğin SON 3 AYINDA kesinlikle kullanılmaz.\n"
            "• Tok karnına alınız.\n"
            "• Uzun süreli kullanımda kan tablosu takibi."
        ),
        "etkilesim": (
            "• Varfarin, aspirin, klopidogrel ile kanama riski katlanır.\n"
            "• SSRI antidepresanlar, kortizon, lityum, metotreksat ile etkileşim.\n"
            "• Tansiyon ilaçlarının etkisini azaltır.\n"
            "• Siklosporin, takrolimus ile böbrek toksisitesi.\n"
            "• Alkol ile mide kanaması."
        ),
        "yan_etki": (
            "• Sık: bulantı, mide ağrısı, hazımsızlık, ishal, baş ağrısı, baş dönmesi, döküntü.\n"
            "• CİDDİ YAN ETKİ: Mide kanaması, kalp krizi/inme (artmış risk), karaciğer hasarı, "
            "böbrek yetmezliği, ciddi alerjik reaksiyon, Stevens-Johnson sendromu → ACİL doktora."
        ),
        "sonlandirma": "Ağrı geçtiğinde bırakın, 5-7 günden uzun düzenli kullanmayın.",
        "hatirlatma": "• En düşük etkili dozda en kısa sürede kullanın.\n• Diş çekimi/ameliyat öncesi bildirin.",
    }),
    ("M01AH", {  # Koksib (selekoksib, etorikoksib — COX-2 selektif)
        "dikkat": (
            "• Kalp hastalığı, geçirilmiş inme, periferik damar hastalığı olanlar dikkatli kullanmalı.\n"
            "• Aspirin/sülfonamid alerjisi olanlar kullanmamalı.\n"
            "• Aktif ülser/kanama olanlar kullanmamalı.\n"
            "• Gebeliğin son 3 ayında kullanılmaz.\n"
            "• En düşük etkili dozda en kısa sürede kullanın."
        ),
        "etkilesim": (
            "• ACE inhibitörü, ARB, diüretik etkisini azaltır.\n"
            "• Varfarin etkisini artırabilir.\n"
            "• Lityum kan seviyesini yükseltir.\n"
            "• Flukonazol selekoksib seviyesini yükseltir."
        ),
        "yan_etki": (
            "• Sık: hazımsızlık, baş ağrısı, ödem, tansiyon yükselmesi.\n"
            "• CİDDİ YAN ETKİ: Kalp krizi/inme (artmış risk), karaciğer hasarı, böbrek yetmezliği, "
            "ciddi alerjik reaksiyon → ACİL doktora."
        ),
        "sonlandirma": "Ağrı geçtiğinde bırakın.",
        "hatirlatma": "• Kardiyovasküler risk faktörleri olanlarda dikkat.",
    }),
    ("M02", {  # Topikal NSAİİ (cilt jeli/kremi)
        "dikkat": (
            "• Sadece DIŞ KULLANIM içindir.\n"
            "• Etkilenen bölgeye İNCE BİR TABAKA halinde sürünüz.\n"
            "• Göz, ağız, açık yara, mukoza temasından kaçının.\n"
            "• Geniş alana / uzun süreli kullanım sistemik yan etki yapabilir.\n"
            "• Güneşten korunun (fotosensitivite).\n"
            "• Aspirin/NSAİİ alerjisi olanlar kullanmamalı."
        ),
        "etkilesim": (
            "• Aynı bölgeye başka cilt ilacı uygulamayın.\n"
            "• Geniş alan/uzun süreli kullanım sistemik NSAİİ etkileşimi yapar (varfarin, ASA)."
        ),
        "yan_etki": (
            "• Sık: uygulama yerinde kızarıklık, kaşıntı, yanma, kuruluk.\n"
            "• CİDDİ YAN ETKİ: yaygın ciltte döküntü, kabarcık, fotosensitivite reaksiyonu → ilacı bırakın."
        ),
        "sonlandirma": "Şikayet geçince bırakın, 7-10 günden uzun rutin kullanmayın.",
        "hatirlatma": "• Uygulamadan önce ve sonra ellerinizi yıkayın.",
    }),
    ("M03B", {  # Santral kas gevşetici (tiyokolşikosid)
        "dikkat": (
            "• Uyku hali yapabilir — araç ve makine kullanmayınız.\n"
            "• Tedavi 5-7 GÜNDEN uzun sürmemelidir.\n"
            "• Gebelik (özellikle 1. trimester) ve emzirmede kullanılmaz.\n"
            "• Çocuklarda 16 yaş altı kullanılmaz.\n"
            "• Karaciğer/böbrek yetmezliği olanlar dikkatli kullanmalı."
        ),
        "etkilesim": "Alkol, sakinleştiriciler ve diğer uyku/sersemlik yapan ilaçlarla etkileri katlanır.",
        "yan_etki": (
            "• Sık: bulantı, ishal, mide ağrısı, uyku hali, ciltte döküntü.\n"
            "• CİDDİ YAN ETKİ: ciddi alerjik reaksiyon, hepatit (sarılık), nöbet → doktora."
        ),
        "sonlandirma": "Şikayet geçince bırakın, max 7 gün.",
        "hatirlatma": "• Sıcak duş, hafif egzersiz, masaj destekleyici.",
    }),

    # ============================================================
    # N02 — ANALJEZİK
    # ============================================================
    ("N02BE", {  # Parasetamol ve kombinasyonları
        "dikkat": (
            "• Karaciğer ve böbrek yetmezliği olanlar doktor kontrolünde kullanmalı.\n"
            "• Diğer parasetamol içeren ilaçlarla birlikte ALINMAZ (doz aşımı = karaciğer ölümü).\n"
            "• Alkol alanlarda günlük doz 2 gramı aşmamalı.\n"
            "• 24 saatte 4 dozdan fazla alınmaz, dozlar arası en az 4 saat.\n"
            "• Gebelik ve emzirmede güvenli kabul edilir."
        ),
        "etkilesim": (
            "• Varfarin etkisini artırabilir (kanama).\n"
            "• Alkol, izoniazid, karbamazepin karaciğer hasarı riskini artırır.\n"
            "• Soğuk algınlığı/grip ilaçlarında bulunur — kombine kullanımda doz aşımına dikkat."
        ),
        "yan_etki": (
            "• Sık: nadiren bulantı, kusma.\n"
            "• CİDDİ YAN ETKİ (yüksek dozda): KARACİĞER HASARI (ölümcül olabilir), kan tablosu bozukluğu, "
            "ciltte ciddi döküntü (Stevens-Johnson) → ACİL acil servis."
        ),
        "sonlandirma": "Ağrı/ateş geçince bırakın.",
        "hatirlatma": "• Diğer ilaçların etiketlerini kontrol edin — parasetamol içeriyor mu?",
    }),
    ("N02BA", {  # Salisilat (aspirin)
        "dikkat": (
            "• Aspirin alerjisi, aktif ülser, kanama bozukluğu olanlar kullanmamalı.\n"
            "• 16 yaş altı çocuklara verilmez (Reye sendromu riski).\n"
            "• Astım hastalarında dikkat (nadir bronkospazm).\n"
            "• Gebeliğin son 3 ayında kullanılmaz.\n"
            "• Diş çekimi/ameliyat öncesi 7-10 gün önceden bırakılması gerekebilir."
        ),
        "etkilesim": (
            "• Varfarin, klopidogrel, heparin ile birlikte ciddi kanama riski.\n"
            "• İbuprofen aspirinin kalp koruyucu etkisini azaltabilir; arada saat bırakın.\n"
            "• ACE inhibitörü, diüretik etkisini azaltır.\n"
            "• Metotreksat toksisitesini artırır.\n"
            "• Alkol mide kanama riskini artırır."
        ),
        "yan_etki": (
            "• Sık: mide ağrısı, mide yanması, hafif kanama (diş eti, burun).\n"
            "• CİDDİ YAN ETKİ: Mide kanaması (siyah dışkı, kan kusma), beyin kanaması (ani şiddetli baş ağrısı), "
            "şiddetli alerjik reaksiyon → ACİL doktora."
        ),
        "sonlandirma": "Düşük doz kan sulandırıcı amaçlı kullanıyorsa doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• Mide koruyucu eşlik edebilir.\n• Çocukta kullanılmaz.",
    }),
    ("N02BB", {  # Pirazolon (metamizol)
        "dikkat": (
            "• Metamizol alerjisi, kemik iliği hastalığı, akut intermittan porfiri olanlar kullanmamalı.\n"
            "• 3 ay altı bebeklere verilmez.\n"
            "• Gebeliğin son 3 ayında ve emzirmede kullanılmaz.\n"
            "• Çok sık veya uzun süreli kullanılmamalı.\n"
            "• Ateş, boğaz ağrısı, ağız yarası bildirin (agranülositoz belirtisi)."
        ),
        "etkilesim": "Siklosporin kan seviyesini düşürebilir. Alkol etkilerini artırır.",
        "yan_etki": (
            "• Sık: alerjik reaksiyon, idrarda kırmızı renk değişikliği (zararsız).\n"
            "• CİDDİ YAN ETKİ: AGRANÜLOSİTOZ (akyuvar ani düşmesi — ateş, halsizlik, boğaz ağrısı), "
            "anafilaktik şok, Stevens-Johnson sendromu, tansiyon düşmesi → ACİL acil servis."
        ),
        "sonlandirma": "Ağrı geçince bırakın.",
        "hatirlatma": "• Ani ateş veya boğaz ağrısı durumunda hemen kan tetkiki yaptırın.",
    }),
    ("N02A", {  # Opioid (kuvvetli ağrı kesici)
        "dikkat": (
            "• Doktorun belirlediği dozu aşmayın.\n"
            "• Solunum sorunu, ciddi karaciğer/böbrek hastalığı olanlar dikkatli kullanmalı.\n"
            "• Gebelik ve emzirmede kısıtlı kullanım.\n"
            "• Uyku hali ve solunum baskılanması — araç-makine kullanmayın.\n"
            "• Alkol ile birlikte alınmaz (tehlikeli)."
        ),
        "etkilesim": (
            "• Diğer uyku/sersemlik yapan ilaçlar, alkol, benzodiazepinler ile birlikte ölümcül solunum baskılanması.\n"
            "• MAO inhibitörü antidepresanlarla birlikte kullanılmaz."
        ),
        "yan_etki": (
            "• Sık: uyku hali, bulantı, kabızlık, ağız kuruluğu, kaşıntı, idrar yapamama.\n"
            "• CİDDİ: solunum baskılanması (yavaş/yüzeyel nefes), bilinç değişikliği, bağımlılık → doktora."
        ),
        "sonlandirma": "Ani kesilmez — kademeli azaltılır, doktor takibinde.",
        "hatirlatma": "• Alkol almayın.\n• Çocukların ulaşamayacağı yerde saklayın.",
    }),
    ("N02C", {  # Migren (triptanlar, ergot)
        "dikkat": (
            "• Atak başlangıcında erken alınız.\n"
            "• 24 saatte 2 dozdan fazla alınmaz.\n"
            "• Kalp hastalığı, hipertansiyon, geçirilmiş inme olanlar kullanmamalı.\n"
            "• Aurali migrende dikkat.\n"
            "• Gebelik ve emzirmede kullanılmaz."
        ),
        "etkilesim": (
            "• MAO inhibitörü antidepresanlar ile birlikte kullanılmaz.\n"
            "• SSRI ile birlikte serotonin sendromu riski.\n"
            "• Ergot türevleri ile birlikte alınmaz.\n"
            "• Diğer triptanlardan 24 saat ara verin."
        ),
        "yan_etki": (
            "• Sık: göğüste sıkışma hissi, baş dönmesi, sıcaklık hissi, yorgunluk, ağız kuruluğu.\n"
            "• CİDDİ YAN ETKİ: göğüs ağrısı, çarpıntı, görme kaybı, inme belirtileri → ACİL."
        ),
        "sonlandirma": "Atak geçince bırakın. Aylık 10+ kullanım kronik baş ağrısı (rebound) yapar.",
        "hatirlatma": "• Migren günlüğü tutun, tetikleyicileri belirleyin.",
    }),

    # ============================================================
    # A — SİNDİRİM SİSTEMİ
    # ============================================================
    ("A02BC", {  # PPI (pantoprazol, lansoprazol, esomeprazol, omeprazol)
        "dikkat": (
            "• Aç karnına, kahvaltıdan en az 30-60 dakika önce alınız.\n"
            "• Tableti çiğnemeden, bütün olarak yutunuz.\n"
            "• Uzun süreli kullanımda B12, magnezyum, kalsiyum eksikliği gelişebilir.\n"
            "• Karaciğer yetmezliği olanlar dikkatli kullanmalı.\n"
            "• Gebelik ve emzirmede doktora danışınız.\n"
            "• Uzun süreli (>1 yıl) kullanım için doktor değerlendirsin."
        ),
        "etkilesim": (
            "• Klopidogrel etkisini azaltabilir (kalp riski).\n"
            "• HIV ilaçları (atazanavir, nelfinavir) emilimi düşer.\n"
            "• Demir, B12, ketokonazol, dasatinib emilimi azalır.\n"
            "• Varfarin etkisini artırabilir.\n"
            "• Diazepam, fenitoin kan seviyelerini etkileyebilir.\n"
            "• Metotreksat toksisitesini artırabilir."
        ),
        "yan_etki": (
            "• Sık: baş ağrısı, ishal, kabızlık, mide ağrısı, bulantı, gaz.\n"
            "• CİDDİ YAN ETKİ: kemik kırığı riski (uzun süreli), şiddetli ishal (C. difficile), "
            "düşük magnezyum (kas krampları, çarpıntı), B12 eksikliği, böbrek hasarı, "
            "Stevens-Johnson sendromu → doktora."
        ),
        "sonlandirma": (
            "Doktor önerisi ile süre belirlenir. Uzun süreli kullanımda kademeli azaltma "
            "(ani kesim mide asit sıçraması yapar)."
        ),
        "hatirlatma": (
            "• Yağlı/baharatlı yemekler, kahve, sigara, alkol şikayeti tetikler.\n"
            "• Yatağın baş tarafını yükseltin, yatmadan önce yemek yemeyin."
        ),
    }),
    ("A02BA", {  # H2 reseptör blokeri (famotidin, ranitidin)
        "dikkat": (
            "• Yemekle veya yatmadan önce alınabilir.\n"
            "• Böbrek yetmezliği olanlar doz ayarlaması ile kullanmalı.\n"
            "• Gebelik ve emzirmede doktor onayı.\n"
            "• Yaşlılarda konfüzyon yapabilir."
        ),
        "etkilesim": "Antiasitler emilimini azaltır. Bazı ilaçların emilimini etkiler.",
        "yan_etki": "• Sık: baş ağrısı, baş dönmesi, ishal veya kabızlık.\n• CİDDİ: kan tablosu bozukluğu, kalp ritm değişiklikleri → doktora.",
        "sonlandirma": "Şikayet geçince bırakılabilir.",
        "hatirlatma": "• Yaşam tarzı değişiklikleri ilaç ihtiyacını azaltır.",
    }),
    ("A02BX", {  # Reflü (aljinik asit, sodyum aljinat)
        "dikkat": (
            "• Yemeklerden sonra ve yatmadan önce kullanınız.\n"
            "• Kullanmadan önce şişeyi çalkalayın.\n"
            "• Diğer ilaçlarınızla en az 2 saat ara veriniz.\n"
            "• Sodyum kısıtlı diyettekiler doktora danışmalı.\n"
            "• 12 yaş altı çocuklarda doktor onayı."
        ),
        "etkilesim": "Demir, tetrasiklin, tiroid ilaçları, antibiyotik emilimini düşürür — 2 saat ara.",
        "yan_etki": "• Sık: nadiren bulantı, kabızlık veya ishal.\n• CİDDİ: alerjik reaksiyon nadir → ilacı bırakın.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "• Yatağın baş tarafını yükseltin.",
    }),
    ("A03B", {  # Antispazmodik (butilskopolamin, hyosin)
        "dikkat": (
            "• Glokom, prostat büyümesi, miyastenia gravis, bağırsak tıkanıklığı olanlar kullanmamalı.\n"
            "• Ağız kuruluğu, görme bulanıklığı yapar — araç kullanırken dikkat.\n"
            "• Kalp ritm bozukluğu (taşikardi) olanlar dikkatli."
        ),
        "etkilesim": "Diğer antikolinerjikler (bazı antidepresanlar, parkinson ilaçları) ile etkileri katlanır.",
        "yan_etki": "• Sık: ağız kuruluğu, görme bulanıklığı, kabızlık, çarpıntı, idrara çıkma güçlüğü.\n• CİDDİ: akut glokom atağı (ani göz ağrısı), idrar yapamama → doktora.",
        "sonlandirma": "Ağrı geçince bırakın.",
        "hatirlatma": "• Yeterli sıvı tüketin.",
    }),
    ("A03F", {  # Bulantı kesici (domperidon, metoklopramid)
        "dikkat": (
            "• 5-7 günden uzun süre kullanılmaz (uzun kullanım hareket bozukluğu yapabilir).\n"
            "• Parkinson, epilepsi, mide-bağırsak tıkanıklığı olanlar kullanmamalı.\n"
            "• Uyku/sersemlik (metoklopramid) — araç kullanmayın.\n"
            "• Kalp ritm bozukluğu öyküsü olanlar dikkat (domperidon QT uzaması)."
        ),
        "etkilesim": (
            "• Antikolinerjik ilaçlar etkisini azaltır.\n"
            "• Levodopa etkisini azaltır.\n"
            "• Alkol/uyku ilaçları ile sersemlik artar.\n"
            "• QT uzatan ilaçlarla birlikte aritmi riski."
        ),
        "yan_etki": (
            "• Sık: uyku hali (metoklopramid), prolaktin yükselmesi, baş ağrısı.\n"
            "• CİDDİ YAN ETKİ (metoklopramid): yüz/dilde istemsiz hareket (ekstrapiramidal), "
            "kas sertliği + ateş (NMS), depresyon → ACİL doktora."
        ),
        "sonlandirma": "Bulantı geçince bırakın, max 5-7 gün.",
        "hatirlatma": "• Az ve sık beslenme bulantıyı azaltır.",
    }),
    ("A04", {  # Bulantı/kusma (5-HT3, NK1 antagonistleri)
        "dikkat": (
            "• Karaciğer yetmezliği olanlar doz ayarlaması ile kullanmalı.\n"
            "• Gebelik ve emzirmede doktor onayı.\n"
            "• Kalp ritm bozukluğu (uzun QT) olanlar dikkat."
        ),
        "etkilesim": "QT uzatan ilaçlarla birlikte aritmi. SSRI ile serotonin sendromu (nadir).",
        "yan_etki": "• Sık: baş ağrısı, kabızlık, yorgunluk.\n• CİDDİ: kalp ritm bozukluğu → doktora.",
        "sonlandirma": "İhtiyaca göre kullanılır.",
        "hatirlatma": "• Az ve sık beslenme, sıvı destekleyici.",
    }),
    ("A06", {  # Laksatif
        "dikkat": (
            "• Bağırsak tıkanıklığı şüphesinde kullanılmaz.\n"
            "• Bol su tüketin.\n"
            "• Şeker hastaları dikkatli (laktüloz içeriği şeker).\n"
            "• Uzun süreli kullanım elektrolit bozukluğu yapar."
        ),
        "etkilesim": "Bazı ilaçların emilimini etkileyebilir.",
        "yan_etki": "• Sık: gaz, şişkinlik, karın krampı, ishal.\n• CİDDİ: ciddi elektrolit bozukluğu → doktora.",
        "sonlandirma": "Bağırsak düzeni sağlanınca bırakın.",
        "hatirlatma": "• Lifli beslenme, bol su, hareket uzun vadeli çözüm.",
    }),
    ("A07", {  # Antidiyareik / probiyotik
        "dikkat": (
            "• Kanlı veya ateşli ishalde kullanılmaz (doktor değerlendirsin).\n"
            "• Bol sıvı tüketin (oral rehidratasyon önemli).\n"
            "• 2 günden uzun süren ishalde doktora başvurun."
        ),
        "etkilesim": "Antibiyotikler ile arada 2 saat ara verin.",
        "yan_etki": "• Sık: nadiren kabızlık, hafif karın ağrısı.",
        "sonlandirma": "İshal geçince bırakın.",
        "hatirlatma": "• Hijyene dikkat.",
    }),
    ("A09", {  # Sindirim enzimi
        "dikkat": "• Yemekle birlikte alınır.\n• Ezmeyiniz, çiğnemeyiniz (enterik kaplı).",
        "etkilesim": "Önemli ilaç etkileşimi yoktur.",
        "yan_etki": "• Sık: nadiren karın ağrısı, ishal.",
        "sonlandirma": "İhtiyaca göre kullanılır.",
        "hatirlatma": "• Düşük yağlı beslenme destekleyici.",
    }),
    ("A10A", {  # İnsülin
        "dikkat": (
            "• Cilt altına (göbek, uyluk, kol) enjekte edilir, bölge dönüşümlü.\n"
            "• BUZDOLABINDA (2-8°C) saklanır; kullanımdaki kalem oda sıcaklığında 28 gün dayanır.\n"
            "• Dondurmayın.\n"
            "• Doz atlamayın — şeker yükselir.\n"
            "• Tip 1 diyabette ASLA bırakmayın (ölümcül)."
        ),
        "etkilesim": (
            "• Alkol, beta-bloker, MAO inhibitörü düşük şeker etkisini artırır.\n"
            "• Kortizon, diüretik, hormonal doğum kontrol şekeri yükseltir."
        ),
        "yan_etki": (
            "• Sık: düşük şeker (terleme, titreme, çarpıntı, açlık), kilo artışı, lipodistrofi.\n"
            "• CİDDİ: şiddetli hipoglisemi (bilinç kaybı) → ACİL şeker verin / acil servis."
        ),
        "sonlandirma": "ASLA bırakmayın.",
        "hatirlatma": (
            "• Şeker ölçer + glukagon kalemi + hızlı şeker kaynağı yanınızda olsun.\n"
            "• Düşük şeker kartı taşıyın."
        ),
    }),
    ("A10B", {  # Oral antidiyabetik (metformin, sülfonilüre, DPP-4, SGLT2)
        "dikkat": (
            "• Her gün aynı saatlerde, yemekle alınız.\n"
            "• Aç kalmak / öğün atlama düşük şeker yapar.\n"
            "• Röntgen/tomografide kontrast madde öncesi metformin bırakılmalı.\n"
            "• Ciddi enfeksiyon, ameliyat, hamileliği doktora bildirin.\n"
            "• Ciddi böbrek/karaciğer hastalığı olanlar dikkatli kullanmalı.\n"
            "• SGLT2 inhibitörleri: idrar yolu enfeksiyonu, mantar riski; bol su."
        ),
        "etkilesim": (
            "• Alkol düşük şeker riskini artırır (metformin için laktik asidoz).\n"
            "• Kortizon, diüretik şekeri yükseltir.\n"
            "• Beta-bloker düşük şeker belirtilerini maskeleyebilir."
        ),
        "yan_etki": (
            "• Sık: bulantı, ishal (metformin), düşük şeker, kilo değişimi.\n"
            "• CİDDİ YAN ETKİ: laktik asidoz (metformin — yorgunluk, kas ağrısı, hızlı nefes), "
            "şiddetli düşük şeker, diyabetik ketoasidoz (SGLT2 — bulantı, derin nefes), "
            "Fournier kangreni (SGLT2 — genital bölgede şiddetli ağrı) → ACİL."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": (
            "• Şeker ölçer ile düzenli takip.\n"
            "• Beslenme + egzersiz tedavinin ayrılmaz parçası.\n"
            "• Düşük şeker kartı taşıyın."
        ),
    }),
    ("A11C", {  # D vitamini
        "dikkat": (
            "• Doktor önerisi olmadan yüksek doz kullanmayın (toksik olabilir).\n"
            "• Hiperkalsemi, böbrek taşı, ciddi böbrek yetmezliği olanlar kullanmamalı.\n"
            "• Damla formunda dozu damla ile doğru ölçün.\n"
            "• Bebeklerde doz aşımına dikkat."
        ),
        "etkilesim": "Tiyazid diüretik ile kalsiyum yükselir. Digoksin ile ritm bozukluğu riski. Antiepileptikler D etkisini azaltır.",
        "yan_etki": "• Sık (normal dozda): nadirdir.\n• CİDDİ (yüksek doz): iştahsızlık, susama, sık idrar, kabızlık, kas güçsüzlüğü → doktora.",
        "sonlandirma": "Kan değeri normale gelince doz ayarlanır.",
        "hatirlatma": "• Güneş ışığı doğal D vitamini kaynağıdır (haftada 2-3 kez 15-20 dk).",
    }),
    ("A11D", {  # B kompleks vitamini
        "dikkat": "• Önerilen dozdan fazla kullanmayın.\n• İdrarda sarımsı renk yapar (B2 — zararsız).",
        "etkilesim": "B6 levodopa etkisini azaltır. Fenitoin, izoniazid ile etkileşim.",
        "yan_etki": "• Sık: nadiren bulantı, hafif ishal.\n• CİDDİ (yüksek doz B6): el-ayakta uyuşma → doktora.",
        "sonlandirma": "Eksiklik düzelince bırakın.",
        "hatirlatma": "• Et, tahıl, baklagil, yumurta doğal kaynaklardır.",
    }),
    ("A12A", {  # Kalsiyum
        "dikkat": "• Bol su ile alınız.\n• Demir/tiroid ilaçlarınızdan 2 saat ayrı alın.",
        "etkilesim": "Levotiroksin, tetrasiklin, kinolon, demir emilimini azaltır — 2 saat ara.",
        "yan_etki": "• Sık: kabızlık, gaz.\n• CİDDİ: yüksek kalsiyum (uzun süreli) → bulantı, kafa karışıklığı.",
        "sonlandirma": "İhtiyaç bitince bırakın.",
        "hatirlatma": "• D vitamini ile birlikte alındığında emilim artar.",
    }),
    ("A12B", {  # Potasyum
        "dikkat": (
            "• Yemekle veya bol su ile alınız (mide tahrişi).\n"
            "• Yutma güçlüğü olanlar dikkatli kullanmalı.\n"
            "• Ciddi böbrek yetmezliği olanlar kullanmamalı."
        ),
        "etkilesim": "Potasyum tutucu diüretik, ACE/ARB ile birlikte yüksek potasyum riski.",
        "yan_etki": "• Sık: bulantı, kusma, ishal.\n• CİDDİ: yüksek potasyum (çarpıntı, kas güçsüzlüğü) → ACİL.",
        "sonlandirma": "Kan değeri normale gelince doz ayarlanır.",
        "hatirlatma": "• Düzenli kan testi gerekir.",
    }),
    ("A12C", {  # Diğer mineraller (çinko, magnezyum)
        "dikkat": "• Aç karnına bulantı yapabilir, yemekle alın.\n• Önerilen dozdan fazla kullanmayın.",
        "etkilesim": "Tetrasiklin, kinolon, tiroid ilacı emilimini azaltır — 2 saat ara.",
        "yan_etki": "• Sık: bulantı, ishal (magnezyum) veya kabızlık.",
        "sonlandirma": "Eksiklik düzelince bırakın.",
        "hatirlatma": "• Çeşitli beslenme tercih edilir.",
    }),

    # ============================================================
    # C — KALP-DAMAR
    # ============================================================
    ("C07", {  # Beta-blokör (metoprolol, bisoprolol, atenolol, karvedilol)
        "dikkat": (
            "• ANİ KESMEYİN — kademeli azaltılmalı (çarpıntı, kalp krizi riski).\n"
            "• Astım, ağır kalp bloğu, ciddi düşük tansiyon olanlar kullanmamalı.\n"
            "• Şeker hastalarında düşük şeker belirtilerini maskeleyebilir.\n"
            "• Tableti çiğnemeden bütün yutunuz.\n"
            "• Gebelik ve emzirmede doktora danışınız.\n"
            "• Tansiyon ve nabız düzenli takip."
        ),
        "etkilesim": (
            "• Diğer tansiyon ilaçlarıyla birlikte etkileri katlanır.\n"
            "• Verapamil, diltiazem ile birlikte ciddi yavaş kalp atışı, AV blok.\n"
            "• İnsulin/oral antidiyabetiklerle düşük şeker maskelenir.\n"
            "• NSAİİ etkiyi azaltır.\n"
            "• Alkol tansiyon düşmesini şiddetlendirir."
        ),
        "yan_etki": (
            "• Sık: yorgunluk, baş dönmesi, soğuk eller-ayaklar, yavaş kalp atışı, ereksiyon sorunu.\n"
            "• CİDDİ YAN ETKİ: çarpıntı/baygınlık, nefes darlığı, ayaklarda şişme (kalp yetmezliği), "
            "ciddi yavaş kalp atışı → ACİL doktora."
        ),
        "sonlandirma": "Kademeli azaltılır — 1-2 hafta süresince.",
        "hatirlatma": "• Diş çekimi/ameliyat öncesi bildirin.\n• Tansiyonunuzu evde takip edin.",
    }),
    ("C08", {  # Kalsiyum kanal blokeri (amlodipin, nifedipin, diltiazem)
        "dikkat": (
            "• Düşük tansiyon, ciddi kalp yetmezliği olanlar dikkatli kullanmalı.\n"
            "• Her gün aynı saatte alınız.\n"
            "• Yiyecek emilimi etkilemez (bazıları hariç).\n"
            "• Gebelik ve emzirmede doktor onayı.\n"
            "• Diş eti büyümesi olabilir — diş hijyenine dikkat."
        ),
        "etkilesim": (
            "• GREYFURT SUYU ile birlikte kan seviyesi tehlikeli yükselir.\n"
            "• Beta-bloker + verapamil/diltiazem → ciddi AV blok.\n"
            "• Statinler ile birlikte kas hasarı riski.\n"
            "• Siklosporin, takrolimus seviyesini etkileyebilir."
        ),
        "yan_etki": (
            "• Sık: ayaklarda şişme, baş ağrısı, kızarıklık, çarpıntı, kabızlık.\n"
            "• CİDDİ YAN ETKİ: ciddi tansiyon düşmesi, kalp yetmezliği belirtileri, AV blok → doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• Greyfurt sudan uzak durun.\n• Tansiyon takibi.",
    }),
    ("C09AA", {  # ACE inhibitörü (ramipril, enalapril, lisinopril)
        "dikkat": (
            "• İlk doz sonrası tansiyon düşmesi olabilir (yavaş kalkın).\n"
            "• Anjiyoödem öyküsü olanlar kullanmamalı.\n"
            "• Gebelikte KESİNLİKLE KULLANILMAZ (fetal hasar).\n"
            "• Hiperpotasemi riski — düzenli kan testi.\n"
            "• Aort darlığı, böbrek arter darlığı olanlar dikkatli kullanmalı.\n"
            "• Cerrahi öncesi doktora bildirin."
        ),
        "etkilesim": (
            "• NSAİİ ile birlikte böbrek yetmezliği riski.\n"
            "• Potasyum tutucu diüretik, potasyum desteği ile birlikte hiperpotasemi.\n"
            "• Lityum kan seviyesini yükseltir.\n"
            "• Diğer tansiyon ilaçlarıyla birlikte aşırı düşüş."
        ),
        "yan_etki": (
            "• Sık: KURU İNATÇI ÖKSÜRÜK, baş dönmesi, baş ağrısı, halsizlik.\n"
            "• CİDDİ YAN ETKİ: ANJİYOÖDEM (yüz/dilde ani şişme, nefes darlığı) → ACİL acil servis, "
            "böbrek yetmezliği, hiperpotasemi → doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• Kuru öksürük varsa ARB grubuna geçiş düşünülebilir (doktor).",
    }),
    ("C09C", {  # ARB (valsartan, losartan, candesartan)
        "dikkat": (
            "• Gebelikte KESİNLİKLE KULLANILMAZ.\n"
            "• Anjiyoödem öyküsü, ciddi karaciğer hastalığı olanlar dikkatli.\n"
            "• Hiperpotasemi riski.\n"
            "• Düzenli kan testi (böbrek, potasyum)."
        ),
        "etkilesim": "ACE inhibitörü ile aynı etkileşimler. NSAİİ ile böbrek riski.",
        "yan_etki": (
            "• Sık: baş dönmesi, yorgunluk, baş ağrısı (ACE'den daha az öksürük).\n"
            "• CİDDİ: anjiyoödem (nadir), böbrek yetmezliği → doktora."
        ),
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli tansiyon takibi.",
    }),
    ("C09B", {  # ACE/ARB kombinasyonu (diüretikli)
        "dikkat": (
            "• Sabah alınması önerilir (gece tuvalete kalkmamak).\n"
            "• Potasyum dengesine dikkat (hipopotasemi olabilir).\n"
            "• Gebelikte KESİNLİKLE KULLANILMAZ.\n"
            "• Sülfa alerjisi olanlarda dikkat (tiyazid)."
        ),
        "etkilesim": "ACE/ARB ve diüretik etkileşimlerinin toplamı.",
        "yan_etki": "• Sık: baş dönmesi, sık idrara çıkma, kas krampları.\n• CİDDİ: anjiyoödem, böbrek hasarı, elektrolit bozukluğu → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Yeterli sıvı, potasyumlu gıdalar (muz, portakal).",
    }),
    ("C03", {  # Diüretik
        "dikkat": (
            "• Sabah erken alınız (gece sık idrara kalkma önlemek için).\n"
            "• POTASYUM DÜŞEBİLİR (furosemid/tiazidlerde) — halsizlik, bacak krampı, "
            "çarpıntı varsa doktora bildirin; muz, kuru kayisi, portakal tüketimi yardımcı olur.\n"
            "• Tiazidler güneşe karşı cilt hassasiyeti yapabilir — güneşten korunun.\n"
            "• Gut hastalığı, diyabet, böbrek sorunu olanlar dikkatli kullanmalı.\n"
            "• Ayağa kalkışta baş dönmesi → yavaş kalkın (özellikle yaşlılarda düşme riski)."
        ),
        "etkilesim": (
            "• Digoksin ile potasyum düşerse ritim bozukluğu riski artar.\n"
            "• NSAİİ (ağrı kesici) diüretik etkisini azaltır.\n"
            "• Lityum kan seviyesini yükseltir — psikiyatrik ilaç kullananlar bildirsin.\n"
            "• Spironolakton potasyum TUTAR — ACE inhibitörü ile kombinasyon hiperkalemi yapabilir."
        ),
        "yan_etki": "• Sık: sık idrara çıkma, baş dönmesi, kas krampları, ağız kuruluğu.\n• CİDDİ: ciddi elektrolit bozukluğu (K⁺ düşmesi), dehidratasyon, gut atağı → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Günlük tartılın — kilo artışı sıvı tutulumuna işaret edebilir.",
    }),
    ("C10AA", {  # Statin (atorvastatin, rosuvastatin, simvastatin)
        "dikkat": (
            "• Aktif karaciğer hastalığı olanlar kullanmamalı.\n"
            "• Gebelik ve emzirmede KESİNLİKLE kullanılmaz.\n"
            "• Düzenli karaciğer enzim ve kas (CK) takibi.\n"
            "• Kas ağrısı/güçsüzlüğünü bildirin.\n"
            "• Akşam alınması daha etkilidir."
        ),
        "etkilesim": (
            "• Siklosporin, klaritromisin, eritromisin, antimantar (azol) ile kas hasarı riski artar.\n"
            "• GREYFURT SUYU ile birlikte alınmaz (özellikle simvastatin, lovastatin).\n"
            "• Fibrik asit türevleri ile birlikte rabdomiyoliz riski.\n"
            "• Varfarin etkisini artırabilir."
        ),
        "yan_etki": (
            "• Sık: kas ağrısı, baş ağrısı, sindirim şikayetleri.\n"
            "• CİDDİ YAN ETKİ: Şiddetli kas ağrısı + koyu idrar (rabdomiyoliz), karaciğer hasarı, "
            "yeni başlayan şeker hastalığı, periferik nöropati → ACİL doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• Diyet + egzersiz ilaç etkisini artırır.\n• Yılda 1 karaciğer + lipid panel kontrolü.",
    }),
    ("C10AX", {  # Ezetimib / kombi
        "dikkat": "• Karaciğer hastalığı olanlar dikkatli.\n• Gebelik ve emzirmede kullanılmaz.",
        "etkilesim": "Siklosporin, fibrat ile etkileşim.",
        "yan_etki": "• Sık: ishal, kas ağrısı, baş ağrısı.\n• CİDDİ: karaciğer hasarı, kas hasarı → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Diyet desteği önemli.",
    }),
    ("C01", {  # Kalp ilacı genel (digoksin, antiaritmik)
        "dikkat": (
            "• Her gün aynı saatte alınız.\n"
            "• Nabzınızı düzenli kontrol edin.\n"
            "• Düşük potasyum, ciddi kalp blokları olanlar dikkat.\n"
            "• Diş eti büyümesi (bazı antiaritmikler) — diş hijyenine dikkat."
        ),
        "etkilesim": "Çok sayıda etkileşim — yeni ilaç başlarken doktora bildirin.",
        "yan_etki": "• Sık: yorgunluk, baş dönmesi, bulantı.\n• CİDDİ: ciddi yavaş kalp atışı, ritm bozukluğu, görme bozukluğu → ACİL.",
        "sonlandirma": "Ani kesilmez.",
        "hatirlatma": "• Düzenli kan testi (digoksin seviyesi).",
    }),
    ("C02", {  # Antihipertansif diğer
        "dikkat": "• Tansiyonu düzenli takip edin.\n• Ani kesmeyin.",
        "etkilesim": "Diğer tansiyon ilaçları ile birlikte aşırı düşüş.",
        "yan_etki": "• Sık: baş dönmesi, yorgunluk, ağız kuruluğu.\n• CİDDİ: ciddi tansiyon düşmesi → doktora.",
        "sonlandirma": "Kademeli azaltma.",
        "hatirlatma": "• Tuzsuz/az tuzlu diyet destekleyici.",
    }),
    ("C04", {  # Periferik vazodilatör
        "dikkat": "• Her gün düzenli alınız.\n• Bol su için.",
        "etkilesim": "Diğer tansiyon ilaçları ile etki katlanır.",
        "yan_etki": "• Sık: nadiren mide şikayetleri, baş ağrısı, ayaklarda şişme.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli yürüyüş dolaşımı artırır.",
    }),
    ("C05A", {  # Hemoroid / anal fissür (topikal rektal) — C05'ten ÖNCE
        "dikkat": (
            "• REKTAL kullanım — makat bölgesine uygulanır, YUTULMAZ.\n"
            "• Tuvaletten sonra bölgeyi temizleyip kurulayarak uygulayın.\n"
            "• Makattan kanama sürerse veya 1 haftada düzelmezse doktora başvurun."
        ),
        "etkilesim": "Lokal etkilidir, sistemik etkileşim azdır.",
        "yan_etki": "• Sık: uygulama bölgesinde yanma, batma, kaşıntı.",
        "sonlandirma": "Şikayet geçince bırakın; kortizonluları uzun süre kullanmayın.",
        "hatirlatma": "• Lifli beslenme, bol su, hareket kabızlığı önler; tuvalette uzun süre ıkınmayın.",
    }),
    ("C05", {  # Varis / hemoroid
        "dikkat": "• Genelde harici uygulama; sadece dış kullanım.\n• Hijyen sonrası uygulayın.",
        "etkilesim": "Lokal etkilidir, sistemik etkileşim azdır.",
        "yan_etki": "• Sık: uygulama bölgesinde yanma, kaşıntı.",
        "sonlandirma": "Şikayet geçince bırakın.",
        "hatirlatma": "• Lifli beslenme, bol su, hareket destekleyici.",
    }),

    # ============================================================
    # B — KAN
    # ============================================================
    ("B01AC", {  # Antiplatelet (klopidogrel, tikagrelor, aspirin düşük doz)
        "dikkat": (
            "• Aktif kanama, ciddi karaciğer hastalığı olanlar kullanmamalı.\n"
            "• Diş çekimi, ameliyat öncesi doktora bildirin (5-7 gün önce bırakılabilir).\n"
            "• Mide ülseri öyküsü olanlar mide koruyucu ile birlikte kullanmalı.\n"
            "• KESİNLİKLE bırakmayın (kalp krizi/inme riski)."
        ),
        "etkilesim": (
            "• Diğer kan sulandırıcılarla birlikte kanama riski katlanır.\n"
            "• NSAİİ, SSRI ile kanama riski.\n"
            "• Omeprazol/esomeprazol klopidogrel etkisini azaltabilir.\n"
            "• Statinler, antifungaller seviyeyi etkileyebilir."
        ),
        "yan_etki": (
            "• Sık: olağandışı morarma, hafif burun/diş eti kanaması, sindirim şikayetleri.\n"
            "• CİDDİ YAN ETKİ: Şiddetli kanama (siyah/kanlı dışkı, kan kusma, ani baş ağrısı), "
            "kan tablosu bozukluğu (TTP), şiddetli alerjik reaksiyon → ACİL doktora."
        ),
        "sonlandirma": "ASLA doktor önerisi olmadan bırakmayın.",
        "hatirlatma": (
            "• Yumuşak diş fırçası, elektrikli tıraş makinesi.\n"
            "• Düşmekten kaçının.\n"
            "• Ağrı için parasetamol tercih edin."
        ),
    }),
    ("B01AB", {  # LMW heparin (enoksaparin, dalteparin)
        "dikkat": (
            "• Sağlık personeli veya eğitimli hasta tarafından cilt altına uygulanır.\n"
            "• Bölgeyi her seferinde değiştirin.\n"
            "• Heparin alerjisi, aktif kanama olanlar kullanmamalı.\n"
            "• Düşme/yaralanmadan kaçının.\n"
            "• Diş çekimi/ameliyat öncesi doktora bildirin."
        ),
        "etkilesim": "Diğer kan sulandırıcılarla kanama riski katlanır. NSAİİ mide kanaması.",
        "yan_etki": (
            "• Sık: enjeksiyon yerinde morarma, kabarık.\n"
            "• CİDDİ YAN ETKİ: şiddetli kanama, ani baş ağrısı, trombositopeni (HIT) → ACİL doktora."
        ),
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Saklama koşullarına dikkat (oda sıcaklığı — kutuda yazılı).",
    }),
    ("B01AA", {  # Varfarin
        "dikkat": (
            "• Doz BİREYSEL — INR takibi ile ayarlanır.\n"
            "• Düzenli kan testi şart.\n"
            "• K vitamini içerikli yeşil yapraklı sebzeleri DÜZENLİ tüketin (ani değişim yapmayın).\n"
            "• Alkol etkileşir, sınırlı tüketin.\n"
            "• Gebelikte KESİNLİKLE kullanılmaz."
        ),
        "etkilesim": (
            "• ÇOK SAYIDA ilaçla etkileşim — yeni ilaç başlarken doktora bildirin.\n"
            "• Antibiyotik (özellikle siprofloksasin, metronidazol), amiodaron, fluvastatin etkisini artırır.\n"
            "• Karbamazepin, rifampin etkisini azaltır.\n"
            "• Greyfurt suyu, cranberry suyu etkisini artırır.\n"
            "• NSAİİ, aspirin ile kanama riski."
        ),
        "yan_etki": "• Sık: hafif kanama, morarma.\n• CİDDİ: şiddetli kanama (siyah dışkı, kanlı idrar, ani baş ağrısı) → ACİL.",
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• Kan sulandırıcı kartı taşıyın.\n• INR hedef aralığında kalmalı.",
    }),
    ("B01AF", {  # DOAK (rivaroksaban, apiksaban, edoksaban)
        "dikkat": (
            "• Aktif kanama, ciddi karaciğer hastalığı olanlar kullanmamalı.\n"
            "• Diş çekimi/ameliyat öncesi 24-48 saat önce bırakılır (doktor önerisiyle).\n"
            "• Gebelikte kullanılmaz.\n"
            "• Böbrek yetmezliği olanlar doz ayarlaması ile kullanmalı."
        ),
        "etkilesim": (
            "• Güçlü CYP3A4 inhibitörü (klaritromisin, antimantar) ile birlikte kanama riski.\n"
            "• NSAİİ, aspirin ile birlikte kanama riski.\n"
            "• Karbamazepin, fenitoin etkisini azaltır."
        ),
        "yan_etki": "• Sık: hafif kanama (diş eti, burun), morarma.\n• CİDDİ: şiddetli kanama → ACİL.",
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• İlaç kartı taşıyın.\n• Düşmekten kaçının.",
    }),
    ("B03", {  # Antianemik
        "dikkat": (
            "• Demir: aç karnına emilim iyi, mide şikayetinde tok karnına.\n"
            "• Süt/çay/kahve ile alınmaz (emilim düşer).\n"
            "• Dışkıda siyah renk (zararsız).\n"
            "• Çocuklarda doz aşımı tehlikelidir.\n"
            "• B12 (kobalamin) genelde kas içine uygulanır."
        ),
        "etkilesim": "Levotiroksin, kinolon, tetrasiklin, antiasit emilimi etkilenir.",
        "yan_etki": "• Sık: bulantı, kabızlık, ishal (demir).\n• CİDDİ: çocuk yutması → ACİL.",
        "sonlandirma": "Kan değerleri normale gelince doktor karar verir (3-6 ay).",
        "hatirlatma": "• C vitamini ile birlikte demir emilimi artar.",
    }),

    # ============================================================
    # H — HORMON
    # ============================================================
    ("H02AB", {  # Sistemik kortikosteroid (metilprednizolon, deksametazon, prednizolon)
        "dikkat": (
            "• KESİNLİKLE ani kesmeyin (adrenal yetmezlik) — kademeli azaltma.\n"
            "• TUZ ALIMINI AZALTIN — kortizol vücutta sodyum/su tutar, şişlik ve tansiyon yapar.\n"
            "• ŞEKERLİ VE NIŞASTALI GIDALARDAN KAÇININ — kan şekerini yükseltir; diyabetlilerde özellikle önemli.\n"
            "• Enfeksiyon riski artar — temas hijyeni, canlı aşı yapılmaz.\n"
            "• Şeker hastalığı, tansiyon, osteoporoz, ülser, glokom olanlar dikkatli kullanmalı.\n"
            "• Yemekle alınız (mide koruyucu)."
        ),
        "etkilesim": (
            "• NSAİİ ile mide kanaması riski.\n"
            "• Diüretik ile potasyum düşmesi.\n"
            "• Şeker ilaçlarının dozu artabilir.\n"
            "• CYP3A4 inhibitörleri/indüktörleri seviyeyi etkiler.\n"
            "• Varfarin etkisini artırabilir."
        ),
        "yan_etki": (
            "• Sık: kilo artışı, ay yüzü, kan şekeri yükselmesi, uyku düzensizliği, ruh hali değişikliği, mide şikayetleri.\n"
            "• CİDDİ YAN ETKİ: ciddi enfeksiyon, mide kanaması, görme bozukluğu (katarakt, glokom), "
            "psikoz, kemik erimesi → doktora.\n"
            "• Uzun süreli: osteoporoz, diyabet, hipertansiyon."
        ),
        "sonlandirma": "KADEMELİ azaltılmalı — kesinlikle ani bırakılmaz.",
        "hatirlatma": (
            "• Kortizon kartı taşıyın.\n"
            "• Kalsiyum + D vitamini desteği.\n"
            "• Stres/enfeksiyon dönemlerinde doz artırılması gerekebilir."
        ),
    }),
    ("H03A", {  # Tiroid hormonu (levotiroksin)
        "dikkat": (
            "• Sabah aç karnına, kahvaltıdan en az 30-60 dakika önce alınız.\n"
            "• Doktor önerisi olmadan dozu değiştirmeyiniz.\n"
            "• Düzenli kan tahlili (TSH) ile doz ayarı.\n"
            "• Kalp hastalığı olanlar düşük dozdan başlamalı.\n"
            "• Demir, kalsiyum, magnezyum, soya ürünleri ile en az 4 saat ara."
        ),
        "etkilesim": (
            "• Demir, kalsiyum, magnezyum, antiasit, kolestiramin emilimini azaltır.\n"
            "• Varfarin etkisini artırır.\n"
            "• Şeker ilaçlarının dozu yeniden ayarlanabilir.\n"
            "• Östrojen tiroid bağlayıcı globulin etkiler."
        ),
        "yan_etki": (
            "• Sık (ilk başlarda): hafif çarpıntı, halsizlik.\n"
            "• CİDDİ YAN ETKİ: çarpıntı, göğüs ağrısı, aşırı kilo kaybı, terleme, titreme (tirotoksikoz) → doktora."
        ),
        "sonlandirma": "Doktor önerisi olmadan bırakılmaz (genelde ömür boyu).",
        "hatirlatma": "• Soya, kahve, süt emilimi etkiler — aralarında 4 saat olsun.",
    }),
    ("H03B", {  # Antitiroid (metimazol, propilthiyourasil)
        "dikkat": (
            "• Düzenli kan testi (karaciğer, kan hücresi).\n"
            "• Ateş, boğaz ağrısı, ağız yarası varsa doktora başvurun (agranülositoz).\n"
            "• Gebelikte özel takip."
        ),
        "etkilesim": "Varfarin etkisini etkileyebilir.",
        "yan_etki": "• Sık: ciltte döküntü, eklem ağrısı.\n• CİDDİ: agranülositoz, karaciğer hasarı, vaskülit → ACİL.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Belirti olursa hemen kan tetkiki.",
    }),

    # ============================================================
    # N — SİNİR SİSTEMİ
    # ============================================================
    ("N03", {  # Antiepileptik
        "dikkat": (
            "• Doktor önerisi olmadan KESİNLİKLE bırakmayın (nöbet riski).\n"
            "• Her gün aynı saatlerde alınız.\n"
            "• Gebelik PLANI varsa MUTLAKA doktora bildirin (bazıları teratojen).\n"
            "• Düzenli kan seviyesi takibi.\n"
            "• Folik asit desteği önerilir (kadınlarda).\n"
            "• Araç ehliyeti için doktor onayı."
        ),
        "etkilesim": (
            "• Doğum kontrol haplarının etkisini azaltabilir.\n"
            "• Çok sayıda ilaçla etkileşim — yeni ilaç başlarken bildirin.\n"
            "• Alkol nöbet eşiğini düşürür."
        ),
        "yan_etki": (
            "• Sık: uyku hali, baş dönmesi, görme bulanıklığı, sindirim şikayetleri, kilo değişimi.\n"
            "• CİDDİ YAN ETKİ: yaygın ciltte döküntü (Stevens-Johnson, DRESS), karaciğer hasarı, "
            "kan tablosu bozukluğu, INTIHAR DÜŞÜNCESİ → ACİL doktora."
        ),
        "sonlandirma": "ASLA aniden bırakmayın.",
        "hatirlatma": "• Nöbet kartı taşıyın.\n• Bilinen tetikleyicilerden kaçının.",
    }),
    ("N04", {  # Parkinson (levodopa, dopamin agonisti)
        "dikkat": (
            "• Her gün aynı saatlerde alınız.\n"
            "• Protein içeren yemeklerden 30 dakika önce/sonra (levodopa için).\n"
            "• Ani uyku atakları yapabilir — araç kullanırken dikkat.\n"
            "• Dürtüsel davranış (kumar, alışveriş) gelişebilir — yakın takip."
        ),
        "etkilesim": (
            "• B6 vitamini, antipsikotikler, metoklopramid etkisini azaltır.\n"
            "• MAO inhibitörü ile tehlikeli."
        ),
        "yan_etki": (
            "• Sık: bulantı, baş dönmesi, ayağa kalkarken tansiyon düşmesi, istemsiz hareketler.\n"
            "• CİDDİ: ani uyku, psikotik belirtiler, dürtü kontrol bozukluğu → doktora."
        ),
        "sonlandirma": "Ani kesilmez.",
        "hatirlatma": "• Yatağa otururken yavaş hareket edin.",
    }),
    ("N05A", {  # Antipsikotik
        "dikkat": (
            "• Doktor önerisi olmadan ilacı bırakmayınız.\n"
            "• Alkol ile birlikte kullanmayınız.\n"
            "• Uyku/sersemlik — araç kullanmayınız.\n"
            "• Şeker, kolesterol, kilo takibi gerekir.\n"
            "• Yaşlı demanslı hastalarda dikkat (artmış mortalite).\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": "Uyku/sersemlik yapan ilaçlar, alkol, opioidler ile etkileri artar. QT uzatan ilaçlarla aritmi.",
        "yan_etki": (
            "• Sık: uyku hali, kilo artışı, ağız kuruluğu, kabızlık, kan şekeri yükselmesi.\n"
            "• CİDDİ YAN ETKİ: Nöroleptik malign sendrom (yüksek ateş + kas sertliği + bilinç bulanması), "
            "tardif diskinezi (kalıcı istemsiz hareket), QT uzaması → ACİL doktora."
        ),
        "sonlandirma": "ASLA aniden bırakmayın.",
        "hatirlatma": "• Düzenli kilo, şeker, lipid takibi.",
    }),
    ("N05BA", {  # Benzodiazepin (alprazolam, diazepam, lorazepam)
        "dikkat": (
            "• Bağımlılık yapabilir — kısa süreli kullanım.\n"
            "• Uyku/sersemlik — araç kullanmayınız.\n"
            "• Alkol ile alınmaz (tehlikeli solunum baskılanması).\n"
            "• Gebelik/emzirmede kullanılmaz.\n"
            "• Yaşlılarda düşme riski."
        ),
        "etkilesim": "Opioid, antipsikotik, antihistaminik, alkol ile birlikte tehlikeli solunum baskılanması.",
        "yan_etki": (
            "• Sık: uyku hali, halsizlik, hafıza güçlüğü, denge sorunu.\n"
            "• CİDDİ: solunum baskılanması, paradoks ajitasyon, bağımlılık → doktora."
        ),
        "sonlandirma": "Kademeli azaltılır (yoksunluk: nöbet, kaygı sıçraması).",
        "hatirlatma": "• Geçici kullanım için.\n• Psikoterapi destekleyici.",
    }),
    ("N05C", {  # Uyku ilacı (zolpidem, zopiklon)
        "dikkat": (
            "• Yatmadan 30 dakika önce alınız.\n"
            "• Bağımlılık yapabilir — uzun süre kullanmayın.\n"
            "• Sabah uykululuk — araç kullanırken dikkat.\n"
            "• Alkol ile alınmaz."
        ),
        "etkilesim": "Diğer uyku/sersemlik yapan ilaçlar, alkol ile etkisi artar.",
        "yan_etki": "• Sık: sabah sersemliği, baş ağrısı, ağız kuruluğu.\n• CİDDİ: uyurgezerlik, hafıza boşlukları → doktora.",
        "sonlandirma": "Kademeli azaltılır.",
        "hatirlatma": "• Uyku hijyeni destekleyici (düzenli saat, ekransız akşam).",
    }),
    ("N06AB", {  # SSRI antidepresan (sertralin, essitalopram, fluoksetin, paroksetin)
        "dikkat": (
            "• Tam etki için 2-6 hafta gerekir.\n"
            "• Doktor önerisi olmadan bırakmayın (yoksunluk: baş dönmesi, bulantı).\n"
            "• Alkol almayın.\n"
            "• 25 yaş altında intihar düşüncesi artabilir — yakın takip.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": (
            "• MAO inhibitörü ile birlikte KULLANILMAZ (serotonin sendromu).\n"
            "• Tramadol, triptanlar, lityum ile serotonin sendromu.\n"
            "• NSAİİ, varfarin ile kanama riski artar.\n"
            "• St. John's wort birlikte alınmaz."
        ),
        "yan_etki": (
            "• Sık (ilk haftalar): bulantı, baş ağrısı, uyku düzensizliği, cinsel istek azalması, kilo değişimi.\n"
            "• CİDDİ YAN ETKİ: serotonin sendromu (ateş, terleme, titreme, ajitasyon), intihar düşüncesi artışı, "
            "kanama belirtileri → ACİL doktora."
        ),
        "sonlandirma": "Kademeli azaltılır (haftalar içinde).",
        "hatirlatma": "• Düzenli uyku, hareket etkiyi destekler.",
    }),
    ("N06AX", {  # Diğer antidepresan (SNRI — duloksetin, venlafaksin; mirtazapin)
        "dikkat": (
            "• Tansiyon yükselmesi olabilir — düzenli takip.\n"
            "• Doktor önerisi olmadan bırakmayın.\n"
            "• Alkol almayın.\n"
            "• Glokom, prostat sorunu olanlar dikkatli kullanmalı."
        ),
        "etkilesim": "MAO inhibitörü ile birlikte kullanılmaz. Triptan, tramadol ile serotonin sendromu. NSAİİ ile kanama.",
        "yan_etki": (
            "• Sık: bulantı, ağız kuruluğu, uykusuzluk veya uyku hali, terleme, baş dönmesi.\n"
            "• CİDDİ: serotonin sendromu, tansiyon yükselmesi, intihar düşüncesi → ACİL."
        ),
        "sonlandirma": "Kademeli azaltılır.",
        "hatirlatma": "• Tansiyon takibi.",
    }),

    # ============================================================
    # R — SOLUNUM
    # ============================================================
    ("R01AA", {  # Lokal burun açıcı (oksimetazolin, ksilometazolin)
        "dikkat": (
            "• 7 GÜNDEN uzun kullanılmaz (rebound).\n"
            "• Birden fazla kişi tarafından kullanılmamalıdır.\n"
            "• Yüksek tansiyon, kalp hastalığı, glokom, prostat büyümesi olanlar dikkatli.\n"
            "• Bebek formu sadece bebekler için.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": "MAO inhibitörü ile birlikte kullanılmaz. Tansiyon ilaçlarının etkisini azaltabilir.",
        "yan_etki": "• Sık: burunda yanma/kuruluk, çarpıntı, baş ağrısı.\n• CİDDİ: çocuk yutarsa zehirlenme → ACİL.",
        "sonlandirma": "Şikayet geçince bırakın, max 7 gün.",
        "hatirlatma": "• Tuzlu su spreyi yan etkisiz alternatiftir.",
    }),
    ("R01AD", {  # Burun kortikosteroidi (mometazon, flutikazon)
        "dikkat": "• Düzenli (günlük) kullanılır.\n• Tam etki 1-2 hafta.\n• Birden fazla kişi kullanmaz.",
        "etkilesim": "Sistemik etkileşim azdır.",
        "yan_etki": "• Sık: burunda kuruluk, hafif kanama, baş ağrısı.\n• CİDDİ: septum perforasyonu, görme bozukluğu → doktora.",
        "sonlandirma": "Mevsim sonu / doktor önerisi.",
        "hatirlatma": "• Spreyleme yönü: septuma DEĞİL, dış duvara doğru.",
    }),
    ("R03AC", {  # Beta-2 agonist inhaler (salbutamol, salmeterol, formoterol)
        "dikkat": (
            "• Kısa etkili (salbutamol): atakta kurtarıcı; uzun etkili (salmeterol/formoterol): düzenli idame.\n"
            "• Aşırı kullanım çarpıntı, titreme.\n"
            "• Günde 8 puftan fazla salbutamol = astım kontrolsüz.\n"
            "• Kalp hastalığı, tiroid sorunu, diyabet olanlar dikkat."
        ),
        "etkilesim": "Beta-bloker (göz damlası dahil) etkisini azaltır. Diüretikle düşük potasyum. MAO inhibitörü ile dikkat.",
        "yan_etki": "• Sık: titreme, çarpıntı, baş ağrısı, ağız kuruluğu.\n• CİDDİ: çarpıntı, göğüs ağrısı, paradoks bronkospazm → ACİL.",
        "sonlandirma": "Salbutamol ihtiyaca, uzun etkili doktor önerisi ile.",
        "hatirlatma": "• İnhaler tekniği önemli — eczacı kontrolü yararlı.\n• Salbutamol yedeği yanınızda olsun.",
    }),
    ("R03BA", {  # İnhale kortikosteroid (budesonid, flutikazon, beklometazon)
        "dikkat": "• Düzenli (günlük) kullanılır, atakta değil.\n• Kullandıktan sonra ağzı çalkalayın (mantar).",
        "etkilesim": "Sistemik etkileşim genelde az.",
        "yan_etki": "• Sık: ağız mantarı, ses kısıklığı, boğaz tahrişi.\n• CİDDİ: paradoks bronkospazm, glokom, katarakt → doktora.",
        "sonlandirma": "Doktor önerisi olmadan bırakılmaz.",
        "hatirlatma": "• Spacer kullanımı tekniği iyileştirir.",
    }),
    ("R03BB", {  # Antikolinerjik inhaler (ipratropium, tiotropium)
        "dikkat": "• Düzenli kullanılır.\n• Glokom, prostat büyümesi olanlar dikkatli.\n• Göze sıkmayın (göz tansiyonu yükselebilir).",
        "etkilesim": "Diğer antikolinerjik ilaçlarla birlikte etkileri katlanır.",
        "yan_etki": "• Sık: ağız kuruluğu, kabızlık, idrara çıkma güçlüğü.\n• CİDDİ: akut glokom atağı, idrar yapamama → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Kullandıktan sonra ağzı çalkalayın.",
    }),
    ("R03DC", {  # Lökotrien antagonisti (montelukast)
        "dikkat": (
            "• Düzenli (genelde akşam) kullanılır.\n"
            "• Atak için değildir.\n"
            "• Ruh hali değişikliği, intihar düşüncesi olabilir — yakın takip."
        ),
        "etkilesim": "Genelde önemli etkileşim yok. Fenobarbital seviyeyi etkileyebilir.",
        "yan_etki": "• Sık: baş ağrısı, sindirim şikayetleri.\n• CİDDİ: ruh hali değişikliği, intihar düşüncesi, Churg-Strauss → doktora.",
        "sonlandirma": "Mevsim sonu doktorla.",
        "hatirlatma": "• Allerjen kaçınma destekleyici.",
    }),
    ("R05CB", {  # Mukolitik (asetilsistein, ambroksol, erdostein)
        "dikkat": "• Bol sıvı tüketiniz.\n• Şikayet 5 günden uzunsa doktora.\n• Mide ülseri olanlar dikkatli (asetilsistein).",
        "etkilesim": "Öksürük kesici ile birlikte alınmaz (balgam birikir). Antibiyotikten 2 saat ara (asetilsistein).",
        "yan_etki": "• Sık: nadiren bulantı, ciltte döküntü.",
        "sonlandirma": "Balgam azalınca bırakın.",
        "hatirlatma": "• Buhar, sıcak içecek destekleyici.",
    }),
    ("R05DB", {  # Periferik öksürük kesici (butamirat, levodropropizin)
        "dikkat": (
            "• Balgamlı öksürükte balgam sökücü ile birlikte alınmaz.\n"
            "• 2 ay altı bebeklerde, gebelikte 1. trimesterde kullanılmaz.\n"
            "• Şeker hastalarında dikkatli (şurupta şeker).\n"
            "• Uyku hali yapabilir."
        ),
        "etkilesim": "Sakinleştirici ve alkol ile sersemlik artar.",
        "yan_etki": "• Sık: uyku hali, yorgunluk, bulantı.\n• CİDDİ: ciltte döküntü, alerjik reaksiyon (seyrek) → ilacı bırakın.",
        "sonlandirma": "Öksürük geçince bırakın.",
        "hatirlatma": "• Bol sıvı, nemli ortam destekleyici.",
    }),
    ("R05DA", {  # Opioid öksürük kesici (kodein, dekstrometorfan)
        "dikkat": (
            "• 12 yaş altı çocuklara verilmez (özellikle kodein).\n"
            "• Bağımlılık ve solunum baskılanması.\n"
            "• Gebelik ve emzirmede dikkatli.\n"
            "• Araç kullanırken dikkat."
        ),
        "etkilesim": "Sakinleştirici, alkol, MAO inhibitörü ile birlikte tehlikeli.",
        "yan_etki": "• Sık: uyku hali, kabızlık, bulantı.\n• CİDDİ: solunum baskılanması, bağımlılık → doktora.",
        "sonlandirma": "Öksürük geçince bırakın.",
        "hatirlatma": "• Reçetesiz kullanılmaz.",
    }),
    ("R06A", {  # Antihistaminik (setirizin, loratadin, fexofenadin, hidroksizin)
        "dikkat": (
            "• 1. kuşak (hidroksizin, klorfeniramin) uyku hali yapar — araç kullanmayın.\n"
            "• 2. kuşak daha az uyku yapar ama yine de dikkat.\n"
            "• Glokom, prostat büyümesi olanlar dikkatli.\n"
            "• Gebelik ve emzirmede doktor onayı."
        ),
        "etkilesim": "Alkol, sakinleştirici ile uyku hali artar. QT uzatan ilaçlarla aritmi (nadir).",
        "yan_etki": "• Sık: uyku hali, ağız kuruluğu, baş ağrısı.\n• CİDDİ: kalp ritm bozukluğu (uzun QT), şiddetli alerjik reaksiyon (nadir) → doktora.",
        "sonlandirma": "Şikayet geçince bırakın.",
        "hatirlatma": "• Allerjen kaçınma destekleyici.",
    }),

    # ============================================================
    # S — DUYU ORGANLARI
    # ============================================================
    ("S01A", {  # Göz anti-infektif
        "dikkat": (
            "• Şişe ucu göze değmemeli.\n"
            "• Birden fazla kişi kullanmamalıdır.\n"
            "• Kontakt lens varsa damlatmadan önce çıkarın, 15 dakika sonra takın.\n"
            "• Tedaviyi tamamlayınız."
        ),
        "etkilesim": "Aynı göze birden fazla damla varsa aralarında 5 dakika.",
        "yan_etki": "• Sık: gözde yanma, hafif bulanık görme.\n• CİDDİ: göz ağrısı, kalıcı kızarıklık → doktora.",
        "sonlandirma": "Tedavi süresini tamamlayın.",
        "hatirlatma": "• Damlattıktan sonra 1 dakika göz iç köşesine bastırın (sistemik emilim azalır).",
    }),
    ("S01B", {  # Göz kortikosteroidi
        "dikkat": "• Doktor takibinde kullanılır.\n• Göz tansiyonu takibi gerekir.",
        "etkilesim": "Diğer göz damlalarından 5 dakika ara.",
        "yan_etki": "• Sık: hafif yanma, bulanık görme.\n• CİDDİ: göz tansiyonu artışı (glokom), katarakt, enfeksiyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Reçetesiz kullanılmaz.",
    }),
    ("S01E", {  # Glokom (prostaglandin, beta-bloker, karbonik anhidraz, alfa-agonist)
        "dikkat": (
            "• Her gün AYNI saatte damlatın — düzensiz kullanım göz tansiyonunu yükseltir.\n"
            "• Şişe ucu göze değmemeli (kontaminasyon).\n"
            "• Damlattıktan sonra gözün iç köşesine 1 dakika bastırın — "
            "sistemik emilimi azaltır (özellikle beta-bloker damlalar için kritik).\n"
            "• ASTIM / KOAH hastasıysanız veya kalp ilacı kullanıyorsanız doktorunuza söyleyin — "
            "beta-bloker damlalar (timolol/betaksolol) sistemik emilimle bronkospazm/kalp ritim "
            "bozukluğu yapabilir.\n"
            "• Prostaglandin damlası (latanoprost/travoprost/bimatoprost) kullanıyorsanız: "
            "İRİS RENGİ KOYULAŞMASI ve KİRPİK UZAMASI/KOYULAŞMASI olabilir — KALICIdir, "
            "tehlikeli değildir; ancak iki göz farklı renk alabilir."
        ),
        "etkilesim": (
            "• Beta-bloker damla + oral beta-bloker = etki toplanır, kalp yavaşlayabilir.\n"
            "• Aynı göze birden fazla damla kullanılıyorsa aralarında 5 dakika bekleyin.\n"
            "• MAO inhibitörü + sempatomimetik damlalar (brimonidin) dikkat."
        ),
        "yan_etki": (
            "• Sık: gözde yanma/batma, kirpik uzaması, iris koyulaşması (prostaglandin).\n"
            "• CİDDİ: nefes darlığı, hırıltılı nefes, yavaş kalp atışı (beta-bloker sistemik "
            "emilim) → doktora; ani görme kaybı, şiddetli göz ağrısı (akut glokom krizi) → ACİL."
        ),
        "sonlandirma": "Doktor önerisi olmadan KESİNLİKLE bırakılmaz — göz tansiyonu yükselir, görme kaybı olabilir.",
        "hatirlatma": "• 6 ayda bir göz muayenesi; gözlük kullanıyorsanız optisyene de bildirin.",
    }),
    ("S01XA", {  # Yapay göz yaşı
        "dikkat": "• Şişe ucu göze değmemeli.\n• Açıldıktan sonra 1 ay (tek dozluk 12 saat).",
        "etkilesim": "Aynı göze damlalar arası 5 dakika.",
        "yan_etki": "• Sık: hafif yanma, bulanık görme.",
        "sonlandirma": "İhtiyaca göre.",
        "hatirlatma": "• Ekran kullanırken sık göz kırpıştırın.",
    }),
    ("S02", {  # Kulak ilacı
        "dikkat": "• Şişeyi avucunuzda 1-2 dakika ısıtın.\n• Damlattıktan sonra 5 dakika yatın.\n• Kulak zarı delik olanlar kullanmamalı.",
        "etkilesim": "Aynı kulağa damlalar arası 30 dakika.",
        "yan_etki": "• Sık: kulakta yanma, kaşıntı.\n• CİDDİ: işitme kaybı, baş dönmesi → doktora.",
        "sonlandirma": "Şikayet geçince bırakın.",
        "hatirlatma": "• Birden fazla kişi kullanmaz.",
    }),

    # ============================================================
    # D — DERMATOLOJİK
    # ============================================================
    ("D01AC", {  # Topikal antimantar imidazol
        "dikkat": "• Sadece DIŞ KULLANIM.\n• İnce tabaka, etkilenen bölgeye.\n• Şikayet geçtikten sonra 1-2 hafta devam edin.",
        "etkilesim": "Aynı bölgeye başka cilt ilacı uygulamayın.",
        "yan_etki": "• Sık: uygulama yerinde kızarıklık, kaşıntı.\n• CİDDİ: şiddetli alerjik reaksiyon → bırakın.",
        "sonlandirma": "Şikayet + 1-2 hafta.",
        "hatirlatma": "• Bölgeyi kuru tutun, havlu/iç çamaşırı paylaşmayın.",
    }),
    ("D02", {  # Cilt yumuşatıcı/emolyent
        "dikkat": "• Sadece dış kullanım.\n• Banyo sonrası nemli cilde uygulanır.",
        "etkilesim": "Genelde önemli etkileşim yok.",
        "yan_etki": "• Sık: nadiren kızarıklık, kaşıntı.",
        "sonlandirma": "İhtiyaca göre.",
        "hatirlatma": "• Düzenli kullanım önemli.",
    }),
    ("D03", {  # Yara iyileştirici
        "dikkat": "• Sadece dış kullanım.\n• Temiz cilt bölgesine.",
        "etkilesim": "Önemli etkileşim yok.",
        "yan_etki": "• Sık: nadiren kızarıklık.",
        "sonlandirma": "Yara iyileşince bırakın.",
        "hatirlatma": "• Hijyen kuralları, gerekirse pansuman.",
    }),
    ("D04", {  # Kaşıntı önleyici / lokal anestezik
        "dikkat": "• Sadece dış kullanım.\n• Geniş alana / uzun süre kullanmayın.",
        "etkilesim": "Geniş alan sistemik etki yapabilir.",
        "yan_etki": "• Sık: hafif yanma, kızarıklık.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Buz uygulama destekleyici.",
    }),
    ("D05", {  # Antipsoriyatik
        "dikkat": "• Sadece dış kullanım (genelde).\n• Yüz/genital bölgeye sürmeyin.\n• Güneşten korunun.",
        "etkilesim": "Diğer cilt ilaçları ile aynı bölgeye uygulamayın.",
        "yan_etki": "• Sık: ciltte yanma, kızarıklık, tahriş.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Nemlendirici destekleyici.",
    }),
    ("D06A", {  # Topikal antibiyotik
        "dikkat": "• Sadece dış kullanım.\n• İnce tabaka.\n• Geniş alan kullanmayın.",
        "etkilesim": "Aynı bölgede başka cilt ilacı kullanmayın.",
        "yan_etki": "• Sık: kızarıklık, kaşıntı.",
        "sonlandirma": "Enfeksiyon geçince.",
        "hatirlatma": "• Eller önce ve sonra yıkanır.",
    }),
    ("D07A", {  # Topikal kortikosteroid
        "dikkat": (
            "• Sadece DIŞ KULLANIM.\n"
            "• Yüz, koltukaltı, kasık bölgesine uzun süreli kullanmayın.\n"
            "• Bol miktarda sürmeyin.\n"
            "• Geniş alana uzun süreli kullanım sistemik etki yapar."
        ),
        "etkilesim": "Aynı bölgede başka ilaç kullanmayın.",
        "yan_etki": (
            "• Sık: cilt incelmesi, kılcal damar görünümü, akne benzeri döküntü, telanjiektazi.\n"
            "• CİDDİ (uzun/yaygın kullanım): Cushing benzeri belirti, adrenal baskılanma → doktora."
        ),
        "sonlandirma": "Kısa süreli (1-2 hafta), kademeli azaltma.",
        "hatirlatma": "• Reçeteyle düşük güç (yüze) ya da yüksek güç (uzuvlara) ayrılır.",
    }),
    ("D08", {  # Antiseptik
        "dikkat": "• Sadece DIŞ KULLANIM, yutmayın.\n• Açık yarada doktor onayı.",
        "etkilesim": "Önemli etkileşim yok.",
        "yan_etki": "• Sık: cilt kuruluğu, tahriş.",
        "sonlandirma": "İhtiyaç bitince.",
        "hatirlatma": "• Bebek bezi altına bol kullanmayın.",
    }),
    ("D10", {  # Akne tedavisi
        "dikkat": (
            "• Güneşten korunun (fotosensitivite).\n"
            "• Gebelikte (oral retinoidler — KESİNLİKLE kontraseptif) kullanılmaz.\n"
            "• Cilt kuruluğu beklenir.\n"
            "• Yağsız nemlendirici kullanın."
        ),
        "etkilesim": "Diğer cilt ilaçları ile birlikte tahriş artar.",
        "yan_etki": "• Sık: ciltte kuruluk, kızarıklık, soyulma.\n• CİDDİ (oral retinoid): karaciğer hasarı, ruh hali değişikliği → doktora.",
        "sonlandirma": "Tedavi planı 3-6 ay.",
        "hatirlatma": "• Oil-free güneş kremi.",
    }),
    ("D11", {  # Diğer dermatolojik
        "dikkat": "• Dış kullanım.\n• Göz ve mukoza teması yok.",
        "etkilesim": "Aynı bölgede dikkat.",
        "yan_etki": "• Sık: uygulama yerinde reaksiyon.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Eller yıkanır.",
    }),

    # ============================================================
    # G — ÜROGENİTAL / HORMON
    # ============================================================
    ("G01", {  # Vajinal preparat
        "dikkat": "• Yatmadan önce vajinaya yerleştirin.\n• Adet döneminde devam edin.\n• Eşle birlikte tedavi gerekebilir.",
        "etkilesim": "Aynı bölgeye başka ürün kullanmayın.",
        "yan_etki": "• Sık: yanma, kaşıntı.",
        "sonlandirma": "Tedavi süresini tamamlayın.",
        "hatirlatma": "• Pamuklu iç çamaşırı.",
    }),
    ("G03AD", {  # Ertesi gün hapı (acil kontrasepsiyon) — TEK dozluk; "her gün
        #            aynı saatte" gibi düzenli-hap ibareleri YANLIŞ olur.
        "dikkat": (
            "• ACİL korunma içindir — ilişkiden sonra MÜMKÜN OLAN EN KISA sürede alınız "
            "(levonorgestrel en geç 72 saat, ulipristal en geç 5 gün).\n"
            "• Tek dozluktur; düzenli doğum kontrol yöntemi DEĞİLDİR.\n"
            "• Aldıktan sonraki 3 saat içinde kusarsanız doz tekrarlanır."
        ),
        "etkilesim": "Rifampisin, antiepileptikler, St. John's wort etkisini azaltır.",
        "yan_etki": (
            "• Sık: bulantı, baş ağrısı, karın ağrısı, adet düzensizliği, meme hassasiyeti.\n"
            "• Adet 7 günden fazla gecikirse gebelik testi yapınız."
        ),
        "sonlandirma": "Tek dozluk acil kullanımdır; düzenli kullanılmaz.",
        "hatirlatma": "• Düzenli ve etkili korunma yöntemi için doktora başvurun.",
    }),
    ("G03A", {  # Doğum kontrol hapı (kombine/faz-değişken oral kontraseptif)
        "dikkat": (
            "• Her gün AYNI SAATTE alınız — saat farkı korumayı azaltabilir.\n"
            "• Hap unutulursa kutu içindeki talimat veya ek bariyer yöntemi kullanın.\n"
            "• SİGARA + doğum kontrol hapı = tromboz (pıhtı) riski KAT KAT ARTAR — "
            "özellikle 35 yaş üstünde sigara kullananlarda ciddi risk.\n"
            "• Migren + aura, daha önce pıhtı öyküsü, karaciğer hastalığı olanlar kullanmamalı."
        ),
        "etkilesim": (
            "• Rifampisin, antiepileptikler (karbamazepin/fenitoin/topiramid), St. John's wort "
            "etkisini azaltır — ek bariyer yöntemi kullanın, doktorunuza bildirin.\n"
            "• Bazı antibiyotikler (ampisilin grubu) ile etki azalabilir — ek koruma önerilir."
        ),
        "yan_etki": (
            "• Sık: bulantı, baş ağrısı, ara kanama (ilk 3 ay), göğüs hassasiyeti, ruh hali değişimi.\n"
            "• CİDDİ — ACİL DOKTORA: bacakta tek taraflı şişlik/ağrı (derin ven trombozu), "
            "ani nefes darlığı + göğüs ağrısı (pulmoner emboli), şiddetli baş ağrısı, "
            "görme değişikliği/bozukluğu, konuşma güçlüğü (inme belirtisi)."
        ),
        "sonlandirma": "Kutu sonu / doktor önerisi. Hamile kalmak istiyorsanız önceden doktorunuza bildirin.",
        "hatirlatma": "• Yıllık jinekoloji muayenesi (kan basıncı dahil) önerilir.",
    }),
    ("G04", {  # Üroloji (prostat - alfa bloker, 5-ARI; mesane)
        "dikkat": (
            "• Her gün aynı saatte.\n"
            "• İlk dozda baş dönmesi (yavaş kalkın).\n"
            "• Katarakt ameliyatı öncesi göz doktoruna bildirin (iris floppy).\n"
            "• 5-ARI: gebe kadın el sürmemeli (cilt emilimi)."
        ),
        "etkilesim": "Tansiyon ilaçları ile aşırı düşüş. Ereksiyon ilaçları kombinasyonu dikkat.",
        "yan_etki": "• Sık: baş dönmesi, ejakülasyon problemi, burun tıkanıklığı.\n• CİDDİ: bayılma, priapizm → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• PSA testleri etkilenebilir (5-ARI).",
    }),

    # ============================================================
    # L — ANTİNEOPLASTİK / İMMÜN
    # ============================================================
    ("L01", {  # Kanser ilacı
        "dikkat": "• Onkoloji takibinde kullanılır.\n• Düzenli kan testi gerekir.\n• Yan etkilere göre destek tedavisi.",
        "etkilesim": "Çok sayıda etkileşim — tüm ilaçlar bildirilmeli.",
        "yan_etki": "• Sık: bulantı, halsizlik, saç dökülmesi, kan hücresi düşmesi.\n• CİDDİ: enfeksiyon (ateş), şiddetli yan etki → ACİL.",
        "sonlandirma": "Onkoloji ekibi karar verir.",
        "hatirlatma": "• Onkoloji destek hattı yanınızda olsun.",
    }),
    ("L02", {  # Hormon tedavisi (kanser)
        "dikkat": "• Düzenli kullanılır.\n• Pıhtı riski olanlar dikkatli.",
        "etkilesim": "Diğer hormon, antikoagülan ile etkileşim.",
        "yan_etki": "• Sık: sıcak basması, eklem ağrısı, kilo değişimi.\n• CİDDİ: pıhtı, kalp hastalığı → doktora.",
        "sonlandirma": "Onkoloji ekibi ile.",
        "hatirlatma": "• Düzenli takip.",
    }),
    ("L03", {  # İmmün modülatör (interferon)
        "dikkat": "• Genelde enjeksiyonla.\n• Saklama koşullarına dikkat.\n• Düzenli kan testi.",
        "etkilesim": "Pek çok etkileşim — bildirin.",
        "yan_etki": "• Sık: grip benzeri belirtiler, halsizlik, depresyon.\n• CİDDİ: ciddi depresyon, otoimmün hastalık → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Soğuk zincir saklama.",
    }),
    ("L04", {  # İmmünsüpresif (biyolojik dahil)
        "dikkat": (
            "• Bağışıklığı baskılar — enfeksiyon belirtilerinde doktora.\n"
            "• CANLI AŞI yapılmaz (kızamık, suçiçeği, BCG).\n"
            "• Düzenli kan testi.\n"
            "• Biyolojikler genelde buzdolabında saklanır."
        ),
        "etkilesim": "Pek çok etkileşim — bildirin.",
        "yan_etki": "• Sık: enfeksiyon, sindirim şikayetleri.\n• CİDDİ: ciddi enfeksiyon, lenfoma riski, otoimmün hastalık → ACİL.",
        "sonlandirma": "Doktor takibinde.",
        "hatirlatma": "• Hijyen, kalabalık ortamda dikkat.\n• İnaktif aşılar önerilir.",
    }),

    # ============================================================
    # P — PARAZİT
    # ============================================================
    ("P02", {  # Bağırsak parazit ilacı
        "dikkat": (
            "• Tek doz veya doktor önerisine göre.\n"
            "• Aile üyeleri ile birlikte tedavi gerekebilir.\n"
            "• 2 yaş altı bebeklerde doktor önerisi."
        ),
        "etkilesim": "Genelde önemli etkileşim yok.",
        "yan_etki": "• Sık: bulantı, karın ağrısı, ishal.",
        "sonlandirma": "Genelde tek doz; gerekirse 2-3 hafta sonra tekrarlanır.",
        "hatirlatma": "• Hijyen önemli (el yıkama, tırnak kesimi).",
    }),
    ("P03", {  # Bit/uyuz ilacı
        "dikkat": (
            "• Tüm vücuda boyundan aşağıya uygulanır (uyuz).\n"
            "• 8-12 saat beklendikten sonra yıkanır.\n"
            "• Gerekirse 1 hafta sonra tekrarlanır.\n"
            "• Göz, ağız temasından kaçının."
        ),
        "etkilesim": "Aynı bölgede başka ürün kullanmayın.",
        "yan_etki": "• Sık: ciltte yanma, kaşıntı, kızarıklık.",
        "sonlandirma": "Tek doz / doktor önerisi.",
        "hatirlatma": "• Tüm aile/temas üyeleri birlikte tedavi.\n• Yatak takımları sıcak suda yıkayın.",
    }),

    # ============================================================
    # V — ÇEŞİTLİ
    # ============================================================
    ("V03", {  # Antidot
        "dikkat": "• Sağlık personeli denetiminde.\n• Acil durumlarda.",
        "etkilesim": "Çok sayıda durum-spesifik etkileşim.",
        "yan_etki": "• Durum-spesifik.",
        "sonlandirma": "Doktor önerisi.",
        "hatirlatma": "• Acil müdahalecilere bildirin.",
    }),
    ("V06", {  # Beslenme ürünü
        "dikkat": "• Doktor önerisi ile, belirtilen miktar.\n• Mikrodalga ile ısıtmayın.\n• Açıldıktan sonra buzdolabı, 24 saat.",
        "etkilesim": "Antibiyotik ve demir emilimini etkileyebilir.",
        "yan_etki": "• Sık: nadiren ishal, bulantı.",
        "sonlandirma": "Doktor önerisi.",
        "hatirlatma": "• Yutma güçlüğü olanlar için kıvam ayarı.",
    }),
    ("V08", {  # Radyolojik kontrast
        "dikkat": "Sağlık ocağı / hastane ortamında uygulanır. İşlem öncesi açlık gerekebilir.",
        "etkilesim": "Metformin geçici olarak bırakılmalı (laktik asidoz).",
        "yan_etki": "• Sık: hafif bulantı.\n• CİDDİ: alerjik reaksiyon, böbrek hasarı → doktora.",
        "sonlandirma": "Tek seferlik.",
        "hatirlatma": "• Alerji geçmişi ve böbrek değeri bildirin.",
    }),

    # ============================================================
    # EK PREFIX'LER (genişletilmiş kapsam)
    # ============================================================
    ("C09D", {  # ARB + kalsiyum kanal blokeri kombinasyonu
        "dikkat": "• Her gün aynı saatte alınız.\n• Ani kesmeyin.\n• Gebelikte KESİNLİKLE kullanılmaz.\n• Düzenli tansiyon takibi.",
        "etkilesim": "Greyfurt suyu, NSAİİ, lityum, potasyum tutucu diüretikler etkileşir.",
        "yan_etki": "• Sık: baş dönmesi, baş ağrısı, ayaklarda şişme.\n• CİDDİ: anjiyoödem, böbrek hasarı, ciddi tansiyon düşmesi → doktora.",
        "sonlandirma": "Doktor önerisi olmadan bırakmayın.",
        "hatirlatma": "• Tansiyon takibi, düşük tuzlu diyet.",
    }),
    ("R03A", {  # Adrenergic inhaler (bronkodilatör + steroid kombi vb.)
        "dikkat": (
            "• Düzenli idame için kullanılır.\n"
            "• Atak için değildir (kombi formlarda).\n"
            "• Kullandıktan sonra ağzı çalkalayın (kortizonlu form).\n"
            "• Kalp hastalığı, diyabet, tiroid olanlar dikkat."
        ),
        "etkilesim": "Beta-bloker, diüretik, MAO inhibitörü etkileşim.",
        "yan_etki": "• Sık: titreme, çarpıntı, ses kısıklığı, ağız mantarı.\n• CİDDİ: paradoks bronkospazm, çarpıntı, göğüs ağrısı → ACİL.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Spacer kullanımı tekniği iyileştirir.\n• Kurtarıcı inhaler yanınızda olsun.",
    }),
    ("R03C", {  # Oral bronkodilatör (teofilin)
        "dikkat": "• Dar terapötik aralık — düzenli kan seviyesi takibi.\n• Sigara/alkol etkisi değiştirir.\n• Yemekle veya yemek arası alınabilir (üreticiye göre).",
        "etkilesim": "Çok sayıda etkileşim — yeni ilaç bildirin (makrolid, kinolon, simetidin etkisini artırır).",
        "yan_etki": "• Sık: bulantı, uykusuzluk, çarpıntı, titreme.\n• CİDDİ: aritmi, nöbet (yüksek doz) → ACİL.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Kafein içerikli içeceklerden uzak durun.",
    }),
    ("R03D", {  # Diğer sistemik solunum
        "dikkat": "• Düzenli kullanılır.\n• Yan etkileri bildirin.",
        "etkilesim": "Diğer solunum ilaçları ile etkileşim bildirilmeli.",
        "yan_etki": "• Sık: baş ağrısı, sindirim şikayetleri.\n• CİDDİ: ruh hali değişikliği, ciddi alerjik reaksiyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Allerjen kaçınma destekleyici.",
    }),
    ("M01A", {  # NSAİİ (genel, M01AE/AB/AC/AH dışı)
        "dikkat": (
            "• Aspirin/NSAİİ alerjisi olanlar kullanmamalı.\n"
            "• Mide ülseri, ciddi kalp/böbrek yetmezliği olanlar dikkatli.\n"
            "• Gebeliğin son 3 ayında kullanılmaz.\n"
            "• Tok karnına alınız."
        ),
        "etkilesim": "Aspirin, varfarin, lityum, metotreksat, tansiyon ilaçları etkileşir.",
        "yan_etki": "• Sık: bulantı, mide ağrısı, baş ağrısı, baş dönmesi.\n• CİDDİ: mide kanaması, kalp riski, alerji → ACİL.",
        "sonlandirma": "Ağrı geçince bırakın.",
        "hatirlatma": "• En düşük etkili dozda en kısa sürede.",
    }),
    ("M05B", {  # Osteoporoz / bisfosfonat
        "dikkat": (
            "• Aç karnına, bol su (200 ml) ile alınız.\n"
            "• Alındıktan sonra 30-60 dakika YATMAYIN, başka ilaç almayın.\n"
            "• Yutma güçlüğü/özofajit olanlar kullanmamalı.\n"
            "• Diş işlemleri öncesi doktora bildirin (çene osteonekrozu riski)."
        ),
        "etkilesim": "Kalsiyum, demir, antiasit aynı anda alınmaz (30 dk ara).",
        "yan_etki": "• Sık: mide şikayetleri, yutkunma zorluğu, kas-eklem ağrısı.\n• CİDDİ: özofajit, çene osteonekrozu, atipik kemik kırığı → doktora.",
        "sonlandirma": "Tedavi süresi 3-5 yıl, doktor karar verir.",
        "hatirlatma": "• Kalsiyum + D vitamini eşlik etmeli.",
    }),
    ("M04", {  # Gut / ürik asit (allopurinol, kolşisin, febuksostat)
        "dikkat": (
            "• Bol su tüketin (ürik asit atılımı için günde en az 2 litre).\n"
            "• KIRMIZI ET, SAKATAT, ALKOL (özellikle bira), DENİZ ÜRÜNLERİ purin "
            "içerir ve ürik asit yükseltir — kısıtlayın.\n"
            "• Her gün düzenli alınız; AKUT ATAKTA başlatılmaz (atağı uzatır), "
            "atak sonrası 2-4 hafta beklenerek başlanır.\n"
            "• Allopurinol ilk 6 haftada ciltte kızarıklık/döküntü olursa HEMEN bırakıp "
            "doktora başvurun (ağır alerjik reaksiyon riski).\n"
            "• Karaciğer/böbrek takibi gerekir."
        ),
        "etkilesim": (
            "• Azatiyoprin/merkaptopürin ile birlikte KESİNLİKLE kullanılmaz (toksik doz birikimi).\n"
            "• Greyfurt suyu (kolşisin için — tehlikeli düzey artışı).\n"
            "• Varfarin etkisini artırabilir — kanama takibi."
        ),
        "yan_etki": "• Sık: ciltte döküntü, sindirim şikayetleri.\n• CİDDİ: Stevens-Johnson sendromu / toksik epidermal nekroliz (allopurinol — döküntü + ateş varsa ACİL), kas hasarı (kolşisin) → ACİL doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Diyet + alkol azaltma ilaç etkisini destekler; kilo vermek uzun vadede ürik asidi düşürür.",
    }),
    ("M05", {  # Diğer kemik tedavisi
        "dikkat": "• Düzenli kullanılır.\n• Kalsiyum/D vitamini desteği önerilir.",
        "etkilesim": "Kalsiyum içeren ilaçlar emilimini etkiler.",
        "yan_etki": "• Sık: eklem-kas ağrısı, baş ağrısı.\n• CİDDİ: hipokalsemi, alerjik reaksiyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli kemik yoğunluğu takibi.",
    }),
    ("D01A", {  # Topikal antifungal (D01AC dışı)
        "dikkat": "• Sadece dış kullanım.\n• İnce tabaka.\n• Şikayet geçtikten sonra 1-2 hafta devam.",
        "etkilesim": "Aynı bölgede başka cilt ilacı kullanmayın.",
        "yan_etki": "• Sık: kızarıklık, kaşıntı, yanma.\n• CİDDİ: yaygın alerjik reaksiyon → bırakın.",
        "sonlandirma": "Şikayet + 1-2 hafta.",
        "hatirlatma": "• Bölge kuru, hijyenik tutulmalı.",
    }),
    ("D06B", {  # Antiviral/antiseptik cilt
        "dikkat": "• Sadece dış kullanım.\n• Erken kullanım önemli (uçuk).",
        "etkilesim": "Aynı bölgede başka ilaç kullanmayın.",
        "yan_etki": "• Sık: hafif yanma, kaşıntı.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Kabarcığa dokunmayın, kişisel temizlik.",
    }),
    ("D07X", {  # Kortikosteroid + diğer kombi cilt
        "dikkat": "• Sadece dış kullanım.\n• Uzun süreli kullanmayın.\n• Yüz/genital bölgeye dikkatli.",
        "etkilesim": "Aynı bölgede başka ilaç uygulamayın.",
        "yan_etki": "• Sık: cilt incelmesi, kızarıklık.\n• CİDDİ: yaygın sistemik etki (uzun kullanım) → doktora.",
        "sonlandirma": "Kısa süreli, kademeli azaltma.",
        "hatirlatma": "• Kullanım sınırlamalarına uyun.",
    }),
    ("D07C", {  # Kortikosteroid + antibiyotik cilt
        "dikkat": "• Sadece dış kullanım.\n• 1-2 hafta üstü kullanılmaz.",
        "etkilesim": "Aynı bölge çoklu ilaç kullanmayın.",
        "yan_etki": "• Sık: yanma, kaşıntı.\n• CİDDİ: alerjik reaksiyon, dirençli enfeksiyon → doktora.",
        "sonlandirma": "Enfeksiyon geçince bırakın.",
        "hatirlatma": "• Bölge kuru tutulmalı.",
    }),
    ("A01A", {  # Ağız bakımı / antiseptik
        "dikkat": "• YUTMAYINIZ.\n• Kullandıktan sonra 30 dakika yiyip içmeyin.\n• Diş hijyenine dikkat.",
        "etkilesim": "Diş macunundan 30 dakika ara (klorheksidin).",
        "yan_etki": "• Sık: dişlerde renklenme (uzun süreli), tat değişikliği.",
        "sonlandirma": "Şikayet geçince bırakılır.",
        "hatirlatma": "• Diş ipi, düzenli muayene.",
    }),
    ("A02A", {  # Antiasit
        "dikkat": "• Diğer ilaçlardan 2 saat ara.\n• Çiğneme tabletini çiğneyin.",
        "etkilesim": "Birçok ilacın emilimini azaltır (tetrasiklin, demir, kinolon, tiroid).",
        "yan_etki": "• Sık: magnezyumlu → ishal, alüminyumlu → kabızlık.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Yemekten 1 saat sonra ve yatmadan önce.",
    }),
    ("A03A", {  # Antispazmodik / antikolinerjik diğer
        "dikkat": "• Glokom, prostat sorunu olanlar dikkat.\n• Ağız kuruluğu, görme bulanıklığı.",
        "etkilesim": "Diğer antikolinerjiklerle etkileri katlanır.",
        "yan_etki": "• Sık: ağız kuruluğu, kabızlık, görme bulanıklığı.\n• CİDDİ: akut glokom, idrar yapamama → doktora.",
        "sonlandirma": "Ağrı geçince bırakın.",
        "hatirlatma": "• Yeterli sıvı tüketin.",
    }),
    ("A05", {  # Karaciğer / safra
        "dikkat": "• Düzenli kullanılır.\n• Karaciğer takibi gerekir.\n• Sarılık belirtileri bildirilmeli.",
        "etkilesim": "Diğer karaciğer metabolize ilaçlar dikkat.",
        "yan_etki": "• Sık: bulantı, ishal.\n• CİDDİ: karaciğer enzim yüksekliği, sarılık → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Alkolden kaçının, dengeli beslenme.",
    }),
    ("A08", {  # Zayıflama ilacı
        "dikkat": "• Diyet ve egzersiz ile birlikte.\n• Yağlı yemeklerden kaçının.\n• Yağda eriyen vitamin desteği önerilir.",
        "etkilesim": "Siklosporin, levotiroksin, antiepileptik emilimini azaltır — 2 saat ara.",
        "yan_etki": "• Sık: yağlı dışkı, gaz, sık dışkı, karın ağrısı.\n• CİDDİ: karaciğer hasarı (nadir) → doktora.",
        "sonlandirma": "Hedef kiloya ulaşınca veya doktor önerisi.",
        "hatirlatma": "• Düşük yağlı diyet şart.",
    }),
    ("A11H", {  # E vitamini, diğer vitamin
        "dikkat": "• Önerilen dozda kullanın.\n• Yüksek doz E vitamini kanama riski artırır.",
        "etkilesim": "Varfarin etkisini artırır.",
        "yan_etki": "• Sık: nadiren bulantı, baş ağrısı.",
        "sonlandirma": "İhtiyaç bitince.",
        "hatirlatma": "• Yağda erir, yemekle alın.",
    }),
    ("A11E", {  # B kompleks kombinasyonu
        "dikkat": "• Önerilen dozda kullanın.\n• İdrarda sarımsı renk (zararsız).",
        "etkilesim": "B6 levodopa etkisini azaltır.",
        "yan_etki": "• Sık: nadiren bulantı.\n• CİDDİ: yüksek doz B6 → uyuşma → doktora.",
        "sonlandirma": "Eksiklik düzelince.",
        "hatirlatma": "• Çeşitli beslenme önerilir.",
    }),
    ("A16A", {  # Diğer metabolik
        "dikkat": "• Doktor takibinde kullanılır.\n• Düzenli kan testi.",
        "etkilesim": "Spesifik ilaçla etkileşim.",
        "yan_etki": "• Sık: durum-spesifik.\n• CİDDİ: belirtileri doktora bildirin.",
        "sonlandirma": "Doktor önerisi.",
        "hatirlatma": "• Genelde kronik tedavi.",
    }),
    ("B02B", {  # Hemostatik (K vitamini, traneksamik asit)
        "dikkat": "• Doktor önerisi ile kullanılır.\n• Pıhtılaşma riski olanlar dikkatli.",
        "etkilesim": "Antikoagülan etkisini etkileyebilir.",
        "yan_etki": "• Sık: bulantı, ishal.\n• CİDDİ: pıhtı, alerjik reaksiyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Kanama durdurulduğunda bırakılır.",
    }),
    ("B05", {  # IV solüsyon / elektrolit
        "dikkat": "Hastane / sağlık ocağı ortamında uygulanır.",
        "etkilesim": "Diğer IV ilaçlarla uyumluluk önemli.",
        "yan_etki": "• Sık: enjeksiyon yerinde reaksiyon.\n• CİDDİ: elektrolit dengesizliği, sıvı yükü → doktora.",
        "sonlandirma": "İhtiyaç bitince.",
        "hatirlatma": "• Sağlık personeli denetimi.",
    }),
    ("G03G", {  # Gonadotropin / kısırlık tedavisi
        "dikkat": "• Doktor takibinde uygulanır.\n• Genelde cilt altı enjeksiyon.\n• Saklama koşullarına dikkat (buzdolabı).",
        "etkilesim": "Diğer hormon tedavileri ile etkileşim.",
        "yan_etki": "• Sık: enjeksiyon yerinde reaksiyon, baş ağrısı, karın gerginliği.\n• CİDDİ: OHSS (yumurtalık aşırı uyarılması), pıhtı riski → doktora.",
        "sonlandirma": "Tedavi planına göre.",
        "hatirlatma": "• Yakın doktor takibi.",
    }),
    ("G03D", {  # Progesteron preparatları
        "dikkat": "• Doktor önerisi ile.\n• Pıhtı öyküsü, karaciğer hastalığı olanlar dikkatli.",
        "etkilesim": "Antiepileptikler, rifampin etkisini azaltır.",
        "yan_etki": "• Sık: baş ağrısı, göğüs hassasiyeti, kilo değişimi.\n• CİDDİ: pıhtı, depresyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli kontrol.",
    }),
    ("G03F", {  # Östrojen-progesteron kombi
        "dikkat": (
            "• Pıhtı öyküsü, karaciğer hastalığı, hormonal kansere meyilli olanlar kullanmamalı.\n"
            "• Sigara + hormon = pıhtı riski katlanır.\n"
            "• Düzenli meme + jinekoloji kontrolü."
        ),
        "etkilesim": "Antibiyotik, antiepileptik, St. John's wort etkisini azaltır.",
        "yan_etki": "• Sık: bulantı, göğüs hassasiyeti, ara kanama.\n• CİDDİ: pıhtı, meme/endometrium kanseri riski → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Yıllık muayene şart.",
    }),
    ("G03C", {  # Östrojen tek başına
        "dikkat": "• Doktor takibinde, kanser meyili olanlarda kullanılmaz.\n• Yıllık jinekoloji muayenesi.",
        "etkilesim": "Antiepileptik, rifampin etkisini azaltır.",
        "yan_etki": "• Sık: bulantı, baş ağrısı, sıvı tutulumu.\n• CİDDİ: pıhtı, endometrium kanseri riski → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli kontrol.",
    }),
    ("N01B", {  # Lokal anestezik
        "dikkat": "• Sağlık personeli tarafından uygulanır.\n• Alerji öyküsü bildirilmeli.",
        "etkilesim": "Adrenalin içerikli formlar kardiyak ilaçlarla etkileşir.",
        "yan_etki": "• Sık: enjeksiyon yerinde reaksiyon, geçici uyuşma.\n• CİDDİ: alerjik reaksiyon, nöbet → doktora.",
        "sonlandirma": "Tek seferlik.",
        "hatirlatma": "• Bilinen alerjilerinizi bildirin.",
    }),
    ("N06D", {  # Demans / Alzheimer
        "dikkat": "• Her gün aynı saatte düzenli kullanın.\n• Bulantı yapabilir, yemekle alın.\n• Kalp ritm sorunu olanlar dikkat.",
        "etkilesim": "Antikolinerjik ilaçlar etkisini azaltır. NSAİİ ile mide kanaması.",
        "yan_etki": "• Sık: bulantı, kusma, ishal, baş dönmesi.\n• CİDDİ: bayılma, yavaş kalp atışı → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Bakıcı/aile desteği önemli.",
    }),
    ("N06B", {  # DEHB / uyanıklık ilacı (metilfenidat, modafinil)
        "dikkat": (
            "• Sabah, yemekten sonra alınır.\n"
            "• Akşam alımı uykusuzluk yapar.\n"
            "• Kalp hastalığı, ciddi anksiyete olanlar dikkat.\n"
            "• Boy/kilo gelişimi takip edilir (çocuk)."
        ),
        "etkilesim": "MAO inhibitörü ile birlikte kullanılmaz. Tansiyon ilaçları etkisi azalabilir.",
        "yan_etki": "• Sık: iştahsızlık, uykusuzluk, baş ağrısı, kilo kaybı.\n• CİDDİ: çarpıntı, göğüs ağrısı, psikoz, bağımlılık → doktora.",
        "sonlandirma": "Doktor takibinde.",
        "hatirlatma": "• İlaç tatili bazen önerilebilir.",
    }),
    ("N07C", {  # Vertigo / antiemetik
        "dikkat": "• Uyku hali yapar — araç kullanmayın.\n• Alkol almayın.",
        "etkilesim": "Sakinleştirici, alkol ile etki artar.",
        "yan_etki": "• Sık: uyku hali, ağız kuruluğu, sersemlik.\n• CİDDİ: kalp ritm bozukluğu (nadir) → doktora.",
        "sonlandirma": "Şikayet geçince bırakın.",
        "hatirlatma": "• Yatak başı yükseltme destekleyici.",
    }),
    ("N07B", {  # Bağımlılık tedavisi
        "dikkat": "• Doktor takibinde kullanılır.\n• Reçetesiz alınmaz.",
        "etkilesim": "Alkol, opioid, MAO inhibitörü etkileşim.",
        "yan_etki": "• Sık: bulantı, baş ağrısı, uykusuzluk.\n• CİDDİ: karaciğer hasarı, ruh hali değişikliği → doktora.",
        "sonlandirma": "Doktor takibinde.",
        "hatirlatma": "• Psikososyal destek önemli.",
    }),
    ("J01C", {  # Genel penisilin
        "dikkat": "• Penisilin alerjisi olanlar kullanmamalı.\n• Tedaviyi tamamlayın.",
        "etkilesim": "Doğum kontrol etkisini azaltabilir. Probenesid atılımı azaltır.",
        "yan_etki": "• Sık: ishal, döküntü.\n• CİDDİ: anafilaksi, ciltte döküntü → ACİL.",
        "sonlandirma": "Tedaviyi tamamlayın.",
        "hatirlatma": "• Probiyotik destek.",
    }),
    ("J01X", {  # Antibakteriyel diğer
        "dikkat": "• Spesifik kullanım, doktor takibinde.\n• Tedaviyi tamamlayın.",
        "etkilesim": "Spesifik ilaca göre değişir, bildirin.",
        "yan_etki": "• Sık: ishal, bulantı.\n• CİDDİ: ciddi alerjik reaksiyon, ciltte döküntü → doktora.",
        "sonlandirma": "Tedaviyi tamamlayın.",
        "hatirlatma": "• Bol su tüketin.",
    }),
    ("J01G", {  # Aminoglikozid
        "dikkat": (
            "• Sağlık personeli tarafından uygulanır.\n"
            "• Böbrek/işitme takibi gerekir.\n"
            "• Yaşlılarda ve böbrek yetmezliğinde doz ayarlaması."
        ),
        "etkilesim": "Furosemid, vankomisin, NSAİİ ile böbrek/işitme toksisitesi artar.",
        "yan_etki": "• Sık: enjeksiyon yerinde reaksiyon.\n• CİDDİ YAN ETKİ: işitme kaybı, böbrek hasarı, denge bozukluğu → ACİL.",
        "sonlandirma": "Tedaviyi tamamlayın.",
        "hatirlatma": "• Hastane ortamında uygulanır.",
    }),
    ("J02A", {  # Sistemik antifungal (flukonazol, itrakonazol, vorikonazol)
        "dikkat": (
            "• Karaciğer takibi gerekir.\n"
            "• Gebelik ve emzirmede doktor onayı.\n"
            "• Kalp ritm bozukluğu (uzun QT) olanlar dikkat."
        ),
        "etkilesim": (
            "• Çok sayıda etkileşim — yeni ilaç bildirin.\n"
            "• Statinler ile birlikte kas hasarı.\n"
            "• Varfarin etkisini artırır.\n"
            "• Antasit/PPI emilimi etkiler (itrakonazol)."
        ),
        "yan_etki": "• Sık: bulantı, baş ağrısı, ciltte döküntü.\n• CİDDİ YAN ETKİ: karaciğer hasarı, kalp ritm bozukluğu, Stevens-Johnson → ACİL.",
        "sonlandirma": "Tedaviyi tamamlayın.",
        "hatirlatma": "• Yeni ilaçları doktora bildirin.",
    }),
    ("J06B", {  # İmmün serum / immünoglobülin
        "dikkat": "Sağlık ocağı / hastane ortamında uygulanır.",
        "etkilesim": "Canlı aşıların etkisini azaltabilir.",
        "yan_etki": "• Sık: enjeksiyon yerinde reaksiyon, baş ağrısı.\n• CİDDİ: alerjik reaksiyon → doktora.",
        "sonlandirma": "Genelde tek seferlik veya periyodik.",
        "hatirlatma": "• Sağlık personeli denetimi.",
    }),
    ("J07A", {  # Bakteriyel aşı
        "dikkat": "• Sağlık personeli tarafından uygulanır.\n• Soğuk zincir saklama.",
        "etkilesim": "İmmünsüpresif tedavi etkisini azaltır.",
        "yan_etki": "• Sık: enjeksiyon yerinde reaksiyon, ateş.\n• CİDDİ: alerjik reaksiyon → ACİL.",
        "sonlandirma": "Aşı şemasına göre.",
        "hatirlatma": "• Aşı kartı taşıyın.",
    }),
    ("J07B", {  # Viral aşı
        "dikkat": "• Sağlık personeli tarafından.\n• Soğuk zincir.\n• Bağışıklık baskısı olanlar dikkat.",
        "etkilesim": "İmmünsüpresif tedavi etkisini azaltır. Canlı aşılar belirli koşullarda kullanılmaz.",
        "yan_etki": "• Sık: ateş, kas ağrısı, enjeksiyon yerinde reaksiyon.\n• CİDDİ: alerjik reaksiyon, nadir nörolojik → doktora.",
        "sonlandirma": "Şema tamamlanır.",
        "hatirlatma": "• Aşı kartı taşıyın.",
    }),
    ("S01C", {  # Göz kortikosteroid + antibiyotik kombi
        "dikkat": "• Doktor takibinde kullanılır.\n• Göz tansiyon takibi.\n• Birden fazla kişi kullanmaz.",
        "etkilesim": "Diğer göz damlaları arası 5 dakika.",
        "yan_etki": "• Sık: yanma, bulanık görme.\n• CİDDİ: göz tansiyonu artışı, katarakt, enfeksiyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Reçetesiz kullanılmaz.",
    }),
    ("S01G", {  # Göz allerji ilacı
        "dikkat": "• Şişe ucu göze değmemeli.\n• Birden fazla kişi kullanmaz.\n• Kontakt lens 15 dakika sonra.",
        "etkilesim": "Aynı göze damlalar arası 5 dakika.",
        "yan_etki": "• Sık: yanma, bulanık görme, ağız kuruluğu.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Allerjen kaçınma destekleyici.",
    }),
    ("S01F", {  # Midriyatik / oftalmolojik tanı
        "dikkat": "• Doktor takibinde.\n• Geçici görme bulanıklığı (4-6 saat).",
        "etkilesim": "Glokom ilaçlarıyla dikkat.",
        "yan_etki": "• Sık: yanma, bulanık görme, ışığa duyarlılık.\n• CİDDİ: göz tansiyonu artışı → doktora.",
        "sonlandirma": "Tek seferlik / tanısal.",
        "hatirlatma": "• Sonrasında araç kullanmayın.",
    }),
    ("R01A", {  # Burun ilacı diğer
        "dikkat": "• Birden fazla kişi kullanmaz.\n• Uzun süre kullanılmaz.",
        "etkilesim": "Sistemik etki azdır.",
        "yan_etki": "• Sık: burunda yanma, hapşırma.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Burnu sümkürerek temizleyin.",
    }),
    ("J03", {  # diğer J03 yok aslında - generic placeholder
        "dikkat": "• Doktor önerisi ile kullanılır.",
        "etkilesim": "Yeni ilaç bildirin.",
        "yan_etki": "• Sık: durum-spesifik.\n• CİDDİ: belirti olursa doktora.",
        "sonlandirma": "Doktor önerisi.",
        "hatirlatma": "• Tedavi şemanıza uyun.",
    }),

    # ============================================================
    # Tek-harf SON FALLBACK'ler — kalan ATC'leri kapsamak için
    # En sona konuldu, daha spesifik prefix'ler bunlardan önce eşleşir.
    # ============================================================
    ("A", {  # Sindirim sistemi diğer
        "dikkat": "• Doktorunuzun önerdiği doz ve süreye uyunuz.\n• Sindirim sisteminizdeki şikayetleri doktora bildirin.\n• Karaciğer ve böbrek yetmezliği olanlar doktor kontrolünde.",
        "etkilesim": "Diğer ilaçlarınızı doktora bildirin. Yemek emilimi etkileyebilir.",
        "yan_etki": "• Sık: bulantı, ishal veya kabızlık, mide şikayetleri.\n• CİDDİ: şiddetli alerjik reaksiyon, karaciğer hasarı → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Dengeli ve düzenli beslenme destekleyici.",
    }),
    ("B", {  # Kan ilacı diğer
        "dikkat": "• Düzenli kan testi gerekir.\n• Kanama belirtilerini bildirin.\n• Doktorunuza diğer ilaçlarınızı bildirin.",
        "etkilesim": "Antikoagülan ve antiplatelet etkileşim.",
        "yan_etki": "• Sık: durum-spesifik.\n• CİDDİ: ciddi kanama, alerjik reaksiyon → ACİL doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli kontrol önemli.",
    }),
    ("C", {  # Kalp-damar diğer
        "dikkat": "• Tansiyon ve nabzı takip edin.\n• Doktor önerisi olmadan bırakmayın.\n• Düzenli kullanın.",
        "etkilesim": "Diğer kalp/tansiyon ilaçlarıyla etkileşim. NSAİİ etkiyi azaltır.",
        "yan_etki": "• Sık: baş dönmesi, yorgunluk.\n• CİDDİ: göğüs ağrısı, çarpıntı, bayılma → ACİL.",
        "sonlandirma": "Kademeli azaltma.",
        "hatirlatma": "• Düşük tuzlu diyet, düzenli kontrol.",
    }),
    ("D", {  # Dermatolojik diğer
        "dikkat": "• Sadece DIŞ KULLANIM.\n• Göz/mukoza temasından kaçınınız.\n• Etkilenen bölgeye ince tabaka.",
        "etkilesim": "Aynı bölgede başka cilt ilacı kullanmayın.",
        "yan_etki": "• Sık: uygulama yerinde kızarıklık, kaşıntı.\n• CİDDİ: yaygın alerjik reaksiyon → bırakın.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Uygulamadan önce ve sonra eller yıkanır.",
    }),
    ("G", {  # Ürogenital / hormon diğer
        "dikkat": "• Doktor önerisi ile kullanılır.\n• Düzenli kullanım.\n• Hormonal etkiler bildirilmeli.",
        "etkilesim": "Diğer hormonal tedaviler ile etkileşim.",
        "yan_etki": "• Sık: bulantı, baş ağrısı, ruh hali değişikliği.\n• CİDDİ: pıhtı, ciddi alerjik reaksiyon → doktora.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• Düzenli muayene şart.",
    }),
    ("H", {  # Hormon diğer
        "dikkat": "• Doktor önerisi olmadan dozu değiştirmeyin.\n• Düzenli kan testi.\n• Gebelik durumunu bildirin.",
        "etkilesim": "Çok sayıda hormonal etkileşim — yeni ilaç bildirin.",
        "yan_etki": "• Sık: kilo değişimi, sıvı tutulumu.\n• CİDDİ: belirti olursa doktora.",
        "sonlandirma": "Doktor takibinde kademeli.",
        "hatirlatma": "• Kronik tedavi olabilir.",
    }),
    ("J", {  # Anti-infektif diğer
        "dikkat": "• Tedaviyi tamamlayın.\n• Alerji öyküsü bildirilmeli.\n• Karaciğer/böbrek takibi gerekebilir.",
        "etkilesim": "Doğum kontrol etkisi azalabilir. Diğer ilaçları bildirin.",
        "yan_etki": "• Sık: ishal, bulantı, döküntü.\n• CİDDİ: anafilaksi, şiddetli ishal, alerjik reaksiyon → ACİL.",
        "sonlandirma": "Tedaviyi TAMAMLAYINIZ.",
        "hatirlatma": "• Probiyotik destek faydalı.",
    }),
    ("L", {  # Antineoplastik / immün diğer
        "dikkat": "• Onkoloji/romatoloji takibinde.\n• Düzenli kan testi.\n• Enfeksiyon belirtilerini bildirin.\n• Canlı aşı yapılmaz.",
        "etkilesim": "Çok sayıda etkileşim — yeni ilaç bildirin.",
        "yan_etki": "• Sık: enfeksiyon, halsizlik, sindirim şikayetleri.\n• CİDDİ: ciddi enfeksiyon, kanama, yan etki → ACİL.",
        "sonlandirma": "Uzman doktor takibinde.",
        "hatirlatma": "• Hijyen, kalabalık ortamlarda dikkat.",
    }),
    ("M", {  # Kas-iskelet diğer
        "dikkat": "• Doktor önerisi ile.\n• Aspirin/NSAİİ alerjisi olanlar dikkatli.",
        "etkilesim": "Kan sulandırıcılar, tansiyon ilaçları ile etkileşim.",
        "yan_etki": "• Sık: mide şikayetleri, baş ağrısı.\n• CİDDİ: mide kanaması, alerjik reaksiyon → doktora.",
        "sonlandirma": "Şikayet geçince bırakın.",
        "hatirlatma": "• En düşük etkili doz.",
    }),
    ("N", {  # Sinir sistemi diğer
        "dikkat": "• Doktor önerisi olmadan bırakmayın.\n• Uyku/sersemlik yapabilir — araç kullanmayın.\n• Alkol almayın.",
        "etkilesim": "Sakinleştirici, alkol, diğer sinir sistemi ilaçları ile etkileşim.",
        "yan_etki": "• Sık: uyku hali, baş dönmesi, ağız kuruluğu.\n• CİDDİ: ruh hali değişikliği, ciddi alerjik reaksiyon → doktora.",
        "sonlandirma": "Kademeli azaltma.",
        "hatirlatma": "• Düzenli uyku destekleyici.",
    }),
    ("P", {  # Antiparazitik / böcek diğer
        "dikkat": "• Doktor önerisi ile.\n• Hijyen önemli.\n• Aile üyeleri ile birlikte tedavi gerekebilir.",
        "etkilesim": "Genelde önemli sistemik etkileşim yok.",
        "yan_etki": "• Sık: bulantı, ciltte tahriş.\n• CİDDİ: alerjik reaksiyon → bırakın.",
        "sonlandirma": "Tek doz / tedavi şeması.",
        "hatirlatma": "• Hijyen kuralları, çamaşır yıkama.",
    }),
    ("R", {  # Solunum diğer
        "dikkat": "• Düzenli kullanılır.\n• Atak için kurtarıcı yanınızda olsun (astım).",
        "etkilesim": "Beta-bloker etki azaltır. MAO inhibitörü ile dikkat.",
        "yan_etki": "• Sık: titreme, çarpıntı, ses kısıklığı, baş ağrısı.\n• CİDDİ: çarpıntı, paradoks bronkospazm → ACİL.",
        "sonlandirma": "Doktor önerisi ile.",
        "hatirlatma": "• İnhaler tekniği önemli.",
    }),
    ("S", {  # Göz-kulak diğer
        "dikkat": "• Şişe ucu göze/kulağa değmemeli.\n• Birden fazla kişi kullanmamalı.",
        "etkilesim": "Aynı göze damlalar arası 5 dakika.",
        "yan_etki": "• Sık: hafif yanma, bulanık görme.\n• CİDDİ: ağrı, kalıcı kızarıklık → doktora.",
        "sonlandirma": "Şikayet geçince.",
        "hatirlatma": "• Hijyene dikkat.",
    }),
    ("V", {  # Çeşitli diğer
        "dikkat": "• Doktor önerisi ile kullanılır.",
        "etkilesim": "Spesifik duruma göre.",
        "yan_etki": "• Sık: durum-spesifik.\n• CİDDİ: belirti olursa doktora.",
        "sonlandirma": "Doktor önerisi.",
        "hatirlatma": "• Sağlık personeli denetimi gerekebilir.",
    }),
]


# ============================================================
# Generator function
# ============================================================
def generate_general_blocks(atc_code: str | None) -> dict[str, str]:
    """ATC koduna göre 5 detaylı blok döner: dikkat, etkilesim, yan_etki,
    sonlandirma, hatirlatma. Saklama+sıvı+hazırlama form bazlıdır
    (atc_label_blocks.py'da)."""
    if not atc_code:
        return {}
    code = atc_code.upper()
    for prefix, blocks in ATC_PREFIX_BLOCKS:
        if code.startswith(prefix):
            return dict(blocks)
    return {}
