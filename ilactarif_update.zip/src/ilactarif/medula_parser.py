"""Medula reçete HTML → yapısal veri.

Medula iki ekranda ilaç bilgisi gösterir; ikisini de destekliyoruz:

  1) ReceteIslem2.jsp + form `f`     → reçete yazma/inceleme
     - Tablo id 'f:tbl1', class 'dataTableEx'
     - Kolonlar: Barkod | Adet/Periyot/Doz | Stk/Raf | Adı | Tutar | Fark | Rapor

  2) ReceteIslem2.jsp + form `form1` → karekod onay (KarekodIslem.jsp'ye action)
     - Tablo borderTable
     - Kolonlar: RAF | İlaç Adı | Reçeteki Adet | Stok | Doz | Eksik KK
     - 'Doz' sütununda "2 x 1,00 (1Günde)" formatı

Output: PrescriptionCapture (hasta + ilaç listesi).
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Optional

from bs4 import BeautifulSoup


# ---------------------------------------------------------------------------
# Veri yapıları
# ---------------------------------------------------------------------------
@dataclass
class CapturedDrug:
    barkod: str = ""
    ad: str = ""
    adet: str = ""                # "1" / "6"
    doz_ham: str = ""             # "Günde 1 x 1.0" / "2 x 1,00 (1Günde)" / "1 / Günde / 1 Adet"
    doz_gunluk_kez: Optional[int] = None
    doz_birim_adedi: Optional[float] = None   # her seferdeki ADET (t4) "1.0" → 1.0
    doz_birim: str = ""           # "Adet" / "Gram" / "Mililitre"
    birim_doz_miktari: Optional[float] = None  # BİR adedin gerçek miktarı: Medula
                                  # "Adet/Periyot/Doz" sütunundaki mavi span
                                  # ("5, Mililitre"→5, "0,04 Mililitre"→0.04,
                                  # "1, Adet"→1, "10, Mililitre"→10, "1, Gram"→1).
                                  # 1 adetin ne olduğunu (ölçek/damla/ml/tane) belirler.
    periyot: str = ""             # "Günde" / "Haftada" / "Ayda" / "Yılda"
    raf: str = ""                 # "E.6 (4)" gibi
    stok: Optional[int] = None    # "Stk/Raf" sütunundaki güncel stok adedi. Reçete
                                   # KAYDEDİLDİKTEN sonra düşülür; elde yoksa EKSİYE
                                   # düşer (örn. -1). Etiket-baskısı kararında kullanılır.
    eksik_kk: Optional[int] = None  # İTS Karekod İşlemleri ekranı "Eksik KK Adet"
                                  # sütunu: bu ilaç için henüz OKUTULMAMIŞ karekod
                                  # sayısı. 0 → tüm karekodlar okutuldu. Yalnız
                                  # karekod_onay sayfasında dolu olur.
    aciklama: str = ""            # Doktor notu, varsa
    tutar: str = ""
    kullanim_sekli: str = ""      # "Ağızdan", "Göz üzerine", "Cilt üzerine" gibi
    urun_id: str = ""             # Medula'nın iç urunid attribute'u
    geri_odeme_yok: bool = False  # "(Geri Ödeme Kapsamında Değildir)" satırı varsa True
                                   # (SGK ödemez; etiket yine reçete başında üretilir)


@dataclass
class PrescriptionCapture:
    page_kind: str = ""           # "e_recete_detay" | "e_recete_sorgu_sonuc"
                                   # | "recete_yazma" | "karekod_onay" | "diger"
    document_url: str = ""
    hasta_ad: str = ""
    hasta_tc: str = ""
    recete_no: str = ""           # E-Reçete No (örn. 2NY2W16)
    takip_no: str = ""
    recete_tarihi: str = ""
    recete_turu: str = ""         # Normal/Kırmızı vb.
    recete_alt_turu: str = ""     # Ayaktan/Yatan vb.
    fatura_kapsami: str = ""      # "Kapsam:" alanı (reçete işlem form f sayfası):
                                   # örn. "Geçici Koruma Kanunu (6458) Kapsamında Olan
                                   # Yabancılar". Yabancı uyruklu (TC 98/99) hastalarda
                                   # geçici koruma DIŞI bir kapsam → SGK kağıdı uyarısı
                                   # için kullanılır (bkz. needs_foreign_paper_warning).
    dr_ad: str = ""
    dr_brans: str = ""
    drugs: list = field(default_factory=list)
    tanılar: list = field(default_factory=list)   # [(ICD-10 kodu, tanı metni)]
    recete_aciklamalari: list = field(default_factory=list)
    # [(açıklama türü, açıklama metni)] — örn. ("Teşhis/Tanı", "Hasta diyabet ile takipte")
    # Medula form1:tableEx1 'Açıklama Listesi' tablosundan gelir; reçete bazlıdır
    # (tüm ilaçlara uygulanır).
    raw_kalem_kutu: str = ""      # "2 KALEM, 2 KUTU GETİRİN" gibi
    eczane: str = ""
    saved: bool = False           # E-reçete KAYDEDİLMİŞ mi? True → reçete SONU (SGK
                                   # onaylı, kalanlar), False → reçete BAŞI (taslak).
                                   # Sinyal: "İTS Karekod İşlemleri" butonu (kayıt sonrası belirir).
    scanned_karekodlar: list = field(default_factory=list)
                                   # İTS Karekod İşlemleri ekranındaki textarea'ya (form1:textarea1)
                                   # OKUTULAN karekodların ham satırları. Barkoda dönüştürülüp
                                   # "hangi ilaçtan kaç kutu okutuldu" sayımı için kullanılır.
    eksik_kk_total: Optional[int] = None
                                   # karekod_onay sayfasındaki "Eksik KK Adet" sütununun
                                   # TOPLAMI (tüm ilaçlar). 0 → tüm karekodlar okutuldu;
                                   # >0 → eksik karekod var. None → sütun okunamadı.
                                   # Pencere tema rengi (compute_medula_theme) için kullanılır.
    karekod_pending: bool = False  # Kaydedilmiş reçete sayfasında "İTS Karekod İşlemleri"
                                   # butonu HÂLÂ duruyor mu? True → karekod adımı henüz
                                   # tamamlanmamış (reçete kaydedildi ama sonlanmadı).


# ---------------------------------------------------------------------------
# Yardımcı: hücreyi normalize et
# ---------------------------------------------------------------------------
def _t(el) -> str:
    if el is None:
        return ""
    return re.sub(r"\s+", " ", el.get_text(" ", strip=True))


_DOZ_BIRIM_RX = re.compile(
    r"(Adet|Gram|Mililitre|ml|gr|Damla|Ölçek|Tablet|Tane|Puf|Fitil|Ovül)",
    re.IGNORECASE,
)

# "Stk/Raf" hücresi: baştaki (eksi olabilen) stok adedi + raf kodu. Raf kodu
# daima "(adet)" ile biter: "0 D.10(9)", "-1 J.6(14)", "5 J.5(16)". Sondaki
# parantez yalnız RAKAM içerir → ilaç adı "… (10 ADET)" / fiyat / tarih elenir.
_STK_RAF_RX = re.compile(r"^\s*(-?\d+)\s+(.*\(\d+\))\s*$")

# Medula "Adet / Periyot / Doz" sütunundaki birim-doz: "5, Mililitre" /
# "0,04 Mililitre" / "1, Adet" / "10, Mililitre" / "1, Gram". Miktar + birim.
_BIRIM_DOZ_RX = re.compile(
    r"(?P<miktar>\d+(?:[.,]\d+)?)\s*,?\s*"
    r"(?P<birim>Adet|Mililitre|Gram|Mikrogram|Ünite|Damla|Ölçek)",
    re.IGNORECASE,
)


def _extract_birim_doz(text: str) -> tuple[Optional[float], str]:
    """'5, Mililitre' → (5.0, 'Mililitre'); '0,04 Mililitre' → (0.04, 'Mililitre').

    Medula doz hücresindeki birim-doz (1 adetin gerçek miktarı+birimi). Bulamazsa
    (None, '').
    """
    if not text:
        return None, ""
    m = _BIRIM_DOZ_RX.search(text)
    if not m:
        return None, ""
    try:
        miktar = float(m.group("miktar").replace(",", "."))
    except (TypeError, ValueError):
        miktar = None
    return miktar, m.group("birim").capitalize()


def _doz_blob_from_cell(cell) -> tuple[str, Optional[float]]:
    """Doz hücresinden (blob, birim_doz_miktari) döndürür.

    Reçete yazma/sonu sayfasında doz hücresi bir input+select widget'ıdır
    (panelBox). get_text() iki nedenle bozuk sonuç verir:
      • <input> value'larını (gerçek sayılar: kez, doz) GÖRMEZ,
      • <select>'in TÜM option'larını döker → "Günde Haftada Ayda Yılda".
    Bu yüzden değerleri input value'larından ve SEÇİLİ option'dan okuyup
    "Günde 1 x 1,0 Adet" gibi _parse_doz'un anladığı düz bir blob kurarız.
    Widget yoksa düz metne düşer (eski davranış).
    """
    # Birim-doz (1 adetin gerçek miktarı): hücredeki mavi span "5, Mililitre".
    # input value'ları get_text'te görünmediğinden hücre metnindeki tek sayı
    # bu span'in miktarıdır.
    bd_miktar, _bd_birim = _extract_birim_doz(_t(cell))

    box = cell.find("table", class_="panelBox")
    if box is None:
        return _t(cell), bd_miktar

    def _inp(suffix: str) -> str:
        el = box.find("input", id=lambda v: v and v.endswith(":" + suffix))
        return (el.get("value", "") if el else "").strip()

    periyot = ""
    sel = box.find("select")
    if sel is not None:
        opt = sel.find("option", selected=True) or sel.find("option")
        periyot = _t(opt)

    kez = _inp("t3")       # periyot içindeki kez sayısı (Doz: "kez x adet")
    adet = _inp("t4")      # her seferdeki doz miktarı (NxM'deki M)
    pcount = _inp("t5")    # PERİYOT ÇARPANI: "her N <birim>de". Medula haftalığı
                           # "Günde + t5=7" olarak kodlar (ör. D-Colefor: 7 Günde
                           # 2 kez = HAFTADA 2). t5 yoksa/1 ise normal günlük.
    m = _DOZ_BIRIM_RX.search(_t(cell))
    birim = m.group(1) if m else ""

    eff_periyot = _map_periyot(periyot, pcount)
    if eff_periyot and kez and adet:
        return f"{eff_periyot} {kez} x {adet} {birim}".strip(), bd_miktar
    return _t(cell), bd_miktar


def _map_periyot(unit: str, count) -> str:
    """Periyot birimi + çarpan → standart periyot kelimesi.

    Medula "her N günde" periyodunu "Günde" birimi + t5=N olarak kodlar.
    Günde+7 → Haftada, Günde+~30 → Ayda, Günde+365 → Yılda. Tanımsız çarpanda
    birim olduğu gibi döner (regresyon yok). Haftada/Ayda zaten seçiliyse korunur.
    """
    u = (unit or "Günde").strip()
    try:
        n = int(float(str(count).replace(",", "."))) if count else 1
    except (TypeError, ValueError):
        n = 1
    if n <= 1:
        return u
    low = u.lower()
    if low.startswith("gün") or low.startswith("gun"):
        if n == 7:
            return "Haftada"
        if n in (28, 29, 30, 31):
            return "Ayda"
        if n in (365, 366):
            return "Yılda"
    return u


# ---------------------------------------------------------------------------
# Sayfa tipi tespiti
# ---------------------------------------------------------------------------
def is_erecete_saved(soup: BeautifulSoup) -> bool:
    """E-reçete KAYDEDİLMİŞ mi? (reçete sonu / SGK onaylı)

    En güvenilir sinyal: kayıt işleminden sonra sayfaya eklenen
    "İTS Karekod İşlemleri" butonu (id=f:buttonKarekodIslemleri). Kaydedilmemiş
    (reçete başı / taslak) sayfada bu buton YOKTUR. Yedek sinyal: "Karekod
    Sonlandır" butonu.
    """
    if soup.find(id=re.compile(r"buttonKarekodIslemleri", re.IGNORECASE)):
        return True
    for inp in soup.find_all("input"):
        val = inp.get("value") or ""
        if "Karekod İşlemleri" in val or "Karekod Sonlandır" in val:
            return True
    return False


def _extract_erecete_no(soup: BeautifulSoup) -> str:
    """Form sayfasından TEMİZ e-Reçete No değerini çıkarır (mavi outputText span).

    'e-Reçete No' etiketinden sonraki mavi değer span'ini bulur ve değerin makul bir
    e-reçete kodu (4-12 alfanümerik) olduğunu doğrular. Erken↔final eşleşme anahtarı
    olarak kullanılır; _extract_recete_meta'nın birleşik hücre kirliliğini önler.
    """
    for span in soup.find_all("span", class_="outputText"):
        t = _t(span).strip().lower().rstrip(":").strip()
        if t in ("e-reçete no", "ereçete no", "e reçete no"):
            nxt = span.find_next(
                lambda tag: tag.name == "span"
                and "outputText" in (tag.get("class") or [])
                and "blue" in (tag.get("style") or "").lower()
            )
            if nxt:
                v = _t(nxt).strip()
                if re.fullmatch(r"[0-9A-Za-z]{4,12}", v):
                    return v
    return ""


def _extract_recete_no_sgk(soup: BeautifulSoup) -> str:
    """SGK 'Reçete No' değerini çıkarır (kağıt reçetede kayıtta atanır).

    TAM 'Reçete No' etiketini hedefler ('e-Reçete No' DEĞİL). Kaydedilmemiş kağıtta
    bu değer '0' veya boştur; kaydedilince alfanümerik bir numara atanır.
    """
    for span in soup.find_all("span", class_="outputText"):
        t = _t(span).strip().lower().rstrip(":").strip()
        if t == "reçete no":          # tam eşleşme — 'e-reçete no' hariç
            nxt = span.find_next(
                lambda tag: tag.name == "span"
                and "outputText" in (tag.get("class") or [])
                and "blue" in (tag.get("style") or "").lower()
            )
            if nxt:
                return _t(nxt).strip()
    return ""


def _recete_no_is_assigned(soup: BeautifulSoup) -> bool:
    """SGK Reçete No ATANMIŞ mı? ('0'/'-'/boş değil → KAYDEDİLMİŞ reçete = reçete sonu).

    e-reçete/kağıt ayrımından bağımsız genel sinyal: kayıt işleminden sonra reçete
    numarası atanır. Sonradan reçete dolaşılırken bu numara dolu görülürse reçetenin
    KAYDEDİLMİŞ (reçete sonu) olduğu anlaşılır.
    """
    sgk = _extract_recete_no_sgk(soup)
    return bool(sgk) and sgk not in ("0", "-", "")


def is_kagit_saved(soup: BeautifulSoup) -> bool:
    """KAĞIT reçete KAYDEDİLMİŞ mi? (e-Reçete No boş VE SGK Reçete No dolu)."""
    return (not _extract_erecete_no(soup)) and _recete_no_is_assigned(soup)


def _norm_tr(s: str) -> str:
    """Türkçe-duyarsız karşılaştırma için normalize (küçük harf + ı/İ/ç… → ASCII)."""
    s = (s or "").strip().lower().replace("̇", "")   # combining dot (İ→i̇)
    table = str.maketrans({
        "ı": "i", "ş": "s", "ğ": "g", "ü": "u", "ö": "o", "ç": "c",
        "İ": "i", "Ş": "s", "Ğ": "g", "Ü": "u", "Ö": "o", "Ç": "c", "I": "i",
    })
    return s.translate(table)


def _extract_fatura_kapsami(soup: BeautifulSoup) -> str:
    """Reçete işlem (form f) sayfasındaki 'Kapsam:' değerini döndürür.

    HTML yapısı:
        <SPAN ... >Kapsam:</SPAN></TD>
        <TD><SPAN ... COLOR: blue>Geçici Koruma Kanunu (6458) Kapsamında ...</SPAN>
    'Kapsam:' etiketinden sonraki ilk mavi (COLOR: blue) outputText değerini alır.
    Bulamazsa 'Fat.Türü:' etiketinin değerine düşer (aynı bilgi). Yoksa ''.
    """
    def _value_after(label_span) -> str:
        nxt = label_span.find_next(
            lambda tag: tag.name in ("span", "SPAN")
            and "outputText" in (tag.get("class") or [])
            and "blue" in (tag.get("style") or "").lower()
            and _t(tag).strip()
        )
        return _t(nxt).strip() if nxt else ""

    for wanted in ("kapsam", "fat.turu", "fat turu"):
        for span in soup.find_all(["span", "SPAN"]):
            if "outputText" not in (span.get("class") or []):
                continue
            if _norm_tr(_t(span).rstrip(":").strip()) == wanted:
                v = _value_after(span)
                if v:
                    return v
    return ""


def _extract_recete_sahibi_tc(soup: BeautifulSoup) -> str:
    """Form f sayfasındaki 'Reçete Sahibi T.C.' giriş kutusunun (f:t18) değerini al.

    Reçete sonu/işlem sayfasında hasta TC'si genel etiket eşlemesiyle gelmez;
    'Reçete Sahibi T.C. (*)' etiketinden sonraki 11 haneli INPUT'tan okunur.
    ('Teslim Alan T.C.' DEĞİL — o ilacı teslim alan kişidir.)
    """
    # En güvenilir: sabit id f:t18
    el = soup.find(id="f:t18")
    if el is not None and el.name in ("input", "INPUT"):
        v = (el.get("value") or "").strip()
        if re.fullmatch(r"\d{11}", v):
            return v
    # Yedek: 'Reçete Sahibi T.C.' etiketinden sonraki ilk 11 haneli input
    lbl = next(
        (s for s in soup.find_all(["span", "label", "SPAN", "LABEL"])
         if _norm_tr(_t(s)).startswith("recete sahibi t.c")),
        None,
    )
    if lbl is not None:
        inp = lbl.find_next(["input", "INPUT"])
        if inp is not None:
            v = (inp.get("value") or "").strip()
            if re.fullmatch(r"\d{11}", v):
                return v
    return ""


def is_foreign_tc(tc: str) -> bool:
    """TC kimlik no yabancı uyruklu kimliği mi? (98 veya 99 ile başlar)

    Yabancı uyruklulara verilen yabancı kimlik no'ları 98/99 ile başlar; T.C.
    vatandaşı kimlik numaraları bu önekle başlamaz.
    """
    tc = (tc or "").strip()
    return tc.isdigit() and len(tc) == 11 and tc[:2] in ("98", "99")


def needs_foreign_paper_warning(cap: "PrescriptionCapture") -> bool:
    """Hasta yabancı uyruklu (TC 98/99) AMA geçici koruma kapsamı DIŞINDA mı?

    True → 'SGK'lı yabancı uyruklu, Topkapı SGK'dan kağıt getirmeli' uyarısı gerekir.
    Kural:
      • TC 98/99 ile başlamıyorsa (T.C. vatandaşı) → uyarı yok.
      • 'Kapsam:' değeri okunamadıysa → uyarı yok (yanlış alarm engellenir).
      • Kapsam 'Geçici Koruma' içeriyorsa → sorun yok, uyarı yok.
      • Kapsam başka bir fatura grubu ise → uyarı GEREKİR.
    """
    if not is_foreign_tc(getattr(cap, "hasta_tc", "")):
        return False
    kapsam = _norm_tr(getattr(cap, "fatura_kapsami", "") or "")
    if not kapsam:
        return False
    return "gecici koruma" not in kapsam


def detect_page_kind(soup: BeautifulSoup) -> str:
    # Success message tespiti (e-reçete + kağıt reçete kayıtları için ortak)
    success_span = None
    for sp in soup.find_all(["span", "SPAN"]):
        cls = sp.get("class") or []
        if "receteSuccessMessage" in cls:
            success_span = sp
            break
    if success_span:
        # Muadil değişikliği sırasında çıkan ara sayfalar (ITS satış iptali,
        # reçete silme teyidi vb.) de receteSuccessMessage içeriyor; bunlar
        # gerçek reçete kaydı değil, görmezden gel.
        _ss_txt = _t(success_span).lower()
        _IPTAL_KW = ("satış iptali", "satıs iptali", "silindi", "iptal edildi", "iptali yapıldı")
        if any(kw in _ss_txt for kw in _IPTAL_KW):
            return "diger"
        # E-REÇETE mi KAĞIT mı? → tek güvenilir ayraç: e-Reçete No alanı DOLU mu?
        # (Hem e-reçetenin e-reçete no'su hem kağıdın SGK reçete no'su alfanümerik
        #  olabildiği için numara FORMATI ayırt etmez; ayraç e-Reçete No alanıdır.)
        if _extract_erecete_no(soup):
            return "e_recete_basarili"
        # e-Reçete No yok → KAĞIT reçete (kaydedilmiş, SGK reçete no atanmış)
        return "kagit_recete_basarili"

    # En spesifik: E-Reçete Detay (hem E-Reçete Bilgileri hem İlaç Bilgileri başlıkları)
    header_texts = {_t(tr) for tr in soup.find_all("tr", class_="headerRow")}
    if "İlaç Bilgileri" in header_texts and "E-Reçete Bilgileri" in header_texts:
        return "e_recete_detay"
    # E-Reçete sorgu sonuç (hasta seçim listesi)
    if soup.find("table", id="form1:tableExERecete"):
        return "e_recete_sorgu_sonuc"
    # Reçete işlem sayfası (form f, f:tbl1) — kağıt VEYA e-reçete olabilir.
    # NOT: "E-Reçete Görüntüle" sayfası yukarıda e_recete_detay olarak yakalandığı için
    # buraya düşmez; bu yüzden burada SGK reçete no doluysa = KAYDEDİLMİŞ = reçete SONU.
    if soup.find("form", id="f") and soup.find("table", id="f:tbl1"):
        if _recete_no_is_assigned(soup):
            # Reçete numarası atanmış → KAYDEDİLMİŞ reçete (sonradan dolaşılırken de).
            # e-Reçete No varsa kaydedilmiş e-reçete, yoksa kaydedilmiş kağıt reçete.
            return "e_recete_basarili" if _extract_erecete_no(soup) else "kagit_recete_basarili"
        return "recete_yazma"
    # Karekod onay
    form1 = soup.find("form", id="form1")
    if form1 and "KarekodIslem.jsp" in (form1.get("action") or ""):
        return "karekod_onay"
    # E-Reçete sorgu formu (henüz reçete seçilmemiş)
    if soup.find(string=re.compile(r"E-Reçete\s*Sorgu", re.IGNORECASE)):
        return "e_recete_sorgu_form"
    return "diger"


# ---------------------------------------------------------------------------
# Medula pencere TEMASI: reçete yaşam döngüsüne göre renk durumu
# ---------------------------------------------------------------------------
def compute_medula_theme(cap: "PrescriptionCapture") -> Optional[str]:
    """Reçetenin o anki durumuna göre Medula penceresinin tema rengini döndürür.

    Döndürür: "green" | "orange" | "blue" | None.

    Kullanıcı tanımı:
      • YEŞİL  — reçete SONLANMIŞ (İTS karekod işlemi tamamlandı).
      • TURUNCU — karekod ekranında EKSİK karekod var, henüz sonlandırılmamış.
      • MAVİ   — reçete açık / işlem sürüyor (henüz sonlanmamış).
      • None   — reçeteyle ilgisiz sayfa (tema değiştirme).

    En güvenilir sinyal İTS Karekod İşlemleri ("karekod_onay") ekranındaki
    "Eksik KK Adet" toplamıdır: >0 → turuncu, 0 → tüm karekodlar okutuldu → yeşil.
    """
    pk = cap.page_kind
    if pk == "karekod_onay":
        total = cap.eksik_kk_total
        if total is None:
            # Eksik sütunu okunamadı: okutma başladıysa turuncu, yoksa mavi.
            return "orange" if (cap.scanned_karekodlar or []) else "blue"
        return "green" if total <= 0 else "orange"
    if pk == "kagit_recete_basarili":
        # Kağıt reçetede İTS karekod adımı yok → kayıt = sonlanmış.
        return "green"
    if pk == "e_recete_basarili":
        # Kaydedildi; "İTS Karekod İşlemleri" butonu duruyorsa karekod bekliyor.
        return "blue" if cap.karekod_pending else "green"
    if pk in ("e_recete_detay", "recete_yazma"):
        return "blue"
    return None


# ---------------------------------------------------------------------------
# Eczane ve hasta bilgisi (üst banner + reçete no kutuları)
# ---------------------------------------------------------------------------
def _extract_eczane(soup: BeautifulSoup) -> str:
    t = soup.find("td", class_="menuText")
    return _t(t)


def _extract_recete_meta(soup: BeautifulSoup) -> dict:
    """Reçete No, Hasta TC, Hasta Adı, Reçete Tarihi gibi alanları arar."""
    meta = {}
    # Türkçe etiketleri arayıp komşu hücredeki değeri al
    label_map = {
        "Reçete No":   "recete_no",
        "Reçete Tarihi": "recete_tarihi",
        "Hasta T.C.":   "hasta_tc",
        "Hasta TC":     "hasta_tc",
        "Hasta Adı":    "hasta_ad",
        "Hak Sahibi":   "hasta_ad",
        "Dr. Ad/Soyad": "dr_ad",
        "Dr Ad/Soyad":  "dr_ad",
    }
    for td in soup.find_all(["td", "label", "span"]):
        txt = _t(td)
        for label, key in label_map.items():
            if txt.startswith(label) and key not in meta:
                # Aynı td içinde değer olabilir (Reçete No: 0)
                m = re.match(rf"^{re.escape(label)}\s*[:：]?\s*(.+)$", txt)
                val = (m.group(1).strip() if m else "")
                if not val:
                    # Komşu td/span/label'a bak
                    nxt = td.find_next(["td", "span", "label", "input"])
                    if nxt is not None:
                        if nxt.name == "input":
                            val = nxt.get("value", "")
                        else:
                            val = _t(nxt)
                if val:
                    meta[key] = val
                break

    # Sonuç sayfası (e_recete_basarili): hasta adı genel etiket eşlemesinde
    # yok; "Reçete Sahibi Adı/Soy." etiketinin yanındaki panelBox içinde
    # iki ayrı span (ad + soyad) olarak durur. ("Teslim Alan Adı/Soy." ise
    # ilacı teslim alan kişidir; onu DEĞİL reçete sahibini alıyoruz.)
    if not meta.get("hasta_ad"):
        lbl = next(
            (s for s in soup.find_all("span")
             if _t(s).startswith("Reçete Sahibi Ad")),
            None,
        )
        if lbl is not None:
            tr = lbl.find_parent("tr")
            box = None
            if tr is not None:
                box = tr.find("table", class_="panelBox") or tr.find("table")
            if box is not None:
                parts = [_t(s) for s in box.find_all("span")]
                name = " ".join(p for p in parts if p).strip()
                if name:
                    meta["hasta_ad"] = name

    return meta


# ---------------------------------------------------------------------------
# Sayfa tipi 1: Reçete yazma (form f, f:tbl1)
# ---------------------------------------------------------------------------
_PERIYOT_KW = ("günde", "haftada", "ayda", "yılda", "gunde", "yilda")
# Fiyat hücresi: "64,77", "1.234,56", "0,00" gibi sadece sayı+ayraç
_RX_PRICE = re.compile(r"^\d{1,3}(?:[.,]\d{3})*(?:[.,]\d+)?$")
_RX_LETTERS = re.compile(r"[A-Za-zÇĞİÖŞÜçğıöşü]")


def _looks_like_price(t: str) -> bool:
    return bool(_RX_PRICE.fullmatch((t or "").strip()))


def _letter_count(t: str) -> int:
    return len(_RX_LETTERS.findall(t or ""))


def _is_doz_cell(cell) -> bool:
    """Doz hücresi: panelBox widget'ı veya 'Günde/Haftada/...' periyot metni içerir."""
    if cell.find("table", class_="panelBox"):
        return True
    low = _t(cell).lower()
    return any(k in low for k in _PERIYOT_KW)


def parse_recete_yazma(soup: BeautifulSoup) -> PrescriptionCapture:
    cap = PrescriptionCapture(page_kind="recete_yazma")
    cap.eczane = _extract_eczane(soup)
    cap.__dict__.update({k: v for k, v in _extract_recete_meta(soup).items() if v})

    tbl = soup.find("table", id="f:tbl1")
    if not tbl:
        return cap

    # SABİT kolon indeksi KIRILGAN: Medula 'Stk/Raf' gibi kolonları boşsa
    # daraltıp atlayabiliyor → veri satırı başlıktan az hücre içeriyor, 'Adı'
    # bir sola kayıp 'Tutar' (fiyat) okunuyordu (etikette "64,77" çıktı).
    # Çözüm: ilaç satırlarını CSS sınıfından (rowClass1/2) seç ve içinde
    #   • doz hücresi  = periyot/panelBox içeren hücre,
    #   • ilaç adı     = en çok harf içeren (fiyat/tarih olmayan) hücre,
    #   • barkod       = satırdaki 8-14 hanelik input value,
    # olarak İÇERİKTEN tespit et — kolon kayması bunu etkilemez.
    drug_rows = [
        tr for tr in tbl.find_all("tr", recursive=True)
        if any(c in ("rowClass1", "rowClass2") for c in (tr.get("class") or []))
    ]
    # Yedek: rowClass yoksa eski davranış (>=5 hücreli satırlar)
    if not drug_rows:
        drug_rows = [
            tr for tr in tbl.find_all("tr", recursive=True)
            if len(tr.find_all("td", recursive=False)) >= 5
        ]

    for tr in drug_rows:
        cells = tr.find_all("td", recursive=False)
        if len(cells) < 4:
            continue

        # Barkod: satırdaki 8-14 hanelik input value
        barkod = ""
        for c in cells:
            inp = c.find("input")
            v = (inp.get("value", "") if inp else "").strip()
            if re.fullmatch(r"\d{8,14}", v):
                barkod = v
                break

        # Doz hücresi (periyot/panelBox)
        doz_cell = next((c for c in cells if _is_doz_cell(c)), None)
        if doz_cell is not None:
            doz_blob, _bd_miktar = _doz_blob_from_cell(doz_cell)
        else:
            doz_blob, _bd_miktar = "", None

        # İlaç adı: doz hücresi DIŞINDA, fiyat olmayan, en çok harf içeren hücre
        ad = ""
        best_letters = 0
        for c in cells:
            if c is doz_cell:
                continue
            t = _t(c)
            if not t or _looks_like_price(t):
                continue
            lc = _letter_count(t)
            # En az 3 harf olsun (raf kodu "F.6(5)" ya da tarih elenir)
            if lc >= 3 and lc > best_letters:
                best_letters = lc
                ad = t

        # Tutar: ad hücresinden SONRA gelen ilk fiyat hücresi (bilgi amaçlı)
        tutar = ""
        seen_ad = False
        for c in cells:
            t = _t(c)
            if t == ad:
                seen_ad = True
                continue
            if seen_ad and _looks_like_price(t) and t not in ("0,00", "0.00"):
                tutar = t
                break

        # Boş / çöp satırları atla
        if not (barkod or ad):
            continue
        if not re.search(r"[0-9A-Za-zÇĞİÖŞÜçğıöşü]", f"{barkod}{ad}"):
            continue
        if ad.lower() == "adı" or barkod.lower() == "barkod":
            continue
        # Medula'nın editörlü tablosunda BOŞ ilaç slotları olur (ad yok, doz
        # "0,00"). Bunlar etikette "0,00" adıyla boş etiket üretiyordu. Gerçek
        # ilacın daima harfli bir adı vardır → en az 3 harf yoksa satırı atla.
        if _letter_count(ad) < 3:
            continue

        drug = CapturedDrug(
            barkod=barkod, ad=ad, doz_ham=doz_blob, tutar=tutar
        )
        drug.birim_doz_miktari = _bd_miktar
        _parse_doz(drug, doz_blob)

        # Stk/Raf hücresi: "0 D.10(9)" / "-1 J.6(14)" → stok = baştaki tam sayı,
        # raf = kalan ("D.10(9)"). Eczane stoğu KAYDEDİLEN reçetede düşülür;
        # elde yoksa eksiye iner. Hücre, "(\d+)" ile biten raf kalıbıyla ayırt
        # edilir (fiyat "96,57" / ilaç adı / tarih "28/06/2026" eşleşmez).
        for c in cells:
            if c is doz_cell:
                continue
            m_stk = _STK_RAF_RX.match(_t(c))
            if m_stk:
                try:
                    drug.stok = int(m_stk.group(1))
                except ValueError:
                    drug.stok = None
                if not drug.raf:
                    drug.raf = m_stk.group(2).strip()
                break

        # Kutu adedi: panelBox içindeki t2 input (id suffix ":t2"), value "__3"→"3"
        if doz_cell is not None:
            box32 = doz_cell.find("table", class_="panelBox")
            if box32 is not None:
                t2_el = box32.find("input", id=lambda v: v and v.endswith(":t2"))
                if t2_el is not None:
                    raw_t2 = (t2_el.get("value") or "").strip()
                    m_t2 = re.match(r"_*(\d+)", raw_t2)
                    if m_t2:
                        k = int(m_t2.group(1))
                        if k > 0:
                            drug.adet = str(k)

        cap.drugs.append(drug)

    # Toplam ve kalem/kutu
    box30 = soup.find(id="f:box30")
    if box30:
        cap.raw_kalem_kutu = _t(box30)

    return cap


# ---------------------------------------------------------------------------
# Sayfa tipi 2: Karekod onay (form1)
# ---------------------------------------------------------------------------
def parse_karekod_onay(soup: BeautifulSoup) -> PrescriptionCapture:
    cap = PrescriptionCapture(page_kind="karekod_onay")
    cap.eczane = _extract_eczane(soup)
    cap.__dict__.update({k: v for k, v in _extract_recete_meta(soup).items() if v})

    # İTS Karekod İşlemleri textarea'sı (form1:textarea1): OKUTULAN karekod satırları.
    # İlaç tablosu OLMASA DA okunabilsin diye erken return'lerden ÖNCE alınır.
    cap.scanned_karekodlar = _extract_scanned_karekodlar(soup)

    # İlk borderTable + "RAF / İlaç Adı / Reçeteki Adet / Stok / Doz / Eksik KK"
    # bulalım — başlık satırına göre tabloyu seç
    target = None
    for tbl in soup.find_all("table"):
        headers = [_t(c) for c in tbl.find_all(["th", "td"])[:6]]
        if headers and "RAF" in headers and "İlaç Adı" in headers and "Doz" in headers:
            target = tbl
            break
    if not target:
        return cap

    header_cells = []
    for tr in target.find_all("tr"):
        header_cells = [_t(c) for c in tr.find_all(["th", "td"])]
        if header_cells and "RAF" in header_cells:
            break
    if not header_cells:
        return cap

    # Kolon indeksleri
    def col(name): return header_cells.index(name) if name in header_cells else -1
    ci_raf = col("RAF"); ci_ad = col("İlaç Adı"); ci_radet = col("Reçeteki Adet")
    ci_stok = col("Stok"); ci_doz = col("Doz"); ci_eks = col("Eksik KK Adet")

    for tr in target.find_all("tr"):
        cells = [_t(c) for c in tr.find_all(["th", "td"])]
        if not cells or cells == header_cells:
            continue
        if len(cells) < max(ci_ad, ci_doz) + 1:
            continue
        # Boş satır filtresi
        ad = cells[ci_ad] if ci_ad >= 0 else ""
        if not ad or ad == "İlaç Adı":
            continue
        drug = CapturedDrug(
            ad=ad,
            raf=cells[ci_raf] if ci_raf >= 0 else "",
            adet=cells[ci_radet] if ci_radet >= 0 else "",
            doz_ham=cells[ci_doz] if ci_doz >= 0 else "",
        )
        # "Eksik KK Adet" — bu ilaç için okutulmamış karekod sayısı
        if ci_eks >= 0 and len(cells) > ci_eks:
            m = re.search(r"-?\d+", cells[ci_eks] or "")
            if m:
                drug.eksik_kk = int(m.group())
        drug.birim_doz_miktari = _extract_birim_doz(drug.doz_ham)[0]
        _parse_doz(drug, drug.doz_ham)
        cap.drugs.append(drug)

    # Eksik karekod toplamı (pencere tema rengi için). En az bir ilaçta sütun
    # okunabildiyse topla; hiçbiri okunamadıysa None bırak (tema bilinmez).
    eks_vals = [d.eksik_kk for d in cap.drugs if d.eksik_kk is not None]
    cap.eksik_kk_total = sum(eks_vals) if eks_vals else None

    return cap


# ---------------------------------------------------------------------------
# Karekod → barkod (İTS Karekod İşlemleri okutma sayımı)
# ---------------------------------------------------------------------------
# GS1: "01" + 14 hane GTIN. EAN-13 = GTIN'in baştaki 0'ı atılmış 13 hanesi.
# Kullanıcı kuralı: "010 ile başlar, 13 hane sürer, 21 ile başlayan yerde biter"
# → 01 + (0 + 13 hane barkod) + 21... Aşağıdaki regex "010" + 13 hane yakalar.
_KAREKOD_BARKOD_RX = re.compile(r"010(\d{13})")


def barcode_from_karekod(line: str) -> Optional[str]:
    """Tek bir karekod satırından 13 haneli barkodu çıkarır (yoksa None).

    "010869959157003421100230470030898-1729..." → "8699591570034".
    """
    s = (line or "").strip()
    if not s:
        return None
    m = _KAREKOD_BARKOD_RX.search(s)
    if m:
        return m.group(1)
    # Düz 13 haneli barkod satırı (karekod değil) → olduğu gibi
    if s.isdigit() and len(s) == 13:
        return s
    return None


def _extract_scanned_karekodlar(soup: BeautifulSoup) -> list:
    """İTS Karekod İşlemleri ekranındaki textarea'dan (form1:textarea1) okutulan
    karekod satırlarını döndürür. IE/MSHTML outerHTML'inde textarea'ya yazılan
    metin innerText olarak görünür."""
    ta = soup.find("textarea", id="form1:textarea1")
    if ta is None:
        # id farklıysa: 'inputTextarea' sınıfı veya ilk textarea
        ta = soup.find("textarea", class_="inputTextarea") or soup.find("textarea")
    if ta is None:
        return []
    raw = ta.get_text("\n", strip=False) or ""
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    return lines


# ---------------------------------------------------------------------------
# Sayfa tipi 3: E-Reçete Detay (asıl hedef sayfa)
# ---------------------------------------------------------------------------
def _clean_drug_note(text: str) -> str:
    """İlaç-altı 'Teşhis/Tanı - <metin>' notundan basılabilir doktor talimatını ayıklar.

    Medula her ilacın altına bir 'row2' satırı basar: "Teşhis/Tanı - <metin>".
    Çoğu zaman bu '<protokol no> Protokolüne ait reçeteler' gibi İDARİ bir
    referanstır (hastaya basılmaz). Ama bazen 'LÜZUM HALİNDE SABAHLARI AÇ
    KARNINA' gibi GERÇEK bir kullanım talimatı içerir. Bu fonksiyon yalnızca
    ikincisini döndürür; idari/anlamsız notlarda boş string verir.
    """
    t = (text or "").strip()
    if not t:
        return ""
    # Önek "Açıklama Türü - " (örn. "Teşhis/Tanı - ") kaldır
    t = re.sub(r"^\s*[A-Za-zÇĞİÖŞÜçğıöşü/ ]+?\s*-\s*", "", t, count=1).strip()
    if not t:
        return ""
    low = t.lower()
    # İdari gürültü: "<protokol no> Protokolüne ait reçeteler"
    if "protokol" in low and "reçete" in low:
        return ""
    # SGK geri-ödeme bildirimi ("(Geri Ödeme Kapsamında Değildir)") not değildir
    if "geri ödeme" in low or "geri odeme" in low:
        return ""
    # Harf içermeyen (yalnız sayı/noktalama) not anlamsızdır
    if not re.search(r"[A-Za-zÇĞİÖŞÜçğıöşü]", t):
        return ""
    return t


def parse_e_recete_detay(soup: BeautifulSoup) -> PrescriptionCapture:
    cap = PrescriptionCapture(page_kind="e_recete_detay")
    cap.eczane = _extract_eczane(soup)
    # Kaydedilmiş mi? (İTS Karekod İşlemleri butonu varsa → reçete SONU)
    cap.saved = is_erecete_saved(soup)

    # Hasta adı: "Geri Dön" butonunun yanındaki TD (label, color blue) genelde
    # ama daha güvenilir yöntem: "T.C.Kimlik No" label'ının değerini al,
    # ve eczane menüText üstündeki başlığı al.

    # "E-Reçete Bilgileri" başlığını içeren <table>'ı bul
    info_table = None
    for tr in soup.find_all("tr", class_="headerRow"):
        if _t(tr) == "E-Reçete Bilgileri":
            info_table = tr.find_parent("table")
            break
    if info_table:
        # Label → value haritası: "label" sınıflı TD'nin (içinde Span outputText),
        # bir sonraki "label" TD değerdir
        cells = info_table.find_all("td", class_="label")
        i = 0
        kv = {}
        while i < len(cells) - 1:
            ktxt = _t(cells[i])
            vtxt = _t(cells[i + 1])
            if ktxt and vtxt:
                kv[ktxt.rstrip(":").strip()] = vtxt
            i += 1
        # Daha hassas: SPAN[class=outputText][style=COLOR: blue]
        for span in info_table.select("span.outputText"):
            style = (span.get("style") or "").lower()
            if "blue" not in style:
                continue
            # Önceki kardeş hücredeki label'ı bul
            td = span.find_parent("td")
            if not td:
                continue
            prev_td = td.find_previous_sibling("td")
            if not prev_td:
                continue
            # 'TD>:<TD>span' yapısı, geriye 2 td gerekebilir
            label_td = prev_td
            for _ in range(2):
                lbl_text = _t(label_td)
                if lbl_text and ":" not in lbl_text and "<" not in lbl_text:
                    break
                prev2 = label_td.find_previous_sibling("td")
                if prev2 is None: break
                label_td = prev2
            label = _t(label_td).rstrip(":").strip()
            value = _t(span)
            if label and value:
                kv[label] = value

        cap.recete_no      = kv.get("E-Reçete No", "")
        cap.takip_no       = kv.get("Takip No", "")
        cap.hasta_tc       = kv.get("T.C.Kimlik No", "") or kv.get("T.C. Kimlik No", "")
        cap.recete_tarihi  = kv.get("Reçete Tarihi", "")
        cap.recete_turu    = kv.get("Reçete Türü", "")
        cap.recete_alt_turu= kv.get("Reçete Alt Türü", "")
        cap.dr_ad          = kv.get("Doktor Adı/Soyadı", "") or kv.get("Doktor Ad/Soyad", "")
        cap.dr_brans       = kv.get("Doktor Branş", "")

    # Hasta adı: form1:textKisiAdi (ad) + form1:textKisiSoyadi (soyad)
    ad_span    = soup.find("span", id=re.compile(r"textKisiAdi$"))
    soyad_span = soup.find("span", id=re.compile(r"textKisiSoyadi$"))
    parts = []
    if ad_span:    parts.append(_t(ad_span))
    if soyad_span: parts.append(_t(soyad_span))
    if parts:
        cap.hasta_ad = " ".join(p for p in parts if p)

    # İlaç Bilgileri bloğu: "İlaç Bilgileri" header TR'sinin sonraki kardeşleri
    drug_header = None
    for tr in soup.find_all("tr", class_="headerRow"):
        if _t(tr) == "İlaç Bilgileri":
            drug_header = tr
            break
    if drug_header:
        # Aynı TBODY içinde, sonraki row1 sınıflı TR'leri tara
        tbody = drug_header.parent
        for tr in tbody.find_all("tr", recursive=False):
            cls = tr.get("class") or []
            if "row1" not in cls and "row2" not in cls:
                continue
            cells = tr.find_all("td", recursive=False)
            if len(cells) < 2:
                continue
            # "Adı : " ile başlayan TR'ler asıl ilaç satırları
            first_txt = _t(cells[0])
            if not first_txt.startswith("Adı"):
                continue

            drug = CapturedDrug()
            # urunid attribute
            drug.urun_id = cells[0].get("urunid", "") or ""
            # cells: [Adı:, ADI_VALUE, Adet:, ADET, Kullanım:, DOZ, Kullanım Şekli:, ŞEKİL]
            def cell(idx):
                return _t(cells[idx]) if idx < len(cells) else ""

            ad_blob = cell(1)
            # "VISCOTEARS 2 MG/G GOZ JELI 10 G (8681738440010)" → ad + barkod
            m = re.match(r"^(.*?)\s*\((\d{8,14})\)\s*$", ad_blob)
            if m:
                drug.ad = m.group(1).strip()
                drug.barkod = m.group(2)
            else:
                drug.ad = ad_blob

            drug.adet = cell(3)
            drug.doz_ham = cell(5)
            drug.kullanim_sekli = cell(7)
            drug.birim_doz_miktari = _extract_birim_doz(drug.doz_ham)[0]
            _parse_doz(drug, drug.doz_ham)

            # İlaç-altı doktor notu: "Adı" satırından sonraki 'row2' kardeşinde
            # "Teşhis/Tanı - <metin>" olarak gelir. ARADA başka row1 satırları
            # olabilir (örn. SGK ödemeyen ilaçta "(Geri Ödeme Kapsamında Değildir)"
            # kırmızı satırı, ya da HR ayraç). Bu yüzden gerçek not satırını (row2)
            # bulana ya da SONRAKİ ilacın "Adı" satırına ulaşana kadar ilerle.
            # İdari notlar (protokol/geri-ödeme) _clean_drug_note ile elenir.
            note_tr = tr.find_next_sibling("tr")
            _hops = 0
            while note_tr is not None and _hops < 6:
                _ncls = note_tr.get("class") or []
                _ntxt = _t(note_tr)
                if "row1" in _ncls and _ntxt.strip().startswith("Adı"):
                    break  # sonraki ilaca geçtik, not yok
                # SGK geri-ödeme bildirimi (kırmızı row1) → ilaca bayrak koy
                _low = _ntxt.lower()
                if "geri ödeme" in _low or "geri odeme" in _low:
                    drug.geri_odeme_yok = True
                if "row2" in _ncls:
                    drug.aciklama = _clean_drug_note(_ntxt)
                    break
                note_tr = note_tr.find_next_sibling("tr")
                _hops += 1

            cap.drugs.append(drug)

    # Tanılar (ICD-10 + isim)
    tani_tbl = soup.find("table", id=re.compile(r"^form1:tableEx3"))
    if tani_tbl:
        for tr in tani_tbl.find_all("tr"):
            cells = tr.find_all("td")
            if len(cells) >= 2:
                kod = _t(cells[0])
                tani = _t(cells[1])
                if re.match(r"^[A-Z]\d{2}(\.\d+)?", kod):
                    cap.tanılar.append((kod, tani))

    # Reçete Açıklamaları (form1:tableEx1, "Açıklama Listesi")
    # Sütunlar: Açıklama Türü | Reçete Açıklama
    aciklama_tbl = soup.find("table", id=re.compile(r"^form1:tableEx1$"))
    if aciklama_tbl:
        # Caption ile doğrula
        caption = aciklama_tbl.find("caption")
        if caption and "Açıklama" in _t(caption):
            tbody = aciklama_tbl.find("tbody")
            if tbody:
                for tr in tbody.find_all("tr"):
                    cells = tr.find_all("td")
                    if len(cells) < 2:
                        continue
                    tip = _t(cells[0]).strip()
                    metin = _t(cells[1]).strip()
                    # Boş veya placeholder "." satırlarını atla
                    if not tip or not metin or metin in (".", "-", "_", "_."):
                        continue
                    cap.recete_aciklamalari.append((tip, metin))

    return cap


# ---------------------------------------------------------------------------
# Sayfa tipi 4: E-Reçete sorgu sonuç (hasta + reçete listesi)
# ---------------------------------------------------------------------------
def parse_e_recete_sorgu_sonuc(soup: BeautifulSoup) -> PrescriptionCapture:
    cap = PrescriptionCapture(page_kind="e_recete_sorgu_sonuc")
    cap.eczane = _extract_eczane(soup)

    # Hasta adı: tablonun hemen üstündeki "blue" başlık
    tbl = soup.find("table", id="form1:tableExERecete")
    if tbl:
        prev = tbl.find_previous("span", class_="outputText")
        if prev:
            cap.hasta_ad = _t(prev)
    return cap


# ---------------------------------------------------------------------------
# Doz string'ini ayrıştır: "2 x 1,00 (1Günde)" / "1 / Günde / 1 Adet" /
# "Günde 1 x 1.0" / "Günde 3 x 1,5"
# ---------------------------------------------------------------------------
RX_DOZ_X = re.compile(
    r"(?P<kez>\d+)\s*x\s*(?P<adet>\d+(?:[.,]\d+)?)\s*\(?(?:(?P<periyot_kez>\d+)\s*)?"
    r"(?P<periyot>Günde|Haftada|Ayda|Yılda)?\)?",
    re.IGNORECASE,
)
# "Günde 1 x 1.0" gibi (önce periyot, sonra kez x adet)
RX_DOZ_GUNDE_X = re.compile(
    r"(?P<periyot>Günde|Haftada|Ayda|Yılda)\s+(?P<kez>\d+)\s*x\s*(?P<adet>\d+(?:[.,]\d+)?)",
    re.IGNORECASE,
)
RX_DOZ_SLASH = re.compile(
    r"(?P<adet>\d+(?:[.,]\d+)?)\s*/\s*(?P<periyot>Günde|Haftada|Ayda|Yılda)\s*/\s*"
    r"(?P<birim_adedi>\d+(?:[.,]\d+)?)\s*(?P<birim>Adet|Gram|Mililitre|ml|gr)?",
    re.IGNORECASE,
)


def _parse_doz(drug: CapturedDrug, blob: str) -> None:
    if not blob:
        return
    # Önce "Günde 1 x 1.0" formatını dene (E-Reçete Detay sayfası)
    m = RX_DOZ_GUNDE_X.search(blob)
    if m:
        drug.periyot = m.group("periyot")
        drug.doz_gunluk_kez = int(m.group("kez"))
        drug.doz_birim_adedi = float(m.group("adet").replace(",", "."))
        m2 = re.search(r"(Adet|Gram|Mililitre|ml|gr|Damla|Ölçek)", blob, re.IGNORECASE)
        if m2:
            drug.doz_birim = m2.group(1).capitalize()
        return
    m = RX_DOZ_X.search(blob)
    if m:
        drug.doz_gunluk_kez = int(m.group("kez"))
        drug.doz_birim_adedi = float(m.group("adet").replace(",", "."))
        drug.periyot = m.group("periyot") or "Günde"
        m2 = re.search(r"(Adet|Gram|Mililitre|ml|gr|Damla|Ölçek)", blob, re.IGNORECASE)
        drug.doz_birim = m2.group(1).capitalize() if m2 else ""
        return
    m = RX_DOZ_SLASH.search(blob)
    if m:
        drug.doz_birim_adedi = float(m.group("adet").replace(",", "."))
        drug.periyot = m.group("periyot") or "Günde"
        drug.doz_birim = (m.group("birim") or "").capitalize()


# ---------------------------------------------------------------------------
# Ekran-bazlı tarih / hasta adı (hasta etiketi için doğrudan element id ile)
# ---------------------------------------------------------------------------
_RX_DATE = re.compile(r"\d{2}/\d{2}/\d{4}")


def _extract_screen_date(soup: BeautifulSoup) -> str:
    """Reçete tarihini ekrandaki SABİT element id'lerinden çıkarır (fallback).

    Reçete başı (ReceteIslem2.jsp): SPAN id='form1:text16'.
    Reçete sonu (RaporGorme.jsp):   INPUT id='f:t31' (value).
    Genel etiket eşlemesi tarihi yakalayamadığında kullanılır.
    """
    for idv in ("form1:text16", "f:t31"):
        el = soup.find(id=idv)
        if el is None:
            continue
        raw = el.get("value", "") if el.name == "input" else _t(el)
        m = _RX_DATE.search(raw or "")
        if m:
            return m.group(0)
    # Yedek: id'si ':text16'/':t31' ile biten herhangi bir element
    for el in soup.find_all(id=True):
        idv = el.get("id") or ""
        if idv.endswith(":text16") or idv.endswith(":t31"):
            raw = el.get("value", "") if el.name == "input" else _t(el)
            m = _RX_DATE.search(raw or "")
            if m:
                return m.group(0)
    return ""


def _extract_screen_name(soup: BeautifulSoup) -> str:
    """Hasta ad-soyadını ekrandaki element id'lerinden çıkarır (fallback).

    Reçete başı: form1:textKisiAdi (+ textKisiSoyadi). Reçete sonu: f:t15.
    """
    ad = soup.find(id=re.compile(r"textKisiAdi$"))
    soyad = soup.find(id=re.compile(r"textKisiSoyadi$"))
    parts = [_t(x) for x in (ad, soyad) if x is not None]
    name = " ".join(p for p in parts if p).strip()
    if name:
        return name
    el = soup.find(id="f:t15")
    if el is not None:
        return _t(el).strip()

    # e-Reçete Sorgu formu: "Adı / Soyadı" etiketinin yanındaki panelBox'ta ad+soyad
    # iki ayrı span'de (form1:text7 + form1:text6). Etiket-tabanlı (id'ler generic).
    def _norm(s: str) -> str:
        return re.sub(r"\s+", " ", (s or "")).strip().lower()
    _NAME_LABELS = {"adı / soyadı", "ad / soyad", "adı/soyadı", "ad/soyad",
                    "adı soyadı", "ad soyad"}
    for lbl in soup.find_all(["span", "td", "label"]):
        if _norm(_t(lbl)) in _NAME_LABELS:
            tr = lbl.find_parent("tr")
            box = (tr.find("table", class_="panelBox") if tr is not None else None)
            if box is None:
                box = lbl.find_next("table", class_="panelBox")
            if box is not None:
                nm = " ".join(p for p in (_t(s) for s in box.find_all("span")) if p).strip()
                if nm:
                    return nm
    return ""


# ---------------------------------------------------------------------------
# Genel giriş noktası
# ---------------------------------------------------------------------------
def parse_html(html: str, document_url: str = "") -> PrescriptionCapture:
    # lxml daha hızlı/sağlam; kurulu değilse stdlib html.parser'a düş.
    # (lxml yoksa watcher her tick'te sessizce çöküp hiç etiket üretmez.)
    try:
        soup = BeautifulSoup(html, "lxml")
    except Exception:
        soup = BeautifulSoup(html, "html.parser")
    kind = detect_page_kind(soup)
    if kind == "e_recete_detay":
        cap = parse_e_recete_detay(soup)
    elif kind == "e_recete_sorgu_sonuc":
        cap = parse_e_recete_sorgu_sonuc(soup)
    elif kind == "recete_yazma":
        cap = parse_recete_yazma(soup)
    elif kind == "e_recete_basarili":
        # Kaydedilmiş e-reçete (reçete SONU): ilaç listesi f:tbl1'den okunur.
        cap = parse_recete_yazma(soup)
        cap.page_kind = "e_recete_basarili"
        cap.saved = True
        # Anahtar = TEMİZ e-Reçete No (detay sayfasıyla aynı), kirli blob'u ez.
        ern = _extract_erecete_no(soup)
        if ern:
            cap.recete_no = ern
        else:
            sp = soup.find("span", class_="receteSuccessMessage")
            if sp:
                m = re.search(r"numaras[ıi]\s*[:：]?\s*([0-9A-Za-z]{4,12})",
                              _t(sp), re.IGNORECASE)
                if m:
                    cap.recete_no = m.group(1)
    elif kind == "kagit_recete_basarili":
        # Kaydedilmiş kağıt reçete (reçete SONU). Ayrıntılı ilaç parse'ı UI tarafında
        # parse_paper_form ile yapılır; burada watcher dedup'u için stabil anahtar +
        # saved bayrağı yeterli.
        cap = PrescriptionCapture(page_kind=kind)
        cap.eczane = _extract_eczane(soup)
        cap.saved = True
        cap.recete_no = _extract_recete_no_sgk(soup)
    elif kind == "karekod_onay":
        cap = parse_karekod_onay(soup)
    else:
        cap = PrescriptionCapture(page_kind=kind)
        cap.eczane = _extract_eczane(soup)
    cap.document_url = document_url
    # Karekod adımı bekliyor mu? Kaydedilmiş reçete sayfasında "İTS Karekod
    # İşlemleri" / "Karekod Sonlandır" butonu duruyorsa karekod henüz
    # tamamlanmamıştır. Pencere tema rengi (compute_medula_theme) için.
    try:
        cap.karekod_pending = is_erecete_saved(soup)
    except Exception:
        pass
    # Fatura kapsamı ('Kapsam:' alanı) — yabancı uyruklu/geçici koruma denetimi için
    # (yalnız reçete işlem/sonu form f sayfasında bulunur; yoksa boş kalır).
    if not cap.fatura_kapsami:
        cap.fatura_kapsami = _extract_fatura_kapsami(soup)
    # Reçete sahibi TC: form f sayfasında genel eşleme yakalayamaz → input'tan tamamla.
    if not (cap.hasta_tc or "").strip():
        tc = _extract_recete_sahibi_tc(soup)
        if tc:
            cap.hasta_tc = tc
    # Hasta etiketi için tarih/ad fallback'i: genel eşleme boş bıraktıysa
    # ekrandaki sabit element id'lerinden (form1:text16 / f:t31 / f:t15) tamamla.
    # Reçete tarihi: genel etiket eşlemesi bazen tarih yerine zorunlu-alan işaretini
    # ("(*)") ya da boş değer yakalar (örn. reçete başı sayfası). Değer geçerli bir
    # tarih (gg/aa/yyyy veya gg.aa.yyyy) DEĞİLSE ekrandaki sabit id'lerden
    # (_extract_screen_date: form1:text16 / f:t31) yeniden oku; gerçek tarih yoksa
    # boş bırak ki etikete "(*)" gibi çöp basılmasın.
    if not re.search(r"\d{1,2}[./]\d{1,2}[./]\d{4}", (cap.recete_tarihi or "").strip()):
        cap.recete_tarihi = _extract_screen_date(soup)
    if not (cap.hasta_ad or "").strip():
        nm = _extract_screen_name(soup)
        if nm:
            cap.hasta_ad = nm
    return cap


def to_dict(cap: PrescriptionCapture) -> dict:
    d = asdict(cap)
    d["drugs"] = [asdict(x) for x in cap.drugs]
    return d
