"""Etiketin sağ üst köşesindeki ilaç türü ibaresi — HASTA DİLİNDE, KISA.

`drugs.indication_short` (örn. "CİLT İLACI", "GÖZ İLACI") içerde ANAHTAR olarak
kalır: C etiketi blokları, toplu tarifler ve özel kurallar ona bağlı. Bu modül
yalnızca köşeye BASILAN yazıyı ATC koduna bakarak daha açıklayıcı hâle getirir
("CİLT İLACI" → "SEDEF İLACI", "GÖZ İLACI" → "GÖZ ALERJİSİ").

Kurallar (eczacı ile 2026-11-25'te kararlaştırıldı):
  • Mümkün olduğunca kısa: "EGZAMA İLACI", "SEDEF İLACI", "MANTAR İLACI".
  • Krem/damla gibi form yazılmaz (talimat satırı zaten söylüyor).
  • "KANSER İLACI" moral bozucu → kemoterapi / hedefe yönelik tedavi / asıl
    hastalık adı. HIV ilaçları → "VİRÜS İLACI" (hastalık adı yazılmaz).
    Hepatit ilaçları "HEPATİT İLACI" yazabilir.
  • Yalnız OTOMATİK üretilmiş kategoriler değiştirilir. Eczacının elle girdiği
    farklı bir ibare (veri editörü) olduğu gibi basılır.
"""
from __future__ import annotations

# (ATC öneki, köşe ibaresi) — EN SPESİFİK ÖNCE. İbare None ise "dokunma".
_KURALLAR: list[tuple[str, str | None]] = [
    # ===== D: Cilt =====
    ("D01",     "MANTAR İLACI"),            # krem/sprey + terbinafin tablet
    ("D02",     "NEMLENDİRİCİ"),
    ("D03AX",   "YARA-PİŞİK İLACI"),        # dekspantenol vb. (nedbe jeli ayrı kural)
    ("D03BA",   "YARA TEMİZLEYİCİ"),
    ("D04AB",   "AĞRI-KAŞINTI GİDERİCİ"),   # lidokainli
    ("D04",     "KAŞINTI İLACI"),
    ("D05BA",   "SEDEF-ALACA İLACI"),
    ("D05",     "SEDEF İLACI"),
    ("D06A",    "ANTİBİYOTİK"),
    ("D06BB",   "UÇUK İLACI"),
    ("D06BA",   "YANIK İLACI"),
    ("D06BX",   "YÜZ KIZARIKLIĞI"),         # metronidazol jel (rozase)
    ("D07B",    "ANTİBİYOTİK+KORTİZON"),    # kortizon + antiseptik
    ("D07C",    "ANTİBİYOTİK+KORTİZON"),    # Fucicort, Fucidin H
    ("D07XA",   "EGZAMA İLACI"),
    ("D07X",    "SEDEF-EGZAMA İLACI"),      # kortizon + salisilik asit
    ("D07A",    "EGZAMA-KAŞINTI"),
    ("D08AX",   "ÇIBAN MERHEMİ"),           # ihtiyol
    ("D08",     "MİKROP ÖLDÜRÜCÜ"),
    ("D11AH",   "EGZAMA İLACI"),            # Protopic, Elidel, Dupixent
    ("D11AF",   "SİĞİL İLACI"),
    ("D11AA",   "TERLEME İLACI"),
    ("D11AX01", "SAÇ DÖKÜLMESİ"),           # minoksidil
    ("D11AX10", "SAÇ DÖKÜLMESİ"),           # finasterid
    ("D11AX11", "LEKE AÇICI"),              # hidrokinon
    ("D11AX16", "TÜY AZALTICI"),            # eflornitin
    ("D11AX18", "GÜNEŞ LEKESİ İLACI"),      # diklofenak jel (aktinik keratoz)
    ("D11AX21", "YÜZ KIZARIKLIĞI"),         # brimonidin jel
    ("D11AX",   "PİŞİK KREMİ"),             # Hamazinc, Hametan
    ("M02",     "KAS-EKLEM AĞRISI"),
    ("N01BX04", "KAS-EKLEM AĞRISI"),        # kapsaisin

    # ===== S: Göz / kulak =====
    ("S01AD",   "GÖZ UÇUĞU İLACI"),
    ("S01A",    "GÖZ ANTİBİYOTİĞİ"),
    ("S01B",    "GÖZ İLTİHABI"),            # S01BC (Acular) kortizon DEĞİL
    ("S01C",    "ANTİBİYOTİK+KORTİZON"),
    ("S01E",    "GÖZ TANSİYONU"),
    ("S01F",    "GÖZ BEBEĞİ BÜYÜTÜCÜ"),
    ("S01GA",   "GÖZ KIZARIKLIĞI"),
    ("S01GX",   "GÖZ ALERJİSİ"),
    ("S01LA",   "SARI NOKTA İLACI"),
    ("S01XA",   "SUNİ GÖZYAŞI"),
    ("S02A",    "KULAK ANTİBİYOTİĞİ"),
    ("S02B",    "KULAK İLTİHABI"),
    ("S02C",    "ANTİBİYOTİK+KORTİZON"),
    ("S02D",    "KULAK AĞRISI"),
    ("S03A",    "GÖZ-KULAK ANTİBİYOTİĞİ"),
    ("S03B",    "GÖZ-KULAK İLTİHABI"),
    ("S03C",    "ANTİBİYOTİK+KORTİZON"),

    # ===== Yanlış sınıflandırma düzeltmeleri =====
    ("N02BF",   "SİNİR AĞRISI İLACI"),      # pregabalin/gabapentin "AĞRI KESİCİ" değil
    ("J01XX01", None),                      # fosfomisin — idrar yolu doğru
    ("J01XX05", None),                      # metenamin — idrar yolu doğru
    ("J01XX",   "ANTİBİYOTİK"),             # daptomisin/linezolid idrar yolu DEĞİL
    ("C01AA",   "KALP YETMEZLİĞİ"),         # digoksin
    ("C01B",    "KALP RİTİM İLACI"),
    ("C01CA",   "ACİL KALP İLACI"),         # adrenalin/noradrenalin/dopamin
    ("R03BC",   "ASTIM ÖNLEYİCİ"),          # kromoglikat — kortizon DEĞİL

    # ===== Ruh sağlığı =====
    ("N05A",    "RUH SAĞLIĞI İLACI"),
    ("N05B",    "SAKİNLEŞTİRİCİ"),
    ("N06A",    "DEPRESYON-KAYGI İLACI"),

    # ===== Virüs =====
    ("J05AB01", "UÇUK-ZONA İLACI"),         # asiklovir
    ("J05AB09", "UÇUK-ZONA İLACI"),         # famsiklovir
    ("J05AB11", "UÇUK-ZONA İLACI"),         # valasiklovir
    ("J05AB15", "UÇUK-ZONA İLACI"),         # brivudin
    ("J05AF08", "HEPATİT İLACI"),           # adefovir
    ("J05AF10", "HEPATİT İLACI"),           # entekavir
    ("J05AF11", "HEPATİT İLACI"),           # telbivudin
    ("J05AF13", "HEPATİT İLACI"),           # tenofovir alafenamid (Vemlidy)
    ("J05AP",   "HEPATİT İLACI"),
    ("J05AH",   "GRİP İLACI"),
    ("J05A",    "VİRÜS İLACI"),             # HIV vb. — hastalık adı yazılmaz

    # ===== Kanser / bağışıklık ("KANSER İLACI" yazılmaz) =====
    ("L01EX09", "AKCİĞER FİBROZU İLACI"),   # nintedanib (Ofev)
    ("L01EJ",   "KAN HASTALIĞI İLACI"),     # ruksolitinib
    ("L01XX05", "KAN HASTALIĞI İLACI"),     # hidroksiüre (Hydrea)
    ("L01XX35", "KAN HASTALIĞI İLACI"),     # anagrelid
    ("L01E",    "HEDEFE YÖNELİK TEDAVİ"),   # kinaz inhibitörleri
    ("L01F",    "HEDEFE YÖNELİK TEDAVİ"),   # monoklonal antikorlar
    ("L01XG",   "HEDEFE YÖNELİK TEDAVİ"),
    ("L01XJ",   "HEDEFE YÖNELİK TEDAVİ"),
    ("L01XK",   "HEDEFE YÖNELİK TEDAVİ"),
    ("L01",     "KEMOTERAPİ İLACI"),
    ("L03AA",   "BEYAZ KÜRE ARTIRICI"),     # filgrastim
    ("L03",     "BAĞIŞIKLIK DÜZENLEYİCİ"),
    ("L04",     "BAĞIŞIKLIK BASKILAYICI"),

    # ===== Genel ibarelerin açılması =====
    ("A01AC",   "AFT İLACI"),
    ("A03AA",   "BAĞIRSAK SPAZMI"),
    ("A03AB",   "BAĞIRSAK SPAZMI"),
    ("A03DB",   "KARIN AĞRISI"),
    ("A07AX",   "İSHAL İLACI"),
    ("A07BA",   "AKTİF KÖMÜR"),
    ("A07B",    "İSHAL İLACI"),
    ("A07CA",   "İSHALDE SIVI DESTEĞİ"),
    ("A07D",    "İSHAL İLACI"),
    ("A07E",    "BAĞIRSAK İLTİHABI"),
    ("A07XA",   "İSHAL İLACI"),
    ("A16",     "METABOLİK HASTALIK"),
    ("B02BD",   "PIHTILAŞMA FAKTÖRÜ"),
    ("B02BX",   "KAN PULCUĞU ARTIRICI"),
    ("B03A",    "DEMİR İLACI"),
    ("B03BA",   "B12 VİTAMİNİ"),
    ("B03BB",   "FOLİK ASİT"),
    ("B03",     "KANSIZLIK İLACI"),
    ("C03",     "İDRAR SÖKTÜRÜCÜ"),
    ("C05BX",   "DAMAR KORUYUCU"),
    ("C05C",    "DAMAR KORUYUCU"),
    ("G01AF06", "VAJİNAL ENFEKSİYON"),      # ornidazol — mantar değil
    ("G01AF",   None),                      # vajinal mantar: "MANTAR İLACI" doğru
    ("G01AA02", None),
    ("G01AX12", None),
    ("G01",     "VAJİNAL ENFEKSİYON"),
    ("G02B",    "DOĞUM KONTROL"),
    ("G02CB",   "SÜT KESİCİ"),
    ("G02CC",   "VAJİNAL İLTİHAP"),
    ("G03BA",   "TESTOSTERON HORMONU"),
    ("G03C",    "MENOPOZ HORMONU"),
    ("G03D",    "PROGESTERON HORMONU"),
    ("G03F",    "MENOPOZ HORMONU"),
    ("G03G",    "KISIRLIK TEDAVİSİ"),
    ("G03HB",   None),                      # Climen (menopoz) + Diane-35 (sivilce) aynı ATC
    ("G04BD",   "SIK İDRARA ÇIKMA"),
    ("G04BX14", "ERKEN BOŞALMA İLACI"),     # dapoksetin (Priligy)
    ("G04BX15", "MESANE İLACI"),            # pentosan (Elmiron)
    ("G04BX",   None),                      # Canephron, Uro-Vaxom
    ("G04C",    "PROSTAT İLACI"),
    ("H01AC",   "BÜYÜME HORMONU"),
    ("H03A",    "TİROİD HORMONU"),
    ("H03B",    "TİROİD FAZLA ÇALIŞMASI"),
    ("J02",     "MANTAR İLACI"),
    ("M05",     "KEMİK ERİMESİ İLACI"),
    ("N01A",    "NARKOZ İLACI"),
    ("N01B",    "UYUŞTURMA İLACI"),
    ("N06BX",   "HAFIZA-DOLAŞIM İLACI"),
    ("N07AA",   "KAS GÜÇSÜZLÜĞÜ"),
    ("N07BA",   "SİGARA BIRAKMA"),
    ("N07BB",   "ALKOL BIRAKMA"),
    ("N07BC",   "BAĞIMLILIK TEDAVİSİ"),
    ("N07CA03", None),                      # flunarizin — kendi ibaresi var
    ("N07CA",   "BAŞ DÖNMESİ İLACI"),
    ("R01AB",   "BURUN AÇICI"),
    ("R01AC",   "BURUN ALERJİSİ"),
    ("R01BA",   "BURUN TIKANIKLIĞI"),
    ("R07AX",   "BAĞIŞIKLIK DESTEĞİ"),
]

# Otomatik üretilmiş (atc_indications / toplu yükleme) kategoriler. Yalnız
# bunlardan biri DB'de duruyorsa köşe ibaresi ATC'ye göre değiştirilir;
# eczacının elle yazdığı başka bir ibare korunur.
_OTOMATIK: frozenset[str] = frozenset({
    "ANTİBİYOTİK", "ANTİBİYOTİK (İDRAR YOLU)", "ANTİBİYOTİKLİ KREM",
    "AĞRI KESİCİ", "AĞRI KESİCİ (HARİCİ)", "CİLT İLACI (AĞRI)",
    "CİLT İLACI", "CİLT KORTİZONU", "CİLT ANTİBİYOTİĞİ", "CİLT BAKIM ÜRÜNÜ",
    "CİLT NEMLENDİRİCİ", "CİLT LEKE AÇICI", "KAŞINTI / CİLT İLACI",
    "MANTAR İLACI (DIŞ KULLANIM)", "ANTİVİRAL / ANTİSEPTİK (CİLT)",
    "ANTİSEPTİK", "YARA İYİLEŞTİRİCİ", "SEDEF İLACI", "SİVİLCE İLACI",
    "GÖZ İLACI", "GÖZ İLACI (ANTİBİYOTİK)", "GÖZ İLACI (ANTİ-İNFEKTİF)",
    "GÖZ İLACI (KORTİZON)", "GLOKOM İLACI", "KURU GÖZ İLACI",
    "GÖZ-KULAK İLACI", "KULAK İLACI",
    "KALP RİTM İLACI", "ASTIM İLACI (KORTİZON)",
    "ANTİPSİKOTİK", "ANKSİYOLİTİK", "ANTİDEPRESAN",
    "ANTİVİRAL", "KANSER İLACI", "KANSER / İMMÜN İLACI",
    "BAĞIŞIKLIK SİSTEMİ İLACI", "İMMÜNOSUPRESİF",
    "AĞIZ-DİŞ İLACI", "SİNDİRİM SİSTEMİ İLACI", "KARIN GAZI İLACI",
    "İSHAL / BAĞIRSAK", "KANAMA DURDURUCU", "ANEMİ TEDAVİSİ", "DİÜRETİK",
    "VARİS / HEMOROİD İLACI", "KADIN HASTALIKLARI", "KADIN DOĞUM İLACI",
    "MANTAR İLACI", "HORMON", "ÜROLOJİ İLACI", "HORMON (HİPOFİZ)",
    "GUATR İLACI", "ANTİMANTAR (SİSTEMİK)", "OSTEOPOROZ İLACI",
    "SİNİR SİSTEMİ İLACI", "LOKAL ANESTEZİK", "DEHB İLACI",
    "NÖROLOJİ İLACI", "BURUN İLACI", "SOLUNUM İLACI",
})


def hasta_kategori(atc_code: str | None, kategori: str | None) -> str:
    """Köşeye basılacak ibare. Eşleşme yoksa `kategori` aynen döner."""
    kat = (kategori or "").strip().upper()
    if not kat or kat not in _OTOMATIK:
        return kategori or ""
    code = (atc_code or "").strip().upper()
    if not code:
        return kategori or ""
    for onek, ibare in _KURALLAR:
        if code.startswith(onek):
            return ibare if ibare else (kategori or "")
    return kategori or ""
