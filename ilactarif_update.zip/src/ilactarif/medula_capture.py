"""Botanik EOS içindeki gömülü Internet Explorer_Server'dan canlı HTML çek.

Mimari:
  - Botanik EOS bir WinForms uygulamasıdır (class: WindowsForms10.Window.8.app.*)
  - Top-level pencere başlığı: "MEDULA <ver> <KULLANICI> (A)" formatı
  - Uygulama içinde Win32 child olarak "Internet Explorer_Server" (Trident) gömülü
  - WM_HTML_GETOBJECT mesajı ile o pencereden IHTMLDocument2 alınır
  - document.url ve documentElement.outerHTML okunabilir

Bağımlılık: pywin32, comtypes
"""
from __future__ import annotations

import ctypes
import os
from ctypes.wintypes import HWND, LPARAM
from dataclasses import dataclass, field

import comtypes
import comtypes.client


_user32  = ctypes.windll.user32
_oleacc  = ctypes.windll.oleacc

# Microsoft tarafından yayınlı registered window message
_WM_HTML_GETOBJECT = _user32.RegisterWindowMessageW("WM_HTML_GETOBJECT")

# IHTMLDocument2 COM Interface IID
_IID_IHTMLDocument2 = comtypes.GUID("{332C4425-26CB-11D0-B483-00C04FD90119}")

_user32.SendMessageTimeoutW.restype  = ctypes.c_void_p
_oleacc.ObjectFromLresult.restype    = ctypes.HRESULT


# ---------------------------------------------------------------------------
# MSHTML typelib (ilk çağrıda Python'da otomatik wrapper üretilir, ~1 sn)
# ---------------------------------------------------------------------------
_MSHTML = None


def _get_mshtml():
    global _MSHTML
    if _MSHTML is None:
        windir = os.environ.get("WINDIR", r"C:\Windows")
        tlb = os.path.join(windir, "System32", "mshtml.tlb")
        _MSHTML = comtypes.client.GetModule(tlb)
    return _MSHTML


# ---------------------------------------------------------------------------
# Pencere keşfi
# ---------------------------------------------------------------------------
_EnumProc = ctypes.WINFUNCTYPE(ctypes.c_int, HWND, LPARAM)


@dataclass
class MedulaWindow:
    hwnd:       int
    title:      str
    class_name: str
    pid:        int
    ie_servers: list = field(default_factory=list)   # list[int] child hwnd


def _get_pid(hwnd: int) -> int:
    pid = ctypes.c_ulong(0)
    _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def enum_top_windows() -> list[tuple[int, str, str, int]]:
    """Görünür top-level pencereleri (hwnd, title, class, pid) olarak listele."""
    items = []
    def cb(hwnd, lparam):
        if not _user32.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(512)
        _user32.GetWindowTextW(hwnd, buf, 512)
        if not buf.value:
            return True
        cls = ctypes.create_unicode_buffer(128)
        _user32.GetClassNameW(hwnd, cls, 128)
        items.append((hwnd, buf.value, cls.value, _get_pid(hwnd)))
        return True
    _user32.EnumWindows(_EnumProc(cb), 0)
    return items


def enum_child_windows(parent_hwnd: int) -> list[tuple[int, str]]:
    items = []
    def cb(hwnd, lparam):
        cls = ctypes.create_unicode_buffer(128)
        _user32.GetClassNameW(hwnd, cls, 128)
        items.append((hwnd, cls.value))
        return True
    _user32.EnumChildWindows(parent_hwnd, _EnumProc(cb), 0)
    return items


def is_medula_foreground() -> bool:
    """Ön plandaki (aktif) pencere bir Medula penceresi mi? (başlıkta 'MEDULA').

    Tüm pencereleri taramaz; yalnız GetForegroundWindow başlığına bakar → ucuz,
    keep-alive tıklama dinlemesinde sık çağrılabilir.
    """
    try:
        hwnd = _user32.GetForegroundWindow()
        if not hwnd:
            return False
        buf = ctypes.create_unicode_buffer(512)
        _user32.GetWindowTextW(hwnd, buf, 512)
        return "MEDULA" in (buf.value or "").upper()
    except Exception:
        return False


def find_medula_windows() -> list[MedulaWindow]:
    """Başlığında 'MEDULA' içeren top-level pencereleri ve içlerindeki IE_Server'ları bul."""
    result = []
    for hwnd, title, cls, pid in enum_top_windows():
        if "MEDULA" not in title.upper():
            continue
        ie_hwnds = [h for h, c in enum_child_windows(hwnd) if c == "Internet Explorer_Server"]
        result.append(MedulaWindow(
            hwnd=hwnd, title=title, class_name=cls, pid=pid, ie_servers=ie_hwnds,
        ))
    return result


def find_ie_servers_all() -> list[tuple[int, int]]:
    """Tüm görünür pencerelerin altında IE_Server child'larını tara (Botanik tespit edilemezse fallback).

    Döndürür: list[(parent_hwnd, ie_hwnd)]
    """
    out = []
    for hwnd, title, cls, pid in enum_top_windows():
        for ch, ccls in enum_child_windows(hwnd):
            if ccls == "Internet Explorer_Server":
                out.append((hwnd, ch))
    return out


# ---------------------------------------------------------------------------
# IE_Server hwnd'sinden IHTMLDocument2 al
# ---------------------------------------------------------------------------
def get_ie_document(ie_hwnd: int):
    """WM_HTML_GETOBJECT + ObjectFromLresult ile IHTMLDocument2 POINTER'ı döndür."""
    mshtml = _get_mshtml()

    SMTO_ABORTIFHUNG = 0x0002
    lres = ctypes.c_void_p(0)
    rc = _user32.SendMessageTimeoutW(
        HWND(ie_hwnd),
        ctypes.c_uint(_WM_HTML_GETOBJECT),
        0, 0,
        SMTO_ABORTIFHUNG,
        2000,
        ctypes.byref(lres),
    )
    if not rc or not lres.value:
        return None

    doc_ptr = ctypes.POINTER(mshtml.IHTMLDocument2)()
    try:
        _oleacc.ObjectFromLresult(
            lres,
            ctypes.byref(_IID_IHTMLDocument2),
            0,
            ctypes.byref(doc_ptr),
        )
    except OSError as e:
        return None
    return doc_ptr


# ---------------------------------------------------------------------------
# HTML + URL çek
# ---------------------------------------------------------------------------
def capture_one(ie_hwnd: int) -> dict:
    """Tek bir IE_Server'dan {url, title, html} veya hata bilgisi döndür."""
    doc = get_ie_document(ie_hwnd)
    if doc is None:
        return {"ie_hwnd": ie_hwnd, "error": "IHTMLDocument2 alınamadı"}
    try:
        url   = doc.url
        title = doc.title or ""
        # IHTMLDocument2'de body var; outerHTML için IHTMLElement gereklidir
        body = doc.body
        if body is None:
            return {"ie_hwnd": ie_hwnd, "url": url, "title": title,
                    "html": "", "error": "body None"}
        # body parent element → <html> kökü, tüm sayfa
        html_root = body
        try:
            html_root = body.parentElement or body
        except Exception:
            pass
        outer = html_root.outerHTML or ""
        return {"ie_hwnd": ie_hwnd, "url": url, "title": title, "html": outer}
    except Exception as e:
        return {"ie_hwnd": ie_hwnd, "error": f"{type(e).__name__}: {e}"}


def capture_window(mw: MedulaWindow) -> list[dict]:
    return [capture_one(h) for h in mw.ie_servers]


# ---------------------------------------------------------------------------
# Oturum canlı tutma (refresh + Enter) ve eski pencere kapatma
# ---------------------------------------------------------------------------
_WM_KEYDOWN = 0x0100
_WM_KEYUP   = 0x0101
_WM_CLOSE   = 0x0010
_VK_F5      = 0x74     # F5 = yenile
_VK_RETURN  = 0x0D     # Enter


def _post_key(hwnd: int, vk: int) -> None:
    """Odağı çalmadan bir pencereye tuş (down+up) gönderir (PostMessage)."""
    _user32.PostMessageW(HWND(hwnd), _WM_KEYDOWN, vk, 0)
    _user32.PostMessageW(HWND(hwnd), _WM_KEYUP, vk, 0)


def _is_winforms_main(class_name: str) -> bool:
    """Botanik EOS ana penceresi WinForms sınıfındadır (popup/dialog değil)."""
    return class_name.startswith("WindowsForms")


def _medula_targets() -> list[int]:
    """Keep-alive için tuş gönderilecek hedef hwnd listesi (IE_Server'lar).

    Ön planda (foreground) bir Medula penceresi varsa onu, yoksa bulunan ilk
    Medula penceresini hedefler. Boş liste = açık Medula yok.
    """
    wins = find_medula_windows()
    if not wins:
        return []
    fg = _user32.GetForegroundWindow()
    target = next((w for w in wins if w.hwnd == fg), wins[0])
    return list(target.ie_servers or [target.hwnd])


def keep_alive_refresh() -> list[int]:
    """Medula'ya F5 (yenile) gönderir; Enter için hedef hwnd listesini döndürür.

    Enter, sayfanın yeniden YÜKLENMESİNİ beklemek için ayrı/gecikmeli gönderilir
    (bkz. keep_alive_enter). Odak çalınmaz (PostMessage).
    """
    targets = _medula_targets()
    for h in targets:
        try:
            _post_key(h, _VK_F5)
        except Exception:
            pass
    return targets


_BM_CLICK = 0x00F5
_POPUP_OK_TEXTS = ("TAMAM", "OK", "EVET", "KAPAT", "DEVAM", "TAMAM ",
                   "YENİDEN DENE", "YENİDEN", "RETRY", "TEKRAR DENE")


def _enum_child_buttons(parent_hwnd: int) -> list[tuple[int, str]]:
    """parent'ın 'Button' sınıfı alt pencerelerini (hwnd, metin) olarak döndürür."""
    items: list[tuple[int, str]] = []

    def cb(hwnd, lparam):
        cls = ctypes.create_unicode_buffer(64)
        _user32.GetClassNameW(hwnd, cls, 64)
        if cls.value == "Button":
            txt = ctypes.create_unicode_buffer(128)
            _user32.GetWindowTextW(hwnd, txt, 128)
            items.append((hwnd, txt.value))
        return True

    _user32.EnumChildWindows(parent_hwnd, _EnumProc(cb), 0)
    return items


def dismiss_medula_popups() -> int:
    """Medula sürecine ait açık pop-up dialoglarını (class '#32770') kapatır.

    Yenileme (F5) sonrası çıkan 'Tamam' butonlu bilgi penceresini kapatmak için:
    önce 'Tamam/OK/Evet' butonuna BM_CLICK yollar; buton yoksa dialoga Enter
    (VK_RETURN) gönderir. Yalnız Medula/Botanik PID'li #32770 pencereleri hedeflenir
    (başka uygulamaların dialogları etkilenmez). Döndürür: kapatılan pop-up sayısı.
    """
    wins = find_medula_windows()
    pids = {w.pid for w in wins}
    if not pids:
        return 0
    closed = 0
    for hwnd, title, cls, pid in enum_top_windows():
        if cls != "#32770" or pid not in pids:
            continue
        btns = _enum_child_buttons(hwnd)
        ok = next((b for b, t in btns
                   if t.replace("&", "").strip().upper() in _POPUP_OK_TEXTS), None)
        try:
            if ok:
                _user32.PostMessageW(HWND(ok), _BM_CLICK, 0, 0)
            # Her durumda dialog'a Enter gönder: odaklı butonu (Yeniden Dene dahil)
            # etkinleştirir ve dialog'u kapatır.
            _post_key(hwnd, _VK_RETURN)
            closed += 1
        except Exception:
            pass
    return closed


def keep_alive_enter(targets: list[int]) -> int:
    """Yenileme sonrası: çıkan pop-up'ı (Tamam) kapatır + IE sayfasına Enter yollar.

    Önce Medula pop-up'ı kapatılır (refresh sonrası 'Tamam' butonlu pencere);
    ardından IE_Server hedeflerine de Enter gönderilir (oturum/onay alanı için).
    Döndürür: kapatılan pop-up + Enter gönderilen pencere sayısı.
    """
    sent = 0
    try:
        sent += dismiss_medula_popups()
    except Exception:
        pass
    for h in (targets or []):
        try:
            _post_key(h, _VK_RETURN)
            sent += 1
        except Exception:
            pass
    return sent


def keep_alive_medula() -> int:
    """Açık Medula oturumunu canlı tutar: yenile (F5) + Enter gönderir.

    NOT: Bu yardımcı F5 ve Enter'ı PEŞ PEŞE (gecikmesiz) gönderir. Sayfa yüklenmesini
    bekleyen gecikmeli kullanım için keep_alive_refresh + keep_alive_enter çiftini
    kullanın (UI 1 sn gecikme ile bunu yapar). Geriye dönük uyumluluk için korunur.
    Döndürür: tuş gönderilen pencere sayısı.
    """
    targets = keep_alive_refresh()
    return keep_alive_enter(targets)


_SONRAKI_TEXTS = {"SONRA >", "SONRAKİ", "NEXT", "SONRA>", "İLERİ >", "İLERİ>"}


def click_sonraki_button() -> bool:
    """Medula'daki 'Sonra >' (btnSonraki) butonuna BM_CLICK gönderir.

    Döndürür: True = buton bulunup tıklandı, False = bulunamadı.
    """
    wins = find_medula_windows()
    for w in wins:
        buf = ctypes.create_unicode_buffer(256)

        def _find_btn(hwnd, lparam):
            _user32.GetWindowTextW(hwnd, buf, 256)
            val = buf.value.strip().upper().replace("&", "").replace(" ", "")
            # "SONRA>" veya "SONRA >" veya metin içinde SONRA geçen WinForms/Button ctrl
            if "SONRA" in val or val in _SONRAKI_TEXTS:
                cls = ctypes.create_unicode_buffer(128)
                _user32.GetClassNameW(hwnd, cls, 128)
                c = cls.value
                if c.startswith("WindowsForms") or c == "Button":
                    _user32.PostMessageW(HWND(hwnd), _BM_CLICK, 0, 0)
                    # lparam'ı 1 yaparak sinyal ver (ctypes callback dışında güvensiz;
                    # bunun yerine closure ile bulgu işaretle)
            return True

        # closure ile ilk eşleşmeyi bul
        found = [False]

        def _cb(hwnd, lparam):
            _user32.GetWindowTextW(hwnd, buf, 256)
            val = buf.value.strip().upper().replace("&", "").replace(" ", "")
            if ("SONRA" in val) and not found[0]:
                cls = ctypes.create_unicode_buffer(128)
                _user32.GetClassNameW(hwnd, cls, 128)
                c = cls.value
                if c.startswith("WindowsForms") or c == "Button":
                    _user32.PostMessageW(HWND(hwnd), _BM_CLICK, 0, 0)
                    found[0] = True
            return True

        _user32.EnumChildWindows(w.hwnd, _EnumProc(_cb), 0)
        if found[0]:
            return True
    return False


def click_html_element_by_id(element_id: str) -> bool:
    """Medula IE sayfasındaki HTML elementine JavaScript click() gönderir.

    element_id: HTML id attribute değeri (örn. "form1:menuHtmlCommandExButton11_MOUSE")
    Döndürür: True = click gönderildi, False = element/döküman bulunamadı.
    """
    wins = find_medula_windows()
    for w in wins:
        for ie_hwnd in w.ie_servers:
            doc = get_ie_document(ie_hwnd)
            if doc is None:
                continue
            try:
                win = doc.parentWindow
                if win is None:
                    continue
                win.execScript(
                    f"(function(){{var e=document.getElementById('{element_id}');"
                    f"if(e){{e.click();}}}})();",
                    "javascript",
                )
                return True
            except Exception:
                pass
    return False


def click_erecete_sorgu_button() -> bool:
    """Medula'daki 'e-Reçete Sorgu' menü butonuna JavaScript click gönderir."""
    return click_html_element_by_id("form1:menuHtmlCommandExButton11_MOUSE")


_GIRIS_TEXTS = {"GİRİŞ", "GIRIS"}


def click_giris_button() -> bool:
    """Medula giriş penceresindeki 'Giriş' WinForms butonuna BM_CLICK gönderir.

    Döndürür: True = buton bulunup tıklandı, False = bulunamadı.
    """
    wins = find_medula_windows()
    for w in wins:
        found = [False]
        buf = ctypes.create_unicode_buffer(256)

        def _cb(hwnd, lparam):
            _user32.GetWindowTextW(hwnd, buf, 256)
            txt = buf.value.strip().upper().replace("&", "")
            if txt in _GIRIS_TEXTS and not found[0]:
                cls = ctypes.create_unicode_buffer(128)
                _user32.GetClassNameW(hwnd, cls, 128)
                c = cls.value
                if c.startswith("WindowsForms") or c == "Button":
                    _user32.PostMessageW(HWND(hwnd), _BM_CLICK, 0, 0)
                    found[0] = True
            return True

        _user32.EnumChildWindows(w.hwnd, _EnumProc(_cb), 0)
        if found[0]:
            return True
    return False


def close_old_medula_windows(keep_hwnd: int | None = None) -> list[str]:
    """Eski/fazladan Medula pencerelerini kapatır (WM_CLOSE).

    GÜVENLİK: Ana Botanik EOS penceresi (WinForms sınıfı) ve ön plandaki
    (kullanıcının aktif kullandığı) pencere KORUNUR — yalnızca fazladan açık
    kalmış Medula popup/pencereleri kapatılır.

    keep_hwnd verilirse o pencere ek olarak korunur.
    Döndürür: kapatılan pencerelerin başlıkları (loglama/gösterim için).
    """
    wins = find_medula_windows()
    if len(wins) <= 1:
        return []
    fg = _user32.GetForegroundWindow()
    closed: list[str] = []
    for w in wins:
        # Korunacaklar: ana WinForms penceresi, ön plandaki pencere, keep_hwnd
        if _is_winforms_main(w.class_name) or w.hwnd == fg or w.hwnd == keep_hwnd:
            continue
        try:
            _user32.PostMessageW(HWND(w.hwnd), _WM_CLOSE, 0, 0)
            closed.append(w.title)
        except Exception:
            pass
    return closed
