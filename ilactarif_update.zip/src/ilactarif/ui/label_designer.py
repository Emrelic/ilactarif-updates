"""Elle etiket tasarımcısı — serbest WYSIWYG etiket editörü (Tkinter).

Dördüncü sekme: kullanıcı etiket tuvaline yazı/çizgi/çerçeve/container ekler,
puntosunu-rengini-ters rengini-hizalamasını-konumunu elle ayarlar ve doğrudan
yazıcıya gönderir. Tasarımlar JSON şablon olarak kaydedilip yüklenebilir.

Koordinat sistemi: tüm öğeler ETİKET PİKSEL uzayında (0..LABEL_W, 0..LABEL_H)
saklanır. Tuval bu uzayı `scale` ile büyüterek gösterir; çıktı PIL ile birebir
aynı koordinatlardan üretilir (WYSIWYG). Fiziksel termal yazıcı yalnız siyahı
bastığı için, baskı/HTML çıktısında koyu renkler siyaha indirgenir (önizlemede
seçilen renk korunur).
"""
from __future__ import annotations

import copy
import datetime
import json
import logging
from pathlib import Path
from tkinter import colorchooser, filedialog, messagebox
import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageDraw, ImageFont, ImageTk

log = logging.getLogger(__name__)

# Etiket fiziksel boyutu (label_render ile aynı: 60×40 mm @ 203 DPI)
LABEL_W = 480
LABEL_H = 320

# Etiket sarı zemini (fiziksel sarı etiket stoğu). Beyaz seçeneği de var.
BG_YELLOW = "#FFE680"
BG_WHITE = "#FFFFFF"

# Tutamaç (resize handle) boyutu — tuval pikseli
_HANDLE = 8

# Renk hızlı seçim paleti
_QUICK_COLORS = ["#000000", "#ffffff", "#d12626", "#1e63d1", "#1f9e3a", "#999999"]


def _font_path(bold: bool) -> str:
    return "arialbd.ttf" if bold else "arial.ttf"


def _pil_font(size: int, bold: bool) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(_font_path(bold), max(5, int(size)))
    except OSError:
        return ImageFont.load_default()


def _to_print_color(color: str) -> str:
    """Termal baskı için renk indirgeme: koyu renkler SİYAH, açık renkler BEYAZ.

    Fiziksel termal yazıcı yalnız siyahı bastığı için; ekrandaki kırmızı/mavi gibi
    koyu renkler etikette siyah, çok açık renkler (≈beyaz) basılmaz (beyaz kalır).
    """
    try:
        c = color.lstrip("#")
        if len(c) == 3:
            c = "".join(ch * 2 for ch in c)
        r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
    except Exception:
        return "black"
    # Algısal parlaklık
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    return "white" if lum >= 200 else "black"


def _wrap_text(draw: ImageDraw.ImageDraw, text: str, font, max_w: int) -> list[str]:
    """Kelime-bazlı satır sarma; \\n zorunlu satır kesmesi."""
    lines: list[str] = []
    for para in text.split("\n"):
        words = para.split(" ")
        cur = ""
        for w in words:
            trial = (cur + " " + w).strip() if cur else w
            if draw.textlength(trial, font=font) <= max_w or not cur:
                cur = trial
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


def _default_element(kind: str) -> dict:
    """Yeni öğe için varsayılan sözlük (etiket-piksel uzayında)."""
    cx, cy = LABEL_W // 2, LABEL_H // 2
    if kind == "text":
        return {
            "kind": "text", "x": cx - 110, "y": cy - 20, "w": 220, "h": 40,
            "text": "YAZI", "size": 22, "bold": True, "align": "center",
            "color": "#000000", "inverse": False, "wrap": True,
        }
    if kind == "line":
        return {
            "kind": "line", "x": cx - 110, "y": cy, "w": 220, "h": 0,
            "color": "#000000", "width": 2,
        }
    # rect
    return {
        "kind": "rect", "x": cx - 110, "y": cy - 40, "w": 220, "h": 80,
        "color": "#000000", "width": 2, "fill": False,
    }


# ---------------------------------------------------------------------------
# Tasarımı PIL görseline çevir (baskı + HTML önizleme; print_mode=True → siyaha indir)
# ---------------------------------------------------------------------------
def render_design(elements: list[dict], *, bg: str = BG_YELLOW,
                  print_mode: bool = False) -> Image.Image:
    img = Image.new("RGB", (LABEL_W, LABEL_H), bg)
    d = ImageDraw.Draw(img)

    def col(c: str) -> str:
        return _to_print_color(c) if print_mode else c

    for el in elements:
        kind = el.get("kind")
        x, y = int(el.get("x", 0)), int(el.get("y", 0))
        w, h = int(el.get("w", 0)), int(el.get("h", 0))
        if kind == "line":
            lw = max(1, int(el.get("width", 2)))
            d.line([(x, y), (x + w, y + h)], fill=col(el.get("color", "#000000")), width=lw)
        elif kind == "rect":
            bw = max(1, int(el.get("width", 2)))
            c = col(el.get("color", "#000000"))
            if el.get("fill"):
                d.rectangle([x, y, x + w, y + h], fill=c)
            else:
                d.rectangle([x, y, x + w, y + h], outline=c, width=bw)
        elif kind == "text":
            text = str(el.get("text", ""))
            size = int(el.get("size", 20))
            bold = bool(el.get("bold", False))
            align = el.get("align", "center")
            inverse = bool(el.get("inverse", False))
            wrap = bool(el.get("wrap", True))
            font = _pil_font(size, bold)
            if inverse:
                d.rectangle([x, y, x + w, y + h], fill=col("#000000"))
                fill = col("#ffffff")
            else:
                fill = col(el.get("color", "#000000"))
            inner_w = max(4, w - 6)
            if wrap:
                lines = _wrap_text(d, text, font, inner_w)
            else:
                lines = text.split("\n")
            # Satır yüksekliği
            try:
                asc, desc = font.getmetrics()
                line_h = asc + desc + 2
            except Exception:
                line_h = size + 4
            total_h = line_h * len(lines)
            ty = y + max(0, (h - total_h) // 2)
            for ln in lines:
                lw = d.textlength(ln, font=font)
                if align == "left":
                    tx = x + 3
                elif align == "right":
                    tx = x + w - 3 - lw
                else:
                    tx = x + (w - lw) / 2
                d.text((tx, ty), ln, font=font, fill=fill)
                ty += line_h
    return img


# ===========================================================================
# Tasarımcı sekmesi
# ===========================================================================
class LabelDesignerTab(ttk.Frame):
    """Serbest etiket tasarımcısı. `app` = ana ManualLabelApp (yazıcı cfg için)."""

    def __init__(self, parent, app):
        super().__init__(parent, style="Panel.TFrame")
        self.app = app
        self.elements: list[dict] = []
        self.selected: int | None = None      # seçili öğe indeksi
        self.scale: float = 1.8
        self.bg: str = BG_YELLOW
        self.snap: int = 4                     # ızgaraya yapışma (px); 0 = kapalı
        self.show_grid = tk.BooleanVar(value=True)

        # Sürükleme durumu
        self._drag_mode: str | None = None     # "move" | "resize" | None
        self._drag_off = (0, 0)
        self._loading = False                  # özellik panelini doldururken trace tetiklenmesin

        self._photo: ImageTk.PhotoImage | None = None
        self._build()
        self._redraw()

    # ------------------------------------------------------------------ UI
    def _build(self):
        # ÜST ARAÇ ŞERİDİ
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=8, pady=(8, 2))

        ttk.Button(bar, text="➕ Yazı", command=lambda: self._add("text")).pack(side="left", padx=2)
        ttk.Button(bar, text="➕ Çizgi", command=lambda: self._add("line")).pack(side="left", padx=2)
        ttk.Button(bar, text="➕ Çerçeve / Kutu", command=lambda: self._add("rect")).pack(side="left", padx=2)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=8)

        ttk.Label(bar, text="Zemin:").pack(side="left")
        self.var_bg = tk.StringVar(value="Sarı")
        cb = ttk.Combobox(bar, textvariable=self.var_bg, width=7, state="readonly",
                          values=["Sarı", "Beyaz"])
        cb.pack(side="left", padx=(2, 8))
        cb.bind("<<ComboboxSelected>>", self._on_bg_change)

        ttk.Label(bar, text="Yakınlaştır:").pack(side="left")
        ttk.Button(bar, text="–", width=2, command=lambda: self._zoom(-0.2)).pack(side="left")
        ttk.Button(bar, text="+", width=2, command=lambda: self._zoom(0.2)).pack(side="left", padx=(0, 8))

        ttk.Checkbutton(bar, text="Izgara", variable=self.show_grid,
                        command=self._redraw).pack(side="left", padx=4)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(bar, text="💾 Şablon Kaydet", command=self._save_template).pack(side="left", padx=2)
        ttk.Button(bar, text="📂 Şablon Yükle", command=self._load_template).pack(side="left", padx=2)
        ttk.Button(bar, text="🧹 Hepsini Sil", command=self._clear_all).pack(side="left", padx=2)

        # GÖVDE: sol (öğe listesi) | orta (tuval) | sağ (özellikler)
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=8, pady=6)

        # --- Sol: öğe listesi + z-sıra ---
        left = ttk.Frame(body, width=190)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        lf = ttk.LabelFrame(left, text="Öğeler", padding=4)
        lf.pack(fill="both", expand=True)
        self.lst = tk.Listbox(lf, font=("Consolas", 9), activestyle="none")
        self.lst.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.lst.yview)
        self.lst.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.lst.bind("<<ListboxSelect>>", self._on_list_select)

        zrow = ttk.Frame(left)
        zrow.pack(fill="x", pady=(4, 0))
        ttk.Button(zrow, text="⬆ Öne", command=lambda: self._reorder(1)).pack(side="left", expand=True, fill="x", padx=1)
        ttk.Button(zrow, text="⬇ Arka", command=lambda: self._reorder(-1)).pack(side="left", expand=True, fill="x", padx=1)
        ttk.Button(left, text="🗑 Seçiliyi Sil", command=self._delete_selected).pack(fill="x", pady=(4, 0))
        ttk.Button(left, text="⧉ Kopyala", command=self._duplicate_selected).pack(fill="x", pady=(2, 0))

        # --- Orta: tuval ---
        center = ttk.Frame(body)
        center.pack(side="left", fill="both", expand=True, padx=8)
        self.canvas = tk.Canvas(center, background="#3a3a3a", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        # Klavye: nudge + sil (tuvale odak için tıklama yeterli)
        self.canvas.bind("<Left>", lambda e: self._nudge(-1, 0))
        self.canvas.bind("<Right>", lambda e: self._nudge(1, 0))
        self.canvas.bind("<Up>", lambda e: self._nudge(0, -1))
        self.canvas.bind("<Down>", lambda e: self._nudge(0, 1))
        self.canvas.bind("<Delete>", lambda e: self._delete_selected())

        # --- Sağ: özellikler ---
        self.prop = ttk.LabelFrame(body, text="Özellikler", padding=6, width=250)
        self.prop.pack(side="left", fill="y")
        self.prop.pack_propagate(False)
        self._build_props(self.prop)

        # ALT: çıktı şeridi
        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=8, pady=(2, 10))
        ttk.Button(bottom, text="📄 HTML Önizleme", command=self._preview_html).pack(side="left", padx=4, ipady=3)
        ttk.Button(bottom, text="🖨 Yazıcıdan Çıkar", command=self._print).pack(side="left", padx=4, ipady=3)
        self.lbl_hint = ttk.Label(
            bottom, style="Muted.TLabel",
            text="İpucu: Öğeyi sürükle = taşı · sağ-alt köşeden çek = boyutlandır · ok tuşları = kaydır · Delete = sil")
        self.lbl_hint.pack(side="left", padx=12)

    def _build_props(self, p):
        """Sağ özellik paneli — seçime göre ilgili alanlar gösterilir."""
        self._pvars: dict[str, tk.Variable] = {}
        self._prows: dict[str, ttk.Frame] = {}

        def row(key, label):
            f = ttk.Frame(p)
            ttk.Label(f, text=label, style="Panel.TLabel", width=10, anchor="w").pack(side="left")
            self._prows[key] = f
            return f

        # Metin (çok satırlı)
        ftxt = row("text", "Metin")
        ftxt.pack(fill="x", pady=2)
        self.txt = tk.Text(ftxt, height=3, width=20, font=("Segoe UI", 10), wrap="word")
        self.txt.pack(side="left", fill="x", expand=True)
        self.txt.bind("<KeyRelease>", lambda e: self._on_text_edit())

        # Punto
        f = row("size", "Punto"); f.pack(fill="x", pady=2)
        self._pvars["size"] = tk.IntVar(value=22)
        sp = tk.Spinbox(f, from_=6, to=140, width=6, textvariable=self._pvars["size"],
                        command=self._apply_props)
        sp.pack(side="left")
        sp.bind("<KeyRelease>", lambda e: self._apply_props())

        # Kalın + Sarma + Ters
        f = row("flags", "Stil"); f.pack(fill="x", pady=2)
        self._pvars["bold"] = tk.BooleanVar(value=True)
        self._pvars["wrap"] = tk.BooleanVar(value=True)
        self._pvars["inverse"] = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Kalın", variable=self._pvars["bold"],
                        command=self._apply_props).pack(side="left")
        ttk.Checkbutton(f, text="Sar", variable=self._pvars["wrap"],
                        command=self._apply_props).pack(side="left")
        ttk.Checkbutton(f, text="Ters", variable=self._pvars["inverse"],
                        command=self._apply_props).pack(side="left")

        # Hizalama
        f = row("align", "Hizala"); f.pack(fill="x", pady=2)
        self._pvars["align"] = tk.StringVar(value="center")
        for txt, val in (("◧ Sol", "left"), ("▣ Orta", "center"), ("◨ Sağ", "right")):
            ttk.Radiobutton(f, text=txt, value=val, variable=self._pvars["align"],
                            command=self._apply_props).pack(side="left")

        # Dolu (rect) + Kalınlık (rect/line)
        f = row("fill", "Kutu"); f.pack(fill="x", pady=2)
        self._pvars["fill"] = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="İçi dolu (container)", variable=self._pvars["fill"],
                        command=self._apply_props).pack(side="left")

        f = row("width", "Kalınlık"); f.pack(fill="x", pady=2)
        self._pvars["width"] = tk.IntVar(value=2)
        sp2 = tk.Spinbox(f, from_=1, to=30, width=6, textvariable=self._pvars["width"],
                         command=self._apply_props)
        sp2.pack(side="left")
        sp2.bind("<KeyRelease>", lambda e: self._apply_props())

        # Renk
        f = row("color", "Renk"); f.pack(fill="x", pady=2)
        self._color_btn = tk.Button(f, text="  ", width=3, relief="solid", bd=1,
                                    command=self._pick_color)
        self._color_btn.pack(side="left", padx=(0, 4))
        for c in _QUICK_COLORS:
            tk.Button(f, background=c, width=1, relief="solid", bd=1,
                      command=lambda cc=c: self._set_color(cc)).pack(side="left", padx=1)

        # Konum / boyut
        f = row("pos", "Konum"); f.pack(fill="x", pady=(8, 2))
        for key, lbl in (("x", "X"), ("y", "Y")):
            ttk.Label(f, text=lbl, style="Panel.TLabel").pack(side="left")
            self._pvars[key] = tk.IntVar(value=0)
            s = tk.Spinbox(f, from_=-200, to=LABEL_W, width=5, textvariable=self._pvars[key],
                           command=self._apply_props)
            s.pack(side="left", padx=(0, 6))
            s.bind("<KeyRelease>", lambda e: self._apply_props())

        f = row("size_wh", "Boyut"); f.pack(fill="x", pady=2)
        for key, lbl in (("w", "G"), ("h", "Y")):
            ttk.Label(f, text=lbl, style="Panel.TLabel").pack(side="left")
            self._pvars[key] = tk.IntVar(value=0)
            s = tk.Spinbox(f, from_=-LABEL_H, to=LABEL_W, width=5, textvariable=self._pvars[key],
                           command=self._apply_props)
            s.pack(side="left", padx=(0, 6))
            s.bind("<KeyRelease>", lambda e: self._apply_props())

        self._empty_lbl = ttk.Label(p, style="PanelMuted.TLabel", wraplength=220,
                                    text="Bir öğe ekle veya tuvalde bir öğeye tıkla.")
        self._empty_lbl.pack(pady=10)

    # ------------------------------------------------------------- koordinat
    def _s(self, v: float) -> int:
        return int(round(v * self.scale))

    def _disp_origin(self):
        """Tuval içinde etiketin sol-üst köşesinin ekran konumu (ortalanmış)."""
        cw = self.canvas.winfo_width() or 800
        ch = self.canvas.winfo_height() or 600
        lw, lh = self._s(LABEL_W), self._s(LABEL_H)
        ox = max(0, (cw - lw) // 2)
        oy = max(0, (ch - lh) // 2)
        return ox, oy

    def _canvas_to_label(self, cx, cy):
        ox, oy = self._disp_origin()
        return (cx - ox) / self.scale, (cy - oy) / self.scale

    def _snap(self, v: float) -> int:
        if self.snap and self.snap > 0:
            return int(round(v / self.snap) * self.snap)
        return int(round(v))

    # ------------------------------------------------------------- çizim
    def _redraw(self):
        c = self.canvas
        c.delete("all")
        ox, oy = self._disp_origin()
        lw, lh = self._s(LABEL_W), self._s(LABEL_H)

        # Etiket zemini
        c.create_rectangle(ox, oy, ox + lw, oy + lh, fill=self.bg, outline="#000000")

        # Izgara
        if self.show_grid.get():
            step = 40  # etiket-piksel
            for gx in range(0, LABEL_W + 1, step):
                c.create_line(ox + self._s(gx), oy, ox + self._s(gx), oy + lh,
                              fill="#e6d36a" if self.bg == BG_YELLOW else "#eeeeee")
            for gy in range(0, LABEL_H + 1, step):
                c.create_line(ox, oy + self._s(gy), ox + lw, oy + self._s(gy),
                              fill="#e6d36a" if self.bg == BG_YELLOW else "#eeeeee")

        # Öğeler
        for i, el in enumerate(self.elements):
            self._draw_element(el, ox, oy)

        # Seçili öğe çerçevesi + tutamaç
        if self.selected is not None and 0 <= self.selected < len(self.elements):
            el = self.elements[self.selected]
            x0 = ox + self._s(el["x"]); y0 = oy + self._s(el["y"])
            x1 = ox + self._s(el["x"] + el["w"]); y1 = oy + self._s(el["y"] + el["h"])
            # çizgide bbox ters olabilir → normalize
            bx0, bx1 = sorted((x0, x1)); by0, by1 = sorted((y0, y1))
            c.create_rectangle(bx0 - 2, by0 - 2, bx1 + 2, by1 + 2,
                               outline="#1e63d1", dash=(4, 2), width=2)
            # resize tutamacı sağ-alt
            c.create_rectangle(bx1 - _HANDLE, by1 - _HANDLE, bx1 + _HANDLE, by1 + _HANDLE,
                               fill="#1e63d1", outline="white", tags="handle")

        self._refresh_list_highlight()

    def _draw_element(self, el, ox, oy):
        c = self.canvas
        kind = el["kind"]
        x0 = ox + self._s(el["x"]); y0 = oy + self._s(el["y"])
        x1 = ox + self._s(el["x"] + el["w"]); y1 = oy + self._s(el["y"] + el["h"])
        color = el.get("color", "#000000")
        if kind == "line":
            c.create_line(x0, y0, x1, y1, fill=color, width=max(1, self._s(el.get("width", 2))))
        elif kind == "rect":
            if el.get("fill"):
                c.create_rectangle(x0, y0, x1, y1, fill=color, outline=color)
            else:
                c.create_rectangle(x0, y0, x1, y1, outline=color,
                                   width=max(1, self._s(el.get("width", 2))))
        elif kind == "text":
            size = int(el.get("size", 20))
            bold = bool(el.get("bold", False))
            align = el.get("align", "center")
            inverse = bool(el.get("inverse", False))
            wrap = bool(el.get("wrap", True))
            fnt = ("Arial", -max(6, self._s(size)), "bold" if bold else "normal")
            if inverse:
                c.create_rectangle(x0, y0, x1, y1, fill="#000000", outline="#000000")
                fill = "#ffffff"
            else:
                fill = color
            txt = str(el.get("text", ""))
            ww = self._s(el["w"]) - 6
            # Yatay: anchor sol/orta/sağ + dikey orta
            ymid = (y0 + y1) // 2
            if align == "left":
                anchor, px, just = "w", x0 + 3, "left"
            elif align == "right":
                anchor, px, just = "e", x1 - 3, "right"
            else:
                anchor, px, just = "center", (x0 + x1) // 2, "center"
            kwargs = dict(text=txt, fill=fill, font=fnt, anchor=anchor, justify=just)
            if wrap:
                kwargs["width"] = max(8, ww)
            c.create_text(px, ymid, **kwargs)

    # ------------------------------------------------------------- liste
    def _refresh_list(self):
        self.lst.delete(0, "end")
        for i, el in enumerate(self.elements):
            k = el["kind"]
            if k == "text":
                desc = (el.get("text", "") or "").replace("\n", " ")[:18]
                label = f"{i+1}. ✎ {desc}"
            elif k == "line":
                label = f"{i+1}. — çizgi"
            else:
                label = f"{i+1}. ▭ {'kutu' if el.get('fill') else 'çerçeve'}"
            self.lst.insert("end", label)
        self._refresh_list_highlight()

    def _refresh_list_highlight(self):
        self.lst.selection_clear(0, "end")
        if self.selected is not None and 0 <= self.selected < self.lst.size():
            self.lst.selection_set(self.selected)

    def _on_list_select(self, _e=None):
        sel = self.lst.curselection()
        if sel:
            self.selected = sel[0]
            self._populate_props()
            self._redraw()

    # ------------------------------------------------------------- ekle/sil
    def _add(self, kind):
        el = _default_element(kind)
        self.elements.append(el)
        self.selected = len(self.elements) - 1
        self._refresh_list()
        self._populate_props()
        self._redraw()
        self.canvas.focus_set()

    def _delete_selected(self):
        if self.selected is None:
            return
        del self.elements[self.selected]
        self.selected = None
        self._refresh_list()
        self._populate_props()
        self._redraw()

    def _duplicate_selected(self):
        if self.selected is None:
            return
        el = copy.deepcopy(self.elements[self.selected])
        el["x"] += 12; el["y"] += 12
        self.elements.append(el)
        self.selected = len(self.elements) - 1
        self._refresh_list()
        self._populate_props()
        self._redraw()

    def _reorder(self, direction):
        """+1 = öne (listede sona / üste çizilir), -1 = arkaya."""
        i = self.selected
        if i is None:
            return
        j = i + direction
        if not (0 <= j < len(self.elements)):
            return
        self.elements[i], self.elements[j] = self.elements[j], self.elements[i]
        self.selected = j
        self._refresh_list()
        self._redraw()

    def _clear_all(self):
        if self.elements and not messagebox.askyesno("Temizle", "Tüm öğeler silinsin mi?"):
            return
        self.elements = []
        self.selected = None
        self._refresh_list()
        self._populate_props()
        self._redraw()

    def _nudge(self, dx, dy):
        if self.selected is None:
            return
        el = self.elements[self.selected]
        el["x"] += dx; el["y"] += dy
        self._populate_props()
        self._redraw()

    # ------------------------------------------------------------- özellikler
    def _populate_props(self):
        """Seçili öğeye göre paneli doldurur ve ilgisiz satırları gizler."""
        self._loading = True
        el = None
        if self.selected is not None and 0 <= self.selected < len(self.elements):
            el = self.elements[self.selected]
        if el is None:
            for f in self._prows.values():
                f.pack_forget()
            self._empty_lbl.pack(pady=10)
            self._loading = False
            return
        self._empty_lbl.pack_forget()

        kind = el["kind"]
        # ortak: konum/boyut/renk her zaman
        common = ["color", "pos", "size_wh"]
        if kind == "text":
            show = ["text", "size", "flags", "align"] + common
            self.txt.delete("1.0", "end")
            self.txt.insert("1.0", el.get("text", ""))
            self._pvars["size"].set(int(el.get("size", 22)))
            self._pvars["bold"].set(bool(el.get("bold", True)))
            self._pvars["wrap"].set(bool(el.get("wrap", True)))
            self._pvars["inverse"].set(bool(el.get("inverse", False)))
            self._pvars["align"].set(el.get("align", "center"))
        elif kind == "rect":
            show = ["fill", "width"] + common
            self._pvars["fill"].set(bool(el.get("fill", False)))
            self._pvars["width"].set(int(el.get("width", 2)))
        else:  # line
            show = ["width"] + common
            self._pvars["width"].set(int(el.get("width", 2)))

        self._pvars["x"].set(int(el.get("x", 0)))
        self._pvars["y"].set(int(el.get("y", 0)))
        self._pvars["w"].set(int(el.get("w", 0)))
        self._pvars["h"].set(int(el.get("h", 0)))
        self._set_color_btn(el.get("color", "#000000"))

        # satırları sıraya göre yeniden yerleştir
        for f in self._prows.values():
            f.pack_forget()
        order = ["text", "size", "flags", "align", "fill", "width", "color", "pos", "size_wh"]
        for key in order:
            if key in show:
                self._prows[key].pack(fill="x", pady=2)
        self._loading = False

    def _apply_props(self):
        if self._loading or self.selected is None:
            return
        el = self.elements[self.selected]
        kind = el["kind"]
        try:
            el["x"] = int(self._pvars["x"].get())
            el["y"] = int(self._pvars["y"].get())
            el["w"] = int(self._pvars["w"].get())
            el["h"] = int(self._pvars["h"].get())
        except (tk.TclError, ValueError):
            pass
        if kind == "text":
            try:
                el["size"] = max(6, int(self._pvars["size"].get()))
            except (tk.TclError, ValueError):
                pass
            el["bold"] = self._pvars["bold"].get()
            el["wrap"] = self._pvars["wrap"].get()
            el["inverse"] = self._pvars["inverse"].get()
            el["align"] = self._pvars["align"].get()
        elif kind == "rect":
            el["fill"] = self._pvars["fill"].get()
            try:
                el["width"] = max(1, int(self._pvars["width"].get()))
            except (tk.TclError, ValueError):
                pass
        else:
            try:
                el["width"] = max(1, int(self._pvars["width"].get()))
            except (tk.TclError, ValueError):
                pass
        self._redraw()

    def _on_text_edit(self):
        if self._loading or self.selected is None:
            return
        el = self.elements[self.selected]
        if el["kind"] != "text":
            return
        el["text"] = self.txt.get("1.0", "end-1c")
        self._refresh_list()
        self._redraw()

    # renk
    def _set_color_btn(self, color):
        try:
            self._color_btn.configure(background=color)
        except tk.TclError:
            self._color_btn.configure(background="#000000")

    def _set_color(self, color):
        if self.selected is None:
            return
        self.elements[self.selected]["color"] = color
        self._set_color_btn(color)
        self._redraw()

    def _pick_color(self):
        if self.selected is None:
            return
        cur = self.elements[self.selected].get("color", "#000000")
        rgb, hx = colorchooser.askcolor(color=cur, title="Renk seç")
        if hx:
            self._set_color(hx)

    # ------------------------------------------------------------- fare
    def _on_press(self, e):
        self.canvas.focus_set()
        # önce: seçili öğenin resize tutamacına mı bastık?
        if self.selected is not None and 0 <= self.selected < len(self.elements):
            ox, oy = self._disp_origin()
            el = self.elements[self.selected]
            hx = ox + self._s(el["x"] + el["w"])
            hy = oy + self._s(el["y"] + el["h"])
            if abs(e.x - hx) <= _HANDLE + 2 and abs(e.y - hy) <= _HANDLE + 2:
                self._drag_mode = "resize"
                return
        # öğe seçimi: en üstteki (sondaki) öğeden başla
        lx, ly = self._canvas_to_label(e.x, e.y)
        hit = self._hit_test(lx, ly)
        self.selected = hit
        if hit is not None:
            el = self.elements[hit]
            self._drag_mode = "move"
            self._drag_off = (lx - el["x"], ly - el["y"])
        else:
            self._drag_mode = None
        self._populate_props()
        self._redraw()

    def _hit_test(self, lx, ly):
        for i in range(len(self.elements) - 1, -1, -1):
            el = self.elements[i]
            x0, x1 = sorted((el["x"], el["x"] + el["w"]))
            y0, y1 = sorted((el["y"], el["y"] + el["h"]))
            # çizgi/ince öğeler için tıklama payı
            pad = 6
            if x0 - pad <= lx <= x1 + pad and y0 - pad <= ly <= y1 + pad:
                return i
        return None

    def _on_drag(self, e):
        if self._drag_mode is None or self.selected is None:
            return
        el = self.elements[self.selected]
        lx, ly = self._canvas_to_label(e.x, e.y)
        if self._drag_mode == "move":
            el["x"] = self._snap(lx - self._drag_off[0])
            el["y"] = self._snap(ly - self._drag_off[1])
        elif self._drag_mode == "resize":
            el["w"] = self._snap(max(2, lx - el["x"])) if el["kind"] != "line" else self._snap(lx - el["x"])
            el["h"] = self._snap(ly - el["y"]) if el["kind"] == "line" else self._snap(max(2, ly - el["y"]))
        self._redraw()

    def _on_release(self, _e):
        if self._drag_mode is not None:
            self._drag_mode = None
            self._populate_props()

    # ------------------------------------------------------------- zoom/bg
    def _zoom(self, delta):
        self.scale = max(1.0, min(4.0, round(self.scale + delta, 2)))
        self._redraw()

    def _on_bg_change(self, _e=None):
        self.bg = BG_WHITE if self.var_bg.get() == "Beyaz" else BG_YELLOW
        self._redraw()

    # ------------------------------------------------------------- şablon
    def _templates_dir(self) -> Path:
        d = Path(__file__).resolve().parents[3] / "data" / "label_templates"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _save_template(self):
        if not self.elements:
            messagebox.showinfo("Şablon", "Kaydedilecek öğe yok.")
            return
        path = filedialog.asksaveasfilename(
            title="Şablonu kaydet", defaultextension=".json",
            initialdir=str(self._templates_dir()),
            filetypes=[("Etiket şablonu", "*.json")])
        if not path:
            return
        data = {"version": 1, "bg": self.bg, "elements": self.elements}
        try:
            Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            messagebox.showinfo("Şablon", "Şablon kaydedildi.")
        except Exception as e:
            messagebox.showerror("Şablon", f"Kaydedilemedi:\n{e}")

    def _load_template(self):
        path = filedialog.askopenfilename(
            title="Şablon yükle", initialdir=str(self._templates_dir()),
            filetypes=[("Etiket şablonu", "*.json")])
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self.elements = list(data.get("elements", []))
            self.bg = data.get("bg", BG_YELLOW)
            self.var_bg.set("Beyaz" if self.bg == BG_WHITE else "Sarı")
            self.selected = None
            self._refresh_list()
            self._populate_props()
            self._redraw()
        except Exception as e:
            messagebox.showerror("Şablon", f"Yüklenemedi:\n{e}")

    # ------------------------------------------------------------- çıktı
    def _preview_html(self):
        import tempfile
        import webbrowser
        img = render_design(self.elements, bg=self.bg, print_mode=True)
        tmp = Path(tempfile.gettempdir()) / "ilactarif_designer_preview.png"
        img.save(tmp)
        html = Path(tempfile.gettempdir()) / "ilactarif_designer_preview.html"
        html.write_text(
            f"<html><body style='background:#444;text-align:center;padding:30px'>"
            f"<img src='file:///{tmp.as_posix()}' "
            f"style='width:{LABEL_W*2}px;border:1px solid #000;image-rendering:pixelated'>"
            f"<p style='color:#ccc;font-family:sans-serif'>Baskı önizlemesi (siyaha indirgenmiş)</p>"
            f"</body></html>", encoding="utf-8")
        webbrowser.open(html.as_uri())

    def _print(self):
        if not self.elements:
            messagebox.showinfo("Yazıcı", "Yazdırılacak öğe yok.")
            return
        try:
            from .. import printer
        except ImportError:
            messagebox.showerror("Yazıcı", "Printer modülü yüklenemedi.")
            return
        app = self.app
        try:
            cfg = app._active_printer_cfg()
        except Exception as e:
            messagebox.showerror("Yazıcı", f"Aktif yazıcı bulunamadı:\n{e}")
            return
        img = render_design(self.elements, bg=self.bg, print_mode=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        preview_dir = Path(__file__).resolve().parents[3] / "data" / "live_preview"
        preview_dir.mkdir(parents=True, exist_ok=True)
        p = preview_dir / f"designer_{ts}.png"
        img.save(p)
        try:
            printer.send_image(
                p, cfg,
                label_mm=(getattr(app, "label_w_mm", 60.0), getattr(app, "label_h_mm", 40.0)),
                gap_mm=getattr(app, "label_gap_mm", 2.0),
                dpi=getattr(app, "printer_dpi", 203),
            )
            addr = printer.cfg_label(cfg)
            app.status.set(f"🖨 Elle tasarım etiketi {addr} yazıcısına gönderildi.")
        except Exception as e:
            messagebox.showerror("Yazıcı hatası", str(e))
