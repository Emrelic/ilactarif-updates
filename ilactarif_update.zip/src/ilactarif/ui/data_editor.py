"""'Veri Ekle / Düzenle' sekmesi — ilaç veritabanı yönetim arayüzü.

Sol: arama + ilaç listesi (seç → düzenle, ➕ Yeni → boş kayıt).
Orta: kaydırmalı form — Temel kayıt + Kullanım etiketi (A) + Modüler bloklar (B/C/D).
Sağ: seçili/girilen ilacın canlı KULLANIM etiketi önizlemesi + tüm etiketleri önizle.

Yazma stratejisi drug_admin.save_drug_all'da: drugs kolonları + drug_labels tip-1
JSON + drug_label_blocks (source='manual'). Böylece hem Manuel hem Medula sekmesi
düzenlemeleri yansıtır.
"""
from __future__ import annotations

import datetime
import logging

import tkinter as tk
from tkinter import messagebox, ttk

from PIL import Image, ImageTk

from .. import drug_admin
from ..db import get_connection, init_schema
from ..drug_guess import build_kullanim_talimati, guess_form
from ..label_from_db import (
    build_review_list, get_reviewed_ids, render_review_label,
    render_review_labels, reset_review_status, set_review_status,
)
from ..label_render import render_usage_label
from ..models import UsageLabel
from .manual_label_ui import COLORS

log = logging.getLogger("ilactarif.ui")

# Açılır liste seçenekleri
_FORMS = ["", "tablet", "kapsül", "film tablet", "efervesan tablet", "şurup",
          "süspansiyon", "damla", "sprey", "inhaler", "krem", "merhem", "jel",
          "losyon", "solüsyon", "ampul", "flakon", "fitil", "ovül", "pomad",
          "göz damlası", "kulak damlası", "gargara", "toz", "saşe"]
_ROUTES = ["", "ağızdan", "cilt üzerine", "göze", "buruna", "kulağa", "solunum",
           "rektal", "vajinal", "cilt altı", "kas içi", "damar içi"]
_DOSE_UNITS = ["", "tablet", "kapsül", "ml", "puf", "damla", "uygulama",
               "fitil", "ovül", "ünite", "ölçek", "saşe"]
_MEALS = ["", "aç", "tok", "yemekten önce", "yemekle", "yemekten sonra", "fark etmez"]
_PRESC = ["", "Normal", "Kırmızı", "Yeşil", "Mor", "Turuncu", "Beyaz"]
_DRUGTYPES = ["", "İLAÇ", "PASİF İLAÇ"]

# Blok başlıkları (kullanıcıya gösterilecek adlar)
_BLOCK_LABELS = {
    "endikasyon": "Endikasyon (ne için)",
    "hazirlama": "Hazırlama (şurup/süspansiyon adımları) — B",
    "teknik": "Teknik kullanım (inhaler/sprey vb.) — B/D",
    "saklama": "Saklama koşulu — A rozeti",
    "dikkat": "Dikkat edilecekler — C/D",
    "etkilesim": "İlaç/besin etkileşimi — C",
    "sivi": "Sıvı/besin uyarısı — C",
    "yan_etki": "Ciddi yan etkiler — C/D",
    "hatirlatma": "Hatırlatma — D",
    "sonlandirma": "Tedaviyi sonlandırma",
}


class DataAdminTab(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, background=COLORS["bg_main"])
        self.app = app
        self.drug_id = None              # düzenlenen kaydın id'si (None = yeni)
        self._results: list = []
        self._preview_after = None
        self._preview_photo = None
        self._cur_pil = None
        self._fit_after = None

        # --- alan değişkenleri (drugs'taki TÜM düzenlenebilir kolonlar) ---
        self.f = {}
        for key in drug_admin.DRUG_EDIT_COLS:
            self.f[key] = tk.StringVar()
        self.txt = {}                    # büyük metinler: talimat/uyari + bloklar
        self._build()
        self._refresh_list()
        self._new()

    # ==================================================================
    # Arayüz
    # ==================================================================
    def _build(self):
        C = COLORS
        # SOL: arama + liste
        left = tk.Frame(self, background=C["bg_main"], width=300)
        left.pack(side="left", fill="y", padx=(4, 8), pady=4)
        left.pack_propagate(False)

        tk.Label(left, text="🔎 İlaç Ara (barkod / isim)", background=C["bg_main"],
                 foreground=C["text_yellow"], font=("Segoe UI", 10, "bold"),
                 anchor="w").pack(fill="x")
        self.var_search = tk.StringVar()
        ent = ttk.Entry(left, textvariable=self.var_search, font=("Segoe UI", 11))
        ent.pack(fill="x", pady=4)
        ent.bind("<KeyRelease>", lambda e: self._on_search())

        lst_wrap = tk.Frame(left, background=C["bg_panel"])
        lst_wrap.pack(fill="both", expand=True)
        self.lst = tk.Listbox(lst_wrap, font=("Consolas", 9), activestyle="none")
        ysb = ttk.Scrollbar(lst_wrap, orient="vertical", command=self.lst.yview)
        self.lst.configure(yscrollcommand=ysb.set)
        self.lst.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        self.lst.bind("<<ListboxSelect>>", self._on_list_select)

        bbar = tk.Frame(left, background=C["bg_main"])
        bbar.pack(fill="x", pady=4)
        ttk.Button(bbar, text="➕ Yeni İlaç", command=self._new).pack(side="left", padx=2)
        ttk.Button(bbar, text="🗑 Sil", command=self._delete).pack(side="left", padx=2)

        # SAĞ: canlı önizleme (sabit) — formdan ÖNCE pack'lenir ki daima görünsün.
        right = tk.Frame(self, background=C["bg_panel"], width=440)
        right.pack(side="right", fill="y", padx=(8, 4), pady=4)
        right.pack_propagate(False)
        tk.Label(right, text="KULLANIM ETİKETİ ÖNİZLEME", background=C["bg_panel"],
                 foreground=C["text_yellow"], font=("Segoe UI", 10, "bold")).pack(pady=(8, 4))
        self.prev_holder = tk.Frame(right, background=C["bg_panel"])
        self.prev_holder.pack(fill="both", expand=True, padx=10)
        self.prev_img = tk.Label(self.prev_holder, background=C["bg_panel"], borderwidth=0)
        self.prev_img.pack(expand=True)
        self.prev_holder.bind("<Configure>", self._on_prev_resize)
        ttk.Button(right, text="🖨 Tüm Etiketleri Önizle (A/B/C/D)",
                   command=self._preview_all).pack(fill="x", padx=10, pady=(4, 8))

        # ORTA: kaydırmalı form
        mid = tk.Frame(self, background=C["bg_main"])
        mid.pack(side="left", fill="both", expand=True, pady=4)

        # Üst kaydet şeridi
        savebar = tk.Frame(mid, background=C["bg_main"])
        savebar.pack(fill="x", pady=(0, 4))
        self.lbl_title = tk.Label(savebar, text="Yeni İlaç", background=C["bg_main"],
                                  foreground=C["text_yellow"], font=("Segoe UI", 13, "bold"),
                                  anchor="w")
        self.lbl_title.pack(side="left", padx=4)
        ttk.Button(savebar, text="💾 Kaydet", style="Accent.TButton",
                   command=self._save).pack(side="right", padx=4, ipadx=10, ipady=2)
        # Etiket kontrol modülü: muadil-deduplike, en çok kullanılandan etiketleri
        # tek tek gözden geçir (kategori/talimat/uyarı doğruluğu için).
        ttk.Button(savebar, text="🔍 Etiket Kontrol", style="Yellow.TButton",
                   command=self._open_review).pack(side="right", padx=4, ipady=2)

        canvas = tk.Canvas(mid, background=C["bg_main"], highlightthickness=0)
        ysb2 = ttk.Scrollbar(mid, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=ysb2.set)
        canvas.pack(side="left", fill="both", expand=True)
        ysb2.pack(side="right", fill="y")
        form = tk.Frame(canvas, background=C["bg_main"])
        win = canvas.create_window((0, 0), window=form, anchor="nw")
        form.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        canvas.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))

        # === Bölüm 1: Temel kayıt ===
        s1 = self._section(form, "🧾  Temel Kayıt")
        self._entry(s1, "Barkod", "barcode", 0, 0)
        self._entry(s1, "İlaç adı", "name", 0, 2, wide=True)
        self._entry(s1, "Üretici", "manufacturer", 1, 0, wide=True)
        self._entry(s1, "ATC kodu", "atc_code", 2, 0)
        self._entry(s1, "ATC adı", "atc_name", 2, 2)
        self._entry(s1, "Etken madde", "active_ingredient", 3, 0, wide=True)
        self._combo(s1, "Reçete türü", "prescription_type", _PRESC, 4, 0)
        self._combo(s1, "İlaç türü", "drug_type", _DRUGTYPES, 4, 2)
        self._entry(s1, "Eşdeğer kod", "equivalent_code", 5, 0)
        self._entry(s1, "SKRS durum", "skrs_status", 5, 2)

        # === Bölüm 2: Kullanım etiketi (A) ===
        s2 = self._section(form, "💊  Kullanım Etiketi (A)")
        self._entry(s2, "Kategori (başlık)", "indication_short", 0, 0, wide=True)
        self._combo(s2, "Form", "form", _FORMS, 1, 0)
        self._combo(s2, "Veriliş yolu", "route", _ROUTES, 1, 2)
        self._entry(s2, "Doz adedi", "default_dose", 2, 0, small=True)
        self._combo(s2, "Doz birim", "dose_unit", _DOSE_UNITS, 2, 2)
        # Oral şurup/süspansiyonda bir ÖLÇEĞİN ml hacmi (çoğu 5; Duphalac vb. 30).
        # Boşsa 5 ml varsayılır; ölçek sayısı katlanmaz (1x1 → 1 ÖLÇEK).
        self._entry(s2, "Ölçek (ml)", "olcek_ml", 3, 0, small=True)
        self._entry(s2, "Günde kez", "daily_freq", 4, 0, small=True)
        self._entry(s2, "Saat arası", "hours_apart", 4, 2, small=True)
        self._combo(s2, "Öğün", "meal_relation", _MEALS, 5, 0)
        self._entry(s2, "Süre (gün)", "treatment_days", 5, 2, small=True)
        self._text(s2, "Kullanım talimatı", "kullanim_talimati", 6, height=2,
                   hint="(boşsa otomatik üretilir)")
        self._text(s2, "Uyarı metni", "uyari_metni", 7, height=2)

        # === Bölüm 3: Öğün detayı (hassas iki katmanlı öğün modeli + meta) ===
        sm = self._section(form, "🍽  Öğün Detayı")
        self._combo(sm, "Öğün grubu", "meal_group",
                    ["", "AÇ", "TOK", "FARK ETMEZ"], 0, 0)
        self._entry(sm, "Alt satır (hassas)", "meal_detail", 0, 2)
        self._combo(sm, "AÇ kritik?", "meal_ac_critical", ["", "0", "1"], 1, 0)
        self._combo(sm, "Onaylı?", "meal_reviewed", ["", "0", "1"], 1, 2)
        self._entry(sm, "Kaynak", "meal_source", 2, 0, wide=True)
        self._entry(sm, "Güven", "meal_confidence", 3, 0)

        # === Bölüm 4: Hazırlama Etiketi (B) ===
        sb = self._section(form, "🧪  Hazırlama Etiketi (B)")
        self._text(sb, "Hazırlama adımları (şurup/süspansiyon)", "blk_hazirlama", 0, height=3)
        self._text(sb, "Saklama koşulu (A rozeti + B)", "blk_saklama", 2, height=2)

        # === Bölüm 5: Ciddi Uyarı Etiketi (C) ===
        sc = self._section(form, "⚠  Ciddi Uyarı Etiketi (C)")
        self._text(sc, "İlaç/besin etkileşimi", "blk_etkilesim", 0, height=2)
        self._text(sc, "Sıvı/besin uyarısı", "blk_sivi", 2, height=2)
        self._text(sc, "Ciddi yan etkiler", "blk_yan_etki", 4, height=2)
        self._text(sc, "Dikkat edilecekler", "blk_dikkat", 6, height=2)

        # === Bölüm 6: Özel Teknik / Dikkat Etiketi (D) ===
        sd = self._section(form, "🎯  Özel Teknik / Dikkat Etiketi (D)")
        self._text(sd, "Teknik kullanım (inhaler/sprey vb.)", "blk_teknik", 0, height=3)
        self._text(sd, "Hatırlatma", "blk_hatirlatma", 2, height=2)

        # === Bölüm 7: Genel Bilgi (etikete basılmayan KT içeriği) ===
        sg = self._section(form, "📖  Genel Bilgi")
        self._text(sg, "Endikasyon (ne için)", "blk_endikasyon", 0, height=2)
        self._text(sg, "Tedaviyi sonlandırma", "blk_sonlandirma", 2, height=2)

        # === Bölüm 8: Sistem / İstatistik ===
        ss = self._section(form, "📊  Sistem / İstatistik")
        self._entry(ss, "Satış (çıkış)", "sales_count", 0, 0, small=True)
        self._entry(ss, "Stok", "stock", 0, 2, small=True)
        self._entry(ss, "Sıra (rank)", "rank", 1, 0, small=True)

        # canlı önizleme tetikleyicileri
        for var in self.f.values():
            var.trace_add("write", lambda *a: self._schedule_preview())

    def _open_review(self):
        """Etiket Kontrol modülünü açar (muadil-deduplike, en çok kullanılandan)."""
        LabelReviewWindow(self)

    def _section(self, parent, title):
        C = COLORS
        outer = tk.LabelFrame(parent, text=title, background=C["bg_panel"],
                              foreground=C["text_yellow"], font=("Segoe UI", 10, "bold"),
                              labelanchor="nw", bd=1, relief="groove", padx=8, pady=6)
        outer.pack(fill="x", padx=6, pady=5)
        outer.columnconfigure(1, weight=1)
        outer.columnconfigure(3, weight=1)
        return outer

    def _lbl(self, parent, text, r, c):
        tk.Label(parent, text=text + ":", background=COLORS["bg_panel"],
                 foreground=COLORS["text_light"], anchor="e", font=("Segoe UI", 9)
                 ).grid(row=r, column=c, sticky="e", padx=(4, 4), pady=2)

    def _entry(self, parent, label, key, r, c, *, wide=False, small=False):
        self._lbl(parent, label, r, c)
        w = 8 if small else (40 if wide else 18)
        e = ttk.Entry(parent, textvariable=self.f[key], width=w)
        span = 3 if wide else 1
        e.grid(row=r, column=c + 1, columnspan=span, sticky="we", padx=(0, 8), pady=2)

    def _combo(self, parent, label, key, values, r, c):
        self._lbl(parent, label, r, c)
        cb = ttk.Combobox(parent, textvariable=self.f[key], values=values, width=16)
        cb.grid(row=r, column=c + 1, sticky="we", padx=(0, 8), pady=2)
        cb.bind("<<ComboboxSelected>>", lambda e: self._schedule_preview())

    def _text(self, parent, label, key, r, *, height=2, hint=""):
        # Etiket + metin kutusunu TEK grid satırına oturan bir alt-frame'e koy
        # (aksi halde grid satır numaraları karışıyordu).
        holder = tk.Frame(parent, background=COLORS["bg_panel"])
        holder.grid(row=r, column=0, columnspan=4, sticky="we", padx=2, pady=(4, 2))
        cap = label + (f"   {hint}" if hint else "")
        tk.Label(holder, text=cap, background=COLORS["bg_panel"],
                 foreground=COLORS["text_light"], anchor="w", font=("Segoe UI", 9)
                 ).pack(fill="x")
        t = tk.Text(holder, height=height, wrap="word", font=("Segoe UI", 10))
        t.pack(fill="x")
        self.txt[key] = t
        t.bind("<KeyRelease>", lambda e: self._schedule_preview())

    # ==================================================================
    # Liste / arama
    # ==================================================================
    def _on_search(self):
        self._refresh_list()

    def _refresh_list(self):
        self._results = drug_admin.search_drugs(self.var_search.get(), limit=300)
        self.lst.delete(0, "end")
        for r in self._results:
            bc = r["barcode"] or "—"
            self.lst.insert("end", f"{bc:14} {r['name']}")

    def _on_list_select(self, event=None):
        sel = self.lst.curselection()
        if not sel:
            return
        row = self._results[sel[0]]
        self._load(row["id"])

    # ==================================================================
    # Yükle / yeni / kaydet / sil
    # ==================================================================
    def _new(self):
        self.drug_id = None
        for v in self.f.values():
            v.set("")
        for t in self.txt.values():
            t.delete("1.0", "end")
        self.lbl_title.config(text="➕ Yeni İlaç")
        self._refresh_preview()

    def _load(self, drug_id: int):
        d = drug_admin.get_drug(drug_id)
        if not d:
            return
        self.drug_id = drug_id
        for key in self.f:
            val = d.get(key)
            self.f[key].set("" if val is None else str(val))
        # Kullanım reçetesi JSON (talimat/uyarı — yapısal kolonlarda yok)
        uj = drug_admin.get_usage_json(drug_id)
        self.txt["kullanim_talimati"].delete("1.0", "end")
        self.txt["kullanim_talimati"].insert("1.0", uj.get("kullanim_talimati", "") or "")
        self.txt["uyari_metni"].delete("1.0", "end")
        self.txt["uyari_metni"].insert("1.0", uj.get("uyari_metni", "") or "")
        if uj.get("kategori") and not self.f["indication_short"].get():
            self.f["indication_short"].set(uj["kategori"])
        # Bloklar
        blocks = drug_admin.get_blocks_effective(drug_id)
        for bt in drug_admin.BLOCK_TYPES:
            t = self.txt[f"blk_{bt}"]
            t.delete("1.0", "end")
            t.insert("1.0", blocks.get(bt, "") or "")
        self.lbl_title.config(text=f"✏ {d.get('name') or '(adsız)'}")
        self._refresh_preview()

    def _to_int(self, key):
        s = (self.f[key].get() or "").strip()
        if not s:
            return None
        try:
            return int(float(s.replace(",", ".")))
        except Exception:
            return None

    def _collect(self):
        drug_fields = {}
        for key in self.f:
            drug_fields[key] = (self.f[key].get() or "").strip() or None
        # sayısal (INTEGER) alanlar
        for key in drug_admin.INT_COLS:
            drug_fields[key] = self._to_int(key)
        talimat = self.txt["kullanim_talimati"].get("1.0", "end").strip()
        uyari = self.txt["uyari_metni"].get("1.0", "end").strip()
        usage_json = {
            "kategori": drug_fields.get("indication_short") or "",
            "kullanim_talimati": talimat,
            "uyari_metni": uyari,
            "sure_gun": drug_fields.get("treatment_days"),
            "yemek": drug_fields.get("meal_relation") or "",
        }
        blocks = {bt: self.txt[f"blk_{bt}"].get("1.0", "end").strip()
                  for bt in drug_admin.BLOCK_TYPES}
        return drug_fields, usage_json, blocks

    def _save(self):
        drug_fields, usage_json, blocks = self._collect()
        if not (drug_fields.get("name") or "").strip():
            messagebox.showwarning("Eksik", "İlaç adı zorunludur.")
            return
        if not (drug_fields.get("barcode") or "").strip() and self.drug_id is None:
            if not messagebox.askyesno(
                    "Barkod yok", "Barkod boş. Barkodsuz kaydetmek istiyor musunuz?"):
                return
        try:
            did = drug_admin.save_drug_all(
                drug_id=self.drug_id, drug_fields=drug_fields,
                usage_json=usage_json, blocks=blocks)
        except Exception as e:
            log.exception("İlaç kaydı hatası")
            messagebox.showerror("Hata", f"Kaydedilemedi:\n{e}")
            return
        self.drug_id = did
        self.lbl_title.config(text=f"✏ {drug_fields.get('name')}")
        self._refresh_list()
        try:
            self.app.status.set(f"💾 Kaydedildi: {drug_fields.get('name')} (id={did})")
        except Exception:
            pass
        self._refresh_preview()

    def _delete(self):
        if self.drug_id is None:
            messagebox.showinfo("Sil", "Önce listeden bir ilaç seçin.")
            return
        name = self.f["name"].get()
        if not messagebox.askyesno(
                "Onay", f"'{name}' kaydı ve tüm etiket verileri silinsin mi?\n"
                        "Bu işlem geri alınamaz."):
            return
        try:
            drug_admin.delete_drug(self.drug_id)
        except Exception as e:
            messagebox.showerror("Hata", f"Silinemedi:\n{e}")
            return
        try:
            self.app.status.set(f"🗑 Silindi: {name}")
        except Exception:
            pass
        self._new()
        self._refresh_list()

    # ==================================================================
    # Önizleme (kullanım etiketi A)
    # ==================================================================
    def _schedule_preview(self, *_):
        if self._preview_after:
            try:
                self.after_cancel(self._preview_after)
            except Exception:
                pass
        self._preview_after = self.after(220, self._refresh_preview)

    def _usage_label(self) -> UsageLabel:
        g = lambda k: (self.f[k].get() or "").strip()
        adet = g("default_dose")
        birim = g("dose_unit")
        doz = (f"{adet} {birim}".strip()) if (adet or birim) else ""
        kez = self._to_int("daily_freq")
        talimat = self.txt["kullanim_talimati"].get("1.0", "end").strip()
        if not talimat:
            talimat = build_kullanim_talimati(
                drug_name=g("name") or "İLAÇ", gunluk_kez=kez, doz_str=doz)
        return UsageLabel(
            kategori=g("indication_short"),
            kullanim_talimati=talimat,
            uyari_metni=self.txt["uyari_metni"].get("1.0", "end").strip(),
            ilac_turu=guess_form(g("name") or ""),
            doz=doz, gunluk_kez=kez, sure_gun=self._to_int("treatment_days"),
            yemek=g("meal_relation"),
        )

    def _refresh_preview(self):
        self._preview_after = None
        name = (self.f["name"].get() or "").strip()
        if not name:
            self._cur_pil = None
            self.prev_img.configure(image="", text="İlaç adı girin / soldan seçin",
                                    foreground=COLORS["text_muted"],
                                    font=("Segoe UI", 11, "bold"))
            return
        try:
            today = datetime.date.today()
            img = render_usage_label(
                hasta_adi="HASTA ADI", ilac_adi=name, label=self._usage_label(),
                recete_tarihi=today, bitis_tarihi=today + datetime.timedelta(days=7),
                eczane_adi=getattr(self.app, "eczane_adi", "ECZANE"),
                eczane_telefon=getattr(self.app, "eczane_tel", ""),
            )
            self._cur_pil = img.convert("RGB")
            self._fit_preview()
        except Exception:
            log.exception("Veri editörü önizleme hatası")

    def _on_prev_resize(self, event=None):
        if self._fit_after:
            try:
                self.after_cancel(self._fit_after)
            except Exception:
                pass
        self._fit_after = self.after(60, self._fit_preview)

    def _fit_preview(self):
        self._fit_after = None
        pil = self._cur_pil
        if pil is None:
            return
        try:
            W = self.prev_holder.winfo_width() or 420
            H = self.prev_holder.winfo_height() or 300
            w = max(120, W - 6)
            h = int(w / (480 / 320))
            if h > H - 6:
                h = max(80, H - 6)
                w = int(h * (480 / 320))
            photo = ImageTk.PhotoImage(pil.resize((w, h), Image.LANCZOS))
            self.prev_img.configure(image=photo, text="")
            self._preview_photo = photo
        except Exception:
            log.exception("Önizleme ölçekleme hatası")

    def _preview_all(self):
        """Kaydedilmiş ilacın A/B/C/D etiketlerini build_labels_for_drug ile gösterir."""
        if self.drug_id is None:
            messagebox.showinfo("Önizleme", "Önce kaydedin; tüm etiketler kayıttan üretilir.")
            return
        try:
            from ..label_from_db import build_labels_for_drug
            imgs = build_labels_for_drug(self.drug_id, "HASTA ADI", datetime.date.today())
        except Exception as e:
            log.exception("Tüm etiket önizleme hatası")
            messagebox.showerror("Hata", f"Önizleme üretilemedi:\n{e}")
            return
        if not imgs:
            messagebox.showinfo("Önizleme", "Bu ilaç için üretilen etiket yok.")
            return
        win = tk.Toplevel(self)
        win.title(f"Tüm Etiketler — {self.f['name'].get()}")
        win.configure(background=COLORS["bg_main"])
        win.transient(self.winfo_toplevel())
        row = tk.Frame(win, background=COLORS["bg_main"])
        row.pack(padx=10, pady=10)
        self._all_photos = []
        for i, im in enumerate(imgs):
            cell = tk.Frame(row, background="#FFE680", highlightthickness=1,
                            highlightbackground="black")
            cell.grid(row=0, column=i, padx=6)
            ph = ImageTk.PhotoImage(im.convert("RGB").resize((360, 240), Image.LANCZOS))
            self._all_photos.append(ph)
            tk.Label(cell, image=ph, background="#FFE680").pack()


class LabelReviewWindow(tk.Toplevel):
    """Etiket KONTROL modülü.

    Muadiller (aynı ATC + form) tek temsilciye indirgenir; etiketler EN ÇOK
    KULLANILANDAN aşağı doğru tek tek gösterilir. Bir temsilci gösterilince
    grubundaki muadilleri de "gösterilmiş" sayılır. Tüm etiketler tek tip
    SABAH-ÖĞLE-AKŞAM olarak çizilir. 'Bu ilacı düzenle' kaydı düzenleyiciye yükler.
    """

    def __init__(self, owner: "DataAdminTab"):
        super().__init__(owner)
        self.owner = owner
        self.title("🔍 Etiket Kontrol — muadiller tek, en çok kullanılandan")
        self.configure(background=COLORS["bg_main"])
        self.geometry("1120x600")
        self._conn = get_connection()
        self._conn.row_factory = self._conn.row_factory  # mevcut
        init_schema(self._conn)   # label_review_status tablosu kesin var olsun
        self._list = build_review_list(self._conn)
        self._reviewed = get_reviewed_ids(self._conn)   # {rep_id} kontrol edilmiş
        self._idx = 0
        self._cur_rid = None      # o an gösterilen grup temsilcisi (görünüm değişince konumu koru)
        self._photo = None
        self._freq = 3            # kontrol dozu (günde kaç kez): 1/2/3/4
        self._hide_var = tk.BooleanVar(value=False)   # kontrol edilenleri gizle
        self._build_ui()
        self._show()
        self.bind("<Right>", lambda e: self._nav(1))
        self.bind("<Left>", lambda e: self._nav(-1))
        self.bind("<Return>", lambda e: self._mark(True))    # Enter = kontrol edildi
        self.bind("<space>", lambda e: self._mark(False))    # Boşluk = edilmedi, atla
        self.bind("<Escape>", lambda e: self._close())
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.transient(owner)

    def _build_ui(self):
        C = COLORS
        top = tk.Frame(self, background=C["bg_strip"])
        top.pack(fill="x")
        self.lbl_progress = tk.Label(top, background=C["bg_strip"],
                                     foreground=C["text_yellow"],
                                     font=("Segoe UI", 12, "bold"))
        self.lbl_progress.pack(side="left", padx=10, pady=6)
        self.lbl_info = tk.Label(top, background=C["bg_strip"],
                                 foreground=C["text_light"], font=("Segoe UI", 9),
                                 anchor="w", justify="left")
        self.lbl_info.pack(side="left", padx=10)

        # Doz seçici: etiketi 1×1 / 2×1 / 3×1 / 4×1 dozda göster.
        ctrl = tk.Frame(self, background=C["bg_main"])
        ctrl.pack(fill="x", padx=10, pady=(6, 0))
        tk.Label(ctrl, text="Günlük doz:", background=C["bg_main"],
                 foreground=C["text_yellow"], font=("Segoe UI", 9, "bold")
                 ).pack(side="left", padx=(0, 6))
        self._freq_var = tk.IntVar(value=self._freq)
        for n, lbl in [(1, "1×1"), (2, "2×1"), (3, "3×1"), (4, "4×1")]:
            tk.Radiobutton(
                ctrl, text=lbl, value=n, variable=self._freq_var,
                command=self._set_freq, background=C["bg_main"],
                foreground=C["text_light"], selectcolor=C["bg_strip"],
                activebackground=C["bg_main"], activeforeground=C["text_light"],
                font=("Segoe UI", 10, "bold"),
            ).pack(side="left", padx=2)

        # "Kontrol edilenleri getirme": işaretliyse yalnız KONTROL EDİLMEMİŞ
        # ilaçlar, en yüksek satıştan başlayarak gösterilir.
        tk.Checkbutton(
            ctrl, text="Kontrol edilenleri getirme", variable=self._hide_var,
            command=self._on_toggle_hide, background=C["bg_main"],
            foreground=C["text_yellow"], selectcolor=C["bg_strip"],
            activebackground=C["bg_main"], activeforeground=C["text_yellow"],
            font=("Segoe UI", 9, "bold"),
        ).pack(side="right", padx=(0, 4))

        # Etiket alanı: A/B/C/D etiketleri yan yana (yatay kaydırmalı).
        mid = tk.Frame(self, background=C["bg_panel"])
        mid.pack(fill="both", expand=True, padx=10, pady=10)
        self._img_canvas = tk.Canvas(mid, background=C["bg_panel"],
                                     highlightthickness=0)
        xsb = ttk.Scrollbar(mid, orient="horizontal",
                            command=self._img_canvas.xview)
        self._img_canvas.configure(xscrollcommand=xsb.set)
        xsb.pack(side="bottom", fill="x")
        self._img_canvas.pack(side="top", fill="both", expand=True)
        self._img_row = tk.Frame(self._img_canvas, background=C["bg_panel"])
        self._img_canvas.create_window((0, 0), window=self._img_row, anchor="nw")
        self._img_row.bind(
            "<Configure>",
            lambda e: self._img_canvas.configure(
                scrollregion=self._img_canvas.bbox("all")))
        self._photos = []   # PhotoImage referansları (GC engelle)

        bot = tk.Frame(self, background=C["bg_main"])
        bot.pack(fill="x", pady=8)
        ttk.Button(bot, text="◀ Önceki", command=lambda: self._nav(-1)
                   ).pack(side="left", padx=8)
        # KONTROL kararı: "Kontrol Edildi" işaretler ve ilerler; "Kontrol Edilmedi"
        # işaretlemeden ilerler. (Enter = edildi, Boşluk = edilmedi.)
        ttk.Button(bot, text="✓ Kontrol Edildi  (Enter)", style="Accent.TButton",
                   command=lambda: self._mark(True)).pack(side="left", padx=(16, 4))
        ttk.Button(bot, text="Kontrol Edilmedi →  (Boşluk)",
                   command=lambda: self._mark(False)).pack(side="left", padx=4)
        ttk.Button(bot, text="✎ Bu ilacı düzenle", style="Yellow.TButton",
                   command=self._edit).pack(side="left", padx=20)
        ttk.Button(bot, text="📋 Liste (edilen/edilmeyen)",
                   command=self._open_list).pack(side="left", padx=4)
        ttk.Button(bot, text="⟲ Kontrol Edilenleri Sıfırla",
                   command=self._reset_reviews).pack(side="left", padx=4)
        self.lbl_status = tk.Label(bot, background=C["bg_main"],
                                   foreground=C["text_muted"],
                                   font=("Segoe UI", 9, "bold"))
        self.lbl_status.pack(side="left", padx=10)
        ttk.Button(bot, text="Kapat", command=self._close).pack(side="right", padx=8)

    def _active(self):
        """O an gezilecek liste: 'kontrol edilenleri getirme' işaretliyse yalnız
        kontrol EDİLMEMİŞ gruplar (zaten en yüksek satıştan sıralı), aksi tümü."""
        if self._hide_var.get():
            return [g for g in self._list if g["rep_id"] not in self._reviewed]
        return self._list

    def _show(self):
        lst = self._active()
        if not lst:
            for w in self._img_row.winfo_children():
                w.destroy()
            self._photos = []
            if not self._list:
                self.lbl_progress.config(text="(liste boş)")
            else:
                self.lbl_progress.config(text="✓ Tüm ilaçlar kontrol edildi",
                                         foreground=COLORS["accent_green"])
                self.lbl_info.config(text="(Kontrol edilmemiş ilaç kalmadı.)")
                tk.Label(self._img_row, text="🎉 Kontrol edilecek ilaç kalmadı.",
                         background=COLORS["bg_panel"], foreground=COLORS["text_muted"],
                         font=("Segoe UI", 12, "bold")).pack(padx=20, pady=20)
            self._cur_rid = None
            self._update_status()
            return
        self._idx = max(0, min(self._idx, len(lst) - 1))
        g = lst[self._idx]
        self._cur_rid = g["rep_id"]
        is_rev = g["rep_id"] in self._reviewed
        check = "  ✓ KONTROL EDİLDİ" if is_rev else ""
        self.lbl_progress.config(
            text=f"{self._idx + 1} / {len(lst)}{check}",
            foreground=COLORS["accent_green"] if is_rev else COLORS["text_yellow"],
        )
        muadil = (f"· grupta {g['count']} muadil" if g["count"] > 1 else "· tekil")
        _br = g.get("best_rank", 10 ** 9)
        sira = f"satış sırası #{_br}" if _br < 10 ** 9 else "satış sırası yok"
        self.lbl_info.config(
            text=f"{g['rep_name']}\n[{g['atc'] or '—'} · {g['form'] or '—'}]  "
                 f"{sira}  {muadil}")
        self._update_status()
        # Önceki etiket kartlarını temizle
        for w in self._img_row.winfo_children():
            w.destroy()
        self._photos = []
        C = COLORS
        try:
            labels = render_review_labels(
                self._conn, g["rep_id"],
                eczane_adi=getattr(self.owner.app, "eczane_adi", ""),
                eczane_telefon=getattr(self.owner.app, "eczane_tel", ""),
                gunluk_kez=self._freq,
            )
        except Exception as e:
            labels = []
            tk.Label(self._img_row, text=f"(hata: {e})", background=C["bg_panel"],
                     foreground="#f88").pack()
        for title, img in labels:
            cell = tk.Frame(self._img_row, background=C["bg_panel"])
            cell.pack(side="left", padx=8, pady=4, anchor="n")
            tk.Label(cell, text=title, background=C["bg_panel"],
                     foreground=C["text_yellow"], font=("Segoe UI", 9, "bold")
                     ).pack(anchor="w")
            ph = ImageTk.PhotoImage(img.resize((480, 320), Image.LANCZOS))
            self._photos.append(ph)
            tk.Label(cell, image=ph, background="#FFE680",
                     highlightthickness=1, highlightbackground="black").pack()
        if not labels:
            tk.Label(self._img_row, text="(etiket üretilemedi)",
                     background=C["bg_panel"], foreground=C["text_muted"]).pack()
        self._img_canvas.xview_moveto(0)

    def _nav(self, delta: int):
        lst = self._active()
        if lst:
            self._idx = max(0, min(self._idx + delta, len(lst) - 1))
        self._show()

    def _on_toggle_hide(self):
        """'Kontrol edilenleri getirme' aç/kapa: aktif listeyi yenile, mümkünse
        o an görünen ilacın konumunu koru (gizlenmişse aynı sıradakine yaklaş)."""
        lst = self._active()
        new_idx = 0
        if self._cur_rid is not None:
            for i, g in enumerate(lst):
                if g["rep_id"] == self._cur_rid:
                    new_idx = i
                    break
            else:
                new_idx = min(self._idx, len(lst) - 1) if lst else 0
        self._idx = new_idx
        self._show()

    def _reset_reviews(self):
        """Tüm 'kontrol edildi' işaretlerini siler; her kayıt yeniden
        kontrol edilmemiş duruma döner. Onay ister (geri alınamaz)."""
        done = len(self._reviewed)
        if not done:
            messagebox.showinfo(
                "Sıfırla", "Kontrol edilmiş kayıt yok.", parent=self)
            return
        if not messagebox.askyesno(
            "Kontrol Edilenleri Sıfırla",
            f"{done} ilacın 'kontrol edildi' işareti silinecek ve tümü\n"
            "kontrol edilmemiş duruma dönecek.\n\n"
            "Bu işlem geri alınamaz. Devam edilsin mi?",
            icon="warning", parent=self,
        ):
            return
        reset_review_status(self._conn)
        self._reviewed = set()
        self._idx = 0
        self._show()

    def _update_status(self):
        """Alt durum etiketi: toplam / kontrol edilen / kalan sayısı."""
        if not getattr(self, "lbl_status", None) or not self._list:
            return
        total = len(self._list)
        done = sum(1 for g in self._list if g["rep_id"] in self._reviewed)
        self.lbl_status.config(
            text=f"Kontrol edilen: {done} / {total}  ·  kalan: {total - done}")

    def _open_list(self):
        """Kontrol edilen/edilmeyen ilaçların listesini ayrı pencerede gösterir.
        Filtre (Tümü / Edilenler / Edilmeyenler) + çift tık ile o kayda atlama."""
        if not self._list:
            return
        C = COLORS
        win = tk.Toplevel(self)
        win.title("📋 Etiket Kontrol Listesi — edilen / edilmeyen")
        win.configure(background=C["bg_main"])
        win.geometry("760x560")
        win.transient(self)

        top = tk.Frame(win, background=C["bg_strip"])
        top.pack(fill="x")
        flt = tk.StringVar(value="all")
        lbl_count = tk.Label(top, background=C["bg_strip"], foreground=C["text_yellow"],
                             font=("Segoe UI", 10, "bold"))
        lbl_count.pack(side="right", padx=10, pady=6)
        for val, txt in [("all", "Tümü"), ("done", "✓ Kontrol Edilenler"),
                         ("todo", "Edilmeyenler")]:
            tk.Radiobutton(
                top, text=txt, value=val, variable=flt, command=lambda: _fill(),
                background=C["bg_strip"], foreground=C["text_light"],
                selectcolor=C["bg_main"], activebackground=C["bg_strip"],
                activeforeground=C["text_light"], font=("Segoe UI", 9, "bold"),
            ).pack(side="left", padx=6, pady=6)

        cols = ("durum", "ad", "atcform", "sira")
        tree = ttk.Treeview(win, columns=cols, show="headings", selectmode="browse")
        tree.heading("durum", text="Durum")
        tree.heading("ad", text="İlaç (grup temsilcisi)")
        tree.heading("atcform", text="ATC · Form")
        tree.heading("sira", text="Satış #")
        tree.column("durum", width=70, anchor="center")
        tree.column("ad", width=400, anchor="w")
        tree.column("atcform", width=160, anchor="w")
        tree.column("sira", width=80, anchor="center")
        ysb = ttk.Scrollbar(win, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ysb.set)
        ysb.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        tree.tag_configure("done", foreground=C["accent_green"])
        tree.tag_configure("todo", foreground=C["text_light"])

        # iid → global index eşlemesi (çift tık ile atlama için)
        idx_by_iid: dict = {}

        def _fill():
            tree.delete(*tree.get_children())
            idx_by_iid.clear()
            mode = flt.get()
            done = todo = 0
            for i, g in enumerate(self._list):
                is_rev = g["rep_id"] in self._reviewed
                if is_rev:
                    done += 1
                else:
                    todo += 1
                if mode == "done" and not is_rev:
                    continue
                if mode == "todo" and is_rev:
                    continue
                _br = g.get("best_rank", 10 ** 9)
                sira = f"#{_br}" if _br < 10 ** 9 else "—"
                iid = tree.insert(
                    "", "end",
                    values=("✓" if is_rev else "—", g["rep_name"],
                            f"{g['atc'] or '—'} · {g['form'] or '—'}", sira),
                    tags=("done" if is_rev else "todo",))
                idx_by_iid[iid] = i
            lbl_count.config(text=f"Kontrol edilen: {done} · edilmeyen: {todo} "
                                  f"· toplam: {len(self._list)}")

        def _jump(_evt=None):
            sel = tree.selection()
            if not sel:
                return
            i = idx_by_iid.get(sel[0])
            if i is not None:
                rid = self._list[i]["rep_id"]
                # Aktif (gizleme filtreli olabilir) listede konumu bul; kayıt
                # gizlenmişse (kontrol edilmiş + filtre açık) filtreyi kapat.
                lst = self._active()
                pos = next((k for k, g in enumerate(lst) if g["rep_id"] == rid), None)
                if pos is None:
                    self._hide_var.set(False)
                    lst = self._active()
                    pos = next((k for k, g in enumerate(lst) if g["rep_id"] == rid), 0)
                self._idx = pos
                self._show()
                win.destroy()

        tree.bind("<Double-1>", _jump)
        bot = tk.Frame(win, background=C["bg_main"])
        bot.pack(side="bottom", fill="x")
        tk.Label(bot, text="(bir kayda çift tıkla → o etikete git)",
                 background=C["bg_main"], foreground=C["text_muted"],
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=8, pady=6)
        ttk.Button(bot, text="Git", command=_jump).pack(side="right", padx=4, pady=6)
        ttk.Button(bot, text="Kapat", command=win.destroy).pack(side="right", padx=8, pady=6)
        _fill()

    def _mark(self, reviewed: bool):
        """'Kontrol Edildi' (reviewed=True) → işaretle ve sonrakine geç.
        'Kontrol Edilmedi' (reviewed=False) → işaretlemeden sonrakine geç."""
        lst = self._active()
        if not lst:
            return
        idx = max(0, min(self._idx, len(lst) - 1))
        hide = self._hide_var.get()
        if reviewed:
            rid = lst[idx]["rep_id"]
            try:
                set_review_status(self._conn, rid, True)
                self._reviewed.add(rid)
            except Exception:
                pass
            if hide:
                # İşaretlenen kayıt aktif listeden DÜŞER; aynı _idx artık bir
                # sonraki kontrol edilmemiş ilacı gösterir (ileri ilerletme).
                self._show()
                return
        # Diğer durumlarda bir sonrakine geç (sondaysa yerinde kal).
        if idx < len(lst) - 1:
            self._idx = idx + 1
        self._show()

    def _set_freq(self):
        self._freq = self._freq_var.get()
        self._show()

    def _edit(self):
        if not self._list:
            return
        g = self._list[self._idx]
        try:
            self.owner._load(g["rep_id"])
            app = self.owner.app
            if hasattr(app, "notebook") and hasattr(app, "tab_data"):
                app.notebook.select(app.tab_data)
        except Exception:
            pass
        self._close()

    def _close(self):
        try:
            self._conn.close()
        except Exception:
            pass
        self.destroy()
