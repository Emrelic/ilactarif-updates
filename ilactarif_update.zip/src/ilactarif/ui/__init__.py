"""İlaçTarif UI paketi."""
