"""Manuel etiket girişi + otomatik Medula yakalama GUI (Tkinter).

İki sekme:
  • Manuel — barkod/karekod/isim ile elle etiket girişi
  • Otomatik (Medula) — arka plan watcher yakaladığı reçeteleri burada
    sıra ile gösterir; etiketler aynı pencerede görünür, yazıcıya gönderilir.
"""
from __future__ import annotations

import datetime
import json
import logging
import os
import re
import sys
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import font as tkfont
from tkinter import messagebox, ttk
from typing import Optional

from PIL import Image, ImageTk

from ..auto_label_builder import (
    BuiltRecete,
    LabelItem,
    build_labels_for_capture,
    build_patient_label,
)
from ..bulk_recipes import (
    DEFAULT_DOZ,
    DEFAULT_GENERAL_UYARI,
    DEFAULT_SURE_GUN,
    DEFAULT_UYARI,
    build_recipe,
)
from ..db import get_connection, init_schema, save_setting, sync_botanik_katalog
from ..drug_guess import (
    build_kullanim_talimati,
    detect_talimat_zaman,
    guess_form,
    guess_kategori,
    guess_unit,
    set_talimat_zaman,
)
from ..label_from_db import (
    get_label_edit_state,
    get_label_print_override,
    render_label_preview,
    save_label_text_and_render,
    set_label_print_override,
)
from ..label_render import render_usage_label
from ..botanik_capture import BotanikNotFound, read_sale_pages
from ..medula_capture import (
    click_erecete_sorgu_button,
    click_giris_button,
    click_sonraki_button,
    close_old_medula_windows,
    keep_alive_enter,
    keep_alive_refresh,
)
from ..medula_overlay import MedulaThemeOverlay
from ..medula_parser import CapturedDrug, PrescriptionCapture
from ..medula_watcher import MedulaWatcher
from ..models import UsageLabel
from ..paper_recete import (
    PaperReceteForm,
    diff_forms,
    parse_paper_form,
    paper_to_capture,
)
from ..staged_recete import (
    DiffRow,
    compare_captures,
    compare_paper_forms,
)


# ---------------------------------------------------------------------------
# Bir reçetenin iki aşamasını birlikte tutan kayıt
# ---------------------------------------------------------------------------
class ReceteSet:
    """
    Erken (reçete başı) ve final (reçete sonu) etiket setlerini bir arada
    tutan basit konteyner. chosen_stage = etiket panelinde gösterilen sürüm.
    """
    def __init__(self, key: str, source_kind: str):
        self.key: str = key
        self.source_kind: str = source_kind
        self.early: Optional[BuiltRecete] = None
        self.final: Optional[BuiltRecete] = None
        self.diff_rows: list[DiffRow] = []
        # Her ilaç için sürüm seçimi (barkod → "early" | "final" | "skip")
        # Varsayılan: hepsi "final" (eğer final varsa)
        self.chosen_per_drug: dict[str, str] = {}
        # Her ilaç için ETİKET-BAZI baskı seçimi: barkod → {kind('A'/'B'/'C'/'D') → bool}.
        # Kullanıcının kart üstündeki etiket baskı kutuları buraya yazar; baskı yolu
        # (labels_to_print sonrası) yalnız True olan etiketleri gönderir. Boşsa
        # her etiket varsayılanından (label_default_print + kalıcı tercih) hesaplanır.
        self.print_kinds: dict[str, dict[str, bool]] = {}
        # Hasta bilgi etiketi baskı tercihi: None → ayardaki varsayılan, True/False
        # → kullanıcı bu sette kutuyu elle değiştirdi. Set başlığındaki "Hasta
        # Etiketi" kutusu buraya yazar; _print_set bunu okur.
        self.print_hasta: Optional[bool] = None
        # Hasta etiketinde 'TOPLAM BORÇ' satırını bu set için tek seferlik gizle
        # (kart üstündeki ✕ basılınca True olur). Genel ayar zaten kapalıysa etkisiz.
        self.hide_debt: bool = False
        # Reçeteden ÇIKARILAN (early'de var, final'da yok) ilaçların barkodları:
        # ilk görülüşte bir kez baskı anahtarı ATLA'ya çekilir; sonraki render'larda
        # kullanıcının elle değiştirdiği seçim korunsun diye tekrar zorlanmaz.
        self._removed_auto_skipped: set[str] = set()
        # Stok eksiye düştüğü için (elde yok) ilk görülüşte bir kez baskı anahtarı
        # ATLA'ya çekilen ilaçların barkodları; kullanıcının sonraki seçimi korunur.
        self._stock_auto_skipped: set[str] = set()
        # İTS Karekod İşlemleri ekranında OKUTULAN karekod sayımı: barkod → adet
        # (kaç kutu okutuldu). Okutma baskı anahtarını DEĞİŞTİRMEZ; "Sadece okutulan
        # karekodları bas" kısayolu yalnız sayısı ≥1 olan ilaçların etiketini basar.
        self._karekod_counts: dict[str, int] = {}

        # Capture referansları
        self.cap_early: Optional[PrescriptionCapture] = None
        self.cap_final: Optional[PrescriptionCapture] = None
        self.paper_early: Optional[PaperReceteForm] = None
        self.paper_final: Optional[PaperReceteForm] = None

    @property
    def status_label(self) -> str:
        if self.early and self.final:
            return "Reçete Başı + Sonu"
        if self.final:
            return "Reçete Sonu"
        if self.early:
            return "Reçete Başı (taslak)"
        return "—"

    @property
    def display_built(self) -> Optional[BuiltRecete]:
        """Etiket altyapısı geri uyumluluğu için: ilk dolu olanı dön."""
        return self.final or self.early

    # ---- Yazdırma için: her ilaç için seçilen LabelItem'ı topla ------
    def labels_to_print(self) -> list[LabelItem]:
        out: list[LabelItem] = []
        seen_barcodes = set()

        early_map: dict[str, LabelItem] = {}
        final_map: dict[str, LabelItem] = {}
        if self.early:
            for it in self.early.items:
                early_map[it.barkod] = it
        if self.final:
            for it in self.final.items:
                final_map[it.barkod] = it

        all_barcodes = list(early_map.keys()) + [b for b in final_map if b not in early_map]
        for bk in all_barcodes:
            choice = self.chosen_per_drug.get(bk, "final")
            if choice == "skip":
                continue
            it = None
            if choice == "early":
                it = early_map.get(bk) or final_map.get(bk)
            else:  # final
                if self.final and bk not in final_map:
                    # Final mevcut ama ilaç final'da yok → SGK tarafından çıkarılmış;
                    # kullanıcı "early" seçmedikçe bu ilacı yazdırma.
                    continue
                it = final_map.get(bk) or early_map.get(bk)
            if it and bk not in seen_barcodes:
                out.append(it)
                seen_barcodes.add(bk)
        return out

    def default_chosen(self):
        """Yeni eklenmiş bir ilacın varsayılan seçimi."""
        all_bk = set()
        if self.early:
            all_bk.update(it.barkod for it in self.early.items)
        if self.final:
            all_bk.update(it.barkod for it in self.final.items)
        final_barcodes = {it.barkod for it in self.final.items} if self.final else set()
        for bk in all_bk:
            if bk not in self.chosen_per_drug:
                if self.final and bk in final_barcodes:
                    self.chosen_per_drug[bk] = "final"
                elif not self.final:
                    # Final henüz gelmedi → erken sürümü kullan
                    self.chosen_per_drug[bk] = "early"
                # Else: final var ama ilaç final'da yok (muadile çevrildi/SGK çıkardı)
                # → chosen_per_drug'a yazma; labels_to_print "final" default ile atlayacak

log = logging.getLogger("ilactarif.ui")


# ---------------------------------------------------------------------------
# Renk Paleti (referans ilaç tarif uygulamasından esinlenildi)
# ---------------------------------------------------------------------------
COLORS = {
    "bg_main":      "#1d2a4d",   # ana koyu lacivert (program zemini)
    "bg_panel":     "#22305a",   # iç paneller
    "bg_strip":     "#2a3a64",   # başlık şeritleri
    "bg_card":      "#f5c842",   # etiket kartı sarı zemini
    "bg_card_alt":  "#ffd966",   # açık sarı (vurgu)
    "bg_card_soft": "#fef3c7",   # çok açık sarı (placeholder)

    "text_light":   "#ffffff",
    "text_muted":   "#b8bdd4",
    "text_dark":    "#0f172a",
    "text_yellow":  "#fcd34d",

    "accent_green":  "#22c55e",
    "accent_red":    "#ef4444",
    "accent_orange": "#f97316",
    "accent_purple": "#a855f7",
    "accent_blue":   "#3b82f6",
}


def apply_app_theme(root: tk.Tk):
    """ttk.Style üzerinden tüm pencereye koyu tema uygula."""
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    C = COLORS

    root.configure(background=C["bg_main"])

    # ttk Frame
    style.configure("TFrame", background=C["bg_main"])
    style.configure("Panel.TFrame", background=C["bg_panel"])
    style.configure("Strip.TFrame", background=C["bg_strip"])
    style.configure("Yellow.TFrame", background=C["bg_card"])
    style.configure("Card.TFrame", background=C["bg_card"])

    # ttk Label
    style.configure("TLabel", background=C["bg_main"], foreground=C["text_light"])
    style.configure("Panel.TLabel", background=C["bg_panel"], foreground=C["text_light"])
    style.configure("Strip.TLabel", background=C["bg_strip"], foreground=C["text_light"])
    style.configure("Muted.TLabel", background=C["bg_main"], foreground=C["text_muted"])
    style.configure("PanelMuted.TLabel", background=C["bg_panel"], foreground=C["text_muted"])
    style.configure("Yellow.TLabel", background=C["bg_card"], foreground=C["text_dark"])
    style.configure("Title.TLabel", background=C["bg_strip"],
                    foreground=C["text_yellow"], font=("Segoe UI", 16, "bold"))
    style.configure("Subtitle.TLabel", background=C["bg_strip"],
                    foreground=C["text_muted"], font=("Segoe UI", 10))

    # LabelFrame (kullanılan yerler)
    style.configure("TLabelframe", background=C["bg_panel"],
                    foreground=C["text_light"], borderwidth=1, relief="flat")
    style.configure("TLabelframe.Label", background=C["bg_panel"],
                    foreground=C["text_yellow"], font=("Segoe UI", 9, "bold"))

    # Notebook
    style.configure("TNotebook", background=C["bg_main"], borderwidth=0)
    style.configure("TNotebook.Tab",
                    background=C["bg_panel"], foreground=C["text_muted"],
                    padding=(20, 7), font=("Segoe UI", 10, "bold"))
    style.map("TNotebook.Tab",
              background=[("selected", C["bg_card"])],
              foreground=[("selected", C["text_dark"])])

    # Button (varsayılan)
    style.configure("TButton",
                    background=C["bg_strip"], foreground=C["text_light"],
                    borderwidth=0, padding=(10, 6), font=("Segoe UI", 9))
    style.map("TButton",
              background=[("active", C["bg_panel"]), ("pressed", C["bg_main"])])

    # Accent button (yeşil / sarı / kırmızı)
    style.configure("Accent.TButton",
                    background=C["accent_green"], foreground="white",
                    borderwidth=0, padding=(12, 6), font=("Segoe UI", 9, "bold"))
    style.map("Accent.TButton",
              background=[("active", "#16a34a")])
    style.configure("Warn.TButton",
                    background=C["accent_orange"], foreground="white",
                    borderwidth=0, padding=(12, 6), font=("Segoe UI", 9, "bold"))
    style.configure("Yellow.TButton",
                    background=C["bg_card"], foreground=C["text_dark"],
                    borderwidth=0, padding=(12, 6), font=("Segoe UI", 9, "bold"))
    style.map("Yellow.TButton",
              background=[("active", C["bg_card_alt"])])

    # Renkli eylem butonları (ana sekme — Emanet · Botanik · Temizle)
    style.configure("Emanet.TButton",
                    background=C["accent_purple"], foreground="white",
                    borderwidth=0, padding=(12, 7), font=("Segoe UI", 9, "bold"))
    style.map("Emanet.TButton", background=[("active", "#9333ea")])
    style.configure("Botanik.TButton",
                    background=C["accent_blue"], foreground="white",
                    borderwidth=0, padding=(12, 7), font=("Segoe UI", 9, "bold"))
    style.map("Botanik.TButton", background=[("active", "#2563eb")])
    style.configure("Clear.TButton",
                    background=C["accent_red"], foreground="white",
                    borderwidth=0, padding=(12, 6), font=("Segoe UI", 9, "bold"))
    style.map("Clear.TButton", background=[("active", "#dc2626")])

    # Ayarlar butonu — daha görünür/görsel (turuncu, büyük, çerçeveli)
    style.configure("Settings.TButton",
                    background=C["accent_orange"], foreground="white",
                    borderwidth=0, padding=(18, 9), font=("Segoe UI", 11, "bold"))
    style.map("Settings.TButton", background=[("active", "#ea580c")])

    # Radiobutton
    style.configure("TRadiobutton",
                    background=C["bg_main"], foreground=C["text_light"])
    style.configure("Card.TRadiobutton",
                    background=C["bg_card"], foreground=C["text_dark"])
    style.configure("Panel.TRadiobutton",
                    background=C["bg_panel"], foreground=C["text_light"])
    style.configure("Strip.TRadiobutton",
                    background=C["bg_strip"], foreground=C["text_light"])
    style.map("Strip.TRadiobutton",
              background=[("active", C["bg_strip"])])
    style.configure("Strip.TCheckbutton",
                    background=C["bg_strip"], foreground=C["text_light"])
    style.map("Strip.TCheckbutton",
              background=[("active", C["bg_strip"])],
              foreground=[("active", C["text_yellow"])])
    style.map("Panel.TRadiobutton",
              background=[("active", C["bg_panel"])])
    style.map("TRadiobutton",
              background=[("active", C["bg_main"])])
    style.map("Card.TRadiobutton",
              background=[("active", C["bg_card_alt"])])

    # Treeview
    style.configure("Treeview",
                    background=C["bg_panel"], foreground=C["text_light"],
                    fieldbackground=C["bg_panel"], borderwidth=0,
                    rowheight=26, font=("Segoe UI", 9))
    style.configure("Treeview.Heading",
                    background=C["bg_strip"], foreground=C["text_yellow"],
                    relief="flat", font=("Segoe UI", 9, "bold"))
    style.map("Treeview",
              background=[("selected", C["bg_card"])],
              foreground=[("selected", C["text_dark"])])
    style.map("Treeview.Heading", background=[("active", C["bg_panel"])])

    # Scrollbar
    style.configure("Vertical.TScrollbar",
                    background=C["bg_strip"], troughcolor=C["bg_main"],
                    borderwidth=0, arrowcolor=C["text_light"])

    # Entry / Combobox
    style.configure("TEntry", fieldbackground="white", foreground=C["text_dark"],
                    bordercolor="#3a4a78", padding=(4, 3))
    # Combobox: clam temasında açılır-ok butonu varsayılan 3B/gri görünüp alanla
    # uyumsuz ("çarpık") duruyordu. Alanla AYNI düz beyaz zemin + koyu ok + düz
    # kenar ver; yükseklik Entry ile eşitlensin (padding aynı).
    style.configure("TCombobox",
                    fieldbackground="white", background="white",
                    foreground=C["text_dark"], arrowcolor=C["text_dark"],
                    bordercolor="#3a4a78", lightcolor="white", darkcolor="white",
                    padding=(4, 3))
    style.map("TCombobox",
              fieldbackground=[("readonly", "white"), ("disabled", "#e6e6e6")],
              background=[("readonly", "white"), ("active", "white"),
                          ("pressed", "white")],
              foreground=[("disabled", "#99a")],
              arrowcolor=[("disabled", "#aab")])
    # Açılır liste (popdown) renkleri — tk option veritabanı üzerinden
    try:
        root.option_add("*TCombobox*Listbox.background", "white")
        root.option_add("*TCombobox*Listbox.foreground", C["text_dark"])
        root.option_add("*TCombobox*Listbox.selectBackground", C["bg_card"])
        root.option_add("*TCombobox*Listbox.selectForeground", C["text_dark"])
        root.option_add("*TCombobox*Listbox.font", "{Segoe UI} 9")
    except Exception:
        pass

    # PanedWindow
    style.configure("TPanedwindow", background=C["bg_main"])

    return style

# ---------------------------------------------------------------------------
# Karekod parse: GS1 DataMatrix
# ---------------------------------------------------------------------------
# Türkiye İTS karekodu örnek: "010869983209005517240731101234212345678"
#   (01) GTIN-14 (14 hane)  → barkod
#   (17) Son kullanma YYMMDD (6 hane)
#   (10) Lot No (variable, GS ile sonlanır)
#   (21) Seri No (variable)
GS1_AI_RE = re.compile(r"01(\d{14})")


def parse_karekod(raw: str) -> Optional[str]:
    """Karekoddan barkodu (EAN-13) çıkar; düz barkodsa olduğu gibi döner.

    GS1: (01) AI sonrası 14 hane GTIN. EAN-13'ün başına 0 eklenmiş şekli.
    Sondaki 13 haneyi al → EAN-13.
    """
    s = (raw or "").strip()
    # FNC1 / GS karakteri ve parantezleri temizle
    s = s.replace("(", "").replace(")", "").replace("\x1d", "").replace("", "")

    # Düz barkod: 8 veya 13 hane
    if s.isdigit() and len(s) in (8, 13):
        return s

    # GTIN-14 (ilk hane 0 ise) — direkt barkod döner
    if s.isdigit() and len(s) == 14 and s.startswith("0"):
        return s[1:]

    # GS1: 01 ile başlayan 14 hane
    m = GS1_AI_RE.search(s)
    if m:
        gtin = m.group(1)
        # GTIN-14, ilk hane genelde 0 → kırp
        return gtin[1:] if gtin.startswith("0") else gtin

    # Bulunamadıysa ham veri
    return s if s.isdigit() and len(s) >= 8 else None


def _is_raw_karekod(barkod: str) -> bool:
    """Barkod alanı düz barkod değil, HAM karekod (GS1 DataMatrix) mı?

    Kağıt reçeteyi elle girerken barkod kutusuna karekod okutulursa Medula
    KAYDET'ten ÖNCE bu kutuda tüm GS1 dizisini (01+GTIN+21 seri+17 SKT+10 lot)
    tutar; düz barkod 8/13/14 hanedir. Kayıttan sonra Medula barkodu GTIN-13'e
    indirir → ham karekodlu (kayıt-öncesi) kayıt, kayıt-sonrası düzgün barkodla
    eşleşmeyip yanlışlıkla "ÇIKARILDI" görünür. Bu fonksiyon o ham karekodu
    (>14 hane veya rakam-dışı içeren) ayırt eder.
    """
    s = (barkod or "").strip().replace("\x1d", "")
    if not s:
        return False
    return len(s) > 14 or not s.isdigit()


# ---------------------------------------------------------------------------
# Tek bir ilaç satırı (state)
# ---------------------------------------------------------------------------
class DrugRow:
    def __init__(self, barcode: str, name: str, drug_id: Optional[int]):
        self.drug_id = drug_id
        self.barcode = barcode
        self.name = name
        # Defaults — DB'den al
        kategori, talimat, uyari, sure_gun = self._db_recipe()
        self.kategori = kategori
        self.talimat = talimat
        self.uyari = uyari
        self.sure_gun = sure_gun
        # Manuel düzenleme alanları
        self.gunluk_kez = 1
        self.doz_birim = guess_unit(name) or "Tane"
        self.doz_adet = 1.0
        # Doz/zaman/öğün ek alanları (etiket render'ı bunları doz ızgarası,
        # öğün rozeti ve alt "DR. NOTU" şeridi olarak basar).
        self.periyot = "Günde"                 # Günde | Haftada | Ayda
        self.kullanim_zamani: list[str] = []   # ["sabah", "akşam", ...]
        self.meal_badge = ""                   # "AÇ" | "TOK" | "AÇ TOK FARKETMEZ" | ...
        self.not_metni = ""                    # etikete basılan serbest not
        # İnsülin (ATC A10A*) "ünite" ile dozlanır — DB'den ATC ile kesinleştir
        # (isim tahmini tutmasa bile doğru birim gelsin).
        if self.drug_id is not None:
            try:
                with get_connection() as conn:
                    a = conn.execute(
                        "SELECT atc_code FROM drugs WHERE id=?", (self.drug_id,)
                    ).fetchone()
                if a and (a["atc_code"] or "").upper().startswith("A10A"):
                    self.doz_birim = "ünite"
            except Exception:
                pass

    def _db_recipe(self):
        """DB'de varsa tarifi al, yoksa drug_guess ile üret."""
        if self.drug_id is not None:
            with get_connection() as conn:
                row = conn.execute(
                    "SELECT content_json FROM drug_labels WHERE drug_id=? AND label_type=1",
                    (self.drug_id,),
                ).fetchone()
                if row:
                    try:
                        r = json.loads(row["content_json"])
                        return (
                            r.get("kategori", ""),
                            r.get("kullanim_talimati", ""),
                            r.get("uyari_metni", ""),
                            r.get("sure_gun", 7),
                        )
                    except Exception:
                        pass
        # Fallback: drug_guess'ten üret
        r = build_recipe(self.name)
        return (r["kategori"], r["kullanim_talimati"], r["uyari_metni"], r["sure_gun"])


# ---------------------------------------------------------------------------
# Ana pencere
# ---------------------------------------------------------------------------
class ManualLabelApp(tk.Tk):
    def __init__(self):
        super().__init__()
        # DPI: Windows ölçeklendirmesi (125%/150%) arayüzü sıkıştırıp butonları
        # üst üste bindiriyordu. Tk ölçeğini 96 dpi'a sabitle → her bilgisayarda
        # geliştirme makinesiyle BİREBİR aynı 1:1 yerleşim (süreç DPI-farkındalığı
        # main() içinde, Tk oluşmadan önce ayarlanır).
        try:
            self.tk.call("tk", "scaling", 1.3333)
        except Exception:
            pass
        self.title("İLAÇ TARİF — Eczane Etiketleme Sistemi")
        self.geometry("1320x840")
        self.minsize(400, 400)
        # En az 4 etiket aynı anda görünsün diye TAM EKRAN (maximize) aç.
        # Windows'ta 'zoomed'; başka platformlarda sessizce geometry'e düşer.
        self._layout_mode = "normal"   # "normal" | "small"
        try:
            self.state("zoomed")
        except Exception:
            try:
                self.attributes("-zoomed", True)
            except Exception:
                pass
        apply_app_theme(self)
        self._init_db()

        # Otomatik tab state — her reçete bir ReceteSet
        self._recete_sets: list[ReceteSet] = []
        self._key_to_idx: dict[str, int] = {}   # set.key → liste index
        self._auto_thumb_refs: list[ImageTk.PhotoImage] = []
        # Aşama bazlı kart yerleşim durumu (responsive sütunlar)
        self._stage_cards: dict[str, list] = {"early": [], "final": []}
        self._stage_grid: dict[str, Optional[tk.Frame]] = {"early": None, "final": None}
        self._watcher: Optional[MedulaWatcher] = None
        self._preview_dir = Path(__file__).resolve().parents[3] / "data" / "live_preview"
        self._preview_dir.mkdir(parents=True, exist_ok=True)
        # Kağıt reçete erken yakalama için: son işlenen form hash'i (spam engelleme)
        self._last_paper_hash: str = ""
        self._last_paper_form: Optional[PaperReceteForm] = None
        self._last_paper_set_key: Optional[str] = None
        # E-reçete erken yakalama için: recete_no → cap_early
        self._erecete_early_caps: dict[str, PrescriptionCapture] = {}
        # İTS-satış duplike bastırma: kağıt/İTS akışı bir e-reçeteyle (aynı TC +
        # ilaç barkodları örtüşmesi + arka arkaya/kısa süre içinde) eşleştiğinde,
        # o kağıt set anahtarı buraya yazılır ve listeye AYRI satır açılmaz.
        self._suppressed_paper_keys: set[str] = set()
        # Yabancı uyruklu (TC 98/99) + geçici koruma DIŞI hastalar için "Topkapı SGK
        # kağıdı" uyarısı bir kez gösterilsin diye işlenen anahtarlar (recete_no|tc).
        self._foreign_warn_shown: set[str] = set()

        # Medula canlı tutma zamanlayıcı durumu
        self._keepalive_after_id: Optional[str] = None
        self.KEEPALIVE_SECONDS = 119          # boşta-bekleme süresi (ayarlanabilir, sn)
        self.KEEPALIVE_MS = self.KEEPALIVE_SECONDS * 1000
        self.KEEPALIVE_ENTER_DELAY_MS = 1500  # F5'ten sonra Enter için bekleme (1,5 sn)
        self._keepalive_enter_after_id: Optional[str] = None
        # Etkinlik (Medula'ya tıklama) izleme: tıklama olunca sayaç sıfırlanır.
        self.KEEPALIVE_POLL_MS = 600          # fare durumu yoklama aralığı
        self._keepalive_poll_after_id: Optional[str] = None
        self._keepalive_mouse_down = False    # fare basılı-kenar tespiti için önceki durum
        # Geri sayım: checkbox açıkken kaç saniye kaldığını takip eder
        self._keepalive_deadline_ms: Optional[float] = None   # after() bitiş zamanı (ms)
        self._keepalive_tick_after_id: Optional[str] = None   # saniyede-bir güncelleme
        # A/B tip seçimi: "A" = F5+Enter, "B" = Sonraki butonu
        self._keepalive_type: str = "A"

        # Sistem tepsisi (saat yanı) ikonu — pencere kapatılınca programı
        # tepsiye gizler, arka planda çalışmaya devam eder. Boot'ta '--tray'
        # argümanıyla açılırsa pencere hiç görünmeden doğrudan tepside başlar.
        self._tray = None
        self._start_hidden = any(
            a in ("--tray", "--minimized", "--gizli") for a in sys.argv[1:]
        )

        self._build_ui()
        self.rows: list[DrugRow] = []
        self._refresh_table()

        # Medula pencere durum çerçevesi (yeşil/turuncu/mavi) — Tk ana thread'inde yaşar
        self._medula_overlay = MedulaThemeOverlay(
            self, enabled=getattr(self, "_medula_theme_overlay", True))

        # Kısayolları watcher'dan BAĞIMSIZ kaydet — Medula watcher başlamasa
        # (veya hata verse) bile Ctrl+Shift+B / Shift+F12 çalışsın.
        self._bridge_server = None
        self.after(200, self._register_print_hotkey)
        # Watcher otomatik başlasın
        self.after(300, self._start_watcher)
        # Köprü sunucusu — etkinse başlat
        self.after(500, self._start_bridge_if_enabled)
        # İlk açılış: köprü/yazıcı rolü kurulum sihirbazı (gerekiyorsa)
        self.after(900, self._maybe_first_run_setup)
        # Otomatik güncelleme: önceki güncelleme artıklarını temizle + kontrol et
        self.after(3000, self._start_update_check)
        # Sistem tepsisi ikonunu kur (arka planda çalışabilmek için)
        self.after(600, self._setup_tray)
        # Otomatik başlangıç kısayolunu ayara göre kur/kaldır (idempotent)
        self.after(1200, self._apply_autostart_setting)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        # Boot'ta '--tray' ile açıldıysak pencereyi hiç göstermeden gizle
        # (yanıp-sönmeyi önler); tepsi ikonu kurulunca oradan açılır.
        if self._start_hidden:
            try:
                self.withdraw()
            except Exception:
                pass

    def _init_db(self):
        with get_connection() as conn:
            init_schema(conn)
            s = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}
            self.eczane_adi = s.get("eczane_adi", "")
            self.eczane_tel = s.get("eczane_telefon", "")
            self.printer_host = s.get("printer_host", "192.168.1.172")
            try:
                self.printer_port = int(s.get("printer_port", "9100"))
            except (TypeError, ValueError):
                self.printer_port = 9100
            self._load_printers(s)
            self.print_bridge_enabled = s.get("print_bridge_enabled", "0") == "1"
            try:
                self.print_bridge_port = int(s.get("print_bridge_port", "9200"))
            except (TypeError, ValueError):
                self.print_bridge_port = 9200
            # İlk açılış kurulum sihirbazı (köprü rolü) tamamlandı mı?
            self.setup_done = s.get("setup_done", "0") == "1"
            # Bilgisayar açılınca otomatik başla (Windows Başlangıç klasörüne kısayol).
            # Varsayılan AÇIK — program açıldığında kendini başlangıca ekler ve
            # boot'ta tepside gizli (--tray) başlar. Ayarlar → Genel'den kapatılabilir.
            self.autostart_enabled = s.get("autostart_enabled", "1") == "1"
            # Klavye kısayolları
            self.hotkey_recete_sonu         = s.get("hotkey_recete_sonu",         "shift+f12")
            self.hotkey_yazici_recete_basi  = s.get("hotkey_yazici_recete_basi",  "")
            self.hotkey_recete_basi         = s.get("hotkey_recete_basi",         "shift+i")
            self.hotkey_parekende           = s.get("hotkey_parekende",           "shift+p")
            self.hotkey_etiket_sayfasi      = s.get("hotkey_etiket_sayfasi",      "shift+u")
            self.hotkey_goster              = s.get("hotkey_goster",              "")
            self.hotkey_sadece_temel        = s.get("hotkey_sadece_temel",        "")
            self.hotkey_hasta_etiketi       = s.get("hotkey_hasta_etiketi",       "shift+scroll_lock")
            self.hotkey_emanet              = s.get("hotkey_emanet",              "ctrl+shift+e")
            self.hotkey_emanet_hover        = s.get("hotkey_emanet_hover",        "shift+f9")
            self.hotkey_karekod_bas         = s.get("hotkey_karekod_bas",         "ctrl+shift+g")
            self.hotkey_odenmeyen_bas       = s.get("hotkey_odenmeyen_bas",       "ctrl+shift+u")
            # Hasta bilgi etiketi: set başlığındaki kutu VARSAYILAN durumu (kalıcı).
            # Varsayılan KAPALI — kullanıcı elle işaretlemeden hasta etiketi çıkmaz.
            self._hasta_label_default = s.get("hasta_label_default", "0") == "1"
            # Hasta etiketinde 'TOPLAM BORÇ' (veresiye) satırı genel olarak görünsün mü?
            # Varsayılan AÇIK; ayarlardan kapatılabilir, kart üstündeki ✕ ile o anki
            # etikette tek seferlik gizlenebilir.
            self._hasta_show_debt = s.get("hasta_label_show_debt", "1") == "1"
                # Kalıcı etiket kısıtlamaları — BooleanVar'ları güncelle
            _ob_print   = s.get("only_basic_print",   "0") == "1"
            _ob_display = s.get("only_basic_display",  "0") == "1"
            # _init_db, BooleanVar'lar oluşturulmadan (_build_auto_tab) ÖNCE çalışır;
            # bu yüzden değerleri sakla, var'lar kurulurken başlangıç değeri olarak okusun.
            self._only_basic_initial = _ob_print
            self._only_basic_display_initial = _ob_display
            # Parenteral uygulama yolu ayarı (manuel etiket fallback'inde kullanılır)
            self._erecete_parenteral_route = s.get("erecete_parenteral_route", "0") == "1"
            # "Hastaya verilecek ilaç elde yok ise etiket çıkarma": açıkken, kayıt
            # sonrası stok verilecek kutu adedi kadar (veya fazla) eksiye düşmüşse
            # (elimizde o ilaç yoksa) etiketin baskı işareti PASİF gelir.
            self._suppress_out_of_stock = s.get("suppress_out_of_stock", "0") == "1"
            # "Sadece okutulan karekodların etiketini bas": açıkken, İTS Karekod
            # İşlemleri ekranında okutulan karekodlar arka planda sayılır; Ctrl+Shift+Ğ
            # ile yalnız okutulmuş ilaçların etiketleri basılır (reçete başı olmayan
            # doğrudan açılmış reçetelerde).
            self._karekod_scan_print = s.get("karekod_scan_print", "0") == "1"
            # Medula penceresini reçete durumuna göre renkli çerçeveyle boya
            # (yeşil=sonlandı, turuncu=eksik karekod, mavi=sürüyor). Varsayılan AÇIK.
            self._medula_theme_overlay = s.get("medula_theme_overlay", "1") == "1"
            # Reçete sonu (SGK) ekranı görünüm filtreleri:
            #  • ödenmeyen (geri_odeme_yok) ilaçları gösterme
            #  • reçeteden çıkarılan (removed) ilaçları gösterme
            self._hide_unpaid_final = s.get("hide_unpaid_final", "0") == "1"
            self._hide_removed_final = s.get("hide_removed_final", "0") == "1"
            if hasattr(self, "_only_basic_var"):
                self._only_basic_var.set(_ob_print)
            if hasattr(self, "_only_basic_display_var"):
                self._only_basic_display_var.set(_ob_display)
            # Etiket görünüm ölçeği
            try:
                self._label_display_scale = float(s.get("label_display_scale", "1.0"))
            except (TypeError, ValueError):
                self._label_display_scale = 1.0
            # Fiziksel etiket boyutu (mm) — TSPL baskı komutu için
            try:
                self.label_w_mm = float(s.get("label_w_mm", "60"))
            except (TypeError, ValueError):
                self.label_w_mm = 60.0
            try:
                self.label_h_mm = float(s.get("label_h_mm", "40"))
            except (TypeError, ValueError):
                self.label_h_mm = 40.0
            try:
                self.label_gap_mm = float(s.get("label_gap_mm", "2"))
            except (TypeError, ValueError):
                self.label_gap_mm = 2.0
            try:
                self.printer_dpi = int(s.get("printer_dpi", "203"))
            except (TypeError, ValueError):
                self.printer_dpi = 203
            # Kutu üstü fiyat etiketi (6. sekme) — bağımsız boyut + yazıcı seçimi
            try:
                self.box_label_w_mm = float(s.get("box_label_w_mm", "40"))
            except (TypeError, ValueError):
                self.box_label_w_mm = 40.0
            try:
                self.box_label_h_mm = float(s.get("box_label_h_mm", "25"))
            except (TypeError, ValueError):
                self.box_label_h_mm = 25.0
            # Boşsa aktif (ana) yazıcı kullanılır
            self.box_printer_active = s.get("box_printer_active", "") or ""
            # Raf etiketi (5. sekme) — barkod+isim+fiyat; bağımsız boyut + yazıcı
            try:
                self.raf_label_w_mm = float(s.get("raf_label_w_mm", "60"))
            except (TypeError, ValueError):
                self.raf_label_w_mm = 60.0
            try:
                self.raf_label_h_mm = float(s.get("raf_label_h_mm", "40"))
            except (TypeError, ValueError):
                self.raf_label_h_mm = 40.0
            self.raf_printer_active = s.get("raf_printer_active", "") or ""
            # Kargo etiketi (7. sekme) — bağımsız boyut + ayrı yazıcı + firma listesi
            try:
                self.kargo_label_w_mm = float(s.get("kargo_label_w_mm", "60"))
            except (TypeError, ValueError):
                self.kargo_label_w_mm = 60.0
            try:
                self.kargo_label_h_mm = float(s.get("kargo_label_h_mm", "40"))
            except (TypeError, ValueError):
                self.kargo_label_h_mm = 40.0
            self.kargo_printer_active = s.get("kargo_printer_active", "") or ""
            self.kargo_firmalar = [
                p.strip() for p in (s.get("kargo_firmalar", "") or "").split("|")
                if p.strip()
            ]
            self.kargo_firma_son = s.get("kargo_firma_son", "") or ""
            # Eczane adresi (kargo gönderen etiketinde kullanılır)
            self.eczane_adres = s.get("eczane_adres", "") or ""
            # Majistral etiketi (içerik + kullanım) — bağımsız boyut + ayrı yazıcı
            try:
                self.majistral_label_w_mm = float(s.get("majistral_label_w_mm", "60"))
            except (TypeError, ValueError):
                self.majistral_label_w_mm = 60.0
            try:
                self.majistral_label_h_mm = float(s.get("majistral_label_h_mm", "40"))
            except (TypeError, ValueError):
                self.majistral_label_h_mm = 40.0
            self.majistral_printer_active = s.get("majistral_printer_active", "") or ""
            self.magistral_iscilik = s.get("magistral_iscilik", "0") or "0"

    def _load_printers(self, s: dict):
        """Kayıtlı yazıcı listesini ve aktif yazıcıyı settings'ten yükle."""
        # Eski kurulum mu? (yazıcı daha önce Ayarlar'dan yapılandırılmışsa
        # ilk-açılış sihirbazını gösterme — bkz. _maybe_first_run_setup)
        self._had_printers_json = bool(s.get("printers_json"))
        try:
            self.printers = json.loads(s.get("printers_json") or "[]")
            if not isinstance(self.printers, list):
                self.printers = []
        except (ValueError, TypeError):
            self.printers = []
        # Geriye uyum: kayıt yoksa mevcut host/port'tan tek bir TCP yazıcı üret
        if not self.printers:
            self.printers = [{
                "name": f"Ağ Yazıcısı ({self.printer_host})",
                "type": "tcp", "host": self.printer_host, "port": self.printer_port,
            }]
        self.printer_active = s.get("printer_active") or self.printers[0].get("name")
        self._sync_active_printer()

    def _active_printer_cfg(self) -> dict:
        """Aktif yazıcı yapılandırmasını döndür (yoksa ilk kayıt).

        printer_local.json varsa o makinenin yerel override'ı uygulanır
        (git'e girmez; her bilgisayar kendi yazıcısını kullanır).
        """
        from .. import printer as _printer
        for p in getattr(self, "printers", []):
            if p.get("name") == getattr(self, "printer_active", None):
                return _printer.apply_local_override(p)
        base = self.printers[0] if getattr(self, "printers", None) else {
            "type": "tcp", "host": self.printer_host, "port": self.printer_port,
        }
        return _printer.apply_local_override(base)

    def _printer_cfg_by_name(self, name: str) -> dict:
        """Adı verilen yazıcının cfg'ini döndür; bulunamazsa aktif yazıcı cfg.

        Kutu-üstü fiyat etiketi sekmesi ana yazıcıdan FARKLI bir yazıcı
        seçebilsin diye kullanılır (yerel override yine uygulanır).
        """
        from .. import printer as _printer
        for p in getattr(self, "printers", []):
            if p.get("name") == name:
                return _printer.apply_local_override(p)
        return self._active_printer_cfg()

    def _sync_active_printer(self):
        """Aktif TCP yazıcının host/port'unu geriye-uyum alanlarına yansıt."""
        cfg = self._active_printer_cfg()
        if cfg.get("type") == "tcp":
            self.printer_host = cfg.get("host", self.printer_host)
            try:
                self.printer_port = int(cfg.get("port", self.printer_port))
            except (TypeError, ValueError):
                pass

    # ------------------------------------------------------------------
    # Ayarlar penceresi (yazıcı + eczane)
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # Kısayol Ayarları diyaloğu
    # ------------------------------------------------------------------
    def _open_shortcut_settings(self):
        from ..db import get_connection, save_setting

        C = COLORS

        # ── Geçerlilik kontrolü ──────────────────────────────────────────────
        def _validate(combo: str) -> tuple[bool, str]:
            """(geçerli_mi, uyarı_metni)"""
            if not combo:
                return True, ""
            parts = [p.strip() for p in combo.split("+") if p.strip()]
            mods  = {"ctrl","alt","shift"}
            fkeys = {f"f{i}" for i in range(1, 13)}
            num_keys = {f"num {i}" for i in range(10)} | {"num decimal","num enter","num +","num -","num *","num /"}
            nav_keys = {"up","down","left","right","home","end","page_up","page_down",
                        "insert","delete","backspace","tab","enter","esc",
                        "print_screen","scroll_lock","pause","space"}
            mod_parts  = [p for p in parts if p in mods]
            key_parts  = [p for p in parts if p not in mods]

            if not key_parts:
                return False, "Ana tuş eksik — modifier yalnız kısayol olamaz."
            if len(key_parts) > 1:
                return False, "Birden fazla ana tuş girilemez."
            main = key_parts[0]

            # Tek harf/rakam, modifier'sız → tüm yazmaları keser
            if not mod_parts and len(main) == 1 and main.isalnum():
                return False, (
                    "Tehlikeli! Modifier'sız tek harf/rakam yazışı engeller.\n"
                    "En az Shift veya Ctrl ekleyin."
                )
            # Shift + rakam → sembol üretir, güvenilmez
            if mod_parts == ["shift"] and len(main) == 1 and main.isdigit():
                return False, (
                    "Shift + rakam güvenilmez (!, @, # gibi sembole dönüşür).\n"
                    "Öneri: Shift + F-tuşu  veya  Ctrl + rakam."
                )
            # Alt + F4 gibi sistem kısayolları
            if "alt" in mod_parts and main == "f4":
                return False, "Alt + F4 pencereyi kapatır — bu kısayolu kullanmayın."
            # F-tuş veya numpad: modifier'sız bile güvenli
            if main in fkeys or main in num_keys or main in nav_keys:
                return True, ""
            # Harf/rakam: en az bir modifier şart
            if not mod_parts:
                return False, (
                    "Harf/rakam kısayolları için en az bir modifier (Ctrl/Alt/Shift) gerekir."
                )
            return True, ""

        # ── Sabit combobox seçenekleri ───────────────────────────────────────
        KEY_CHOICES = (
            ["(boş — devre dışı)"] +
            [f"F{i}" for i in range(1, 13)] +
            ["A","B","C","D","E","F","G","H","I","İ","J","K","L","M",
             "N","O","Ö","P","R","S","Ş","T","U","Ü","V","Y","Z"] +
            [str(i) for i in range(0, 10)] +
            ["Num 0","Num 1","Num 2","Num 3","Num 4",
             "Num 5","Num 6","Num 7","Num 8","Num 9"] +
            ["Enter","Backspace","Delete","Insert","Home","End",
             "Page Up","Page Down","Up","Down","Left","Right",
             "Space","Tab","Esc","Print Screen","Scroll Lock","Pause"]
        )
        # Combobox gösterim → keyboard lib değeri
        _COMBO_TO_KB: dict[str, str] = {
            "(boş — devre dışı)": "",
            "Page Up": "page_up", "Page Down": "page_down",
            "Print Screen": "print_screen", "Scroll Lock": "scroll_lock",
            "Num 0":"num 0","Num 1":"num 1","Num 2":"num 2","Num 3":"num 3",
            "Num 4":"num 4","Num 5":"num 5","Num 6":"num 6","Num 7":"num 7",
            "Num 8":"num 8","Num 9":"num 9",
            "İ": "i",  # Türkçe büyük İ → keyboard lib 'i'
            "Ö": "o", "Ş": "s", "Ü": "u", "Ğ": "g", "Ç": "c",
        }
        def _display_to_kb(disp: str) -> str:
            if disp in _COMBO_TO_KB:
                return _COMBO_TO_KB[disp]
            return disp.lower() if disp else ""

        # Keyboard lib değeri → combobox görüntüsü (mevcut ayarı ayrıştırmak için)
        _KB_TO_DISPLAY: dict[str, str] = {v: k for k, v in _COMBO_TO_KB.items() if v}
        for _f in range(1, 13):
            _KB_TO_DISPLAY[f"f{_f}"] = f"F{_f}"

        def _parse_combo(combo: str) -> tuple[bool, bool, bool, str]:
            """'ctrl+shift+f12' → (ctrl, alt, shift, 'F12')"""
            if not combo:
                return False, False, False, "(boş — devre dışı)"
            parts = [p.strip().lower() for p in combo.split("+")]
            ctrl  = "ctrl"  in parts
            alt   = "alt"   in parts
            shift = "shift" in parts
            key_parts = [p for p in parts if p not in ("ctrl","alt","shift")]
            kb_key = key_parts[0] if key_parts else ""
            disp = _KB_TO_DISPLAY.get(kb_key, kb_key.upper() if kb_key else "(boş — devre dışı)")
            return ctrl, alt, shift, disp

        # ── Pencere ─────────────────────────────────────────────────────────
        win = tk.Toplevel(self)
        win.title("⌨ Kısayol Ayarları")
        win.configure(background=C["bg_card"])
        win.transient(self)
        win.grab_set()
        win.resizable(True, False)

        ACTIONS = [
            ("hotkey_recete_sonu",        "Reçete Sonu → Yazıcı",
             "Medula ön plandaysa ekrandaki hastayı, değilse seçili/son reçete son etiketlerini gönderir"),
            ("hotkey_yazici_recete_basi", "Reçete Başı → Yazıcı",
             "Seçili reçetenin başı (taslak) etiketlerini yazıcıya gönderir"),
            ("hotkey_sadece_temel",       "Sadece A Etiketi → Yazıcı",
             "Seçili/son reçetenin yalnızca A (temel) etiketlerini yazıcıya gönderir"),
            ("hotkey_recete_basi",        "Reçete Başı Yakala",
             "Watcher'ı tetikler, Medula sayfasını hemen yeniden okur"),
            ("hotkey_parekende",          "Parekende Satış Verisi Topla",
             "Botanik satış ekranındaki ürünleri etiket listesine ekler"),
            ("hotkey_etiket_sayfasi",     "Etiket Sayfasını Getir",
             "Medula/Etiket sekmesini ön plana alır"),
            ("hotkey_goster",             "Programı Göster",
             "Etiket programı penceresini ön plana getirir"),
            ("hotkey_hasta_etiketi",      "Hasta Etiketi → Yazıcı",
             "Tarih/ad-soyad/telefon/ödeme/reçete toplamını basan hasta etiketini yazıcıya gönderir (kutu işaretli olsun olmasın)"),
            ("hotkey_emanet",             "Emanet Etiketi → Yazıcı",
             "Takvimden/elle tarih seçtirip 'BU İLAÇ SİZE EMANET VERİLMİŞTİR' etiketini yazıcıya gönderir"),
            ("hotkey_emanet_hover",       "Emanet (Mouse Altındaki İlaç)",
             "Medula'da fareyi bir ilacın üstüne getirip basınca o ilaç için emanet diyaloğunu (ilaç+hasta+tarih+telefon dolu) açar"),
            ("hotkey_karekod_bas",        "Sadece Okutulan Karekodları Bas",
             "İTS Karekod İşlemleri'nde karekodu okutulmuş ilaçların etiketlerini basar (okutulmayanlar atlanır). Ayar açık olmalı."),
            ("hotkey_odenmeyen_bas",      "Ödenmeyen (SGK) İlaçları Bas",
             "Reçete başında olup SGK'nın ödemediği (reçete sonunda olmayan) ilaçların etiketlerini basar"),
        ]

        # Her aksiyon için (ctrl_var, alt_var, shift_var, key_display_var)
        row_state: dict[str, tuple] = {}

        frm = ttk.LabelFrame(win, text="Kısayol Tanımları", padding=(10, 8))
        frm.pack(fill="both", padx=14, pady=(14, 4))

        # Başlık satırı
        for col, (txt, w) in enumerate([
            ("Aksiyon", 22), ("Ctrl", 4), ("Alt", 4), ("Shift", 5),
            ("Ana Tuş", 18), ("Sonuç", 18), ("Durum", 26)
        ]):
            ttk.Label(frm, text=txt, font=("Segoe UI", 8, "bold"),
                      foreground=C.get("text_muted","gray"), width=w, anchor="w"
                      ).grid(row=0, column=col, padx=(0,4), pady=(0,4), sticky="w")

        def _rebuild_combo(ctrl_v, alt_v, shift_v, key_v, preview_v, warn_lbl):
            mods = []
            if ctrl_v.get():  mods.append("ctrl")
            if alt_v.get():   mods.append("alt")
            if shift_v.get(): mods.append("shift")
            kb_key = _display_to_kb(key_v.get())
            combo = "+".join(mods + ([kb_key] if kb_key else []))
            preview_v.set(combo or "(boş)")
            ok, msg = _validate(combo)
            if not combo:
                warn_lbl.config(text="", foreground="gray")
            elif ok:
                warn_lbl.config(text="✓ Geçerli", foreground="#3a9e3a")
            else:
                warn_lbl.config(text=f"⚠ {msg}", foreground="#cc4400")

        for r, (key, label, tip) in enumerate(ACTIONS, start=1):
            current = getattr(self, key, "")
            ctrl_init, alt_init, shift_init, key_disp_init = _parse_combo(current)

            ctrl_v    = tk.BooleanVar(value=ctrl_init)
            alt_v     = tk.BooleanVar(value=alt_init)
            shift_v   = tk.BooleanVar(value=shift_init)
            key_v     = tk.StringVar(value=key_disp_init)
            preview_v = tk.StringVar()
            row_state[key] = (ctrl_v, alt_v, shift_v, key_v)

            # Aksiyon adı + tooltip
            lbl = ttk.Label(frm, text=label, width=22, anchor="w",
                            font=("Segoe UI", 9))
            lbl.grid(row=r, column=0, sticky="w", padx=(0,4), pady=4)
            lbl.bind("<Enter>", lambda e, t=tip: self.status.set(t))
            lbl.bind("<Leave>", lambda e: self.status.set(""))

            # Sonuç önizleme — önce oluştur (lambda'lara geçecek)
            prev_lbl = ttk.Label(frm, textvariable=preview_v,
                                 font=("Consolas", 9), foreground=C.get("accent","#0078d4"),
                                 width=18, anchor="w")
            prev_lbl.grid(row=r, column=5, padx=(0,4), sticky="w")

            # Durum/uyarı — önce oluştur
            warn_lbl = ttk.Label(frm, text="", wraplength=200,
                                 font=("Segoe UI", 8), anchor="w", width=26)
            warn_lbl.grid(row=r, column=6, sticky="w")

            # Modifier checkbox'ları (warn_lbl artık hazır — closure ile geçiliyor)
            ttk.Checkbutton(frm, variable=ctrl_v,
                            command=lambda c=ctrl_v, a=alt_v, s=shift_v, k=key_v,
                                           p=preview_v, wl=warn_lbl:
                                           _rebuild_combo(c, a, s, k, p, wl)
                            ).grid(row=r, column=1, padx=2)
            ttk.Checkbutton(frm, variable=alt_v,
                            command=lambda c=ctrl_v, a=alt_v, s=shift_v, k=key_v,
                                           p=preview_v, wl=warn_lbl:
                                           _rebuild_combo(c, a, s, k, p, wl)
                            ).grid(row=r, column=2, padx=2)
            ttk.Checkbutton(frm, variable=shift_v,
                            command=lambda c=ctrl_v, a=alt_v, s=shift_v, k=key_v,
                                           p=preview_v, wl=warn_lbl:
                                           _rebuild_combo(c, a, s, k, p, wl)
                            ).grid(row=r, column=3, padx=2)

            # Ana tuş combobox
            cb = ttk.Combobox(frm, textvariable=key_v, values=KEY_CHOICES,
                              width=14, state="readonly", font=("Segoe UI", 9))
            cb.grid(row=r, column=4, padx=(2,4), sticky="w")
            cb.bind("<<ComboboxSelected>>",
                    lambda e, c=ctrl_v, a=alt_v, s=shift_v, k=key_v,
                           p=preview_v, wl=warn_lbl: _rebuild_combo(c, a, s, k, p, wl))

            # İlk önizlemeyi doldur
            _rebuild_combo(ctrl_v, alt_v, shift_v, key_v, preview_v, warn_lbl)

        # ── Rehber paneli ────────────────────────────────────────────────────
        guide_frm = ttk.LabelFrame(win, text="Kısayol Rehberi", padding=(10, 6))
        guide_frm.pack(fill="x", padx=14, pady=(6, 4))

        GUIDE_ROWS = [
            ("✅ Shift + F-tuşu",
             "Shift+F1 … Shift+F12 — En güvenli seçim. Medula/tarayıcı ile çakışmaz."),
            ("✅ Ctrl + harf/rakam",
             "Ctrl+B, Ctrl+5 vb. — Yaygın kullanım, ctrl yoksa tarayıcı kısayoluyla çakışabilir."),
            ("✅ Ctrl + Shift + harf",
             "Ctrl+Shift+B vb. — Üçlü kombinasyon, çakışma riski çok düşük."),
            ("✅ Numpad tuşları",
             "Shift+Num1 … Ctrl+Num9 — Masaüstü klavyede NumLock açıksa güvenli."),
            ("⚠ Shift + rakam",
             "!, @, # gibi sembole dönüşür → GÜVENİLMEZ. Bunun yerine Ctrl+rakam kullanın."),
            ("❌ Modifier'sız harf/rakam",
             "Tek başına A, 5 vb. — Tüm yazışı engeller, KULLANMAYIN."),
            ("❌ Alt + F4",
             "Pencereyi kapatır — sistem tarafından yakalanır, atanmaz."),
        ]
        for emoji_lbl, desc in GUIDE_ROWS:
            row_f = ttk.Frame(guide_frm)
            row_f.pack(fill="x", pady=1)
            ttk.Label(row_f, text=emoji_lbl, width=22, anchor="w",
                      font=("Segoe UI", 8, "bold")).pack(side="left")
            ttk.Label(row_f, text=desc, anchor="w",
                      font=("Segoe UI", 8),
                      foreground=C.get("text_muted","gray"),
                      wraplength=480).pack(side="left")

        note = ttk.Label(win,
                         text="ℹ  Boş bırakılan kısayollar devre dışı kalır. "
                              "Yazıcı arka planda çalışırken değişiklikler anında aktif olur.",
                         font=("Segoe UI", 8), foreground=C.get("text_muted","gray"),
                         wraplength=700, anchor="w")
        note.pack(fill="x", padx=14, pady=(2, 4))

        # ── Kaydet / İptal ───────────────────────────────────────────────────
        def _save():
            with get_connection() as conn:
                for key, (ctrl_v, alt_v, shift_v, key_v) in row_state.items():
                    mods = []
                    if ctrl_v.get():  mods.append("ctrl")
                    if alt_v.get():   mods.append("alt")
                    if shift_v.get(): mods.append("shift")
                    kb_key = _display_to_kb(key_v.get())
                    combo = "+".join(mods + ([kb_key] if kb_key else []))
                    save_setting(conn, key, combo)
                    setattr(self, key, combo)
            self._register_print_hotkey()
            self.status.set("⌨ Kısayollar güncellendi.")
            win.destroy()

        btns = ttk.Frame(win)
        btns.pack(fill="x", padx=14, pady=(4, 14))
        ttk.Button(btns, text="İptal", command=win.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="💾 Kaydet", style="Accent.TButton",
                   command=_save).pack(side="right", padx=4)

        win.update_idletasks()
        x = self.winfo_rootx() + max(0, (self.winfo_width() - win.winfo_width()) // 2)
        y = self.winfo_rooty() + 40
        win.geometry(f"+{max(0, x)}+{max(0, y)}")
    def _scrollable_body(self, parent):
        """parent içine dikey kaydırılabilir bir gövde frame'i kurar ve onu döndürür.
        İçerik bu gövdeye yerleştirilince, küçük/ölçekli ekranlarda alttaki elementler
        (örn. etiket boyutu) kaydırma çubuğu / fare tekerleği ile görülebilir."""
        C = COLORS
        # Zemin KOYU (bg_main) — içerik kısa kalınca altta anlamsız SARI boşluk
        # görünmesin (eskiden bg_card=sarıydı). Boş alan artık dark temaya uyar.
        canvas = tk.Canvas(parent, highlightthickness=0,
                           background=C.get("bg_main", "#1d2a4d"))
        vsb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        body = ttk.Frame(canvas, padding=6)
        win_id = canvas.create_window((0, 0), window=body, anchor="nw")
        # Gövde büyüdükçe kaydırma alanını güncelle; genişliği canvas'a eşitle.
        body.bind("<Configure>",
                  lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfigure(win_id, width=e.width))
        # Fare tekerleği — yalnız imleç bu alandayken (diğer listeleri etkilemesin).
        def _wheel(e):
            canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _wheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
        return body

    def _open_settings(self):
        from .. import printer
        from ..db import get_connection, save_setting

        C = COLORS
        win = tk.Toplevel(self)
        win.title("Ayarlar")
        # Pencere zemini KOYU — notebook kenar boşluklarında/boş alanda sarı sızmasın
        win.configure(background=C["bg_main"])
        win.transient(self)
        win.grab_set()
        # minsize düşük: küçük/ölçekli (DPI %125-150) ekranlarda pencere ekrana
        # sığsın, alttaki "Kaydet ve Kapat" çubuğu ekran dışına itilmesin.
        win.minsize(820, 420)
        # "Veri Ekle/Düzenle" sekmesi buraya taşındığından pencere geniş açılır
        # (ekrana sığacak şekilde kırpılır ve ortalanır). Varsayılan boyut şimdiki
        # gibi; "Tam Ekran" butonu ile büyütülüp eski boyuta dönülebilir.
        _settings_geo = {"normal": None}
        try:
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            w, h = min(1200, sw - 80), min(760, sh - 80)
            x, y = (sw - w) // 2, max(0, (sh - h) // 2 - 10)
            _settings_geo["normal"] = f"{w}x{h}+{x}+{y}"
            win.geometry(_settings_geo["normal"])
        except Exception:
            pass

        # Pencere kapanınca, içinde yaşayan widget referanslarını bırak ki sonradan
        # yok edilmiş widget'lara dokunulmasın (watcher butonu + veri editörü).
        def _on_settings_destroyed(e):
            if e.widget is win:
                self._btn_watcher = None
                self.data_editor = None
        win.bind("<Destroy>", _on_settings_destroyed)

        pad = {"padx": 6, "pady": 3}
        green = C.get("accent_green", "green")

        printers = [dict(p) for p in getattr(self, "printers", [])]
        state = {"active": getattr(self, "printer_active", None)}

        with get_connection() as _c:
            _s = {r["key"]: r["value"] for r in _c.execute("SELECT key, value FROM settings")}
        try:
            group_defaults = json.loads(_s.get("group_label_defaults") or "[]")
        except Exception:
            group_defaults = []

        # ---- Alt cubuk: her zaman gorunur ----
        _bar = ttk.Frame(win)
        _bar.pack(side="bottom", fill="x")
        lbl_info = ttk.Label(_bar, text="", foreground=C["text_dark"], anchor="w")
        lbl_info.pack(fill="x", padx=16, pady=(2, 2))
        _btns_row = ttk.Frame(_bar)
        _btns_row.pack(fill="x", padx=12, pady=(0, 10))
        ttk.Button(_btns_row, text="Kapat", command=win.destroy).pack(side="right", padx=4)

        # Tam Ekran / önceki boyut — "Veri Ekle/Düzenle" sekmesinde rahat çalışmak
        # için pencere büyütülebilir; varsayılan açılış şimdiki gibi kalır.
        def _toggle_settings_full():
            try:
                if win.state() == "zoomed":
                    win.state("normal")
                    if _settings_geo["normal"]:
                        win.geometry(_settings_geo["normal"])
                    _btn_full.config(text="⛶ Tam Ekran")
                else:
                    _settings_geo["normal"] = win.geometry()
                    win.state("zoomed")
                    _btn_full.config(text="🗗 Önceki Boyut")
            except Exception:
                pass
        _btn_full = ttk.Button(_btns_row, text="⛶ Tam Ekran",
                               style="Settings.TButton", command=_toggle_settings_full)
        _btn_full.pack(side="left", padx=4)

        def info(msg, ok=None):
            col = C["text_dark"] if ok is None else (green if ok else C["accent_red"])
            lbl_info.config(text=msg, foreground=col)

        # ---- Ana Notebook ----
        main_nb = ttk.Notebook(win)
        main_nb.pack(fill="both", expand=True, padx=8, pady=(8, 4))

        # Tüm ayar sekmeleri kaydırılabilir gövdeye sarılır (küçük/ölçekli — DPI
        # %125-150 — ekranlarda alttaki kontroller + Kaydet görülebilsin). Veri
        # editörü hariç: o kendi tree/scroll düzenini yönetir.
        tab_yazici_outer = ttk.Frame(main_nb)
        tab_kopru_outer  = ttk.Frame(main_nb)
        tab_eczane_outer = ttk.Frame(main_nb)
        tab_genel_outer  = ttk.Frame(main_nb)
        tab_grup_outer   = ttk.Frame(main_nb)
        tab_veri   = ttk.Frame(main_nb)   # editör kendi iç boşluğunu yönetir

        main_nb.add(tab_yazici_outer, text="  \U0001f5a8 Yazici  ")
        main_nb.add(tab_kopru_outer,  text="  \U0001f310 Kopru  ")
        main_nb.add(tab_eczane_outer, text="  \U0001f3ea Eczane & Etiket  ")
        main_nb.add(tab_genel_outer,  text="  ⚙ Genel  ")
        main_nb.add(tab_grup_outer,   text="  \U0001f4cb Gruplar  ")
        main_nb.add(tab_veri,   text="  \U0001f5c3 Veri Ekle/Düzenle  ")

        tab_yazici = self._scrollable_body(tab_yazici_outer)
        tab_kopru  = self._scrollable_body(tab_kopru_outer)
        tab_eczane = self._scrollable_body(tab_eczane_outer)
        tab_genel  = self._scrollable_body(tab_genel_outer)
        tab_grup   = self._scrollable_body(tab_grup_outer)

        # Veri editörü (eski 4. ana sekme) — Ayarlar'a taşındı; her açılışta taze
        # kurulur (lazy import → döngüsel import'tan kaçın).
        try:
            from .data_editor import DataAdminTab
            self.data_editor = DataAdminTab(tab_veri, self)
            self.data_editor.pack(fill="both", expand=True)
        except Exception:
            log.exception("Veri editörü kurulamadı")
            ttk.Label(tab_veri, text="Veri editörü yüklenemedi.").pack(padx=20, pady=20)

        # ===================================================================
        # TAB 1 - YAZICI
        # ===================================================================
        top = ttk.LabelFrame(tab_yazici, text="Kayıtlı Yazıcılar", padding=8)
        top.pack(fill="x", pady=(0, 6))

        saved = tk.Listbox(top, height=5, font=("Consolas", 10))
        saved.pack(fill="x", padx=4, pady=4)

        def _refresh_saved():
            saved.delete(0, "end")
            for p in printers:
                mark = "●" if p.get("name") == state["active"] else "  "
                saved.insert("end", f" {mark}  {p.get('name', '?')}   —   {printer.cfg_label(p)}")

        def _sel():
            s = saved.curselection()
            return s[0] if s else None

        def _make_default():
            i = _sel()
            if i is None:
                return
            state["active"] = printers[i].get("name")
            _refresh_saved()
            info(f"✓ Varsayılan: {state['active']}", ok=True)

        def _delete():
            i = _sel()
            if i is None:
                return
            name = printers.pop(i).get("name")
            if state["active"] == name:
                state["active"] = printers[0]["name"] if printers else None
            _refresh_saved()
            info(f"\U0001f5d1 Silindi: {name}")

        def _test_selected():
            i = _sel()
            if i is None:
                info("Önce listeden bir yazıcı seçin.")
                return
            cfg = printers[i]
            if cfg.get("type") == "tcp":
                ok = printer.port_open(cfg.get("host", ""), int(cfg.get("port", 9100)), 1.5)
                info(f"{'✓ Bağlandı' if ok else '✗ Bağlanamadı'}: {printer.cfg_label(cfg)}", ok=ok)
            elif cfg.get("type") == "bridge":
                ok = printer.port_open(cfg.get("host", ""), int(cfg.get("port", printer.PRINT_BRIDGE_PORT)), 1.5)
                info(f"{'✓ Köprüye bağlandı' if ok else '✗ Bağlanamadı'}: {printer.cfg_label(cfg)}", ok=ok)
            else:
                ok = cfg.get("win_name") in {p["name"] for p in printer.list_printers()} or \
                     bool(printer.list_network_printers())
                info(f"{'✓' if ok else '⚠'} Windows yazıcısı: {cfg.get('win_name')}", ok=ok or None)

        def _add_printer(cfg: dict):
            names = {p.get("name") for p in printers}
            base = cfg.get("name") or printer.cfg_label(cfg)
            name, k = base, 2
            while name in names:
                name = f"{base} ({k})"
                k += 1
            cfg["name"] = name
            printers.append(cfg)
            if state["active"] is None:
                state["active"] = name
            _refresh_saved()
            info(f"➕ Eklendi: {name}", ok=True)

        sbar = ttk.Frame(top)
        sbar.pack(fill="x", padx=4)
        ttk.Button(sbar, text="✓ Varsayılan Yap", command=_make_default).pack(side="left", padx=2)
        ttk.Button(sbar, text="\U0001f50c Test Et", command=_test_selected).pack(side="left", padx=2)
        ttk.Button(sbar, text="\U0001f5d1 Sil", style="Warn.TButton", command=_delete).pack(side="left", padx=2)

        nb = ttk.Notebook(tab_yazici)
        nb.pack(fill="both", expand=True)

        def _picked_cfg(listbox, found):
            s = listbox.curselection()
            if not s:
                info("Önce listeden bir yazıcı seçin.")
                return None
            return dict(found[s[0]])

        # --- 1a: Agdaki yazicilar ---
        t1 = ttk.Frame(nb, padding=8)
        nb.add(t1, text="  Ağdaki Yazıcılar  ")
        ttk.Label(t1, text="Bu bilgisayarın tanıdığı tüm ağ yazıcıları:").pack(anchor="w")
        net_lst = tk.Listbox(t1, height=6, font=("Consolas", 9))
        net_lst.pack(fill="both", expand=True, pady=4)
        net_found = []

        def _list_net():
            net_lst.delete(0, "end")
            net_found.clear()
            try:
                res = printer.list_network_printers()
            except Exception as e:
                info(f"✗ {e}", ok=False)
                return
            for p in res:
                net_found.append({"name": p["share"], "type": "windows", "win_name": p["win_name"]})
                net_lst.insert("end", p["win_name"])
            info(f"✓ {len(res)} ağ yazıcısı listelendi" if res else "Bağlı ağ yazıcısı yok.", ok=bool(res))

        def _add_net():
            cfg = _picked_cfg(net_lst, net_found)
            if cfg:
                _add_printer(cfg)

        r1 = ttk.Frame(t1)
        r1.pack(fill="x")
        ttk.Button(r1, text="\U0001f504 Listele", command=_list_net).pack(side="left", padx=2)
        ttk.Button(r1, text="➕ Seçileni Ekle", style="Accent.TButton", command=_add_net).pack(side="left", padx=2)

        # --- 1b: IP / Bilgisayar Adi ---
        t2 = ttk.Frame(nb, padding=8)
        nb.add(t2, text="  IP / Bilgisayar Adı  ")
        row = ttk.Frame(t2)
        row.pack(fill="x")
        ttk.Label(row, text="IP veya Bilgisayar adı:").pack(side="left")
        var_target = tk.StringVar(value=getattr(self, "printer_host", "192.168.1.172"))
        ttk.Entry(row, textvariable=var_target, width=24, font=("Consolas", 10)).pack(side="left", padx=4)

        def _resolve_target():
            t = var_target.get().strip()
            ip = printer.resolve_host(t)
            info(f"✓ {t} → {ip}" if ip else f"✗ '{t}' çözümlenemedi", ok=bool(ip))

        ttk.Button(row, text="IP Çözümle", command=_resolve_target).pack(side="left", padx=2)

        host_lst = tk.Listbox(t2, height=6, font=("Consolas", 9))
        host_lst.pack(fill="both", expand=True, pady=4)
        host_found = []

        def _query_host():
            target = var_target.get().strip()
            if not target:
                info("Bir IP veya bilgisayar adı girin.")
                return
            info(f"\U0001f50e {target} sorgulanıyor…")
            btn_q.config(state="disabled")

            def _w():
                try:
                    res = printer.list_printers_on_host(target)
                    err = ""
                except Exception as e:
                    res, err = [], str(e)

                def _d():
                    btn_q.config(state="normal")
                    host_lst.delete(0, "end")
                    host_found.clear()
                    if err:
                        info(f"✗ {err}", ok=False)
                        return
                    for p in res:
                        host_found.append({"name": p["share"], "type": "windows", "win_name": p["win_name"]})
                        host_lst.insert("end", p["win_name"])
                    info(f"✓ {len(res)} yazıcı bulundu" if res else
                         "Yazıcı bulunamadı (paylaşım kapalı olabilir).", ok=bool(res))

                self.after(0, _d)

            threading.Thread(target=_w, daemon=True).start()

        def _scan_subnet():
            info("\U0001f4e1 Ağ taranıyor (port 9100, ~birkaç sn)…")
            btn_scan.config(state="disabled")

            def _w():
                try:
                    res = printer.scan_network_printers()
                    err = ""
                except Exception as e:
                    res, err = [], str(e)

                def _d():
                    btn_scan.config(state="normal")
                    host_lst.delete(0, "end")
                    host_found.clear()
                    if err:
                        info(f"✗ {err}", ok=False)
                        return
                    for r in res:
                        nm = r.get("name") or r["ip"]
                        host_found.append({"name": nm, "type": "tcp", "host": r["ip"], "port": 9100})
                        host_lst.insert("end", f"{r['ip']}:9100 (TSPL)" +
                                        (f"   {r['name']}" if r.get("name") else ""))
                    info(f"✓ {len(res)} doğrudan-ağ (TSPL) yazıcı" if res else
                         "Port 9100 açık yazıcı yok.", ok=bool(res))

                self.after(0, _d)

            threading.Thread(target=_w, daemon=True).start()

        def _add_host():
            cfg = _picked_cfg(host_lst, host_found)
            if cfg:
                _add_printer(cfg)

        r2 = ttk.Frame(t2)
        r2.pack(fill="x")
        btn_q = ttk.Button(r2, text="\U0001f50e Yazıcıları Getir", command=_query_host)
        btn_q.pack(side="left", padx=2)
        btn_scan = ttk.Button(r2, text="\U0001f4e1 Ağı Tara (TSPL 9100)", command=_scan_subnet)
        btn_scan.pack(side="left", padx=2)
        ttk.Button(r2, text="➕ Seçileni Ekle", style="Accent.TButton", command=_add_host).pack(side="left", padx=2)

        # --- 1c: Elle Ekle ---
        t3 = ttk.Frame(nb, padding=8)
        nb.add(t3, text="  Elle Ekle  ")
        var_mname = tk.StringVar()
        var_mtype = tk.StringVar(value="tcp")
        var_mhost = tk.StringVar(value="192.168.1.172")
        var_mport = tk.StringVar(value="9100")
        var_mwin  = tk.StringVar()
        var_mtspl = tk.BooleanVar(value=True)   # Windows yazıcısı için ham TSPL
        g = ttk.Frame(t3)
        g.pack(fill="x")
        ttk.Label(g, text="Ad:").grid(row=0, column=0, sticky="e", **pad)
        ttk.Entry(g, textvariable=var_mname, width=30).grid(row=0, column=1, columnspan=3, sticky="w", **pad)
        ttk.Label(g, text="Tür:").grid(row=1, column=0, sticky="e", **pad)
        ttk.Radiobutton(g, text="Ağ (TSPL / TCP)", variable=var_mtype, value="tcp").grid(row=1, column=1, sticky="w")
        ttk.Radiobutton(g, text="Windows yazıcısı", variable=var_mtype, value="windows").grid(row=1, column=2, columnspan=2, sticky="w")
        ttk.Label(g, text="IP / Host:").grid(row=2, column=0, sticky="e", **pad)
        ttk.Entry(g, textvariable=var_mhost, width=20, font=("Consolas", 10)).grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(g, text="Port:").grid(row=2, column=2, sticky="e", **pad)
        ttk.Entry(g, textvariable=var_mport, width=8).grid(row=2, column=3, sticky="w", **pad)
        ttk.Label(g, text="Windows adı:").grid(row=3, column=0, sticky="e", **pad)
        ttk.Entry(g, textvariable=var_mwin, width=40).grid(row=3, column=1, columnspan=3, sticky="w", **pad)
        ttk.Label(g, text=r"(or. \\192.168.1.172\Gprinter GP-1125D)",
                  foreground=C["text_dark"]).grid(row=4, column=1, columnspan=3, sticky="w", padx=6)
        # TSPL ham gönder: Windows sürücüsü ölçeklemesini (taşma/şişme) atlar.
        # Yalnız Windows yazıcısı türü için anlamlı; TCP zaten ham TSPL gönderir.
        ttk.Checkbutton(
            g, variable=var_mtspl,
            text="TSPL etiket yazıcısı — ham gönder (sürücü ölçeklemesini atla)"
        ).grid(row=5, column=1, columnspan=3, sticky="w", padx=6, pady=(2, 0))

        def _manual_test():
            if var_mtype.get() == "tcp":
                try:
                    port = int(var_mport.get())
                except ValueError:
                    info("Port sayı olmalı.", ok=False)
                    return
                ok = printer.port_open(var_mhost.get().strip(), port, 1.5)
                info(f"{'✓ Bağlandı' if ok else '✗ Bağlanamadı'}: {var_mhost.get().strip()}:{port}", ok=ok)
            else:
                nm = var_mwin.get().strip()
                info("Windows yazıcı adı girin." if not nm else
                     f"Windows yazıcısı: {nm} (Kaydet sonrası deneme yazdırın).", ok=None)

        def _manual_add():
            if var_mtype.get() == "tcp":
                try:
                    port = int(var_mport.get())
                except ValueError:
                    info("Port sayı olmalı.", ok=False)
                    return
                host = var_mhost.get().strip()
                if not host:
                    info("IP / Host boş olamaz.", ok=False)
                    return
                _add_printer({"name": var_mname.get().strip() or f"{host}:{port}",
                              "type": "tcp", "host": host, "port": port})
            else:
                nm = var_mwin.get().strip()
                if not nm:
                    info("Windows yazıcı adı boş olamaz.", ok=False)
                    return
                _add_printer({"name": var_mname.get().strip() or nm,
                              "type": "windows", "win_name": nm,
                              "tspl": bool(var_mtspl.get())})

        r3 = ttk.Frame(t3)
        r3.pack(fill="x", pady=(8, 0))
        ttk.Button(r3, text="\U0001f50c Test", command=_manual_test).pack(side="left", padx=2)
        ttk.Button(r3, text="➕ Ekle", style="Accent.TButton", command=_manual_add).pack(side="left", padx=2)

        # ===================================================================
        # TAB 2 - KOPRU
        # ===================================================================
        baglan_f = ttk.LabelFrame(tab_kopru, text="Başka Bir Bilgisayarın Köprüsüne Bağlan", padding=8)
        baglan_f.pack(fill="x", pady=(0, 10))
        ttk.Label(baglan_f,
                  text="Başka bir bilgisayarda çalışan İlaçTarif'i yazıcı olarak kullanmak için\n"
                       "o bilgisayarda 'Köprü Sunucu'yu etkinleştirin, sonra aşağıya IP'sini girin.",
                  wraplength=560, justify="left").pack(anchor="w", pady=(0, 6))

        brow1 = ttk.Frame(baglan_f)
        brow1.pack(fill="x")
        ttk.Label(brow1, text="Köprü IP / Bilgisayar Adı:").pack(side="left")
        var_bridge_host = tk.StringVar(value="192.168.1.")
        ttk.Entry(brow1, textvariable=var_bridge_host, width=22, font=("Consolas", 10)).pack(side="left", padx=4)
        ttk.Label(brow1, text="Port:").pack(side="left")
        var_bridge_port = tk.StringVar(value=str(printer.PRINT_BRIDGE_PORT))
        ttk.Entry(brow1, textvariable=var_bridge_port, width=7).pack(side="left", padx=4)

        def _bridge_test():
            h = var_bridge_host.get().strip()
            try:
                p = int(var_bridge_port.get())
            except ValueError:
                info("Port sayı olmalı.", ok=False)
                return
            ok = printer.port_open(h, p, 2.0)
            info(f"{'✓ Köprüye bağlandı' if ok else '✗ Bağlanamadı'}: {h}:{p}", ok=ok)

        def _bridge_add():
            h = var_bridge_host.get().strip()
            if not h:
                info("IP / Bilgisayar adı boş olamaz.", ok=False)
                return
            try:
                p = int(var_bridge_port.get())
            except ValueError:
                info("Port sayı olmalı.", ok=False)
                return
            _add_printer({"name": f"Köprü ({h}:{p})", "type": "bridge", "host": h, "port": p})

        br_btns = ttk.Frame(baglan_f)
        br_btns.pack(fill="x", pady=(8, 0))
        ttk.Button(br_btns, text="\U0001f50c Test", command=_bridge_test).pack(side="left", padx=2)
        ttk.Button(br_btns, text="➕ Yazıcı Olarak Ekle", style="Accent.TButton",
                   command=_bridge_add).pack(side="left", padx=2)

        srv_f = ttk.LabelFrame(tab_kopru, text="Bu Bilgisayarı Köprü Sunucu Yap", padding=8)
        srv_f.pack(fill="x")

        srv_top = ttk.Frame(srv_f)
        srv_top.pack(fill="x", pady=(0, 8))
        lbl_srv_status = ttk.Label(srv_top, text="", font=("Segoe UI", 10, "bold"), width=36, anchor="w")
        lbl_srv_status.pack(side="left")
        btn_srv_toggle = ttk.Button(srv_top, text="► Başlat", width=12)
        btn_srv_toggle.pack(side="left", padx=(8, 0))

        var_bridge_enabled  = tk.BooleanVar(value=getattr(self, "print_bridge_enabled", False))
        var_bridge_srv_port = tk.StringVar(value=str(getattr(self, "print_bridge_port", printer.PRINT_BRIDGE_PORT)))

        def _bridge_status_refresh():
            running = bool(self._bridge_server and self._bridge_server.running)
            port_now = getattr(self, "print_bridge_port", printer.PRINT_BRIDGE_PORT)
            my_ip = printer.get_local_ip()
            if running:
                lbl_srv_status.config(
                    text=f"● ÇALIŞIYOR  —  {my_ip}:{port_now}",
                    foreground=green)
                btn_srv_toggle.config(text="■ Durdur")
                var_bridge_enabled.set(True)
            else:
                lbl_srv_status.config(text="● KAPALI", foreground=C.get("accent_red", "red"))
                btn_srv_toggle.config(text="► Başlat")
                var_bridge_enabled.set(False)

        def _bridge_srv_toggle():
            running = bool(self._bridge_server and self._bridge_server.running)
            if running:
                self._stop_bridge_server()
                self.print_bridge_enabled = False
            else:
                try:
                    p = max(1024, int(var_bridge_srv_port.get()))
                except (ValueError, TypeError):
                    p = printer.PRINT_BRIDGE_PORT
                self.print_bridge_port = p
                self.print_bridge_enabled = True
                self._start_bridge_server()
            _bridge_status_refresh()

        btn_srv_toggle.config(command=_bridge_srv_toggle)

        ttk.Checkbutton(
            srv_f,
            text="Uygulama açıldığında köprü sunucuyu otomatik başlat",
            variable=var_bridge_enabled,
        ).pack(anchor="w")

        sp_row = ttk.Frame(srv_f)
        sp_row.pack(fill="x", pady=(4, 0))
        ttk.Label(sp_row, text="Dinlenecek Port:").pack(side="left")
        ttk.Entry(sp_row, textvariable=var_bridge_srv_port, width=7).pack(side="left", padx=4)
        ttk.Label(sp_row,
                  text=f"(varsayılan {printer.PRINT_BRIDGE_PORT})",
                  foreground=C.get("text_muted", "gray"), font=("Segoe UI", 8)).pack(side="left")
        ttk.Label(srv_f,
                  text="Etkinleştirilirse, bu bilgisayar ağdaki diğer İlaçTarif örneklerinden gelen\n"
                       "yazdırma isteklerini kendi yerel yazıcısına iletir.",
                  foreground=C.get("text_muted", "gray"),
                  font=("Segoe UI", 8), justify="left").pack(anchor="w", pady=(8, 0))

        _bridge_status_refresh()

        # ===================================================================
        # TAB 3 - ECZANE & ETIKET
        # ===================================================================
        ef = ttk.LabelFrame(tab_eczane, text="Eczane Bilgileri  (etiket altında görünür)", padding=8)
        ef.pack(fill="x", pady=(0, 8))
        eg = ttk.Frame(ef)
        eg.pack(fill="x")
        _epad = {"padx": (0, 4), "pady": 2}
        ttk.Label(eg, text="Eczane Adı:", anchor="e", width=14).grid(row=0, column=0, sticky="e", **_epad)
        var_eczane_adi = tk.StringVar(value=getattr(self, "eczane_adi", ""))
        ttk.Entry(eg, textvariable=var_eczane_adi, width=36, font=("Segoe UI", 10)).grid(row=0, column=1, columnspan=3, sticky="ew", **_epad)
        ttk.Label(eg, text="Telefon:", anchor="e", width=14).grid(row=1, column=0, sticky="e", **_epad)
        var_eczane_tel = tk.StringVar(value=getattr(self, "eczane_tel", ""))
        ttk.Entry(eg, textvariable=var_eczane_tel, width=20, font=("Segoe UI", 10)).grid(row=1, column=1, sticky="w", **_epad)
        ttk.Label(eg, text="Adres:", anchor="e", width=14).grid(row=2, column=0, sticky="e", **_epad)
        var_eczane_adres = tk.StringVar(value=_s.get("eczane_adres", ""))
        ttk.Entry(eg, textvariable=var_eczane_adres, width=52, font=("Segoe UI", 10)).grid(row=2, column=1, columnspan=3, sticky="ew", **_epad)
        eg.columnconfigure(1, weight=1)
        ttk.Label(ef, text="Değişiklikler hemen uygulanır. Etiket altında 'Ad / Telefon' olarak görünür.",
                  foreground=C.get("text_muted", "gray"), font=("Segoe UI", 8)).pack(anchor="w", pady=(4, 0))

        # === Botanik fiyat kaynağı ===
        bf = ttk.LabelFrame(tab_eczane, text="Botanik Fiyat Kaynağı  (raf/kutu etiketinde barkoddan fiyat)", padding=8)
        bf.pack(fill="x", pady=(0, 8))
        _bpad = {"padx": (0, 4), "pady": 2}
        var_botanik_enabled = tk.BooleanVar(
            value=str(_s.get("botanik_db_enabled", "0")) in ("1", "true", "True"))
        ttk.Checkbutton(
            bf, variable=var_botanik_enabled,
            text="Botanik veritabanından CANLI fiyat çek  (kapalıyken yerel katalogdan okunur)"
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 4))
        ttk.Label(bf, text="Sunucu:", anchor="e", width=10).grid(row=1, column=0, sticky="e", **_bpad)
        var_botanik_server = tk.StringVar(value=_s.get("botanik_db_server", ""))
        ttk.Entry(bf, textvariable=var_botanik_server, width=26).grid(row=1, column=1, sticky="w", **_bpad)
        ttk.Label(bf, text="Veritabanı:", anchor="e", width=10).grid(row=1, column=2, sticky="e", **_bpad)
        var_botanik_db = tk.StringVar(value=_s.get("botanik_db_name", "eczane"))
        ttk.Entry(bf, textvariable=var_botanik_db, width=14).grid(row=1, column=3, sticky="w", **_bpad)
        ttk.Label(bf, text="Kullanıcı:", anchor="e", width=10).grid(row=2, column=0, sticky="e", **_bpad)
        var_botanik_user = tk.StringVar(value=_s.get("botanik_db_user", "calede"))
        ttk.Entry(bf, textvariable=var_botanik_user, width=26).grid(row=2, column=1, sticky="w", **_bpad)
        ttk.Label(bf, text="Şifre:", anchor="e", width=10).grid(row=2, column=2, sticky="e", **_bpad)
        var_botanik_pass = tk.StringVar(value=_s.get("botanik_db_pass", ""))
        ttk.Entry(bf, textvariable=var_botanik_pass, width=14, show="•").grid(row=2, column=3, sticky="w", **_bpad)
        _bupd = _s.get("botanik_katalog_updated", "") or "hiç"
        self._lbl_botanik_info = ttk.Label(
            bf, text=f"Yerel katalog son güncelleme: {_bupd}",
            foreground=C.get("text_muted", "gray"), font=("Segoe UI", 8))
        self._lbl_botanik_info.grid(row=4, column=0, columnspan=4, sticky="w", pady=(4, 0))
        brow = ttk.Frame(bf)
        brow.grid(row=3, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Button(brow, text="🔌 Bağlantıyı Test Et",
                   command=lambda: self._botanik_test_and_report(
                       var_botanik_server.get(), var_botanik_db.get(),
                       var_botanik_user.get(), var_botanik_pass.get())).pack(side="left", padx=(0, 6))
        ttk.Button(brow, text="⬇ Katalogu Şimdi Güncelle",
                   command=lambda: self._botanik_sync_now(
                       var_botanik_server.get(), var_botanik_db.get(),
                       var_botanik_user.get(), var_botanik_pass.get())).pack(side="left", padx=(0, 6))
        ttk.Button(brow, text="🔐 Botanik Erişimini Kur (calede)",
                   command=lambda: self._botanik_provision_now(
                       var_botanik_server, var_botanik_db,
                       var_botanik_user, var_botanik_pass,
                       var_botanik_enabled)).pack(side="left")

        lsf = ttk.LabelFrame(tab_eczane, text="Etiket Kağıt Boyutu  (fiziksel rulo boyutu)", padding=8)
        lsf.pack(fill="x", pady=(0, 8))

        LABEL_PRESETS = [
            ("60 × 40 mm  (standart)", 60.0, 40.0, 2.0),
            ("57 × 40 mm",             57.0, 40.0, 2.0),
            ("57 × 50 mm",             57.0, 50.0, 2.0),
            ("58 × 40 mm",             58.0, 40.0, 2.0),
            ("58 × 38 mm",             58.0, 38.0, 2.0),
            ("55 × 45 mm",             55.0, 45.0, 2.0),
            ("50 × 30 mm",             50.0, 30.0, 2.0),
            ("40 × 30 mm",             40.0, 30.0, 2.0),
            ("75 × 40 mm",             75.0, 40.0, 2.0),
        ]
        var_lw   = tk.StringVar(value=str(getattr(self, "label_w_mm",  60.0)))
        var_lh   = tk.StringVar(value=str(getattr(self, "label_h_mm",  40.0)))
        var_lgap = tk.StringVar(value=str(getattr(self, "label_gap_mm", 2.0)))
        var_dpi  = tk.StringVar(value=str(getattr(self, "printer_dpi", 203)))

        def _apply_preset(w, h, g):
            var_lw.set(str(w)); var_lh.set(str(h)); var_lgap.set(str(g))

        pb = ttk.Frame(lsf)
        pb.pack(fill="x", pady=(0, 6))
        for i, (lbl, w, h, g) in enumerate(LABEL_PRESETS):
            ttk.Button(pb, text=lbl, width=22,
                       command=lambda w=w, h=h, g=g: _apply_preset(w, h, g)
                       ).grid(row=i // 2, column=i % 2, padx=4, pady=2, sticky="w")

        cr = ttk.Frame(lsf)
        cr.pack(fill="x", pady=(4, 0))
        ttk.Label(cr, text="Özel:").pack(side="left")
        ttk.Label(cr, text="Genişlik (mm):").pack(side="left", padx=(8, 2))
        ttk.Entry(cr, textvariable=var_lw, width=6, font=("Consolas", 10)).pack(side="left")
        ttk.Label(cr, text="  Yükseklik (mm):").pack(side="left", padx=(8, 2))
        ttk.Entry(cr, textvariable=var_lh, width=6, font=("Consolas", 10)).pack(side="left")
        ttk.Label(cr, text="  Boşluk (mm):").pack(side="left", padx=(8, 2))
        ttk.Entry(cr, textvariable=var_lgap, width=5, font=("Consolas", 10)).pack(side="left")

        dr = ttk.Frame(lsf)
        dr.pack(fill="x", pady=(6, 0))
        ttk.Label(dr, text="Yazıcı DPI:").pack(side="left")
        for dv, dl in [("203", "203 DPI  (GPrinter GP-1125D ve çoğu model)"),
                       ("300", "300 DPI  (bazı yüksek çözünürluüklü modeller)")]:
            ttk.Radiobutton(dr, text=dl, variable=var_dpi, value=dv).pack(side="left", padx=(8, 0))
        ttk.Label(lsf,
                  text="Genişlik × Yükseklik: TSPL SIZE komutunda kullanılır. "
                       "Boşluk: etiketler arası gap (genellikle 2 mm). "
                       "DPI: yazıcı kafası çözünürluğü — yanlış seçilirse içerik küçük/büyük çıkar.",
                  foreground=C.get("text_muted", "gray"),
                  font=("Segoe UI", 8), wraplength=560).pack(anchor="w", pady=(4, 0))

        sf = ttk.LabelFrame(tab_eczane, text="Etiket Görünüm Boyutu  (ekranda görünen ölçek)", padding=8)
        sf.pack(fill="x")
        srow = tk.Frame(sf, background=C["bg_card"])
        srow.pack(fill="x")
        var_scale = tk.StringVar(value=str(getattr(self, "_label_display_scale", 1.0)))
        for val, lbl in [("1.0", "Tam Boy  (varsayılan)"), ("0.75", "Küçük  (¾)"), ("0.5", "Yarı Boy  (½)")]:
            ttk.Radiobutton(srow, text=lbl, variable=var_scale, value=val).pack(side="left", padx=(0, 20))

        # ===================================================================
        # TAB 4 - GENEL
        # ===================================================================
        qf = ttk.LabelFrame(tab_genel, text="Hızlı Seçenekler", padding=8)
        qf.pack(fill="x")
        qrow = tk.Frame(qf, background=C["bg_card"])
        qrow.pack(fill="x")
        # Medula izleyici Başlat/Durdur — üst banttan buraya taşındı. Durum üst
        # bantta salt-okunur gösterilir; açma/kapama buradan yapılır.
        ttk.Label(qrow, text="Medula izleyici:").pack(side="left", padx=(0, 4))
        self._btn_watcher = tk.Button(
            qrow, text="▶  Başlat",
            background=green, foreground="white",
            font=("Segoe UI", 9, "bold"), relief="flat",
            padx=12, pady=3, cursor="hand2",
            command=self._start_watcher,
        )
        self._btn_watcher.pack(side="left", padx=(0, 16))
        self._update_watcher_btn()   # mevcut duruma göre etiket/renk
        ttk.Checkbutton(qrow, text="\U0001f504 Canlı Tut",
                        variable=self.var_keepalive,
                        command=self._toggle_keepalive).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(qrow, text="✗ Eski Pencereleri Kapat",
                        variable=self.var_close_old,
                        command=self._on_toggle_close_old).pack(side="left", padx=(0, 16))
        _mode_lbl = "⬛ Küçük Ekran" if self._layout_mode == "normal" else "⬜ Tam Ekran"
        ttk.Button(qrow, text=_mode_lbl,
                   command=lambda: [self._toggle_layout_mode(), win.destroy()]).pack(side="left", padx=(0, 16))
        ttk.Button(qrow, text="⌨ Kısayollar",
                   command=self._open_shortcut_settings).pack(side="left")

        # Başlangıç / tepside çalışma
        bf = ttk.LabelFrame(tab_genel, text="Başlangıç ve Tepsi", padding=8)
        bf.pack(fill="x", pady=(8, 0))
        self.var_autostart = tk.BooleanVar(value=getattr(self, "autostart_enabled", True))
        ttk.Checkbutton(
            bf, text="🚀  Bilgisayar açılınca otomatik başlat (tepside gizli)",
            variable=self.var_autostart,
            command=self._on_toggle_autostart,
        ).pack(side="top", anchor="w")
        ttk.Label(bf,
                  text="Program açıldığında saat yanındaki tepsiye yerleşir. Pencereyi "
                       "✕ ile kapatmak programı kapatmaz — tepsi simgesinden tekrar "
                       "açabilir, oradaki 'Çıkış' ile tamamen kapatabilirsiniz.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # Kalıcı etiket kısıtlamaları
        ef = ttk.LabelFrame(tab_genel, text="Etiket Kısıtlamaları (Kalıcı)", padding=8)
        ef.pack(fill="x", pady=(8, 0))
        erow = tk.Frame(ef, background=C["bg_card"])
        erow.pack(fill="x")
        _ob_print_var   = tk.BooleanVar(value=self._only_basic_var.get())
        _ob_display_var = tk.BooleanVar(value=self._only_basic_display_var.get())
        ttk.Checkbutton(
            erow, text="🖨  Sadece temel etiketi bastır (A)",
            variable=_ob_print_var,
        ).pack(side="left", padx=(0, 24))
        ttk.Checkbutton(
            erow, text="👁  Ekranda sadece temel etiketi göster (A)",
            variable=_ob_display_var,
        ).pack(side="left")
        ttk.Label(ef,
                  text="Bu seçenekler kaydedildiğinde kalıcı olur — ana ekrandaki "
                       "geçici kutulardan bağımsız çalışır.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w",
                  ).pack(fill="x", pady=(4, 0))

        # Hasta bilgi etiketi varsayılanı
        hef = ttk.LabelFrame(tab_genel, text="Hasta Bilgi Etiketi", padding=8)
        hef.pack(fill="x", pady=(8, 0))
        _hasta_def_var = tk.BooleanVar(value=getattr(self, "_hasta_label_default", False))
        ttk.Checkbutton(
            hef,
            text="🧾  Hasta etiketi kutusu varsayılan olarak İŞARETLİ gelsin",
            variable=_hasta_def_var,
        ).pack(fill="x", anchor="w")
        _hasta_debt_var = tk.BooleanVar(value=getattr(self, "_hasta_show_debt", True))
        ttk.Checkbutton(
            hef,
            text="💳  Hasta etiketinde 'TOPLAM BORÇ' (veresiye) tutarı görünsün",
            variable=_hasta_debt_var,
        ).pack(fill="x", anchor="w", pady=(2, 0))
        ttk.Label(hef,
                  text="Kapalı (varsayılan): her reçetede 'Hasta Etiketi' kutusu işaretsiz "
                       "gelir; kullanıcı elle işaretlemeden hasta etiketi basılmaz.\n"
                       "Etiket: tarih, ad-soyad, telefon, reçete tutarı ve (açıksa) toplam "
                       "borç tutarını gösterir. 'TOPLAM BORÇ' satırını tek bir etikette "
                       "etiketin sağ-alt köşesindeki ✕ ile de gizleyebilirsiniz.\n"
                       "Kısayol: Shift + Scroll Lock (kutudan bağımsız basar).",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # Parenteral (enjeksiyon) uygulama yolu ayarı
        pf = ttk.LabelFrame(tab_genel, text="Enjeksiyonluk İlaçlar (Parenteral)", padding=8)
        pf.pack(fill="x", pady=(8, 0))
        _par_route_var = tk.BooleanVar(
            value=_s.get("erecete_parenteral_route", "0") == "1")
        ttk.Checkbutton(
            pf,
            text="💉  İntravenöz/intramüsküler bilgiyi e-reçeteden alıp etikete yazdır",
            variable=_par_route_var,
        ).pack(fill="x", anchor="w")
        ttk.Label(pf,
                  text="Kapalı (varsayılan): ampul/flakon/enjektör/IV solüsyon ilaçlarda "
                       "yalnız “SAĞLIK PERSONELİ TARAFINDAN UYGULANIR” yazılır.\n"
                       "Açık: e-reçete “Kullanım Şekli” alanındaki yola göre — kas içine "
                       "(“…KAS İÇİNE UYGULANIR”), damar içine (“…DAMAR İÇİNE (SERUM İLE) "
                       "UYGULANIR”), cilt altı (“CİLT ALTI (SUBKUTAN) YAĞ DOKUSUNA "
                       "UYGULANIR”) — yazılır.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # Stok kontrolü — elde olmayan ilacın etiketini varsayılan basma
        sf = ttk.LabelFrame(tab_genel, text="Stok Kontrolü", padding=8)
        sf.pack(fill="x", pady=(8, 0))
        _oos_var = tk.BooleanVar(
            value=_s.get("suppress_out_of_stock", "0") == "1")
        ttk.Checkbutton(
            sf,
            text="📦  Hastaya verilecek ilaç elde yok ise etiket çıkarma",
            variable=_oos_var,
        ).pack(fill="x", anchor="w")
        ttk.Label(sf,
                  text="Kapalı (varsayılan): tüm ilaçların etiketi işaretli gelir.\n"
                       "Açık: reçete KAYDEDİLDİKTEN sonra eczane stoğu düşülür. Stok, "
                       "verilecek kutu adedi kadar (veya daha fazla) eksiye düşmüşse "
                       "(elimizde o ilaç kalmamışsa) etiketin baskı işareti PASİF "
                       "gelir — etiket basılmaz; istenirse karttan açılıp basılabilir.\n"
                       "Örn. reçetede 4 kutu, stok -4 → elde yok (pasif). Reçetede 4 "
                       "kutu, stok -3 → 1 kutu elde var → etiket basılır.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # İTS Karekod okutma → sadece okutulanları bas
        kf = ttk.LabelFrame(tab_genel, text="İTS Karekod Okutma", padding=8)
        kf.pack(fill="x", pady=(8, 0))
        _kkp_var = tk.BooleanVar(
            value=_s.get("karekod_scan_print", "0") == "1")
        ttk.Checkbutton(
            kf,
            text="📦  Sadece okutulan karekodların etiketini bas (Ctrl+Shift+Ğ)",
            variable=_kkp_var,
        ).pack(fill="x", anchor="w")
        ttk.Label(kf,
                  text="Açık: 'E-Reçete Görüntüle'den GELMEYEN (doğrudan açılmış, reçete "
                       "başı olmayan) bir reçetede İTS Karekod İşlemleri ekranındaki "
                       "okutulan karekodlar arka planda sayılır (hangi ilaçtan kaç kutu). "
                       "Karekod okutmak baskı işaretini değiştirmez. Kısayola (varsayılan "
                       "Ctrl+Shift+Ğ) basınca YALNIZ en az bir kez okutulmuş ilaçların "
                       "etiketi basılır; hiç okutulmayanlar basılmaz. Kısayol, Kısayol "
                       "Ayarları'ndan değiştirilebilir.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # Medula pencere durum çerçevesi (yeşil/turuncu/mavi)
        mtf = ttk.LabelFrame(tab_genel, text="Medula Pencere Durumu", padding=8)
        mtf.pack(fill="x", pady=(8, 0))
        _mto_var = tk.BooleanVar(
            value=_s.get("medula_theme_overlay", "1") == "1")
        ttk.Checkbutton(
            mtf,
            text="🟢  Medula penceresini reçete durumuna göre renkli çerçeveyle boya",
            variable=_mto_var,
        ).pack(fill="x", anchor="w")
        ttk.Label(mtf,
                  text="Açık (varsayılan): Medula ön plandayken pencerenin etrafına ince "
                       "renkli çerçeve çizilir.\n"
                       "  • 🟢 YEŞİL — reçete sonlanmış (İTS karekod işlemi tamamlandı).\n"
                       "  • 🟠 TURUNCU — karekod ekranında EKSİK karekod var, sonlandırılmamış.\n"
                       "  • 🔵 MAVİ — reçete açık / işlem sürüyor (henüz sonlanmamış).\n"
                       "Çerçeve Medula sayfasına dokunmaz, tıklamayı geçirir ve yalnız "
                       "Medula ön plandayken görünür.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # Reçete sonu (SGK) ekranı görünüm filtreleri
        rsf = ttk.LabelFrame(tab_genel, text="Reçete Sonu (SGK) Ekranı", padding=8)
        rsf.pack(fill="x", pady=(8, 0))
        _hide_unpaid_var = tk.BooleanVar(value=_s.get("hide_unpaid_final", "0") == "1")
        _hide_removed_var = tk.BooleanVar(value=_s.get("hide_removed_final", "0") == "1")
        ttk.Checkbutton(
            rsf,
            text="🚫  Reçete sonu ekranında ödenmeyen (SGK) ilacı gösterme",
            variable=_hide_unpaid_var,
        ).pack(fill="x", anchor="w")
        ttk.Checkbutton(
            rsf,
            text="🗑  Reçete sonu ekranından çıkarılan ilaçları gösterme",
            variable=_hide_removed_var,
        ).pack(fill="x", anchor="w", pady=(2, 0))
        ttk.Label(rsf,
                  text="Bu filtreler yalnız 'Reçete Sonu (SGK)' sekmesini etkiler; reçete "
                       "başı sekmesi tüm ilaçları gösterir. Gizlenen ilaçlar yine basılabilir: "
                       "SGK'nın ödemediği ilaçları Ctrl+Shift+Ü kısayolu ile yazdırabilirsiniz.",
                  font=("Segoe UI", 8), foreground=C.get("text_muted", "gray"),
                  wraplength=600, anchor="w", justify="left",
                  ).pack(fill="x", pady=(4, 0))

        # ===================================================================
        # TAB 5 - GRUPLAR
        # ===================================================================
        gf = ttk.LabelFrame(tab_grup,
                            text="İlaç Grubu Etiket Varsayılanları  (ATC öneki → hangi etiket işaretli çıksın)",
                            padding=8)
        gf.pack(fill="both", expand=True)

        _KIND_LABELS = [("A", "A Kullanım"), ("B", "B Hazırlama"), ("C", "C Uyarı"), ("D", "D Dikkat")]

        glist = tk.Listbox(gf, height=8, font=("Consolas", 10), activestyle="dotbox")
        glist.pack(fill="both", expand=True, padx=2, pady=(0, 4))

        def _glist_refresh():
            glist.delete(0, "end")
            for gd in group_defaults:
                parts = []
                for k, _ in _KIND_LABELS:
                    if k in gd:
                        parts.append(f"{k}:{'✓' if gd[k] else '✗'}")
                glist.insert("end", f"  {gd.get('atc','?'):<8}  →  {' '.join(parts)}")

        _glist_refresh()

        grow = tk.Frame(gf, background=C["bg_card"])
        grow.pack(fill="x")
        ttk.Label(grow, text="ATC öneki:").pack(side="left")
        var_gatc = tk.StringVar()
        ttk.Entry(grow, textvariable=var_gatc, width=8, font=("Consolas", 10)).pack(side="left", padx=(2, 10))
        gvars = {}
        for k, lbl in _KIND_LABELS:
            v = tk.BooleanVar(value=(k == "A"))
            gvars[k] = v
            ttk.Checkbutton(grow, text=lbl, variable=v).pack(side="left", padx=(0, 6))

        def _gadd():
            pfx = var_gatc.get().strip().upper()
            if not pfx:
                info("ATC öneki boş olamaz.", ok=False)
                return
            for gd in group_defaults:
                if gd.get("atc", "").upper() == pfx:
                    for k in gvars:
                        gd[k] = gvars[k].get()
                    _glist_refresh()
                    info(f"✓ {pfx} güncellendi.", ok=True)
                    return
            entry = {"atc": pfx}
            for k in gvars:
                entry[k] = gvars[k].get()
            group_defaults.append(entry)
            _glist_refresh()
            info(f"➕ {pfx} eklendi.", ok=True)

        def _gdel():
            sel = glist.curselection()
            if not sel:
                info("Önce listeden bir satır seçin.", ok=False)
                return
            removed = group_defaults.pop(sel[0])
            _glist_refresh()
            info(f"\U0001f5d1 {removed.get('atc')} silindi.")

        def _gsel(evt=None):
            sel = glist.curselection()
            if not sel:
                return
            gd = group_defaults[sel[0]]
            var_gatc.set(gd.get("atc", ""))
            for k in gvars:
                gvars[k].set(bool(gd.get(k, k == "A")))

        glist.bind("<<ListboxSelect>>", _gsel)

        gbtn = ttk.Frame(gf)
        gbtn.pack(fill="x", pady=(4, 0))
        ttk.Button(gbtn, text="➕ Ekle / Güncelle", style="Accent.TButton", command=_gadd).pack(side="left", padx=2)
        ttk.Button(gbtn, text="\U0001f5d1 Sil", style="Warn.TButton", command=_gdel).pack(side="left", padx=2)
        ttk.Label(gbtn, text="  J01=antibiyotik  N05A=antipsikotik  N06A=antidepresan  R03=astım",
                  foreground=C["text_dark"], font=("Segoe UI", 8)).pack(side="left", padx=6)

        # ===================================================================
        # KAYDET / KAPAT
        # ===================================================================
        def _save_close():
            if not printers:
                messagebox.showwarning("Yazıcı", "En az bir yazıcı ekleyin.", parent=win)
                return
            if state["active"] not in {p["name"] for p in printers}:
                state["active"] = printers[0]["name"]
            act = next((p for p in printers if p["name"] == state["active"]), printers[0])
            try:
                new_scale = float(var_scale.get())
            except (ValueError, TypeError):
                new_scale = 1.0
            new_scale = max(0.25, min(2.0, new_scale))

            def _flt(v, default):
                try: return float(v)
                except (ValueError, TypeError): return default

            with get_connection() as conn:
                save_setting(conn, "printers_json", json.dumps(printers, ensure_ascii=False))
                save_setting(conn, "printer_active", state["active"])
                if act.get("type") == "tcp":
                    save_setting(conn, "printer_host", act.get("host", ""))
                    save_setting(conn, "printer_port", str(act.get("port", 9100)))
                save_setting(conn, "label_display_scale", str(new_scale))
                save_setting(conn, "group_label_defaults", json.dumps(group_defaults, ensure_ascii=False))
                save_setting(conn, "print_bridge_enabled", "1" if var_bridge_enabled.get() else "0")
                try:
                    _bport = max(1024, int(var_bridge_srv_port.get()))
                except (ValueError, TypeError):
                    _bport = printer.PRINT_BRIDGE_PORT
                save_setting(conn, "print_bridge_port", str(_bport))
                save_setting(conn, "eczane_adi",     var_eczane_adi.get().strip())
                save_setting(conn, "eczane_telefon", var_eczane_tel.get().strip())
                save_setting(conn, "eczane_adres",   var_eczane_adres.get().strip())
                save_setting(conn, "botanik_db_enabled", "1" if var_botanik_enabled.get() else "0")
                save_setting(conn, "botanik_db_server", var_botanik_server.get().strip())
                save_setting(conn, "botanik_db_name",   var_botanik_db.get().strip())
                save_setting(conn, "botanik_db_user",   var_botanik_user.get().strip())
                save_setting(conn, "botanik_db_pass",   var_botanik_pass.get())
                lw   = _flt(var_lw.get(),   60.0)
                lh   = _flt(var_lh.get(),   40.0)
                lgap = _flt(var_lgap.get(),  2.0)
                save_setting(conn, "label_w_mm",   str(lw))
                save_setting(conn, "label_h_mm",   str(lh))
                save_setting(conn, "label_gap_mm", str(lgap))
                try:
                    dpi_val = int(var_dpi.get())
                except (ValueError, TypeError):
                    dpi_val = 203
                save_setting(conn, "printer_dpi", str(dpi_val))
                save_setting(conn, "only_basic_print",   "1" if _ob_print_var.get()   else "0")
                save_setting(conn, "only_basic_display", "1" if _ob_display_var.get() else "0")
                save_setting(conn, "erecete_parenteral_route",
                             "1" if _par_route_var.get() else "0")
                save_setting(conn, "suppress_out_of_stock",
                             "1" if _oos_var.get() else "0")
                save_setting(conn, "karekod_scan_print",
                             "1" if _kkp_var.get() else "0")
                save_setting(conn, "medula_theme_overlay",
                             "1" if _mto_var.get() else "0")
                save_setting(conn, "hide_unpaid_final",
                             "1" if _hide_unpaid_var.get() else "0")
                save_setting(conn, "hide_removed_final",
                             "1" if _hide_removed_var.get() else "0")
                save_setting(conn, "hasta_label_default",
                             "1" if _hasta_def_var.get() else "0")
                save_setting(conn, "hasta_label_show_debt",
                             "1" if _hasta_debt_var.get() else "0")
            self._erecete_parenteral_route = _par_route_var.get()
            _oos_changed = _oos_var.get() != getattr(self, "_suppress_out_of_stock", False)
            self._suppress_out_of_stock = _oos_var.get()
            self._karekod_scan_print = _kkp_var.get()
            self._medula_theme_overlay = _mto_var.get()
            _ov = getattr(self, "_medula_overlay", None)
            if _ov is not None:
                _ov.set_enabled(_mto_var.get())
            _hide_changed = (
                _hide_unpaid_var.get() != getattr(self, "_hide_unpaid_final", False)
                or _hide_removed_var.get() != getattr(self, "_hide_removed_final", False)
            )
            self._hide_unpaid_final = _hide_unpaid_var.get()
            self._hide_removed_final = _hide_removed_var.get()
            self._hasta_label_default = _hasta_def_var.get()
            self._hasta_show_debt = _hasta_debt_var.get()

            # Kalıcı etiket kısıtlamalarını ana ekran BooleanVar'larına yansıt
            _display_changed = _ob_display_var.get() != self._only_basic_display_var.get()
            self._only_basic_var.set(_ob_print_var.get())
            self._only_basic_display_var.set(_ob_display_var.get())
            # Görünüm / stok / reçete-sonu-filtre ayarı değiştiyse mevcut reçeteyi yeniden render et
            if _display_changed or _oos_changed or _hide_changed:
                _s = self._get_selected_or_last_set()
                if _s is not None:
                    self._render_set(_s)

            self.eczane_adi   = var_eczane_adi.get().strip()
            self.eczane_tel   = var_eczane_tel.get().strip()
            self.label_w_mm   = _flt(var_lw.get(),   60.0)
            self.label_h_mm   = _flt(var_lh.get(),   40.0)
            self.label_gap_mm = _flt(var_lgap.get(),  2.0)
            try:
                self.printer_dpi = int(var_dpi.get())
            except (ValueError, TypeError):
                self.printer_dpi = 203
            self.printers = printers
            self.printer_active = state["active"]
            self._sync_active_printer()
            try:
                _new_bridge_port = max(1024, int(var_bridge_srv_port.get()))
            except Exception:
                _new_bridge_port = printer.PRINT_BRIDGE_PORT
            self.print_bridge_port    = _new_bridge_port
            self.print_bridge_enabled = var_bridge_enabled.get()
            self._label_display_scale = new_scale
            for stage in ("early", "final"):
                self._relayout_stage_cards(stage)
            self.status.set(f"⚙ Aktif yazıcı: {state['active']} ({printer.cfg_label(act)})")
            win.destroy()

        ttk.Button(_btns_row, text="\U0001f4be Kaydet ve Kapat", style="Accent.TButton",
                   command=_save_close).pack(side="right", padx=4)

        _refresh_saved()
        win.update_idletasks()
        x = self.winfo_rootx() + max(0, (self.winfo_width() - win.winfo_width()) // 2)
        y = self.winfo_rooty() + 50
        win.geometry(f"+{max(0, x)}+{max(0, y)}")

    # ------------------------------------------------------------------
    def _build_ui(self):
        C = COLORS

        # === STATUS BAR (alt) ===
        self.status = tk.StringVar(value="Hazır.")
        status_bar = tk.Frame(self, background=C["bg_strip"], height=26)
        status_bar.pack(fill="x", side="bottom")
        status_bar.pack_propagate(False)
        tk.Label(status_bar, textvariable=self.status,
                 background=C["bg_strip"], foreground=C["text_light"],
                 font=("Segoe UI", 9), anchor="w").pack(fill="both", expand=True, padx=10)

        # === NOTEBOOK (sekmeler en üstte) ===
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=(2, 6))
        self.tab_manual = ttk.Frame(notebook, style="Panel.TFrame")
        self.tab_auto = ttk.Frame(notebook, style="Panel.TFrame")
        # NOT: "Veri Ekle/Düzenle" artık ana sekme değil → Ayarlar penceresine
        # taşındı (bkz. _open_settings). Ana sekme çubuğu sadeleşti.
        self.tab_designer = ttk.Frame(notebook, style="Panel.TFrame")
        self.tab_shelf = ttk.Frame(notebook, style="Panel.TFrame")
        self.tab_box = ttk.Frame(notebook, style="Panel.TFrame")
        self.tab_kargo = ttk.Frame(notebook, style="Panel.TFrame")
        self.tab_majistral = ttk.Frame(notebook, style="Panel.TFrame")
        notebook.add(self.tab_auto, text=" 🔄 Medula ")
        notebook.add(self.tab_manual, text=" ✏ Manuel ")
        notebook.add(self.tab_designer, text=" 🎨 Elle Etiket ")
        notebook.add(self.tab_shelf, text=" 🏷 Raf Etiketi ")
        notebook.add(self.tab_box, text=" 🏪 Kutu Fiyat ")
        notebook.add(self.tab_kargo, text=" 📦 Kargo Etiketi ")
        notebook.add(self.tab_majistral, text=" 🧪 Majistral Etiketi ")
        notebook.select(self.tab_auto)
        self.notebook = notebook

        # === ÜST ARAÇ BANDI (sekmelerin üstünde tam-genişlik satır) ===
        # İLAÇ TARİF başlığı + watcher kontrolleri + Botanik burada gruplanır.
        # Eskiden sekme şeridine place() ile bindiriliyordu; dar/yüksek-DPI
        # ekranlarda sekmelerle çakışıyordu → artık ayrı reflow eden satır.
        self._build_top_overlay()

        self._build_manual_tab(self.tab_manual)
        self._build_auto_tab(self.tab_auto)
        # "Veri Ekle/Düzenle" Ayarlar penceresinde lazım olunca kurulur
        # (_open_settings içinde) → ana ekran açılışı hafifler.
        self.data_editor = None
        # Elle etiket tasarımcısı (4. sekme; lazy import)
        from .label_designer import LabelDesignerTab
        self.label_designer = LabelDesignerTab(self.tab_designer, self)
        self.label_designer.pack(fill="both", expand=True)
        self._build_shelf_label_tab(self.tab_shelf)
        self._build_box_label_tab(self.tab_box)
        self._build_kargo_label_tab(self.tab_kargo)
        self._build_magistral_label_tab(self.tab_majistral)

    # ------------------------------------------------------------------
    # Kutu üstü fiyat etiketi sekmesi (6.) — yalnız fiyat + boyut + ayrı yazıcı
    # ------------------------------------------------------------------
    _BOX_ACTIVE_SENTINEL = "★ Aktif (ana) yazıcı"

    @staticmethod
    def _fmt_mm(v: float) -> str:
        """mm değerini kısa biçimle (40.0 → '40', 25.5 → '25.5')."""
        try:
            return str(int(v)) if float(v).is_integer() else str(v)
        except (TypeError, ValueError):
            return str(v)

    def _build_box_label_tab(self, parent):
        """Kutu üstüne yapıştırılan küçük fiyat etiketi sekmesi.

        Sade tasarım: yalnız fiyat (ör. '198,55 TL') + serbest etiket boyutu +
        ana etiket yazıcısından BAĞIMSIZ seçilebilen yazıcı. Sağda canlı önizleme.
        """
        C = COLORS
        self._box_preview_imgtk = None

        wrap = ttk.Frame(parent, style="Panel.TFrame")
        wrap.pack(fill="both", expand=True, padx=14, pady=12)

        # --- Sol sütun: girişler ---
        left = ttk.Frame(wrap, style="Panel.TFrame")
        left.pack(side="left", fill="y", anchor="n")

        box = ttk.LabelFrame(left, text="Kutu Üstü Fiyat Etiketi", padding=12)
        box.pack(fill="x", pady=(0, 10))
        ttk.Label(box, text="Fiyat (örn. 198,55 TL):", style="Panel.TLabel").grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
        self.var_box_price = tk.StringVar()
        ent = ttk.Entry(box, textvariable=self.var_box_price,
                        font=("Segoe UI", 22, "bold"), width=14, justify="center")
        ent.grid(row=1, column=0, columnspan=3, sticky="we", pady=(0, 8))
        ttk.Label(box, text="Adet:", style="Panel.TLabel").grid(
            row=2, column=0, sticky="e", padx=(0, 6))
        self.var_box_copies = tk.IntVar(value=1)
        ttk.Spinbox(box, from_=1, to=99, textvariable=self.var_box_copies,
                    width=5).grid(row=2, column=1, sticky="w")

        sz = ttk.LabelFrame(left, text="Etiket Boyutu (mm)", padding=12)
        sz.pack(fill="x", pady=(0, 10))
        ttk.Label(sz, text="Genişlik:", style="Panel.TLabel").grid(
            row=0, column=0, sticky="e", padx=(0, 6), pady=2)
        self.var_box_w = tk.StringVar(value=self._fmt_mm(self.box_label_w_mm))
        ttk.Entry(sz, textvariable=self.var_box_w, width=7).grid(row=0, column=1, sticky="w")
        ttk.Label(sz, text="mm", style="PanelMuted.TLabel").grid(
            row=0, column=2, sticky="w", padx=(2, 0))
        ttk.Label(sz, text="Yükseklik:", style="Panel.TLabel").grid(
            row=1, column=0, sticky="e", padx=(0, 6), pady=2)
        self.var_box_h = tk.StringVar(value=self._fmt_mm(self.box_label_h_mm))
        ttk.Entry(sz, textvariable=self.var_box_h, width=7).grid(row=1, column=1, sticky="w")
        ttk.Label(sz, text="mm", style="PanelMuted.TLabel").grid(
            row=1, column=2, sticky="w", padx=(2, 0))

        pr = ttk.LabelFrame(left, text="Yazıcı (bu etiketler için ayrı sürüm)", padding=12)
        pr.pack(fill="x", pady=(0, 10))
        self.var_box_printer = tk.StringVar()
        self._box_printer_combo = ttk.Combobox(
            pr, textvariable=self.var_box_printer, state="readonly", width=32,
            postcommand=lambda: self._refresh_box_printer_list(preserve=True),
        )
        self._box_printer_combo.pack(fill="x")
        self._box_printer_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._save_box_settings(quiet=True))
        self._refresh_box_printer_list()

        # Eylem barı: birincil "Yazdır" accent + geniş; "Kaydet" ikincil ayar
        # olduğundan küçültülüp sağa demote edildi (tutarlı düzen — bkz. Raf).
        btns = ttk.Frame(left, style="Panel.TFrame")
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="🖨  Yazdır", style="Accent.TButton",
                   command=self._print_box_label).pack(side="left", fill="x",
                                                        expand=True, ipady=4)
        ttk.Button(btns, text="💾 Kaydet",
                   command=self._save_box_settings).pack(side="right", padx=(8, 0))

        # --- Sağ sütun: canlı önizleme ---
        right = ttk.Frame(wrap, style="Panel.TFrame")
        right.pack(side="left", fill="both", expand=True, padx=(18, 0), anchor="n")
        ttk.Label(right, text="Önizleme", style="Panel.TLabel").pack(anchor="w")
        self._box_preview_lbl = tk.Label(right, relief="solid", borderwidth=1,
                                         background="#cbd5e1")
        self._box_preview_lbl.pack(anchor="nw", pady=(4, 0))

        for v in (self.var_box_price, self.var_box_w, self.var_box_h):
            v.trace_add("write", lambda *a: self._update_box_preview())
        ent.bind("<Return>", lambda _e: self._print_box_label())
        self._update_box_preview()

    def _refresh_box_printer_list(self, preserve: bool = False):
        """Combobox yazıcı listesini güncelle. preserve=True → seçimi koru."""
        names = [self._BOX_ACTIVE_SENTINEL] + [
            p.get("name", "") for p in getattr(self, "printers", []) if p.get("name")
        ]
        self._box_printer_combo.configure(values=names)
        if preserve and self.var_box_printer.get() in names:
            return
        want = getattr(self, "box_printer_active", "") or ""
        self.var_box_printer.set(want if want in names else self._BOX_ACTIVE_SENTINEL)

    def _box_label_size_mm(self) -> tuple[float, float]:
        """Girilen boyutu (mm) makul sınırlara kıstırarak döndür."""
        def _p(var, default):
            try:
                return float((var.get() or "").replace(",", "."))
            except (TypeError, ValueError):
                return default
        w = min(120.0, max(15.0, _p(self.var_box_w, self.box_label_w_mm)))
        h = min(120.0, max(10.0, _p(self.var_box_h, self.box_label_h_mm)))
        return w, h

    def _selected_box_printer_cfg(self) -> dict:
        """Bu sekmede seçili yazıcının cfg'i (sentinel → aktif/ana yazıcı)."""
        name = (self.var_box_printer.get() or "").strip()
        if not name or name == self._BOX_ACTIVE_SENTINEL:
            return self._active_printer_cfg()
        return self._printer_cfg_by_name(name)

    def _update_box_preview(self, *_a):
        from PIL import ImageTk
        from ..label_render import render_box_price_label
        try:
            w_mm, h_mm = self._box_label_size_mm()
            img = render_box_price_label(
                self.var_box_price.get(), width_mm=w_mm, height_mm=h_mm,
                dpi=getattr(self, "printer_dpi", 203),
            )
            scale = min(380 / img.width, 260 / img.height, 4.0)
            disp = img.resize((max(1, int(img.width * scale)),
                               max(1, int(img.height * scale))))
            self._box_preview_imgtk = ImageTk.PhotoImage(disp)
            self._box_preview_lbl.configure(image=self._box_preview_imgtk)
        except Exception:
            log.exception("Kutu fiyat etiketi önizleme hatası")

    def _save_box_settings(self, quiet: bool = False):
        """Kutu etiketi boyutunu + seçili yazıcıyı ayarlara yaz (kalıcı)."""
        from ..db import get_connection, save_setting
        w_mm, h_mm = self._box_label_size_mm()
        self.box_label_w_mm, self.box_label_h_mm = w_mm, h_mm
        sel = (self.var_box_printer.get() or "").strip()
        self.box_printer_active = "" if sel == self._BOX_ACTIVE_SENTINEL else sel
        try:
            with get_connection() as conn:
                save_setting(conn, "box_label_w_mm", self._fmt_mm(w_mm))
                save_setting(conn, "box_label_h_mm", self._fmt_mm(h_mm))
                save_setting(conn, "box_printer_active", self.box_printer_active)
            if not quiet:
                self.status.set("💾 Kutu fiyat etiketi boyutu/yazıcısı kaydedildi.")
        except Exception:
            log.exception("Kutu fiyat etiketi ayarı kaydetme hatası")
            self.status.set("❌ Kutu fiyat etiketi ayarı kaydedilemedi.")

    def _print_box_label(self):
        """Girilen fiyatı, seçili yazıcıya kutu-üstü fiyat etiketi olarak bas."""
        price = (self.var_box_price.get() or "").strip()
        if not price:
            self.status.set("⚠ Kutu fiyat etiketi: fiyat boş, basılmadı.")
            return
        try:
            copies = max(1, int(self.var_box_copies.get()))
        except (TypeError, ValueError, tk.TclError):
            copies = 1
        w_mm, h_mm = self._box_label_size_mm()
        from ..label_render import render_box_price_label
        try:
            img = render_box_price_label(
                price, width_mm=w_mm, height_mm=h_mm,
                dpi=getattr(self, "printer_dpi", 203),
            )
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            out = self._preview_dir / f"kutu_fiyat_{ts}.png"
            img.save(out)
        except Exception:
            log.exception("Kutu fiyat etiketi üretme hatası")
            self.status.set("❌ Kutu fiyat etiketi üretilemedi.")
            return
        cfg = self._selected_box_printer_cfg()

        def worker():
            try:
                from .. import printer
                printer.send_image(
                    out, cfg, copies=copies, label_mm=(w_mm, h_mm),
                    gap_mm=getattr(self, "label_gap_mm", 2.0),
                    dpi=getattr(self, "printer_dpi", 203),
                )
                addr = printer.cfg_label(cfg)
                self.after(0, lambda: self.status.set(
                    f"📦 Kutu fiyat etiketi ×{copies} {addr} yazıcısına gönderildi."))
            except Exception as e:
                log.exception("Kutu fiyat etiketi baskı hatası")
                self.after(0, lambda err=str(e): self.status.set(
                    f"❌ Kutu fiyat etiketi yazdırılamadı: {err}"))

        threading.Thread(target=worker, daemon=True, name="box-price-print").start()

    # ------------------------------------------------------------------
    # Majistral (yapma ilaç) etiketi sekmesi — İÇERİK + KULLANIM etiketi
    # ------------------------------------------------------------------
    # İki ayrı etiket AYRI basılır: (1) içerik etiketi = ilaç adı başlık + maddeler
    # teker teker (madde + miktar) + tarihler; (2) kullanım/bilgilendirme etiketi =
    # ilaç adı + kullanım yolu (dahilen/haricen) + hasta/doktor + kullanım şekli +
    # saklama + uyarılar. İçerik/metin tek etikete sığmazsa otomatik 2.+ etikete taşar
    # (render fonksiyonları sayfa listesi döndürür → hepsi sırayla basılır).
    def _build_magistral_label_tab(self, parent):
        C = COLORS
        self._mag_preview_imgtk = None
        self._mag_ings: list[tuple[str, str]] = []   # [(madde, miktar)]
        self._mag_pages = []                          # son render edilen sayfalar
        self._mag_page_idx = 0

        # Alt eylem çubuğu — HER ZAMAN görünür (içerik uzasa da butonlar kaybolmaz).
        action_bar = ttk.Frame(parent, style="Panel.TFrame")
        action_bar.pack(side="bottom", fill="x", padx=12, pady=(2, 8))

        wrap = ttk.Frame(parent, style="Panel.TFrame")
        wrap.pack(side="top", fill="both", expand=True, padx=12, pady=(10, 4))

        # --- Sol sütun: KAYDIRILABİLİR (içerik ekran boyundan uzun olabilir) ---
        left_outer = ttk.Frame(wrap, style="Panel.TFrame")
        left_outer.pack(side="left", fill="y", anchor="n")
        left_canvas = tk.Canvas(left_outer, highlightthickness=0, borderwidth=0,
                                background=C["bg_panel"], width=470)
        left_sb = ttk.Scrollbar(left_outer, orient="vertical",
                                command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=left_sb.set)
        left_sb.pack(side="right", fill="y")
        left_canvas.pack(side="left", fill="both", expand=True)
        left = ttk.Frame(left_canvas, style="Panel.TFrame")
        left_canvas.create_window((0, 0), window=left, anchor="nw")
        self._mag_left_canvas = left_canvas

        def _mag_left_conf(_e=None):
            left_canvas.configure(scrollregion=left_canvas.bbox("all"),
                                  width=left.winfo_reqwidth())
        left.bind("<Configure>", _mag_left_conf)

        # --- Preparat (ad + kullanım yolu + tarihler) ---
        pf = ttk.LabelFrame(left, text="Preparat", padding=10)
        pf.pack(fill="x", pady=(0, 8))
        ttk.Label(pf, text="İlaç / Preparat adı:", style="Panel.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w")
        self.var_mag_name = tk.StringVar()
        ttk.Entry(pf, textvariable=self.var_mag_name,
                  font=("Segoe UI", 12, "bold"), width=34).grid(
            row=1, column=0, columnspan=4, sticky="we", pady=(0, 6))
        ttk.Label(pf, text="Kullanım yolu:", style="Panel.TLabel").grid(
            row=2, column=0, sticky="w")
        self.var_mag_route = tk.StringVar(value="")
        rr = ttk.Frame(pf, style="Panel.TFrame")
        rr.grid(row=2, column=1, columnspan=3, sticky="w")
        for txt, val in (("Belirtme", ""), ("Dahilen", "DAHİLEN"),
                         ("Haricen", "HARİCEN")):
            ttk.Radiobutton(rr, text=txt, value=val, variable=self.var_mag_route,
                            command=self._mag_update_preview).pack(
                side="left", padx=(0, 8))
        ttk.Label(pf, text="Hazırlama:", style="Panel.TLabel").grid(
            row=3, column=0, sticky="e", pady=(6, 0))
        self.var_mag_prep = tk.StringVar(
            value=datetime.date.today().strftime("%d.%m.%Y"))
        ttk.Entry(pf, textvariable=self.var_mag_prep, width=12).grid(
            row=3, column=1, sticky="w", pady=(6, 0))
        ttk.Label(pf, text="SKT:", style="Panel.TLabel").grid(
            row=3, column=2, sticky="e", pady=(6, 0))
        self.var_mag_expiry = tk.StringVar()
        ttk.Entry(pf, textvariable=self.var_mag_expiry, width=12).grid(
            row=3, column=3, sticky="w", pady=(6, 0))
        pf.columnconfigure(1, weight=1)

        # --- İçerik: hammaddeleri teker teker ekle ---
        igf = ttk.LabelFrame(left, text="İçerik — Hammaddeler (teker teker ekle)",
                             padding=10)
        igf.pack(fill="x", pady=(0, 8))
        self.var_mag_ing_name = tk.StringVar()
        self.var_mag_ing_amt = tk.StringVar()
        self.var_mag_ing_unit = tk.StringVar(value="g")
        ttk.Label(igf, text="Madde (listeden seç / yaz)",
                  style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(igf, text="Miktar", style="Panel.TLabel").grid(
            row=0, column=1, sticky="w")
        ttk.Label(igf, text="Birim", style="Panel.TLabel").grid(
            row=0, column=2, sticky="w")
        # Madde adı: DB'deki hammadde sözlüğünden beslenen TEXTBOX. Yazınca (veya
        # alana girince) ALTINDA canlı öneri listesi açılır → seçilince ada+birim
        # gelir. Listede yoksa elle yazılan ad olduğu gibi işlenir.
        self._mag_ing_results = []       # [dict(ad,birim)] — açık öneriler
        e_name = ttk.Entry(igf, textvariable=self.var_mag_ing_name, width=24)
        self.ent_mag_ing = e_name
        e_name.grid(row=1, column=0, sticky="we", padx=(0, 4))
        e_name.bind("<KeyRelease>", self._mag_ing_typed)
        e_name.bind("<FocusIn>",
                    lambda e: self._mag_ing_show(self.var_mag_ing_name.get() or ""),
                    add="+")
        e_name.bind("<Down>", self._mag_ing_focus_list)
        e_amt = ttk.Entry(igf, textvariable=self.var_mag_ing_amt, width=7)
        e_amt.grid(row=1, column=1, sticky="we", padx=(0, 4))
        e_amt.bind("<FocusIn>", lambda e: self._mag_ing_hide(), add="+")
        ttk.Combobox(igf, textvariable=self.var_mag_ing_unit, width=6,
                     values=["g", "mg", "mcg", "ml", "%", "IU", "adet",
                             "damla", "ks", "q.s."]).grid(
            row=1, column=2, sticky="w", padx=(0, 4))
        ttk.Button(igf, text="➕ Ekle", command=self._mag_add_ing).grid(
            row=1, column=3, sticky="w")
        # Canlı öneri listesi (yazınca açılır, seçince kapanır)
        self.lst_mag_ing = tk.Listbox(igf, height=6, font=("Consolas", 10),
                                      activestyle="dotbox")
        self.lst_mag_ing.grid(row=2, column=0, columnspan=4, sticky="we",
                              pady=(2, 2))
        self.lst_mag_ing.bind("<Double-Button-1>", self._mag_ing_pick)
        self.lst_mag_ing.bind("<Return>", self._mag_ing_pick)
        self.lst_mag_ing.bind("<Escape>", lambda e: self._mag_ing_hide())
        self.lst_mag_ing.grid_remove()
        self.tv_mag_ings = ttk.Treeview(igf, columns=("ad", "miktar"),
                                        show="headings", height=6)
        self.tv_mag_ings.heading("ad", text="Madde")
        self.tv_mag_ings.heading("miktar", text="Miktar")
        self.tv_mag_ings.column("ad", width=210)
        self.tv_mag_ings.column("miktar", width=90, anchor="e")
        self.tv_mag_ings.grid(row=3, column=0, columnspan=4, sticky="we",
                              pady=(6, 4))
        self.tv_mag_ings.bind("<Delete>", lambda e: self._mag_del_ing())
        bb = ttk.Frame(igf, style="Panel.TFrame")
        bb.grid(row=4, column=0, columnspan=4, sticky="w")
        ttk.Button(bb, text="🗑 Sil", command=self._mag_del_ing).pack(
            side="left", padx=(0, 4))
        ttk.Button(bb, text="↑", width=3,
                   command=lambda: self._mag_move_ing(-1)).pack(
            side="left", padx=(0, 2))
        ttk.Button(bb, text="↓", width=3,
                   command=lambda: self._mag_move_ing(1)).pack(
            side="left", padx=(0, 4))
        ttk.Button(bb, text="🧹 Temizle", command=self._mag_clear_ings).pack(
            side="left")
        igf.columnconfigure(0, weight=1)
        e_name.bind("<Return>", self._mag_ing_name_enter)
        e_amt.bind("<Return>", lambda e: self._mag_add_ing())

        # İçerik alanlarına girince önizleme otomatik İÇERİK etiketine geçer.
        for _w in (e_name, e_amt):
            _w.bind("<FocusIn>",
                    lambda e: self._mag_set_preview_mode("icerik"), add="+")

        # --- Kullanım / bilgilendirme alanları ---
        uf = ttk.LabelFrame(left, text="Kullanım / Bilgilendirme", padding=10)
        uf.pack(fill="x", pady=(0, 8))
        ttk.Label(uf, text="Kullanım amacı:", style="Panel.TLabel").grid(
            row=0, column=0, sticky="e", pady=2)
        self.var_mag_purpose = tk.StringVar()
        ttk.Entry(uf, textvariable=self.var_mag_purpose, width=26).grid(
            row=0, column=1, sticky="we", pady=2)
        self.var_mag_purpose_on_content = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            uf, text="İçerik etiketinde yer kalırsa kullanım amacını da yaz",
            variable=self.var_mag_purpose_on_content,
            command=self._mag_update_preview).grid(
            row=1, column=1, sticky="w", pady=(0, 4))
        ttk.Label(uf, text="Hasta:", style="Panel.TLabel").grid(
            row=2, column=0, sticky="e")
        self.var_mag_hasta = tk.StringVar()
        ttk.Entry(uf, textvariable=self.var_mag_hasta, width=26).grid(
            row=2, column=1, sticky="we", pady=2)
        ttk.Label(uf, text="Doktor:", style="Panel.TLabel").grid(
            row=3, column=0, sticky="e")
        self.var_mag_doktor = tk.StringVar()
        ttk.Entry(uf, textvariable=self.var_mag_doktor, width=26).grid(
            row=3, column=1, sticky="we", pady=2)
        ttk.Label(uf, text="Kullanım şekli:", style="Panel.TLabel").grid(
            row=4, column=0, sticky="ne", pady=2)
        self.txt_mag_usage = tk.Text(uf, height=3, width=30, wrap="word",
                                     font=("Segoe UI", 10))
        self.txt_mag_usage.grid(row=4, column=1, sticky="we", pady=2)
        ttk.Label(uf, text="Saklama:", style="Panel.TLabel").grid(
            row=5, column=0, sticky="e", pady=2)
        self.var_mag_storage = tk.StringVar()
        ttk.Combobox(uf, textvariable=self.var_mag_storage, width=28, values=[
            "Oda sıcaklığında, ışıktan uzakta saklayınız.",
            "Buzdolabında (2-8°C) saklayınız.",
            "Serin ve kuru yerde saklayınız.",
        ]).grid(row=5, column=1, sticky="we", pady=2)
        ttk.Label(uf, text="Uyarılar:", style="Panel.TLabel").grid(
            row=6, column=0, sticky="ne", pady=2)
        self.txt_mag_warn = tk.Text(uf, height=2, width=30, wrap="word",
                                    font=("Segoe UI", 10))
        self.txt_mag_warn.grid(row=6, column=1, sticky="we", pady=2)
        uf.columnconfigure(1, weight=1)
        self.txt_mag_usage.bind("<KeyRelease>",
                                lambda e: self._mag_update_preview())
        self.txt_mag_warn.bind("<KeyRelease>",
                               lambda e: self._mag_update_preview())
        self.var_mag_purpose.trace_add("write",
                                       lambda *a: self._mag_update_preview())
        # Kullanım alanlarından herhangi birine girince önizleme otomatik KULLANIM
        # etiketine geçer (yazdıkça canlı görünsün).
        for _w in uf.winfo_children():
            if isinstance(_w, (ttk.Entry, ttk.Combobox, tk.Text)):
                _w.bind("<FocusIn>",
                        lambda e: self._mag_set_preview_mode("kullanim"), add="+")

        # --- Boyut & yazıcı & adet ---
        sp = ttk.LabelFrame(left, text="Boyut & Yazıcı", padding=10)
        sp.pack(fill="x", pady=(0, 8))
        ttk.Label(sp, text="Genişlik:", style="Panel.TLabel").grid(
            row=0, column=0, sticky="e")
        self.var_mag_w = tk.StringVar(value=self._fmt_mm(self.majistral_label_w_mm))
        ttk.Entry(sp, textvariable=self.var_mag_w, width=6).grid(
            row=0, column=1, sticky="w")
        ttk.Label(sp, text="mm   Yükseklik:", style="Panel.TLabel").grid(
            row=0, column=2, sticky="e")
        self.var_mag_h = tk.StringVar(value=self._fmt_mm(self.majistral_label_h_mm))
        ttk.Entry(sp, textvariable=self.var_mag_h, width=6).grid(
            row=0, column=3, sticky="w")
        ttk.Label(sp, text="mm", style="PanelMuted.TLabel").grid(
            row=0, column=4, sticky="w", padx=(2, 0))
        ttk.Label(sp, text="Adet:", style="Panel.TLabel").grid(
            row=1, column=0, sticky="e", pady=(6, 0))
        self.var_mag_copies = tk.IntVar(value=1)
        ttk.Spinbox(sp, from_=1, to=99, textvariable=self.var_mag_copies,
                    width=5).grid(row=1, column=1, sticky="w", pady=(6, 0))
        ttk.Label(sp, text="Yazıcı:", style="Panel.TLabel").grid(
            row=2, column=0, sticky="e", pady=(6, 0))
        self.var_mag_printer = tk.StringVar()
        self._mag_printer_combo = ttk.Combobox(
            sp, textvariable=self.var_mag_printer, state="readonly", width=28,
            postcommand=lambda: self._refresh_mag_printer_list(preserve=True))
        self._mag_printer_combo.grid(row=2, column=1, columnspan=4, sticky="we",
                                     pady=(6, 0))
        self._mag_printer_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: self._save_majistral_settings(quiet=True))
        self._refresh_mag_printer_list()

        # NOT: Yazdır/Kaydet/Sıfırla butonları alttaki SABİT eylem çubuğunda
        # (action_bar) — içerik uzasa da her zaman görünür kalsınlar.
        ttk.Button(action_bar, text="🧾 Birleşik Etiket Bas",
                   style="Accent.TButton",
                   command=self._mag_print_combined).pack(side="left", padx=(0, 6),
                                                          ipady=4)
        ttk.Button(action_bar, text="🧪 İçerik Bas", style="Accent.TButton",
                   command=self._mag_print_content).pack(side="left", padx=(0, 6),
                                                         ipady=4)
        ttk.Button(action_bar, text="📋 Kullanım Bas", style="Accent.TButton",
                   command=self._mag_print_usage).pack(side="left", padx=(0, 6),
                                                       ipady=4)
        ttk.Button(action_bar, text="🧹 Tümünü Temizle",
                   command=self._mag_clear_all).pack(side="right")
        ttk.Button(action_bar, text="💾 Boyut/Yazıcıyı Kaydet",
                   command=self._save_majistral_settings).pack(
            side="right", padx=(0, 6))

        # --- Sağ sütun: önizleme + sayfa gezinme ---
        # fill="y" (expand YOK): önizleme ve maliyet paneli içeriğine göre
        # boyutlanır; sağda kalan yatay alan boş kalır (eskiden expand=True ile
        # maliyet paneli pencere boyunca anlamsızca genişliyordu).
        right = ttk.Frame(wrap, style="Panel.TFrame")
        right.pack(side="left", fill="y", padx=(16, 0), anchor="n")
        selrow = ttk.Frame(right, style="Panel.TFrame")
        selrow.pack(anchor="w")
        self.var_mag_preview = tk.StringVar(value="icerik")
        ttk.Radiobutton(selrow, text="🧪 İçerik", value="icerik",
                        variable=self.var_mag_preview,
                        command=self._mag_preview_switch).pack(
            side="left", padx=(0, 10))
        ttk.Radiobutton(selrow, text="📋 Kullanım", value="kullanim",
                        variable=self.var_mag_preview,
                        command=self._mag_preview_switch).pack(
            side="left", padx=(0, 10))
        ttk.Radiobutton(selrow, text="🧾 Birleşik", value="birlesik",
                        variable=self.var_mag_preview,
                        command=self._mag_preview_switch).pack(side="left")
        nav = ttk.Frame(right, style="Panel.TFrame")
        nav.pack(anchor="w", pady=(6, 2))
        ttk.Button(nav, text="◀", width=3,
                   command=lambda: self._mag_nav(-1)).pack(side="left")
        self.var_mag_pageinfo = tk.StringVar(value="Sayfa 1/1")
        ttk.Label(nav, textvariable=self.var_mag_pageinfo,
                  style="Panel.TLabel").pack(side="left", padx=8)
        ttk.Button(nav, text="▶", width=3,
                   command=lambda: self._mag_nav(1)).pack(side="left")
        self._mag_preview_lbl = tk.Label(right, relief="solid", borderwidth=1,
                                         background="#cbd5e1")
        self._mag_preview_lbl.pack(anchor="nw", pady=(4, 0))
        ttk.Label(
            right,
            text=("İçerik tek etikete sığmazsa otomatik 2.+ etikete taşar;\n"
                  "basınca tüm sayfalar sırayla basılır. ◀ ▶ ile önizleme."),
            style="PanelMuted.TLabel", justify="left").pack(anchor="w", pady=(8, 0))

        # --- Maliyet analizi paneli ---
        self._mag_amb = []          # [(ad, fiyat, adet)] — seçili ambalajlar
        self._mag_price_map = {}    # {ad.lower(): {birim,paket_miktar,paket_fiyat}}
        self.var_mag_iscilik = tk.StringVar(value=str(self.magistral_iscilik or "0"))
        self.var_mag_total = tk.StringVar(value="TOPLAM MALİYET: 0,00 TL")

        cost = ttk.LabelFrame(right, text="💰 Maliyet Analizi", padding=10)
        cost.pack(fill="x", pady=(10, 0))

        ar = ttk.Frame(cost, style="Panel.TFrame")
        ar.pack(fill="x")
        ttk.Label(ar, text="Ambalaj:", style="Panel.TLabel").pack(side="left")
        self.var_mag_amb_sel = tk.StringVar()
        self.cmb_mag_amb = ttk.Combobox(ar, textvariable=self.var_mag_amb_sel,
                                        state="readonly", width=24)
        self.cmb_mag_amb.pack(side="left", padx=(4, 4))
        self.var_mag_amb_adet = tk.IntVar(value=1)
        ttk.Spinbox(ar, from_=1, to=99, width=4,
                    textvariable=self.var_mag_amb_adet).pack(side="left")
        ttk.Button(ar, text="➕", width=3,
                   command=self._mag_amb_add).pack(side="left", padx=(4, 0))
        self.lst_mag_amb = tk.Listbox(cost, height=3, font=("Consolas", 9))
        self.lst_mag_amb.pack(fill="x", pady=(4, 4))
        self.lst_mag_amb.bind("<Delete>", lambda e: self._mag_amb_del())
        self.lst_mag_amb.bind("<Double-Button-1>", lambda e: self._mag_amb_del())

        ir = ttk.Frame(cost, style="Panel.TFrame")
        ir.pack(fill="x")
        ttk.Label(ir, text="İşçilik / ek maliyet:", style="Panel.TLabel").pack(
            side="left")
        ttk.Entry(ir, textvariable=self.var_mag_iscilik, width=8).pack(
            side="left", padx=(4, 2))
        ttk.Label(ir, text="TL", style="PanelMuted.TLabel").pack(side="left")

        self.txt_mag_cost = tk.Text(cost, height=6, width=44, font=("Consolas", 9),
                                    wrap="none", relief="solid", borderwidth=1)
        self.txt_mag_cost.pack(fill="x", pady=(6, 4))
        self.txt_mag_cost.configure(state="disabled")
        ttk.Label(cost, textvariable=self.var_mag_total,
                  font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(2, 4))

        cb = ttk.Frame(cost, style="Panel.TFrame")
        cb.pack(fill="x")
        ttk.Button(cb, text="💲 Hammadde Fiyatları",
                   command=self._mag_open_hammadde_prices).pack(side="left", padx=(0, 4))
        ttk.Button(cb, text="📦 Ambalaj Fiyatları",
                   command=self._mag_open_ambalaj_prices).pack(side="left")

        self._mag_refresh_price_map()
        self._mag_refresh_ambalaj_list()
        self.var_mag_iscilik.trace_add("write", lambda *a: self._mag_update_cost())

        for v in (self.var_mag_name, self.var_mag_route, self.var_mag_prep,
                  self.var_mag_expiry, self.var_mag_hasta, self.var_mag_doktor,
                  self.var_mag_storage, self.var_mag_w, self.var_mag_h):
            v.trace_add("write", lambda *a: self._mag_update_preview())

        # Sol sütun fare tekerleğiyle kaysın (uzun madde/öneri listeleri hariç →
        # onların üstündeyken kendi içlerinde kayarlar).
        def _mag_wheel(e):
            left_canvas.yview_scroll(int(-(e.delta or 0) / 120), "units")
            return "break"

        def _bind_wheel(widget):
            for ch in widget.winfo_children():
                if ch in (self.tv_mag_ings, self.lst_mag_ing):
                    continue
                ch.bind("<MouseWheel>", _mag_wheel)
                _bind_wheel(ch)
        left_canvas.bind("<MouseWheel>", _mag_wheel)
        _bind_wheel(left)
        _mag_left_conf()

        self._mag_update_preview()
        self._mag_update_cost()

    # --- Majistral: yardımcı/işleyiciler ---
    def _refresh_mag_printer_list(self, preserve: bool = False):
        names = [self._BOX_ACTIVE_SENTINEL] + [
            p.get("name", "") for p in getattr(self, "printers", []) if p.get("name")
        ]
        self._mag_printer_combo.configure(values=names)
        if preserve and self.var_mag_printer.get() in names:
            return
        want = getattr(self, "majistral_printer_active", "") or ""
        self.var_mag_printer.set(want if want in names else self._BOX_ACTIVE_SENTINEL)

    def _mag_label_size_mm(self) -> tuple[float, float]:
        def _p(var, default):
            try:
                return float((var.get() or "").replace(",", "."))
            except (TypeError, ValueError):
                return default
        w = min(120.0, max(20.0, _p(self.var_mag_w, self.majistral_label_w_mm)))
        h = min(200.0, max(20.0, _p(self.var_mag_h, self.majistral_label_h_mm)))
        return w, h

    def _selected_mag_printer_cfg(self) -> dict:
        name = (self.var_mag_printer.get() or "").strip()
        if not name or name == self._BOX_ACTIVE_SENTINEL:
            return self._active_printer_cfg()
        return self._printer_cfg_by_name(name)

    # --- Majistral: hammadde TEXTBOX + canlı öneri listesi (DB sözlüğü) ---
    def _mag_ing_show(self, query: str = ""):
        """DB'den `query` eşleşmelerini öneri listesine doldur ve göster.
        Boş query → en çok kullanılan/alfabetik ilk maddeler (tümüne göz at)."""
        try:
            from ..db import search_magistral_hammadde
            with get_connection() as conn:
                limit = 500 if not (query or "").strip() else 60
                self._mag_ing_results = search_magistral_hammadde(
                    conn, query, limit=limit)
        except Exception:
            log.exception("Majistral hammadde arama hatası")
            self._mag_ing_results = []
        lb = self.lst_mag_ing
        lb.delete(0, "end")
        for r in self._mag_ing_results:
            bir = r.get("birim") or ""
            lb.insert("end", f"{r['ad']}" + (f"   [{bir}]" if bir else ""))
        if self._mag_ing_results:
            lb.grid()
        else:
            lb.grid_remove()

    def _mag_ing_typed(self, event=None):
        """Madde adına yazdıkça öneri listesini DB'den süz (kanıtlanmış desen)."""
        if event is not None and event.keysym in (
            "Up", "Down", "Return", "Escape", "Left", "Right", "Tab",
            "Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R",
        ):
            return
        self._mag_ing_show(self.var_mag_ing_name.get() or "")

    def _mag_ing_hide(self):
        if hasattr(self, "lst_mag_ing"):
            self.lst_mag_ing.grid_remove()

    def _mag_ing_focus_list(self, event=None):
        """Madde kutusunda ↓ tuşu → öneri listesine geç (ilk öğeyi seç)."""
        lb = getattr(self, "lst_mag_ing", None)
        if lb is None or not lb.winfo_ismapped() or lb.size() == 0:
            return
        lb.focus_set()
        lb.selection_clear(0, "end")
        lb.selection_set(0)
        lb.activate(0)
        return "break"

    def _mag_ing_name_enter(self, event=None):
        """Madde kutusunda Enter: öneri açıksa ilkini seç, değilse miktara geç."""
        lb = getattr(self, "lst_mag_ing", None)
        if lb is not None and lb.winfo_ismapped() and self._mag_ing_results:
            # Tam eşleşme yoksa ilk öneriyi al (hazır madde tercih edilir).
            typed = (self.var_mag_ing_name.get() or "").strip().lower()
            idx = 0
            for i, r in enumerate(self._mag_ing_results):
                if r["ad"].lower() == typed:
                    idx = i
                    break
            self._mag_ing_apply(idx)
            return "break"
        # Öneri yok → elle yazılan madde olduğu gibi kalır; miktar kutusuna geç.
        self._mag_ing_hide()
        try:
            self.ent_mag_ing.tk_focusNext().focus_set()
        except Exception:
            pass
        return "break"

    def _mag_ing_pick(self, event=None):
        """Öneri listesinden seçilen maddeyi kutuya uygula."""
        sel = self.lst_mag_ing.curselection()
        if not sel:
            return
        self._mag_ing_apply(sel[0])

    def _mag_ing_apply(self, idx: int):
        """idx'teki öneriyi madde kutusuna yaz + birimini getir + miktara odaklan."""
        if idx < 0 or idx >= len(self._mag_ing_results):
            return
        r = self._mag_ing_results[idx]
        self.var_mag_ing_name.set(r["ad"])
        if r.get("birim"):
            self.var_mag_ing_unit.set(r["birim"])
        self._mag_ing_hide()
        if hasattr(self, "ent_mag_ing"):
            # miktar kutusuna geç (bir sonraki giriş)
            try:
                self.ent_mag_ing.tk_focusNext().focus_set()
            except Exception:
                pass

    def _mag_add_ing(self):
        name = (self.var_mag_ing_name.get() or "").strip()
        amt = (self.var_mag_ing_amt.get() or "").strip().replace(".", ",")
        unit = (self.var_mag_ing_unit.get() or "").strip()
        if not name:
            self.status.set("⚠ Madde adı boş.")
            return
        if amt and unit and unit != "q.s.":
            miktar = f"{amt} {unit}"
        elif amt:
            miktar = amt
        elif unit == "q.s.":
            miktar = "q.s."
        else:
            miktar = ""
        self._mag_ings.append((name, miktar))
        self._mag_refresh_ings()
        # Kullanılan maddeyi sözlüğe kaydet/öne çıkar (yeni maddeler de eklenir).
        try:
            from ..db import upsert_magistral_hammadde
            with get_connection() as conn:
                upsert_magistral_hammadde(
                    conn, name, birim=unit if unit in ("g", "ml") else "")
        except Exception:
            log.exception("Majistral hammadde kaydetme hatası")
        self._mag_ing_hide()
        self.var_mag_ing_name.set("")
        self.var_mag_ing_amt.set("")
        if hasattr(self, "ent_mag_ing"):
            self.ent_mag_ing.focus_set()
        self._mag_update_preview()

    def _mag_refresh_ings(self):
        self.tv_mag_ings.delete(*self.tv_mag_ings.get_children())
        for (nm, am) in self._mag_ings:
            self.tv_mag_ings.insert("", "end", values=(nm, am))

    def _mag_sel_index(self) -> int:
        sel = self.tv_mag_ings.selection()
        return self.tv_mag_ings.index(sel[0]) if sel else -1

    def _mag_del_ing(self):
        i = self._mag_sel_index()
        if i < 0:
            return
        del self._mag_ings[i]
        self._mag_refresh_ings()
        self._mag_update_preview()

    def _mag_move_ing(self, delta: int):
        i = self._mag_sel_index()
        if i < 0:
            return
        j = i + delta
        if j < 0 or j >= len(self._mag_ings):
            return
        self._mag_ings[i], self._mag_ings[j] = self._mag_ings[j], self._mag_ings[i]
        self._mag_refresh_ings()
        kids = self.tv_mag_ings.get_children()
        if kids:
            self.tv_mag_ings.selection_set(kids[j])
        self._mag_update_preview()

    def _mag_clear_ings(self):
        self._mag_ings = []
        self._mag_refresh_ings()
        self._mag_update_preview()

    def _mag_render_pages(self, kind: str):
        from ..label_render import (render_magistral_content_label,
                                    render_magistral_usage_label)
        w_mm, h_mm = self._mag_label_size_mm()
        dpi = getattr(self, "printer_dpi", 203)
        purpose = (self.var_mag_purpose.get() if hasattr(self, "var_mag_purpose")
                   else "")
        if kind == "birlesik":
            from ..label_render import render_magistral_combined_label
            return render_magistral_combined_label(
                self.var_mag_name.get(), list(self._mag_ings),
                hasta_adi=self.var_mag_hasta.get(),
                usage_text=self.txt_mag_usage.get("1.0", "end").strip(),
                usage_purpose=purpose,
                usage_route=self.var_mag_route.get(),
                storage=self.var_mag_storage.get(),
                warnings=self.txt_mag_warn.get("1.0", "end").strip(),
                prep_date=self.var_mag_prep.get(),
                expiry=self.var_mag_expiry.get(),
                width_mm=w_mm, height_mm=h_mm, dpi=dpi,
                eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
            )
        if kind == "kullanim":
            return render_magistral_usage_label(
                self.var_mag_name.get(),
                usage_text=self.txt_mag_usage.get("1.0", "end").strip(),
                usage_purpose=purpose,
                hasta_adi=self.var_mag_hasta.get(),
                doktor_adi=self.var_mag_doktor.get(),
                usage_route=self.var_mag_route.get(),
                storage=self.var_mag_storage.get(),
                warnings=self.txt_mag_warn.get("1.0", "end").strip(),
                prep_date=self.var_mag_prep.get(),
                expiry=self.var_mag_expiry.get(),
                width_mm=w_mm, height_mm=h_mm, dpi=dpi,
                eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
            )
        # İçerik etiketine kullanım amacı yalnız kutu işaretliyse + yer kalırsa.
        content_purpose = purpose if (
            hasattr(self, "var_mag_purpose_on_content")
            and self.var_mag_purpose_on_content.get()) else ""
        return render_magistral_content_label(
            self.var_mag_name.get(), list(self._mag_ings),
            prep_date=self.var_mag_prep.get(), expiry=self.var_mag_expiry.get(),
            usage_route=self.var_mag_route.get(),
            usage_purpose=content_purpose,
            width_mm=w_mm, height_mm=h_mm, dpi=dpi,
            eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
        )

    def _mag_preview_switch(self):
        self._mag_page_idx = 0
        self._mag_update_preview()

    def _mag_set_preview_mode(self, mode: str):
        """Önizleme kipini değiştir (içerik/kullanım) ve canlı yenile.
        Alanına tıklayınca o etiketin önizlemesi gelir → yazınca direkt görünür.
        Birleşik kip seçiliyse otomatik geçiş yapılmaz (hepsi tek önizlemede)."""
        if getattr(self, "var_mag_preview", None) is None:
            return
        if self.var_mag_preview.get() == "birlesik":
            return
        if self.var_mag_preview.get() != mode:
            self.var_mag_preview.set(mode)
            self._mag_page_idx = 0
            self._mag_update_preview()

    def _mag_update_preview(self, *_a):
        try:
            pages = self._mag_render_pages(self.var_mag_preview.get())
            self._mag_pages = pages
            if not pages:
                return
            if self._mag_page_idx >= len(pages):
                self._mag_page_idx = 0
            self.var_mag_pageinfo.set(
                f"Sayfa {self._mag_page_idx + 1}/{len(pages)}")
            img = pages[self._mag_page_idx]
            scale = min(420 / img.width, 320 / img.height, 4.0)
            disp = img.resize((max(1, int(img.width * scale)),
                               max(1, int(img.height * scale))))
            self._mag_preview_imgtk = ImageTk.PhotoImage(disp)
            self._mag_preview_lbl.configure(image=self._mag_preview_imgtk)
        except Exception:
            log.exception("Majistral etiketi önizleme hatası")
        if hasattr(self, "txt_mag_cost"):
            self._mag_update_cost()

    def _mag_nav(self, delta: int):
        if not self._mag_pages:
            return
        self._mag_page_idx = (self._mag_page_idx + delta) % len(self._mag_pages)
        self._mag_update_preview()

    def _mag_print_pages(self, pages, prefix: str):
        if not pages:
            self.status.set("⚠ Majistral etiketi: basılacak içerik yok.")
            return
        try:
            copies = max(1, int(self.var_mag_copies.get()))
        except (TypeError, ValueError, tk.TclError):
            copies = 1
        w_mm, h_mm = self._mag_label_size_mm()
        cfg = self._selected_mag_printer_cfg()
        try:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            outs = []
            for i, img in enumerate(pages, 1):
                out = self._preview_dir / f"{prefix}_{ts}_s{i}.png"
                img.save(out)
                outs.append(out)
        except Exception:
            log.exception("Majistral etiketi üretme hatası")
            self.status.set("❌ Majistral etiketi üretilemedi.")
            return

        def worker():
            try:
                from .. import printer
                for out in outs:
                    printer.send_image(
                        out, cfg, copies=copies, label_mm=(w_mm, h_mm),
                        gap_mm=getattr(self, "label_gap_mm", 2.0),
                        dpi=getattr(self, "printer_dpi", 203),
                    )
                addr = printer.cfg_label(cfg)
                self.after(0, lambda: self.status.set(
                    f"🧪 Majistral etiketi ({len(outs)} sayfa ×{copies}) "
                    f"→ {addr}"))
            except Exception as e:
                log.exception("Majistral etiketi baskı hatası")
                self.after(0, lambda err=str(e): self.status.set(
                    f"❌ Majistral etiketi yazdırılamadı: {err}"))

        threading.Thread(target=worker, daemon=True, name="majistral-print").start()

    def _mag_print_content(self):
        if not (self.var_mag_name.get() or "").strip() and not self._mag_ings:
            self.status.set("⚠ İçerik etiketi: en az ilaç adı veya bir madde gerekli.")
            return
        self._mag_print_pages(self._mag_render_pages("icerik"), "majistral_icerik")

    def _mag_print_usage(self):
        if not (self.var_mag_name.get() or "").strip():
            self.status.set("⚠ Kullanım etiketi: ilaç adı gerekli.")
            return
        self._mag_print_pages(self._mag_render_pages("kullanim"),
                              "majistral_kullanim")

    def _mag_print_combined(self):
        if not (self.var_mag_name.get() or "").strip() and not self._mag_ings:
            self.status.set("⚠ Birleşik etiket: en az ilaç adı veya bir madde gerekli.")
            return
        self._mag_print_pages(self._mag_render_pages("birlesik"),
                              "majistral_birlesik")

    def _save_majistral_settings(self, quiet: bool = False):
        from ..db import get_connection, save_setting
        w_mm, h_mm = self._mag_label_size_mm()
        self.majistral_label_w_mm, self.majistral_label_h_mm = w_mm, h_mm
        sel = (self.var_mag_printer.get() or "").strip()
        self.majistral_printer_active = (
            "" if sel == self._BOX_ACTIVE_SENTINEL else sel)
        try:
            with get_connection() as conn:
                save_setting(conn, "majistral_label_w_mm", self._fmt_mm(w_mm))
                save_setting(conn, "majistral_label_h_mm", self._fmt_mm(h_mm))
                save_setting(conn, "majistral_printer_active",
                             self.majistral_printer_active)
                if hasattr(self, "var_mag_iscilik"):
                    isc = (self.var_mag_iscilik.get() or "0").strip()
                    self.magistral_iscilik = isc
                    save_setting(conn, "magistral_iscilik", isc)
            if not quiet:
                self.status.set("💾 Majistral etiketi boyutu/yazıcısı kaydedildi.")
        except Exception:
            log.exception("Majistral etiketi ayarı kaydetme hatası")
            self.status.set("❌ Majistral etiketi ayarı kaydedilemedi.")

    def _mag_clear_all(self):
        self.var_mag_name.set("")
        self.var_mag_route.set("")
        self.var_mag_purpose.set("")
        self.var_mag_expiry.set("")
        self.var_mag_hasta.set("")
        self.var_mag_doktor.set("")
        self.var_mag_storage.set("")
        self.txt_mag_usage.delete("1.0", "end")
        self.txt_mag_warn.delete("1.0", "end")
        self._mag_ings = []
        self._mag_refresh_ings()
        self.var_mag_prep.set(datetime.date.today().strftime("%d.%m.%Y"))
        self._mag_page_idx = 0
        if hasattr(self, "lst_mag_amb"):
            self._mag_amb = []
            self.lst_mag_amb.delete(0, "end")
        self._mag_update_preview()

    # ------------------------------------------------------------------
    # Majistral maliyet analizi (hammadde fiyatı + ambalaj + işçilik)
    # ------------------------------------------------------------------
    @staticmethod
    def _mag_money(v: float) -> str:
        """0.0 → '0,00' (TL biçimi, virgüllü)."""
        try:
            return f"{float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        except (TypeError, ValueError):
            return "0,00"

    def _mag_refresh_price_map(self):
        """Hammadde fiyat haritasını DB'den belleğe al (maliyet hesabı için)."""
        try:
            from ..db import magistral_hammadde_price_map
            with get_connection() as conn:
                self._mag_price_map = magistral_hammadde_price_map(conn)
        except Exception:
            log.exception("Majistral fiyat haritası yükleme hatası")
            self._mag_price_map = {}

    def _mag_refresh_ambalaj_list(self):
        """Ambalaj combobox'ını DB'den doldur (sık kullanılan üste)."""
        try:
            from ..db import list_magistral_ambalaj
            with get_connection() as conn:
                self._mag_ambalaj_all = list_magistral_ambalaj(conn)
        except Exception:
            log.exception("Majistral ambalaj listesi yükleme hatası")
            self._mag_ambalaj_all = []
        if getattr(self, "cmb_mag_amb", None) is not None:
            self.cmb_mag_amb["values"] = [
                f"{r['ad']}  ({self._mag_money(r['fiyat'])} TL)"
                for r in self._mag_ambalaj_all
            ]

    def _mag_amb_add(self):
        idx = None
        sel = (self.var_mag_amb_sel.get() or "").strip()
        if not sel:
            self.status.set("⚠ Ambalaj seçilmedi.")
            return
        # combobox metni "ad  (x TL)" → ada göre eşle
        for i, r in enumerate(self._mag_ambalaj_all):
            if sel.startswith(r["ad"]):
                idx = i
                break
        if idx is None:
            return
        r = self._mag_ambalaj_all[idx]
        try:
            adet = max(1, int(self.var_mag_amb_adet.get()))
        except (TypeError, ValueError, tk.TclError):
            adet = 1
        self._mag_amb.append((r["ad"], float(r["fiyat"]), adet))
        self.lst_mag_amb.insert(
            "end",
            f"{r['ad']} ×{adet} = {self._mag_money(r['fiyat'] * adet)} TL")
        try:
            from ..db import upsert_magistral_ambalaj
            with get_connection() as conn:
                upsert_magistral_ambalaj(conn, r["ad"], bump=True)
        except Exception:
            log.exception("Majistral ambalaj kullanım sayacı hatası")
        self._mag_update_cost()

    def _mag_amb_del(self):
        sel = self.lst_mag_amb.curselection()
        if not sel:
            return
        i = sel[0]
        self.lst_mag_amb.delete(i)
        if 0 <= i < len(self._mag_amb):
            del self._mag_amb[i]
        self._mag_update_cost()

    @staticmethod
    def _mag_parse_amount(miktar_str: str):
        """'3 g' → (3.0, 'g'); '0,5 ml' → (0.5,'ml'); 'q.s.' → (None,'q.s.')."""
        s = (miktar_str or "").strip().replace(",", ".")
        m = re.match(r"^\s*([0-9]*\.?[0-9]+)\s*(.*)$", s)
        if not m:
            return None, (miktar_str or "").strip()
        return float(m.group(1)), m.group(2).strip()

    @staticmethod
    def _mag_to_price_unit(amount: float, used_unit: str, price_birim: str):
        """Kullanılan miktarı, fiyat biriminin (g/ml) cinsine çevir.
        Çevrilemiyorsa (%, damla, adet, IU...) None döndürür. g↔ml yoğunluk≈1."""
        used = (used_unit or "").lower()
        pb = (price_birim or "").lower()
        mass = {"g": 1.0, "gr": 1.0, "mg": 0.001, "mcg": 1e-6, "µg": 1e-6,
                "ug": 1e-6, "kg": 1000.0}
        vol = {"ml": 1.0, "cc": 1.0, "l": 1000.0, "lt": 1000.0}
        if pb == "g":
            if used in mass:
                return amount * mass[used]
            if used == "" or used in vol:   # birimsiz → g say; ml → yoğunluk≈1
                return amount
            return None
        if pb == "ml":
            if used in vol:
                return amount * vol[used]
            if used == "" or used in mass:
                return amount
            return None
        # fiyat birimi bilinmiyor → aynı birim varsay
        if used in mass or used in vol or used == "":
            return amount
        return None

    def _mag_cost_breakdown(self):
        """(satırlar, hammadde_top, ambalaj_top, iscilik, toplam, bilinmeyen) döndürür."""
        lines = []
        mat_total = 0.0
        unknown = 0
        for (name, miktar) in self._mag_ings:
            info = self._mag_price_map.get((name or "").lower())
            amount, used_unit = self._mag_parse_amount(miktar)
            cost = None
            if info and info.get("paket_fiyat") and info.get("paket_miktar") \
                    and amount is not None:
                unit_price = info["paket_fiyat"] / info["paket_miktar"]
                conv = self._mag_to_price_unit(amount, used_unit, info.get("birim"))
                if conv is not None:
                    cost = conv * unit_price
            if cost is None:
                unknown += 1
                lines.append((f"{name[:22]:22} {miktar:>9}", "  —  "))
            else:
                mat_total += cost
                lines.append((f"{name[:22]:22} {miktar:>9}",
                              f"{self._mag_money(cost):>8} TL"))
        amb_total = sum(f * n for (_a, f, n) in self._mag_amb)
        try:
            iscilik = float((self.var_mag_iscilik.get() or "0").replace(",", "."))
        except (TypeError, ValueError):
            iscilik = 0.0
        total = mat_total + amb_total + iscilik
        return lines, mat_total, amb_total, iscilik, total, unknown

    def _mag_update_cost(self, *_a):
        if not hasattr(self, "txt_mag_cost"):
            return
        try:
            lines, mat, amb, isc, total, unknown = self._mag_cost_breakdown()
            t = self.txt_mag_cost
            t.configure(state="normal")
            t.delete("1.0", "end")
            t.insert("end", "HAMMADDE\n")
            if lines:
                for (left, right) in lines:
                    t.insert("end", f"  {left} {right}\n")
            else:
                t.insert("end", "  (madde eklenmedi)\n")
            t.insert("end", f"  Ara toplam: {self._mag_money(mat)} TL\n")
            if self._mag_amb:
                t.insert("end", "AMBALAJ\n")
                for (ad, f, n) in self._mag_amb:
                    t.insert("end",
                             f"  {ad[:24]:24} ×{n} = {self._mag_money(f * n):>7} TL\n")
                t.insert("end", f"  Ara toplam: {self._mag_money(amb)} TL\n")
            if isc:
                t.insert("end", f"İŞÇİLİK/EK: {self._mag_money(isc)} TL\n")
            if unknown:
                t.insert("end", f"\n⚠ {unknown} kalemde fiyat yok "
                                f"(💲 Hammadde Fiyatları)\n")
            t.configure(state="disabled")
            self.var_mag_total.set(f"TOPLAM MALİYET: {self._mag_money(total)} TL")
        except Exception:
            log.exception("Majistral maliyet hesabı hatası")

    def _mag_open_hammadde_prices(self):
        """Hammadde fiyat düzenleme penceresi (paket miktar + paket fiyat)."""
        from ..db import (get_connection as _gc, list_magistral_hammadde,
                          set_magistral_hammadde_fiyat)
        dlg = tk.Toplevel(self)
        dlg.title("💲 Hammadde Fiyatları")
        dlg.transient(self)
        dlg.geometry("640x520")

        top = ttk.Frame(dlg)
        top.pack(fill="x", padx=10, pady=(10, 4))
        ttk.Label(top, text="Ara:").pack(side="left")
        var_q = tk.StringVar()
        ent = ttk.Entry(top, textvariable=var_q, width=30)
        ent.pack(side="left", padx=6)

        cols = ("ad", "birim", "pmik", "pfiy", "bfiy")
        tv = ttk.Treeview(dlg, columns=cols, show="headings", height=16)
        for c, txt, w in (("ad", "Hammadde", 240), ("birim", "Birim", 50),
                          ("pmik", "Paket miktar", 90), ("pfiy", "Paket fiyat", 90),
                          ("bfiy", "Birim fiyat", 90)):
            tv.heading(c, text=txt)
            tv.column(c, width=w, anchor="w" if c == "ad" else "e")
        tv.pack(fill="both", expand=True, padx=10, pady=4)

        rows_cache = {}

        def reload(*_a):
            tv.delete(*tv.get_children())
            rows_cache.clear()
            q = (var_q.get() or "").strip().lower()
            with _gc() as conn:
                rows = list_magistral_hammadde(conn)
            for r in rows:
                if q and q not in r["ad"].lower():
                    continue
                pm, pf = r.get("paket_miktar") or 0, r.get("paket_fiyat") or 0
                bf = (pf / pm) if pm else 0
                iid = tv.insert("", "end", values=(
                    r["ad"], r.get("birim") or "",
                    self._mag_money(pm) if pm else "",
                    self._mag_money(pf) if pf else "",
                    self._mag_money(bf) if bf else ""))
                rows_cache[iid] = r
        var_q.trace_add("write", reload)

        ed = ttk.LabelFrame(dlg, text="Seçili maddeyi fiyatla", padding=8)
        ed.pack(fill="x", padx=10, pady=(4, 10))
        ttk.Label(ed, text="Madde:").grid(row=0, column=0, sticky="e")
        var_ad = tk.StringVar()
        ttk.Label(ed, textvariable=var_ad, font=("Segoe UI", 10, "bold")).grid(
            row=0, column=1, columnspan=3, sticky="w", padx=4)
        ttk.Label(ed, text="Paket miktar:").grid(row=1, column=0, sticky="e", pady=4)
        var_pm = tk.StringVar()
        ttk.Entry(ed, textvariable=var_pm, width=10).grid(row=1, column=1, sticky="w")
        var_bir = tk.StringVar(value="g")
        ttk.Combobox(ed, textvariable=var_bir, width=5,
                     values=["g", "ml"]).grid(row=1, column=2, sticky="w", padx=(2, 8))
        ttk.Label(ed, text="Paket fiyat (TL):").grid(row=1, column=3, sticky="e")
        var_pf = tk.StringVar()
        ttk.Entry(ed, textvariable=var_pf, width=10).grid(row=1, column=4, sticky="w")

        def on_pick(_e=None):
            sel = tv.selection()
            if not sel:
                return
            r = rows_cache.get(sel[0])
            if not r:
                return
            var_ad.set(r["ad"])
            var_bir.set(r.get("birim") or "g")
            var_pm.set(self._mag_money(r["paket_miktar"]) if r.get("paket_miktar") else "")
            var_pf.set(self._mag_money(r["paket_fiyat"]) if r.get("paket_fiyat") else "")
        tv.bind("<<TreeviewSelect>>", on_pick)

        def save():
            ad = (var_ad.get() or "").strip()
            if not ad:
                return
            def _f(v):
                try:
                    return float((v or "0").replace(".", "").replace(",", "."))
                except (TypeError, ValueError):
                    return 0.0
            with _gc() as conn:
                set_magistral_hammadde_fiyat(
                    conn, ad, _f(var_pm.get()), _f(var_pf.get()),
                    birim=var_bir.get().strip() or None)
            self._mag_refresh_price_map()
            self._mag_update_cost()
            reload()
            self.status.set(f"💲 '{ad}' fiyatı güncellendi.")

        bar = ttk.Frame(ed)
        bar.grid(row=2, column=0, columnspan=5, sticky="w", pady=(6, 0))
        ttk.Button(bar, text="💾 Kaydet", style="Accent.TButton",
                   command=save).pack(side="left")
        ttk.Label(ed, text="Not: '100 g paket 250 TL' gir → gram başı fiyat "
                           "otomatik hesaplanır.",
                  style="PanelMuted.TLabel").grid(
            row=3, column=0, columnspan=5, sticky="w", pady=(6, 0))
        reload()
        ent.focus_set()

    def _mag_open_ambalaj_prices(self):
        """Ambalaj malzemesi fiyat/ekleme penceresi."""
        from ..db import (get_connection as _gc, list_magistral_ambalaj,
                          upsert_magistral_ambalaj, delete_magistral_ambalaj)
        dlg = tk.Toplevel(self)
        dlg.title("📦 Ambalaj Fiyatları")
        dlg.transient(self)
        dlg.geometry("520x500")

        cols = ("ad", "fiyat", "kat")
        tv = ttk.Treeview(dlg, columns=cols, show="headings", height=15)
        for c, txt, w in (("ad", "Ambalaj", 280), ("fiyat", "Fiyat (TL)", 90),
                          ("kat", "Kategori", 100)):
            tv.heading(c, text=txt)
            tv.column(c, width=w, anchor="w" if c != "fiyat" else "e")
        tv.pack(fill="both", expand=True, padx=10, pady=(10, 4))
        cache = {}

        def reload():
            tv.delete(*tv.get_children())
            cache.clear()
            with _gc() as conn:
                for r in list_magistral_ambalaj(conn):
                    iid = tv.insert("", "end", values=(
                        r["ad"], self._mag_money(r["fiyat"]), r.get("kategori") or ""))
                    cache[iid] = r

        ed = ttk.LabelFrame(dlg, text="Ekle / Düzenle", padding=8)
        ed.pack(fill="x", padx=10, pady=(4, 10))
        ttk.Label(ed, text="Ad:").grid(row=0, column=0, sticky="e")
        var_ad = tk.StringVar()
        ttk.Entry(ed, textvariable=var_ad, width=28).grid(
            row=0, column=1, columnspan=3, sticky="we", padx=4, pady=2)
        ttk.Label(ed, text="Fiyat (TL):").grid(row=1, column=0, sticky="e")
        var_f = tk.StringVar()
        ttk.Entry(ed, textvariable=var_f, width=10).grid(row=1, column=1, sticky="w")
        ttk.Label(ed, text="Kategori:").grid(row=1, column=2, sticky="e")
        var_k = tk.StringVar()
        ttk.Entry(ed, textvariable=var_k, width=12).grid(row=1, column=3, sticky="w")

        def on_pick(_e=None):
            sel = tv.selection()
            if not sel:
                return
            r = cache.get(sel[0])
            if r:
                var_ad.set(r["ad"])
                var_f.set(self._mag_money(r["fiyat"]))
                var_k.set(r.get("kategori") or "")
        tv.bind("<<TreeviewSelect>>", on_pick)

        def save():
            ad = (var_ad.get() or "").strip()
            if not ad:
                return
            try:
                fiyat = float((var_f.get() or "0").replace(".", "").replace(",", "."))
            except (TypeError, ValueError):
                fiyat = 0.0
            with _gc() as conn:
                upsert_magistral_ambalaj(conn, ad, fiyat=fiyat,
                                         kategori=var_k.get().strip())
                # fiyat 0 girildiyse de yaz (upsert 0'ı korur → ayrıca zorla):
                conn.execute("UPDATE magistral_ambalaj SET fiyat=? WHERE ad=? COLLATE NOCASE",
                             (fiyat, ad))
                conn.commit()
            self._mag_refresh_ambalaj_list()
            reload()
            self.status.set(f"📦 '{ad}' ambalajı kaydedildi.")

        def remove():
            ad = (var_ad.get() or "").strip()
            if not ad:
                return
            with _gc() as conn:
                delete_magistral_ambalaj(conn, ad)
            self._mag_refresh_ambalaj_list()
            reload()
            var_ad.set("")
            var_f.set("")

        bar = ttk.Frame(ed)
        bar.grid(row=2, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Button(bar, text="💾 Kaydet", style="Accent.TButton",
                   command=save).pack(side="left", padx=(0, 6))
        ttk.Button(bar, text="🗑 Sil", command=remove).pack(side="left")
        ed.columnconfigure(1, weight=1)
        reload()

    def _build_top_overlay(self):
        """Sekme çubuğunun ÜSTÜNE yerleştirilen tam-genişlik araç bandı.

        Eskiden ``place()`` ile sekme şeridinin sağ boşluğuna bindiriliyordu;
        dar ekranlarda (1366px / yüksek DPI) sekmelerle çakışıp butonlar üst
        üste biniyordu. Artık ``pack(before=notebook)`` ile gerçek bir satır →
        her ekranda yeniden akar (reflow), hiçbir şeyle çakışmaz. İçerik üç
        görsel gruba ayrıldı (Gestalt yakınlık): SOL=Medula motoru ·
        ORTA=kaynak · SAĞ=sistem.
        """
        C = COLORS
        bar = tk.Frame(self, background=C["bg_strip"])
        bar.pack(fill="x", side="top", before=self.notebook, padx=8, pady=(2, 0))
        self._top_overlay = bar

        # Durum değişkenleri — Ayarlar penceresindeki checkboxlar bunları kullanır.
        self.var_close_old = tk.BooleanVar(value=False)
        self.var_keepalive = tk.BooleanVar(value=False)
        self._keepalive_countdown_var = tk.StringVar(value="")

        # === SOL — Medula izleyici DURUM göstergesi (salt-okunur) ===
        # Başlat/Durdur butonu Ayarlar → Genel → Hızlı Seçenekler'e taşındı;
        # burada yalnız "çalışıyor mu?" durumu + canlı-tut sayacı görünür.
        self.var_watcher_status = tk.StringVar(value="● Kapalı")
        self._watcher_status_lbl = tk.Label(
            bar, textvariable=self.var_watcher_status,
            background=C["bg_strip"], foreground=C["text_muted"],
            font=("Segoe UI", 10, "bold"))
        self._watcher_status_lbl.pack(side="left", padx=(6, 6), pady=4)
        # _btn_watcher Ayarlar penceresinde yaşar; pencere kapalıyken None olur.
        self._btn_watcher = None
        # Eski referans uyumluluğu (artık durum etiketiyle aynı widget).
        self.lbl_watcher_status = self._watcher_status_lbl

        # --- Canlı tut geri sayım (sadece aktifken metin gösterir) ---
        ttk.Label(bar, textvariable=self._keepalive_countdown_var,
                  style="Strip.TLabel").pack(side="left", padx=(0, 6))

        # === SAĞ — sistem (başlık · ayarlar · pencere kontrolleri) ===
        tk.Label(bar, text="💊", background=C["bg_strip"],
                 foreground=C["text_yellow"],
                 font=("Segoe UI Emoji", 14)).pack(side="right", padx=(0, 2))
        tk.Label(bar, text="İLAÇ TARİF",
                 background=C["bg_strip"], foreground=C["text_yellow"],
                 font=("Segoe UI", 12, "bold")).pack(side="right", padx=(0, 8))
        ttk.Button(bar, text="⚙  AYARLAR", style="Settings.TButton",
                   command=self._open_settings).pack(side="right", padx=(2, 12), pady=2)

        # Pencere kontrolleri: görev çubuğuna küçült · tepsiye küçült · kapat.
        # sağdan-sola pack sırası → ekranda soldan sağa bu üçlü görünür.
        ttk.Button(bar, text="⏻ Komple Kapat", style="Warn.TButton",
                   command=self._real_quit).pack(side="right", padx=(2, 8), pady=2)
        ttk.Button(bar, text="🔽 Tepsiye Küçült",
                   command=self._minimize_to_tray_btn).pack(
            side="right", padx=2, pady=2)
        ttk.Button(bar, text="➖ Görev Çubuğuna Küçült",
                   command=self._minimize_to_taskbar).pack(
            side="right", padx=2, pady=2)

    # ------------------------------------------------------------------
    # Küçük Ekran / Tam Ekran düzeni
    # ------------------------------------------------------------------
    def _toggle_layout_mode(self):
        if self._layout_mode == "normal":
            self._apply_layout_mode("small")
        else:
            self._apply_layout_mode("normal")

    def _apply_layout_mode(self, mode: str):
        self._layout_mode = mode
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()

        if mode == "small":
            # Ekranın 1/4'ü kadar dikdörtgensel pencere — sağ altta konumlanır.
            # Genişlik = ekranın yarısı, yükseklik = ekranın yarısı → 1/4 alan.
            win_w = sw // 2
            win_h = sh // 2
            win_x = sw - win_w - 4        # sağ kenar
            win_y = sh - win_h - 48       # taskbar üstü
            try:
                self.state("normal")
            except Exception:
                pass
            self.geometry(f"{win_w}x{win_h}+{win_x}+{win_y}")
            self.minsize(480, 300)
            # Sol panel daralt (gizleme — reçete listesine ulaşılabilsin)
            if hasattr(self, "_auto_left_panel"):
                self._auto_left_panel.configure(width=160)
            # Botanik butonu: kısa ad (toolbar dar olur)
            if hasattr(self, "_btn_botanik"):
                self._btn_botanik.configure(text="🛒 Parekende")
        else:
            # Tam ekrana dön — sol panel genişliğini orijinaline geri al
            if hasattr(self, "_auto_left_panel"):
                self._auto_left_panel.configure(width=230)
            try:
                self.state("zoomed")
            except Exception:
                self.geometry(f"{sw}x{sh}+0+0")
            self.minsize(400, 400)
            # Botanik butonu: tam metin + kısayol geri yükle
            if hasattr(self, "_btn_botanik"):
                self._btn_botanik.configure(text=self._btn_label(
                    "🛒 Botanik Satıştan Etiket Topla", "hotkey_parekende", "shift+p"))

        # Kart ızgarasını tek sütun (small) veya varsayılan (normal) modda yeniden
        # çiz — her iki aşama için tetikle.
        self.after(120, lambda: self._relayout_stage_cards("early"))
        self.after(140, lambda: self._relayout_stage_cards("final"))

    # ------------------------------------------------------------------
    # Manuel sekme
    # ------------------------------------------------------------------
    def _build_manual_tab(self, parent: ttk.Frame):
        C = COLORS
        # ÜST: tek kompakt şerit — Hasta/TC/Tarih + Barkod & İsimle ekleme.
        top = ttk.LabelFrame(parent, text="Reçete / İlaç Ekle", padding=8)
        top.pack(fill="x", padx=10, pady=(8, 4))

        # Satır 0 — Hasta / TC / Tarih
        ttk.Label(top, text="Hasta adı:").grid(row=0, column=0, sticky="e", padx=4, pady=3)
        self.var_hasta = tk.StringVar()
        ttk.Entry(top, textvariable=self.var_hasta, width=26, font=("Segoe UI", 11)).grid(
            row=0, column=1, sticky="we", padx=4)
        ttk.Label(top, text="TC:").grid(row=0, column=2, sticky="e", padx=4)
        self.var_tc = tk.StringVar()
        ttk.Entry(top, textvariable=self.var_tc, width=13).grid(row=0, column=3, sticky="w", padx=4)
        ttk.Label(top, text="Tarih:").grid(row=0, column=4, sticky="e", padx=4)
        self.var_tarih = tk.StringVar(value=datetime.date.today().strftime("%d/%m/%Y"))
        ttk.Entry(top, textvariable=self.var_tarih, width=11).grid(row=0, column=5, sticky="w", padx=4)

        # Hasta adı / tarih değişince seçili ilacın canlı önizlemesini tazele
        self.var_hasta.trace_add("write", lambda *a: self._schedule_editor_preview())
        self.var_tarih.trace_add("write", lambda *a: self._schedule_editor_preview())

        # Satır 1 — Barkod/Karekod + Ekle  |  İsimle ara
        ttk.Label(top, text="Barkod / Karekod:").grid(row=1, column=0, sticky="e", padx=4, pady=(6, 3))
        self.var_barkod = tk.StringVar()
        self.ent_barkod = ttk.Entry(top, textvariable=self.var_barkod, width=26, font=("Consolas", 11))
        self.ent_barkod.grid(row=1, column=1, sticky="we", padx=4, pady=(6, 3))
        self.ent_barkod.bind("<Return>", self._on_barkod_enter)
        ttk.Button(top, text="➕ Ekle (Enter)", style="Accent.TButton",
                   command=self._on_barkod_enter).grid(row=1, column=2, columnspan=2,
                                                       sticky="w", padx=4, pady=(6, 3))
        ttk.Label(top, text="İsimle ara:").grid(row=1, column=4, sticky="e", padx=4)
        self.var_ara = tk.StringVar()
        self.ent_ara = ttk.Entry(top, textvariable=self.var_ara, width=22, font=("Segoe UI", 11))
        self.ent_ara.grid(row=1, column=5, sticky="we", padx=4)
        self.ent_ara.bind("<KeyRelease>", self._on_search_typed)

        # Arama sonuçları — yalnızca sonuç varken görünür (yer kaplamasın).
        self.lst_results = tk.Listbox(top, height=5, font=("Consolas", 10))
        self.lst_results.grid(row=2, column=0, columnspan=6, sticky="we", padx=4, pady=(6, 0))
        self.lst_results.bind("<Double-Button-1>", self._on_result_double)
        self.lst_results.bind("<Return>", self._on_result_double)
        self.lst_results.grid_remove()   # başlangıçta gizli

        top.columnconfigure(1, weight=1)
        top.columnconfigure(5, weight=1)

        # ORTA-ALT: SOLDA etiket sırası (dar liste), SAĞDA seçili ilacın canlı
        # düzenleyicisi + BÜYÜK etiket önizlemesi.
        mid = ttk.Frame(parent)
        mid.pack(fill="both", expand=True, padx=10, pady=4)

        # --- Sol: eklenen etiketlerin sırası (dar) ---
        left = ttk.Frame(mid, width=270)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        tbl = ttk.LabelFrame(left, text="Etiket Sırası", padding=6)
        tbl.pack(fill="both", expand=True)
        cols = ("no", "name", "doz")
        self.tree = ttk.Treeview(tbl, columns=cols, show="headings", height=8)
        self.tree.heading("no", text="#")
        self.tree.heading("name", text="İlaç")
        self.tree.heading("doz", text="Doz")
        self.tree.column("no",   width=26, anchor="center")
        self.tree.column("name", width=160)
        self.tree.column("doz",  width=58, anchor="center")
        ysb = ttk.Scrollbar(tbl, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=ysb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_manual_select)

        tk.Label(left, text="Barkod okut → sıraya eklenir.\nSatıra tıkla → sağda düzenlenir.",
                 background=C["bg_main"], foreground=C["text_muted"],
                 font=("Segoe UI", 8), justify="left").pack(anchor="w", pady=(4, 2))

        btns = ttk.Frame(left)
        btns.pack(fill="x", pady=2)
        ttk.Button(btns, text="🗑 Sil", command=self._on_row_delete).pack(side="left", padx=2)
        ttk.Button(btns, text="🧹 Tümünü Temizle", command=self._on_clear_all).pack(side="left", padx=2)

        # --- Sağ: seçili ilacın canlı düzenleyicisi + büyük önizleme ---
        self.editor = DrugEditorPanel(mid, self, on_change=self._on_editor_change)
        self.editor.pack(side="left", fill="both", expand=True, padx=(8, 0))

        # ALT: çıktı şeridi
        bottom = ttk.Frame(parent)
        bottom.pack(fill="x", padx=10, pady=(4, 10))
        ttk.Button(bottom, text="📄 Önizleme HTML", command=self._on_preview).pack(side="left", padx=4, ipady=4)
        ttk.Button(bottom, text="🖨 Yazıcıdan Çıkar", command=self._on_print).pack(side="left", padx=4, ipady=4)
        ttk.Button(bottom, text="Çıkış", command=self.destroy).pack(side="right", padx=4)

        self.ent_barkod.focus_set()

    # ------------------------------------------------------------------
    # Raf etiketi sekmesi (5.) — barkod deseni + barkod no + ilaç adı + fiyat
    # ------------------------------------------------------------------
    _SHELF_ACTIVE_SENTINEL = "★ Aktif (ana) yazıcı"

    def _build_shelf_label_tab(self, parent: ttk.Frame):
        """Raf etiketi: barkod okut → ad DB'den gelir, fiyatı yaz, bas.

        Etiket içeriği: barkod deseni (EAN-13/Code128) + barkod numarası +
        ilaç adı + satış fiyatı. Boyut/yazıcı ana etiketten bağımsız
        (raf_label_w_mm/h_mm + raf_printer_active). Sağda canlı önizleme.
        """
        C = COLORS
        self._shelf_preview_imgtk = None
        self.var_shelf_barkod = tk.StringVar()
        self.var_shelf_ad = tk.StringVar()
        self.var_shelf_fiyat = tk.StringVar()
        self.var_shelf_copies = tk.IntVar(value=1)
        self.var_shelf_ara = tk.StringVar()
        self._shelf_search_results = []

        wrap = ttk.Frame(parent, style="Panel.TFrame")
        wrap.pack(fill="both", expand=True, padx=14, pady=12)

        # --- Sol sütun: girişler ---
        left = ttk.Frame(wrap, style="Panel.TFrame")
        left.pack(side="left", fill="y", anchor="n")

        gir = ttk.LabelFrame(left, text="Raf Etiketi — Barkod · İlaç · Fiyat", padding=12)
        gir.pack(fill="x", pady=(0, 10))

        ttk.Label(gir, text="Barkod / Karekod:", style="Panel.TLabel").grid(
            row=0, column=0, sticky="e", padx=(0, 6), pady=3)
        self.ent_shelf_barkod = ttk.Entry(gir, textvariable=self.var_shelf_barkod,
                                           width=22, font=("Consolas", 12))
        self.ent_shelf_barkod.grid(row=0, column=1, sticky="we", pady=3)
        self.ent_shelf_barkod.bind("<Return>", self._shelf_barkod_enter)
        ttk.Button(gir, text="🔎 Bul", style="Accent.TButton",
                   command=self._shelf_barkod_enter).grid(row=0, column=2, padx=(6, 0))

        ttk.Label(gir, text="İlaç adı:", style="Panel.TLabel").grid(
            row=1, column=0, sticky="e", padx=(0, 6), pady=3)
        self.ent_shelf_ad = ttk.Entry(gir, textvariable=self.var_shelf_ad,
                                       width=28, font=("Segoe UI", 12))
        self.ent_shelf_ad.grid(row=1, column=1, columnspan=2, sticky="we", pady=3)

        ttk.Label(gir, text="İsimle ara:", style="Panel.TLabel").grid(
            row=2, column=0, sticky="e", padx=(0, 6), pady=3)
        self.ent_shelf_ara = ttk.Entry(gir, textvariable=self.var_shelf_ara,
                                        width=28, font=("Segoe UI", 11))
        self.ent_shelf_ara.grid(row=2, column=1, columnspan=2, sticky="we", pady=3)
        self.ent_shelf_ara.bind("<KeyRelease>", self._shelf_search_typed)

        self.lst_shelf_results = tk.Listbox(gir, height=5, font=("Consolas", 10))
        self.lst_shelf_results.grid(row=3, column=0, columnspan=3, sticky="we", pady=(2, 4))
        self.lst_shelf_results.bind("<Double-Button-1>", self._shelf_result_pick)
        self.lst_shelf_results.bind("<Return>", self._shelf_result_pick)
        self.lst_shelf_results.grid_remove()

        ttk.Label(gir, text="Satış fiyatı (₺):", style="Panel.TLabel").grid(
            row=4, column=0, sticky="e", padx=(0, 6), pady=3)
        self.ent_shelf_fiyat = ttk.Entry(gir, textvariable=self.var_shelf_fiyat,
                                          width=14, font=("Segoe UI", 16, "bold"),
                                          justify="center")
        self.ent_shelf_fiyat.grid(row=4, column=1, sticky="w", pady=3)
        self.ent_shelf_fiyat.bind("<Return>", lambda _e: self._print_shelf_label())

        ttk.Label(gir, text="Adet:", style="Panel.TLabel").grid(
            row=5, column=0, sticky="e", padx=(0, 6), pady=3)
        ttk.Spinbox(gir, from_=1, to=99, textvariable=self.var_shelf_copies,
                    width=5).grid(row=5, column=1, sticky="w", pady=3)
        gir.columnconfigure(1, weight=1)

        # --- Boyut ---
        sz = ttk.LabelFrame(left, text="Etiket Boyutu (mm)", padding=12)
        sz.pack(fill="x", pady=(0, 10))
        ttk.Label(sz, text="Genişlik:", style="Panel.TLabel").grid(
            row=0, column=0, sticky="e", padx=(0, 6), pady=2)
        self.var_shelf_w = tk.StringVar(value=self._fmt_mm(self.raf_label_w_mm))
        ttk.Entry(sz, textvariable=self.var_shelf_w, width=7).grid(row=0, column=1, sticky="w")
        ttk.Label(sz, text="mm", style="PanelMuted.TLabel").grid(
            row=0, column=2, sticky="w", padx=(2, 0))
        ttk.Label(sz, text="Yükseklik:", style="Panel.TLabel").grid(
            row=1, column=0, sticky="e", padx=(0, 6), pady=2)
        self.var_shelf_h = tk.StringVar(value=self._fmt_mm(self.raf_label_h_mm))
        ttk.Entry(sz, textvariable=self.var_shelf_h, width=7).grid(row=1, column=1, sticky="w")
        ttk.Label(sz, text="mm", style="PanelMuted.TLabel").grid(
            row=1, column=2, sticky="w", padx=(2, 0))

        # --- Yazıcı ---
        pr = ttk.LabelFrame(left, text="Yazıcı (bu etiketler için ayrı seçim)", padding=12)
        pr.pack(fill="x", pady=(0, 10))
        self.var_shelf_printer = tk.StringVar()
        self._shelf_printer_combo = ttk.Combobox(
            pr, textvariable=self.var_shelf_printer, state="readonly", width=32,
            postcommand=lambda: self._refresh_shelf_printer_list(preserve=True),
        )
        self._shelf_printer_combo.pack(fill="x")
        self._shelf_printer_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._save_shelf_settings(quiet=True))
        self._refresh_shelf_printer_list()

        # Eylem barı (tutarlı düzen): birincil "Yazdır" accent + geniş; "Temizle"
        # ikincil; "Kaydet" ayar olduğundan küçültülüp sağa demote edildi.
        btns = ttk.Frame(left, style="Panel.TFrame")
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="🖨  Yazdır", style="Accent.TButton",
                   command=self._print_shelf_label).pack(side="left", fill="x",
                                                          expand=True, ipady=4)
        ttk.Button(btns, text="🧹 Temizle",
                   command=self._shelf_clear).pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="💾 Kaydet",
                   command=self._save_shelf_settings).pack(side="right", padx=(8, 0))

        # --- Sağ sütun: canlı önizleme ---
        right = ttk.Frame(wrap, style="Panel.TFrame")
        right.pack(side="left", fill="both", expand=True, padx=(18, 0), anchor="n")
        ttk.Label(right, text="Önizleme", style="Panel.TLabel").pack(anchor="w")
        self._shelf_preview_lbl = tk.Label(right, relief="solid", borderwidth=1,
                                           background="#cbd5e1")
        self._shelf_preview_lbl.pack(anchor="nw", pady=(4, 0))

        for v in (self.var_shelf_barkod, self.var_shelf_ad, self.var_shelf_fiyat,
                  self.var_shelf_w, self.var_shelf_h):
            v.trace_add("write", lambda *a: self._update_shelf_preview())
        self.ent_shelf_barkod.focus_set()
        self._update_shelf_preview()

    # --- Raf etiketi: olay/işleyiciler ---
    @staticmethod
    def _fmt_tl(v) -> str:
        """0.0 → '0,00' (Türkçe ondalık virgül, etiket fiyatı için)."""
        try:
            return f"{float(v):.2f}".replace(".", ",")
        except (TypeError, ValueError):
            return str(v or "")

    def _botanik_lookup(self, barcode: str):
        """Barkod için Botanik fiyat/ad bilgisini çöz (canlı ayar açıksa Botanik
        DB'den, değilse yerel katalogdan). Hata olursa None."""
        try:
            from ..botanik_db import resolve_price
            with get_connection() as conn:
                s = {r["key"]: r["value"] for r in
                     conn.execute("SELECT key, value FROM settings")}
                return resolve_price(conn, s, barcode)
        except Exception:
            log.exception("Botanik fiyat sorgusu hatası")
            return None

    def _botanik_test_and_report(self, server, db, user, password):
        """Botanik bağlantısını ayrı thread'de test eder, sonucu durum çubuğuna yazar."""
        self.status.set("🔌 Botanik bağlantısı test ediliyor…")

        def worker():
            from ..botanik_db import test_connection
            ok, msg = test_connection(server.strip(), db.strip(), user.strip(), password)
            self.after(0, lambda: self.status.set(("✓ " if ok else "❌ ") + msg))

        threading.Thread(target=worker, daemon=True, name="botanik-test").start()

    def _botanik_sync_now(self, server, db, user, password):
        """Botanik kataloğunu (ad+barkod+fiyat) yerel DB'ye yeniden çeker (thread)."""
        self.status.set("⬇ Botanik kataloğu çekiliyor…")

        def worker():
            import datetime as _dt
            try:
                from ..botanik_db import fetch_catalog
                urunler = fetch_catalog(server.strip(), db.strip(), user.strip(), password)
                iso = _dt.datetime.now().isoformat(timespec="seconds")
                with get_connection() as conn:
                    n = sync_botanik_katalog(conn, urunler, updated_iso=iso)
                def done():
                    self.status.set(f"✓ Botanik kataloğu güncellendi — {n} kayıt.")
                    if getattr(self, "_lbl_botanik_info", None) is not None:
                        try:
                            self._lbl_botanik_info.configure(
                                text=f"Yerel katalog son güncelleme: {iso}  ({n} kayıt)")
                        except Exception:
                            pass
                self.after(0, done)
            except Exception as e:
                log.exception("Botanik katalog senkron hatası")
                self.after(0, lambda err=str(e): self.status.set(
                    f"❌ Katalog güncellenemedi: {err}"))

        threading.Thread(target=worker, daemon=True, name="botanik-sync").start()

    def _botanik_provision_now(self, var_server, var_db, var_user, var_pass, var_enabled):
        """Hedef makinede 'calede' (yalnız-SELECT) login'ini kurar (provisioning
        scriptini subprocess ile çalıştırır), sonra ayar alanlarını DB'den tazeler."""
        if not messagebox.askyesno(
                "Botanik Erişimini Kur",
                "Botanik SQL sunucusunda yalnız-okuma yetkili 'calede' kullanıcısı "
                "oluşturulacak/güncellenecek ve ürün kataloğu çekilecek.\n\n"
                "(Şifre bu makineye özel üretilir, hiçbir yere gönderilmez.)\n\nDevam edilsin mi?",
                parent=self):
            return
        self.status.set("🔐 Botanik erişimi kuruluyor (calede)…")
        import sys as _sys
        from ..db import PROJECT_ROOT, DB_PATH
        script = str(PROJECT_ROOT / "tools" / "botanik_provision.py")
        dbp = str(DB_PATH)

        def worker():
            import subprocess
            try:
                r = subprocess.run([_sys.executable, script, dbp, "--enable"],
                                   capture_output=True, text=True, timeout=180)
                ok = r.returncode == 0
                out = (r.stdout or "") + (r.stderr or "")
                last = out.strip().splitlines()[-1] if out.strip() else ""

                def done():
                    try:
                        with get_connection() as conn:
                            s = {row["key"]: row["value"] for row in
                                 conn.execute("SELECT key, value FROM settings")}
                        var_server.set(s.get("botanik_db_server", ""))
                        var_db.set(s.get("botanik_db_name", "eczane"))
                        var_user.set(s.get("botanik_db_user", "calede"))
                        var_pass.set(s.get("botanik_db_pass", ""))
                        var_enabled.set(str(s.get("botanik_db_enabled", "0")) in ("1", "true", "True"))
                    except Exception:
                        log.exception("Botanik ayar tazeleme hatası")
                    self.status.set(("✓ Botanik erişimi kuruldu. " if ok else "❌ Kurulamadı. ") + last)
                self.after(0, done)
            except Exception as e:
                log.exception("Botanik provision hatası")
                self.after(0, lambda err=str(e): self.status.set(
                    f"❌ Botanik erişimi kurulamadı: {err}"))

        threading.Thread(target=worker, daemon=True, name="botanik-provision").start()

    def _shelf_barkod_enter(self, event=None):
        raw = self.var_shelf_barkod.get().strip()
        if not raw:
            return "break"
        barcode = parse_karekod(raw) or raw
        self.var_shelf_barkod.set(barcode)
        # İlaç adı: önce kendi DB; Botanik kataloğu ad+fiyat sağlar.
        row = self._find_drug_by_barcode(barcode)
        name = row["name"] if row else None
        info = self._botanik_lookup(barcode)
        if info:
            if not name and info.get("ad"):
                name = info["ad"]
            if info.get("fiyat") is not None:
                self.var_shelf_fiyat.set(self._fmt_tl(info["fiyat"]))
        if name:
            self.var_shelf_ad.set(name)
        if info and info.get("fiyat") is not None:
            src = "Botanik (canlı)" if info.get("kaynak") == "botanik" else "yerel katalog"
            self.status.set(
                f"✓ {name or barcode} — {self._fmt_tl(info['fiyat'])} TL [{src}]. Basabilirsiniz.")
            self.ent_shelf_fiyat.focus_set()
        elif name:
            self.status.set(f"✓ {name} — fiyat bulunamadı, elle girin.")
            self.ent_shelf_fiyat.focus_set()
        else:
            self.status.set(f"⚠ Barkod bulunamadı ({barcode}) — ad/fiyatı elle girin.")
            self.ent_shelf_ad.focus_set()
        return "break"

    def _shelf_search_typed(self, event=None):
        """İsimle ara: önce Botanik kataloğu (OTC dahil + satış fiyatı), sonra
        katalogda olmayan reçeteli ilaçlar için kendi ilaç DB'si."""
        q = (self.var_shelf_ara.get() or "").strip()
        self.lst_shelf_results.delete(0, "end")
        results: list[dict] = []
        seen: set[str] = set()         # barkod tekrarını ele
        prod_seen: dict[int, dict] = {}   # urun_id → o ürünün seçili satırı
        if len(q) >= 2:
            # 1) Botanik kataloğu — barkod + ad + perakende satış fiyatı.
            #    Aynı ürünün hem barkodlu hem barkodsuz satırı dönebilir; ürün
            #    (urun_id) başına BARKODLU varyantı tercih et → tıklayınca barkod
            #    da gelir.
            try:
                from ..db import botanik_katalog_search
                with get_connection() as conn:
                    for r in botanik_katalog_search(conn, q, limit=60):
                        bk = (r.get("barkod") or "").strip()
                        row = {"barkod": bk, "ad": (r.get("ad") or "").strip(),
                               "fiyat": r.get("fiyat")}
                        uid = r.get("urun_id")
                        if uid is not None:
                            prev = prod_seen.get(uid)
                            if prev is None:
                                prod_seen[uid] = row
                                results.append(row)
                            elif bk and not prev["barkod"]:
                                prev.update(row)   # barkodsuzu barkodluyla değiştir
                        else:
                            results.append(row)
                        if bk:
                            seen.add(bk)
            except Exception:
                log.exception("Raf etiketi katalog arama hatası")
            # 2) Kendi ilaç DB'si (katalogda barkodu olmayan kayıtlar)
            for r in self._search_drugs_by_name(q):
                bk = (r["barcode"] or "").strip()
                if bk and bk in seen:
                    continue
                results.append({"barkod": bk, "ad": r["name"], "fiyat": None})
        self._shelf_search_results = results[:40]
        for r in self._shelf_search_results:
            ftxt = f"   {self._fmt_tl(r['fiyat'])} TL" if r["fiyat"] is not None else ""
            self.lst_shelf_results.insert(
                "end", f"{(r['barkod'] or '—'):14} | {r['ad']}{ftxt}")
        if self._shelf_search_results:
            self.lst_shelf_results.grid()
        else:
            self.lst_shelf_results.grid_remove()

    def _shelf_result_pick(self, event=None):
        sel = self.lst_shelf_results.curselection()
        if not sel:
            return
        r = self._shelf_search_results[sel[0]]
        self.var_shelf_barkod.set(r.get("barkod") or "")
        self.var_shelf_ad.set(r.get("ad") or "")
        if r.get("fiyat") is not None:
            self.var_shelf_fiyat.set(self._fmt_tl(r["fiyat"]))
        self.lst_shelf_results.grid_remove()
        self.var_shelf_ara.set("")
        self.ent_shelf_fiyat.focus_set()

    def _shelf_clear(self):
        self.var_shelf_barkod.set("")
        self.var_shelf_ad.set("")
        self.var_shelf_fiyat.set("")
        self.var_shelf_copies.set(1)
        self.ent_shelf_barkod.focus_set()

    def _shelf_label_size_mm(self) -> tuple[float, float]:
        """Girilen raf etiketi boyutunu (mm) makul sınırlara kıstırarak döndür."""
        def _p(var, default):
            try:
                return float((var.get() or "").replace(",", "."))
            except (TypeError, ValueError):
                return default
        w = min(120.0, max(20.0, _p(self.var_shelf_w, self.raf_label_w_mm)))
        h = min(120.0, max(15.0, _p(self.var_shelf_h, self.raf_label_h_mm)))
        return w, h

    def _selected_shelf_printer_cfg(self) -> dict:
        """Raf sekmesinde seçili yazıcının cfg'i (sentinel → aktif/ana yazıcı)."""
        name = (self.var_shelf_printer.get() or "").strip()
        if not name or name == self._SHELF_ACTIVE_SENTINEL:
            return self._active_printer_cfg()
        return self._printer_cfg_by_name(name)

    def _refresh_shelf_printer_list(self, preserve: bool = False):
        names = [self._SHELF_ACTIVE_SENTINEL] + [
            p.get("name", "") for p in getattr(self, "printers", []) if p.get("name")
        ]
        self._shelf_printer_combo.configure(values=names)
        if preserve and self.var_shelf_printer.get() in names:
            return
        want = getattr(self, "raf_printer_active", "") or ""
        self.var_shelf_printer.set(want if want in names else self._SHELF_ACTIVE_SENTINEL)

    def _save_shelf_settings(self, quiet: bool = False):
        """Raf etiketi boyutunu + seçili yazıcıyı ayarlara yaz (kalıcı)."""
        from ..db import get_connection, save_setting
        w_mm, h_mm = self._shelf_label_size_mm()
        self.raf_label_w_mm, self.raf_label_h_mm = w_mm, h_mm
        sel = (self.var_shelf_printer.get() or "").strip()
        self.raf_printer_active = "" if sel == self._SHELF_ACTIVE_SENTINEL else sel
        try:
            with get_connection() as conn:
                save_setting(conn, "raf_label_w_mm", self._fmt_mm(w_mm))
                save_setting(conn, "raf_label_h_mm", self._fmt_mm(h_mm))
                save_setting(conn, "raf_printer_active", self.raf_printer_active)
            if not quiet:
                self.status.set("💾 Raf etiketi boyutu/yazıcısı kaydedildi.")
        except Exception:
            log.exception("Raf etiketi ayarı kaydetme hatası")
            self.status.set("❌ Raf etiketi ayarı kaydedilemedi.")

    def _shelf_render(self):
        from ..label_render import render_shelf_label
        w_mm, h_mm = self._shelf_label_size_mm()
        return render_shelf_label(
            barkod=self.var_shelf_barkod.get().strip(),
            ilac_adi=self.var_shelf_ad.get().strip(),
            fiyat=self.var_shelf_fiyat.get().strip(),
            width_mm=w_mm, height_mm=h_mm,
            dpi=getattr(self, "printer_dpi", 203),
        )

    def _update_shelf_preview(self, *_a):
        try:
            img = self._shelf_render()
            scale = min(400 / img.width, 280 / img.height, 4.0)
            disp = img.resize((max(1, int(img.width * scale)),
                               max(1, int(img.height * scale))))
            self._shelf_preview_imgtk = ImageTk.PhotoImage(disp)
            self._shelf_preview_lbl.configure(image=self._shelf_preview_imgtk)
        except Exception:
            log.exception("Raf etiketi önizleme hatası")

    def _print_shelf_label(self):
        """Raf etiketini (barkod+isim+fiyat) seçili yazıcıya bas."""
        barkod = self.var_shelf_barkod.get().strip()
        ad = self.var_shelf_ad.get().strip()
        fiyat = self.var_shelf_fiyat.get().strip()
        if not ad and not barkod:
            self.status.set("⚠ Raf etiketi: barkod veya ilaç adı gerekli, basılmadı.")
            return
        if not fiyat and not messagebox.askyesno(
                "Fiyat boş", "Satış fiyatı boş. Yine de bassın mı?", parent=self):
            self.ent_shelf_fiyat.focus_set()
            return
        try:
            copies = max(1, int(self.var_shelf_copies.get()))
        except (TypeError, ValueError, tk.TclError):
            copies = 1
        w_mm, h_mm = self._shelf_label_size_mm()
        try:
            img = self._shelf_render()
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            out = self._preview_dir / f"raf_{ts}.png"
            img.save(out)
        except Exception:
            log.exception("Raf etiketi üretme hatası")
            self.status.set("❌ Raf etiketi üretilemedi.")
            return
        cfg = self._selected_shelf_printer_cfg()

        def worker():
            try:
                from .. import printer
                printer.send_image(
                    out, cfg, copies=copies, label_mm=(w_mm, h_mm),
                    gap_mm=getattr(self, "label_gap_mm", 2.0),
                    dpi=getattr(self, "printer_dpi", 203),
                )
                addr = printer.cfg_label(cfg)
                self.after(0, lambda: self.status.set(
                    f"🏷 Raf etiketi ×{copies} {addr} yazıcısına gönderildi."))
            except Exception as e:
                log.exception("Raf etiketi baskı hatası")
                self.after(0, lambda err=str(e): self.status.set(
                    f"❌ Raf etiketi yazdırılamadı: {err}"))

        threading.Thread(target=worker, daemon=True, name="raf-print").start()

    # ------------------------------------------------------------------
    # Kargo etiketi sekmesi (7.) — alıcı (adres defterli) + gönderen etiketi
    # ------------------------------------------------------------------
    _KARGO_ACTIVE_SENTINEL = "★ Aktif (ana) yazıcı"

    def _build_kargo_label_tab(self, parent: ttk.Frame):
        """Kargo etiketi: alıcı ad/telefon/adres DB'den aranır → seçilince gelir;
        basınca adres defterine kaydedilir. Ayrıca eczane gönderen etiketi."""
        C = COLORS

        self.var_kargo_ad = tk.StringVar()
        self.var_kargo_tel = tk.StringVar()
        self.var_kargo_firma = tk.StringVar(value=self.kargo_firma_son or "")
        self.var_kargo_ara = tk.StringVar()
        self.var_kargo_adet = tk.StringVar(value="1")
        self._kargo_preview_imgtk = None      # GC referansı
        self._kargo_search_results = []

        # === ÜST: giriş şeridi ===
        top = ttk.LabelFrame(parent, text="Kargo Etiketi — Alıcı (Hasta) Bilgisi",
                             padding=10)
        top.pack(fill="x", padx=10, pady=(10, 6))

        # Alıcı ara: yerel adres defteri + (ayar açıksa) Botanik hasta/kurum
        ttk.Label(top, text="Alıcı ara (ad / TC / kurum):").grid(
            row=0, column=0, sticky="e", padx=4, pady=4)
        self.ent_kargo_ara = ttk.Entry(top, textvariable=self.var_kargo_ara,
                                       width=28, font=("Segoe UI", 11))
        self.ent_kargo_ara.grid(row=0, column=1, sticky="we", padx=4, pady=4)
        self.ent_kargo_ara.bind("<KeyRelease>", self._kargo_search_typed)
        ttk.Button(top, text="🆕 Yeni / Temizle",
                   command=self._kargo_clear).grid(row=0, column=2, sticky="w", padx=4)

        # Arama sonuçları — yalnız sonuç varken görünür
        self.lst_kargo_results = tk.Listbox(top, height=4, font=("Consolas", 10))
        self.lst_kargo_results.grid(row=1, column=0, columnspan=3, sticky="we",
                                    padx=4, pady=(0, 4))
        self.lst_kargo_results.bind("<Double-Button-1>", self._kargo_pick)
        self.lst_kargo_results.bind("<Return>", self._kargo_pick)
        self.lst_kargo_results.grid_remove()

        ttk.Separator(top, orient="horizontal").grid(
            row=2, column=0, columnspan=3, sticky="we", pady=(2, 6))

        ttk.Label(top, text="Ad Soyad:").grid(row=3, column=0, sticky="e", padx=4, pady=4)
        self.ent_kargo_ad = ttk.Entry(top, textvariable=self.var_kargo_ad,
                                      font=("Segoe UI", 12), width=34)
        self.ent_kargo_ad.grid(row=3, column=1, columnspan=2, sticky="w", padx=4, pady=4)

        ttk.Label(top, text="Telefon:").grid(row=4, column=0, sticky="e", padx=4, pady=4)
        self.ent_kargo_tel = ttk.Entry(top, textvariable=self.var_kargo_tel,
                                       font=("Segoe UI", 12), width=22)
        self.ent_kargo_tel.grid(row=4, column=1, columnspan=2, sticky="w", padx=4, pady=4)

        ttk.Label(top, text="Adres:").grid(row=5, column=0, sticky="ne", padx=4, pady=4)
        self.txt_kargo_adres = tk.Text(top, height=3, width=40, font=("Segoe UI", 11),
                                       wrap="word")
        self.txt_kargo_adres.grid(row=5, column=1, columnspan=2, sticky="w", padx=4, pady=4)
        self.txt_kargo_adres.bind("<KeyRelease>", lambda e: self._kargo_update_preview())

        ttk.Label(top, text="Kargo firması:").grid(row=6, column=0, sticky="e", padx=4, pady=4)
        self.cmb_kargo_firma = ttk.Combobox(
            top, textvariable=self.var_kargo_firma, values=self.kargo_firmalar,
            font=("Segoe UI", 11), width=24)
        self.cmb_kargo_firma.grid(row=6, column=1, sticky="w", padx=4, pady=4)

        # Tek-satır alanlar içeriğe göre boyutlanır; sağda kalan yatay alan boş
        # kalır (eskiden column 1'e weight verilip alanlar pencere boyunca
        # anlamsızca yayılıyordu).

        # === ORTA: önizleme (solda) + kontroller (sağda) ===
        mid = ttk.Frame(parent)
        mid.pack(fill="both", expand=True, padx=10, pady=4)

        prev_box = ttk.LabelFrame(mid, text="Önizleme", padding=10)
        prev_box.pack(side="left", fill="both", expand=True)
        self.var_kargo_preview = tk.StringVar(value="alici")
        sel_row = ttk.Frame(prev_box)
        sel_row.pack(anchor="w", pady=(0, 6))
        ttk.Radiobutton(sel_row, text="📦 Alıcı", value="alici",
                        variable=self.var_kargo_preview,
                        command=self._kargo_update_preview).pack(side="left", padx=(0, 12))
        ttk.Radiobutton(sel_row, text="🏢 Gönderici", value="gonderen",
                        variable=self.var_kargo_preview,
                        command=self._kargo_update_preview).pack(side="left")
        self.lbl_kargo_preview = tk.Label(prev_box, background=C["bg_main"],
                                          relief="solid", borderwidth=1)
        self.lbl_kargo_preview.pack(expand=True)

        side = ttk.Frame(mid)
        side.pack(side="left", fill="y", padx=(10, 0))

        ttk.Label(side, text="Adet (kopya):").pack(anchor="w", pady=(4, 2))
        ttk.Spinbox(side, from_=1, to=99, width=8, textvariable=self.var_kargo_adet,
                    font=("Segoe UI", 12)).pack(anchor="w")

        ttk.Button(side, text="📦  Alıcı Etiketi Bas", style="Accent.TButton",
                   command=self._kargo_print).pack(fill="x", pady=(16, 4), ipady=8)
        ttk.Button(side, text="🏢  Gönderici Etiketi Bas",
                   command=self._kargo_print_sender).pack(fill="x", pady=2, ipady=4)
        ttk.Button(side, text="💾 Adrese Kaydet",
                   command=lambda: self._kargo_save_alici(silent=False)).pack(fill="x", pady=2)
        ttk.Button(side, text="🧹 Temizle",
                   command=self._kargo_clear).pack(fill="x", pady=2)
        ttk.Button(side, text="⚙ Kargo Ayarları",
                   command=self._kargo_open_settings).pack(fill="x", pady=(8, 2))

        info = tk.Label(
            side,
            text=("Ad / TC / kurum yaz → seçince adres-telefon gelir.\n"
                  "📒 kayıtlı  🟢 Botanik hasta  🏢 Botanik kurum.\n"
                  "Basınca adres deftere kaydedilir (sonra hazır gelir).\n"
                  "Boyut/yazıcı/firma listesi: ⚙ Kargo Ayarları."),
            background=C["bg_main"], foreground=C["text_muted"],
            font=("Segoe UI", 8), justify="left",
        )
        info.pack(anchor="w", pady=(16, 0))

        for v in (self.var_kargo_ad, self.var_kargo_tel, self.var_kargo_firma):
            v.trace_add("write", lambda *a: self._kargo_update_preview())
        self._kargo_update_preview()

    # --- Kargo etiketi: olay/işleyiciler ---
    def _kargo_get_adres(self) -> str:
        return self.txt_kargo_adres.get("1.0", "end").strip()

    def _kargo_set_adres(self, text: str):
        self.txt_kargo_adres.delete("1.0", "end")
        if text:
            self.txt_kargo_adres.insert("1.0", text)

    def _kargo_search_typed(self, event=None):
        q = self.var_kargo_ara.get().strip()
        self.lst_kargo_results.delete(0, "end")
        results: list[dict] = []
        # 1) Yerel adres defteri (kaydedilmiş alıcılar)
        try:
            from ..db import search_kargo_alici
            with get_connection() as conn:
                for r in search_kargo_alici(conn, q):
                    r = dict(r)
                    r["kaynak"] = "yerel"
                    results.append(r)
        except Exception:
            log.exception("Kargo yerel arama hatası")
        # 2) Botanik (ayar açıksa) — ad veya TC ile hasta/kurum; yerelde olmayanları ekle
        if len(q) >= 3:
            try:
                from ..botanik_db import search_recipients_from_settings
                with get_connection() as conn:
                    s = {row["key"]: row["value"] for row in
                         conn.execute("SELECT key, value FROM settings")}
                have = {(r.get("ad"), r.get("adres") or "") for r in results}
                for r in search_recipients_from_settings(s, q):
                    if (r["ad"], r["adres"]) not in have:
                        results.append(r)
            except Exception:
                log.exception("Kargo Botanik arama hatası")
        self._kargo_search_results = results
        for r in results:
            if r.get("kaynak") == "botanik":
                icon = "🏢" if r.get("tip") == "kurum" else "🟢"
                detail = (r.get("adres") or "")[:42]
            else:
                icon = "📒"
                detail = (r.get("telefon") or "") or (r.get("adres") or "")[:42]
            self.lst_kargo_results.insert("end", f"{icon} {r['ad']}  ·  {detail}")
        if results:
            self.lst_kargo_results.grid()
        else:
            self.lst_kargo_results.grid_remove()

    def _kargo_pick(self, event=None):
        sel = self.lst_kargo_results.curselection()
        if not sel:
            return
        r = self._kargo_search_results[sel[0]]
        self.var_kargo_ad.set(r.get("ad") or "")
        self.var_kargo_tel.set(r.get("telefon") or "")
        self._kargo_set_adres(r.get("adres") or "")
        if r.get("kargo_firma"):
            self.var_kargo_firma.set(r["kargo_firma"])
        self.lst_kargo_results.grid_remove()
        self.var_kargo_ara.set("")
        self._kargo_update_preview()

    def _kargo_render(self, for_screen: bool = False):
        """Alıcı etiketi. for_screen=True → şerit firmaya göre RENKLİ (önizleme);
        baskıda for_screen=False → şerit siyah (termal yazıcı yalnız siyah basar)."""
        from ..label_render import render_kargo_label, kargo_firma_renk
        firma = self.var_kargo_firma.get().strip()
        return render_kargo_label(
            alici_ad=self.var_kargo_ad.get().strip(),
            telefon=self.var_kargo_tel.get().strip(),
            adres=self._kargo_get_adres(),
            kargo_firma=firma,
            eczane_adi=self.eczane_adi,
            eczane_telefon=self.eczane_tel,
            firma_renk=kargo_firma_renk(firma) if for_screen else None,
        )

    def _kargo_render_sender(self, for_screen: bool = False):
        """Gönderici (eczane) etiketi. for_screen=True → kargo şeridi RENKLİ
        (önizleme); baskıda siyah. Kargo firması alıcı etiketindekiyle aynı."""
        from ..label_render import render_kargo_sender_label, kargo_firma_renk
        firma = self.var_kargo_firma.get().strip()
        return render_kargo_sender_label(
            eczane_adi=self.eczane_adi,
            eczane_telefon=self.eczane_tel,
            eczane_adres=getattr(self, "eczane_adres", ""),
            kargo_firma=firma,
            firma_renk=kargo_firma_renk(firma) if for_screen else None,
        )

    def _kargo_update_preview(self, *_a):
        try:
            mode = getattr(self, "var_kargo_preview", None)
            if mode is not None and mode.get() == "gonderen":
                img = self._kargo_render_sender(for_screen=True)
            else:
                img = self._kargo_render(for_screen=True)
            pw = 360
            ph = round(pw * img.height / img.width)
            self._kargo_preview_imgtk = ImageTk.PhotoImage(img.resize((pw, ph)))
            self.lbl_kargo_preview.configure(image=self._kargo_preview_imgtk)
        except Exception:
            log.exception("Kargo etiketi önizleme hatası")

    def _kargo_save_alici(self, silent: bool = True) -> bool:
        """Alıcıyı adres defterine kaydeder (upsert). silent=False ise durum yazar."""
        ad = self.var_kargo_ad.get().strip()
        if not ad:
            if not silent:
                self.status.set("⚠ Kaydetmek için en az ad gerekli.")
            return False
        try:
            from ..db import upsert_kargo_alici, save_setting
            firma = self.var_kargo_firma.get().strip()
            with get_connection() as conn:
                upsert_kargo_alici(
                    conn, ad,
                    telefon=self.var_kargo_tel.get().strip(),
                    adres=self._kargo_get_adres(),
                    kargo_firma=firma,
                )
                if firma:
                    save_setting(conn, "kargo_firma_son", firma)
            if firma:
                self.kargo_firma_son = firma
            if not silent:
                self.status.set(f"💾 '{ad}' adres defterine kaydedildi.")
            return True
        except Exception:
            log.exception("Kargo alıcı kaydetme hatası")
            if not silent:
                self.status.set("❌ Adres defterine kaydedilemedi.")
            return False

    def _kargo_print_image(self, img, prefix: str, copies: int) -> bool:
        """Üretilen kargo etiketini PNG'ye yazıp kargo yazıcısına gönderir."""
        try:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            out = self._preview_dir / f"{prefix}_{ts}.png"
            img.save(out)
        except Exception:
            log.exception("Kargo etiketi üretme hatası")
            self.status.set("❌ Kargo etiketi üretilemedi.")
            return False
        try:
            from .. import printer
            cfg = self._printer_cfg_by_name(self.kargo_printer_active) \
                if getattr(self, "kargo_printer_active", "") else self._active_printer_cfg()
            printer.send_image(
                out, cfg, copies=copies,
                label_mm=(getattr(self, "kargo_label_w_mm", 60.0),
                          getattr(self, "kargo_label_h_mm", 40.0)),
                gap_mm=getattr(self, "label_gap_mm", 2.0),
                dpi=getattr(self, "printer_dpi", 203),
            )
            addr = printer.cfg_label(cfg)
            self.status.set(f"📦 Kargo etiketi ×{copies} → {addr}")
            return True
        except Exception as e:
            log.exception("Kargo etiketi baskı hatası")
            self.status.set(f"❌ Kargo etiketi yazdırılamadı: {e}")
            return False

    def _kargo_print(self):
        ad = self.var_kargo_ad.get().strip()
        if not ad:
            self.status.set("⚠ Alıcı etiketi: ad gerekli.")
            self.ent_kargo_ad.focus_set()
            return
        if not self._kargo_get_adres():
            if not messagebox.askyesno("Adres boş",
                                       "Alıcı adresi boş. Yine de bassın mı?",
                                       parent=self):
                self.txt_kargo_adres.focus_set()
                return
        try:
            copies = max(1, int(self.var_kargo_adet.get()))
        except (TypeError, ValueError):
            copies = 1
        # Önce adres defterine kaydet (bir sonraki sefer hazır gelsin), sonra bas.
        self._kargo_save_alici(silent=True)
        self._kargo_print_image(self._kargo_render(), "kargo_alici", copies)

    def _kargo_print_sender(self):
        if not self.eczane_adi:
            self.status.set("⚠ Gönderen etiketi: eczane adı tanımlı değil (Ayarlar).")
            return
        try:
            copies = max(1, int(self.var_kargo_adet.get()))
        except (TypeError, ValueError):
            copies = 1
        self._kargo_print_image(self._kargo_render_sender(), "kargo_gonderen", copies)

    def _kargo_clear(self):
        self.var_kargo_ad.set("")
        self.var_kargo_tel.set("")
        self._kargo_set_adres("")
        self.var_kargo_ara.set("")
        self.var_kargo_firma.set(self.kargo_firma_son or "")
        self.lst_kargo_results.grid_remove()
        self.ent_kargo_ad.focus_set()
        self._kargo_update_preview()

    def _kargo_open_settings(self):
        """Kargo etiketi ayar diyaloğu: boyut (mm) + ayrı yazıcı + firma listesi."""
        dlg = tk.Toplevel(self)
        dlg.title("Kargo Etiketi Ayarları")
        dlg.transient(self)
        dlg.resizable(False, False)
        pad = {"padx": 8, "pady": 4}

        # --- Boyut ---
        sz = ttk.LabelFrame(dlg, text="Etiket Boyutu (mm)", padding=10)
        sz.grid(row=0, column=0, sticky="we", **pad)
        ttk.Label(sz, text="Genişlik:").grid(row=0, column=0, sticky="e", padx=(0, 6), pady=2)
        var_w = tk.StringVar(value=self._fmt_mm(self.kargo_label_w_mm))
        ttk.Entry(sz, textvariable=var_w, width=8).grid(row=0, column=1, sticky="w")
        ttk.Label(sz, text="mm").grid(row=0, column=2, sticky="w", padx=(2, 0))
        ttk.Label(sz, text="Yükseklik:").grid(row=1, column=0, sticky="e", padx=(0, 6), pady=2)
        var_h = tk.StringVar(value=self._fmt_mm(self.kargo_label_h_mm))
        ttk.Entry(sz, textvariable=var_h, width=8).grid(row=1, column=1, sticky="w")
        ttk.Label(sz, text="mm").grid(row=1, column=2, sticky="w", padx=(2, 0))

        # --- Yazıcı ---
        pr = ttk.LabelFrame(dlg, text="Yazıcı (kargo için ayrı seçim)", padding=10)
        pr.grid(row=1, column=0, sticky="we", **pad)
        names = [self._KARGO_ACTIVE_SENTINEL] + [
            p.get("name", "") for p in getattr(self, "printers", []) if p.get("name")
        ]
        want = getattr(self, "kargo_printer_active", "") or ""
        var_pr = tk.StringVar(value=want if want in names else self._KARGO_ACTIVE_SENTINEL)
        ttk.Combobox(pr, textvariable=var_pr, state="readonly", width=34,
                     values=names).pack(fill="x")

        # --- Firma listesi ---
        fr = ttk.LabelFrame(dlg, text="Kargo Firmaları (her satıra bir firma)", padding=10)
        fr.grid(row=2, column=0, sticky="we", **pad)
        txt_firms = tk.Text(fr, height=6, width=34, font=("Segoe UI", 11))
        txt_firms.pack(fill="x")
        txt_firms.insert("1.0", "\n".join(self.kargo_firmalar))

        def _save():
            def _p(var, default):
                try:
                    return float((var.get() or "").replace(",", "."))
                except (TypeError, ValueError):
                    return default
            w_mm = min(120.0, max(15.0, _p(var_w, self.kargo_label_w_mm)))
            h_mm = min(120.0, max(10.0, _p(var_h, self.kargo_label_h_mm)))
            sel = (var_pr.get() or "").strip()
            printer_active = "" if sel == self._KARGO_ACTIVE_SENTINEL else sel
            firms = [ln.strip() for ln in txt_firms.get("1.0", "end").splitlines()
                     if ln.strip()]
            self.kargo_label_w_mm, self.kargo_label_h_mm = w_mm, h_mm
            self.kargo_printer_active = printer_active
            self.kargo_firmalar = firms
            try:
                from ..db import save_setting
                with get_connection() as conn:
                    save_setting(conn, "kargo_label_w_mm", self._fmt_mm(w_mm))
                    save_setting(conn, "kargo_label_h_mm", self._fmt_mm(h_mm))
                    save_setting(conn, "kargo_printer_active", printer_active)
                    save_setting(conn, "kargo_firmalar", "|".join(firms))
                self.cmb_kargo_firma.configure(values=firms)
                self.status.set("💾 Kargo etiketi ayarları kaydedildi.")
            except Exception:
                log.exception("Kargo ayarı kaydetme hatası")
                self.status.set("❌ Kargo ayarları kaydedilemedi.")
            dlg.destroy()

        btns = ttk.Frame(dlg)
        btns.grid(row=3, column=0, sticky="e", **pad)
        ttk.Button(btns, text="💾 Kaydet", style="Accent.TButton",
                   command=_save).pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="İptal", command=dlg.destroy).pack(side="left")

    # ------------------------------------------------------------------
    # Otomatik (Medula) sekme
    # ------------------------------------------------------------------
    @staticmethod
    def _fmt_hotkey(combo: str) -> str:
        """'ctrl+shift+e' → 'Ctrl+Shift+E', 'shift+scroll_lock' → 'Shift+ScrollLock'."""
        if not combo:
            return ""
        out = []
        for tok in str(combo).split("+"):
            tok = tok.strip()
            low = tok.lower()
            if low == "scroll_lock":
                out.append("ScrollLock")
            elif low in ("ctrl", "control"):
                out.append("Ctrl")
            elif low == "alt":
                out.append("Alt")
            elif low == "shift":
                out.append("Shift")
            elif len(tok) == 1:
                out.append(tok.upper())
            elif tok:
                out.append(tok[:1].upper() + tok[1:])
        return "+".join(out)

    def _btn_label(self, base: str, hk_attr: str, default: str = "") -> str:
        """Buton metni: ana metin + (kısayol varsa) 2. satırda küçük kısayol."""
        s = self._fmt_hotkey(getattr(self, hk_attr, default))
        return f"{base}\n[{s}]" if s else base

    def _refresh_action_button_labels(self):
        """Ayarlar'dan kısayol değişince eylem butonlarının metnini tazele."""
        for attr, base, hk, dflt in (
            ("_btn_emanet", "📌 Emanet Etiketi", "hotkey_emanet", "ctrl+shift+e"),
            ("_btn_hasta",  "🧾 Hasta Etiketi",  "hotkey_hasta_etiketi", "shift+scroll_lock"),
            ("_btn_print",  "🖨  SEÇİLİ REÇETEYİ YAZDIR", "hotkey_recete_sonu", "shift+f12"),
        ):
            b = getattr(self, attr, None)
            if b is not None:
                try:
                    b.configure(text=self._btn_label(base, hk, dflt))
                except Exception:
                    pass
        b = getattr(self, "_btn_botanik", None)
        if b is not None and getattr(self, "_layout_mode", "normal") != "small":
            try:
                b.configure(text=self._btn_label(
                    "🛒 Botanik Satıştan Etiket Topla", "hotkey_parekende", "shift+p"))
            except Exception:
                pass

    def _build_auto_tab(self, parent: ttk.Frame):
        C = COLORS

        # NOT: Watcher kontrolleri (Başlat / Durdur / Temizle / checkbox'lar) ve
        # İLAÇ TARİF başlığı artık üst sekme satırına bindirilen şeritte yaşıyor
        # (_build_top_overlay). Burada ayrı kontrol şeridi yok → etiket alanı azami.

        # Sol + Sağ panel (PanedWindow yerine sabit sol genişlik — image taşmasın)
        wrapper = ttk.Frame(parent)
        wrapper.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        # --- Sol: yakalanan reçeteler (SABİT 230 px) + altta YAZDIR butonu ---
        left = ttk.LabelFrame(wrapper, text="Yakalanan Reçeteler", padding=4,
                              width=230)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)
        self._auto_left_panel = left   # küçük ekran modunda gizlenecek

        # Alt: büyük YAZDIR butonu — sol panelin dibine (eski tam-genişlik şeridi
        # kaldırıldı; o yükseklik etiket önizleme alanına eklendi).
        btn_frame = tk.Frame(left, background=C["bg_strip"])
        btn_frame.pack(side="bottom", fill="x", pady=(6, 0))
        # "Sadece temel etiketi bas" kutusu üst araç çubuğuna (Yazıcı Önizleme
        # yanına) taşındı — bkz. _build_auto_tab sub_btns.
        # Kalıcı değerleri DB'den al (_init_db daha önce çalışıp *_initial sakladı)
        self._only_basic_var = tk.BooleanVar(
            value=getattr(self, "_only_basic_initial", False))
        self._only_basic_display_var = tk.BooleanVar(
            value=getattr(self, "_only_basic_display_initial", False))
        # Düzen (yukarıdan aşağıya): EN ÜST Listeyi Temizle (kırmızı) → renkli
        # eylem butonları (Emanet mor · Hasta sarı · Botanik mavi) → EN ALT büyük
        # YAZDIR (yeşil). Her butonun 2. satırında Ayarlar'dan gelen kısayol.
        self._btn_temizle = ttk.Button(
            btn_frame, text="🧹 Listeyi Temizle", style="Clear.TButton",
            command=self._clear_captured)
        self._btn_temizle.pack(fill="x", padx=4, pady=(6, 6), ipady=2)
        self._btn_emanet = ttk.Button(
            btn_frame,
            text=self._btn_label("📌 Emanet Etiketi", "hotkey_emanet", "ctrl+shift+e"),
            style="Emanet.TButton", command=self._open_emanet_dialog)
        self._btn_emanet.pack(fill="x", padx=4, pady=2)
        self._btn_hasta = ttk.Button(
            btn_frame,
            text=self._btn_label("🧾 Hasta Etiketi", "hotkey_hasta_etiketi", "shift+scroll_lock"),
            style="Yellow.TButton", command=self._hasta_etiketi_hotkey_fired)
        self._btn_hasta.pack(fill="x", padx=4, pady=2)
        self._btn_botanik = ttk.Button(
            btn_frame,
            text=self._btn_label("🛒 Botanik Satıştan Etiket Topla", "hotkey_parekende", "shift+p"),
            style="Botanik.TButton", command=self._import_botanik_sale)
        self._btn_botanik.pack(fill="x", padx=4, pady=2)
        self._btn_print = ttk.Button(
            btn_frame,
            text=self._btn_label("🖨  SEÇİLİ REÇETEYİ YAZDIR", "hotkey_recete_sonu", "shift+f12"),
            style="Accent.TButton", command=self._on_auto_print)
        self._btn_print.pack(fill="x", padx=4, pady=(2, 4), ipady=8)

        tree_wrap = tk.Frame(left, background=C["bg_panel"])
        tree_wrap.pack(side="top", fill="both", expand=True)
        cols = ("hasta", "rno", "tarih", "ilac", "durum")
        self.auto_tree = ttk.Treeview(tree_wrap, columns=cols, show="headings", height=20)
        self.auto_tree.heading("hasta", text="Hasta")
        self.auto_tree.heading("rno", text="Reçete No")
        self.auto_tree.heading("tarih", text="Tarih")
        self.auto_tree.heading("ilac", text="İlaç")
        self.auto_tree.heading("durum", text="Aşama")
        self.auto_tree.column("hasta", width=100, minwidth=70)
        self.auto_tree.column("rno", width=64, minwidth=50)
        self.auto_tree.column("tarih", width=64, anchor="center", minwidth=56)
        self.auto_tree.column("ilac", width=28, anchor="center", minwidth=24)
        self.auto_tree.column("durum", width=80, minwidth=56)
        ysb1 = ttk.Scrollbar(tree_wrap, orient="vertical", command=self.auto_tree.yview)
        xsb1 = ttk.Scrollbar(tree_wrap, orient="horizontal", command=self.auto_tree.xview)
        self.auto_tree.configure(yscrollcommand=ysb1.set, xscrollcommand=xsb1.set)
        xsb1.pack(side="bottom", fill="x")
        self.auto_tree.pack(side="left", fill="both", expand=True)
        ysb1.pack(side="right", fill="y")
        self.auto_tree.bind("<<TreeviewSelect>>", self._on_auto_select)

        # --- Sağ: seçili reçetenin etiket görselleri (kalan tüm alan) ---
        right = ttk.LabelFrame(wrapper, text="Etiket Önizlemeleri", padding=4)
        right.pack(side="left", fill="both", expand=True)

        # Alt sekmeler: Reçete Başı | Reçete Sonu — her aşama kendi sekmesinde.
        # Ayrı buton satırı kaldırıldı; sekmeler en üste çekildi → etikete daha çok yer.
        self.auto_sub_nb = ttk.Notebook(right)
        self.auto_sub_nb.pack(fill="both", expand=True)
        tab_early = ttk.Frame(self.auto_sub_nb, style="Panel.TFrame")
        tab_final = ttk.Frame(self.auto_sub_nb, style="Panel.TFrame")
        self.auto_sub_nb.add(tab_early, text="  📝  Reçete Başı  ")
        self.auto_sub_nb.add(tab_final, text="  ✅  Reçete Sonu (SGK)  ")
        self.early_canvas, self.early_inner = self._make_scroll_area(tab_early)
        self.final_canvas, self.final_inner = self._make_scroll_area(tab_final)
        self.auto_sub_nb.select(tab_final)   # varsayılan görünüm: Reçete Sonu

        # Görünüm seçenekleri: alt sekme satırının sağ boşluğuna bindirilen iki
        # kutu (Reçete Başı/Sonu sekmeleriyle aynı hizada). Eylem butonları
        # (Yazıcı Önizleme, Farkları Tablo, Emanet, Hasta) buradan kaldırıldı —
        # Emanet/Hasta sol panele Yazdır altına taşındı; Önizleme/Farkları silindi.
        sub_btns = tk.Frame(right, background=COLORS["bg_panel"])
        sub_btns.place(in_=self.auto_sub_nb, relx=1.0, x=-2, y=1, anchor="ne")
        # Global baskı seçeneği: işaretliyse her ilaçtan yalnız TEMEL (A) etiketi
        # basılır (2./3./4. etiket basılmaz).
        ttk.Checkbutton(
            sub_btns, text="Sadece temel etiket",
            variable=self._only_basic_var, style="Strip.TCheckbutton",
            command=self._persist_only_basic_prefs,
        ).pack(side="right", padx=(2, 8))
        ttk.Checkbutton(
            sub_btns, text="Ekranda sadece temel",
            variable=self._only_basic_display_var, style="Strip.TCheckbutton",
            command=self._on_only_basic_display_changed,
        ).pack(side="right", padx=(2, 4))

    # ------------------------------------------------------------------
    # İlaç bulma
    # ------------------------------------------------------------------
    def _find_drug_by_barcode(self, barcode: str):
        with get_connection() as conn:
            return conn.execute(
                "SELECT id, barcode, name FROM drugs WHERE barcode=?", (barcode,)
            ).fetchone()

    def _search_drugs_by_name(self, q: str, limit: int = 30):
        q = q.strip()
        if len(q) < 2:
            return []
        with get_connection() as conn:
            return conn.execute(
                "SELECT id, barcode, name FROM drugs WHERE name LIKE ? "
                "ORDER BY sales_count DESC LIMIT ?",
                (f"%{q}%", limit),
            ).fetchall()

    # ------------------------------------------------------------------
    # Olaylar
    # ------------------------------------------------------------------
    def _on_barkod_enter(self, event=None):
        raw = self.var_barkod.get().strip()
        if not raw:
            return
        barcode = parse_karekod(raw)
        if not barcode:
            self.status.set(f"❌ Karekod/barkod tanınamadı: {raw[:40]}")
            return
        row = self._find_drug_by_barcode(barcode)
        if not row:
            # DB'de yok — yine de eklemesine izin ver (manuel ad sor)
            from tkinter.simpledialog import askstring
            ad = askstring("İlaç DB'de yok",
                           f"Barkod: {barcode}\nİlaç adını manuel girin:", parent=self)
            if not ad:
                return
            self._add_drug(barcode, ad, drug_id=None)
        else:
            self._add_drug(row["barcode"], row["name"], drug_id=row["id"])
        self.var_barkod.set("")
        self.ent_barkod.focus_set()

    def _on_search_typed(self, event=None):
        q = self.var_ara.get()
        self.lst_results.delete(0, "end")
        results = self._search_drugs_by_name(q)
        self._search_results = results
        for r in results:
            self.lst_results.insert("end", f"{r['barcode']:15} | {r['name']}")
        if results:
            self.lst_results.grid()   # sonuç var → göster
            self.status.set(f"{len(results)} sonuç — çift tıkla / Enter ile ekle")
        else:
            self.lst_results.grid_remove()   # boş → gizle (yer kaplamasın)
            self.status.set("Sonuç yok." if q.strip() else "")

    def _on_result_double(self, event=None):
        sel = self.lst_results.curselection()
        if not sel:
            return
        row = self._search_results[sel[0]]
        self._add_drug(row["barcode"] or "", row["name"], drug_id=row["id"])
        self.var_ara.set("")
        self.lst_results.delete(0, "end")
        self.lst_results.grid_remove()
        self.ent_barkod.focus_set()

    def _add_drug(self, barcode: str, name: str, drug_id: Optional[int]):
        # Mükerrer önle
        for r in self.rows:
            if r.barcode and r.barcode == barcode:
                self.status.set(f"⚠ Zaten ekli: {name}")
                return
        self.rows.append(DrugRow(barcode, name, drug_id))
        self._refresh_table()
        # Yeni eklenen ilacı otomatik seç → düzenleyici ona bağlanır
        self._select_manual_row(len(self.rows) - 1)
        self.status.set(f"✓ Eklendi: {name} — sağdan doz/zaman/öğün düzenleyin")

    def _refresh_table(self):
        # Düzenleyicide bağlı satırı koru (yeniden seçmek için)
        sel_row = getattr(self.editor, "row", None) if hasattr(self, "editor") else None
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        for i, r in enumerate(self.rows):
            self.tree.insert("", "end", iid=str(i),
                             values=(i + 1, r.name, self._format_doz(r)))
        if not hasattr(self, "editor"):
            return
        # Seçimi yeniden kur: bağlı satır hâlâ varsa onu, yoksa sonuncuyu, hiç
        # yoksa düzenleyiciyi boşalt.
        if sel_row in self.rows:
            self._select_manual_row(self.rows.index(sel_row))
        elif self.rows:
            self._select_manual_row(len(self.rows) - 1)
        else:
            self.editor.set_row(None)

    def _select_manual_row(self, idx: int):
        """Listede idx'li satırı seç ve düzenleyiciyi o ilaca bağla."""
        iid = str(idx)
        if iid in self.tree.get_children():
            self.tree.selection_set(iid)
            self.tree.see(iid)
            if hasattr(self, "editor"):
                self.editor.set_row(self.rows[idx])

    def _on_manual_select(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        if 0 <= idx < len(self.rows) and hasattr(self, "editor"):
            self.editor.set_row(self.rows[idx])

    def _on_editor_change(self, row: DrugRow):
        """Düzenleyici canlı değişiklik yaptıkça tablodaki o satırın metnini tazele."""
        try:
            idx = self.rows.index(row)
        except ValueError:
            return
        self.tree.item(str(idx), values=(idx + 1, row.name, self._format_doz(row)))

    def _schedule_editor_preview(self):
        if hasattr(self, "editor"):
            self.editor.schedule_preview()

    def _format_doz(self, r: DrugRow) -> str:
        if float(r.doz_adet).is_integer():
            s = str(int(r.doz_adet))
        else:
            s = f"{r.doz_adet:.1f}".replace(".", ",")
        return f"{s} {r.doz_birim}" if r.doz_birim else s

    def _on_row_delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        del self.rows[idx]
        self._refresh_table()

    def _on_clear_all(self):
        if not self.rows:
            return
        if messagebox.askyesno("Onay", f"{len(self.rows)} ilacı silmek istediğinize emin misiniz?"):
            self.rows.clear()
            self._refresh_table()

    # ------------------------------------------------------------------
    # Çıktı: önizleme & yazdır
    # ------------------------------------------------------------------
    def _manual_recete_date(self) -> datetime.date:
        """Reçete tarihi alanını datetime.date'e çevir (hatalıysa bugün)."""
        try:
            d, m, y = self.var_tarih.get().split("/")
            return datetime.date(int(y), int(m), int(d))
        except Exception:
            return datetime.date.today()

    def _manual_label_image(self, r: DrugRow, hasta: str, r_date: datetime.date):
        """Tek bir manuel ilaç satırından kullanım etiketi görseli (PIL) üret."""
        talimat = r.talimat
        if not talimat:
            doz = self._format_doz(r)
            talimat = build_kullanim_talimati(
                drug_name=r.name, gunluk_kez=r.gunluk_kez, doz_str=doz,
                parenteral_route_mode=("recete"
                    if getattr(self, "_erecete_parenteral_route", False)
                    else "generic"),
            )
        label = UsageLabel(
            kategori=r.kategori, kullanim_talimati=talimat, uyari_metni=r.uyari,
            ilac_turu=guess_form(r.name), doz=self._format_doz(r),
            gunluk_kez=r.gunluk_kez, sure_gun=r.sure_gun,
            periyot=getattr(r, "periyot", "") or "Günde",
            kullanim_zamani=list(getattr(r, "kullanim_zamani", []) or []),
            meal_badge=getattr(r, "meal_badge", "") or "",
            doktor_notu=getattr(r, "not_metni", "") or "",
        )
        bitis = r_date + datetime.timedelta(days=int(r.sure_gun or 7))
        return render_usage_label(
            hasta_adi=hasta, ilac_adi=r.name, label=label,
            recete_tarihi=r_date, bitis_tarihi=bitis,
            eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
        )

    def _build_labels(self):
        hasta = (self.var_hasta.get() or "").strip().upper()
        if not hasta:
            messagebox.showwarning("Eksik", "Hasta adı boş olamaz.")
            return None
        if not self.rows:
            messagebox.showwarning("Eksik", "Hiç ilaç eklenmedi.")
            return None
        r_date = self._manual_recete_date()
        return [(r, self._manual_label_image(r, hasta, r_date)) for r in self.rows]

    def _on_preview(self):
        out = self._build_labels()
        if not out:
            return
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        preview_dir = Path(__file__).resolve().parents[3] / "data" / "live_preview"
        preview_dir.mkdir(parents=True, exist_ok=True)
        html_lines = ['<!DOCTYPE html><html><head><meta charset="utf-8"><style>',
                      'body{font-family:Segoe UI;background:#f3f4f8;padding:18px}',
                      '.lab{display:inline-block;margin:8px;background:#fff;border:1px solid #ccc;padding:6px;border-radius:6px}',
                      '.lab img{display:block;width:480px;height:320px;border:1px dashed #999}',
                      '.cap{font-size:12px;color:#555;margin-bottom:4px}',
                      '</style></head><body>']
        for i, (r, img) in enumerate(out):
            p = preview_dir / f"manual_{ts}_{i}.png"
            img.save(p)
            html_lines.append(f'<div class="lab"><div class="cap">{r.name}</div><img src="{p.name}"></div>')
        html_lines.append('</body></html>')
        out_path = preview_dir / f"manual_preview_{ts}.html"
        out_path.write_text("".join(html_lines), encoding="utf-8")
        webbrowser.open(out_path.as_uri())
        self.status.set(f"✓ Önizleme açıldı: {out_path.name}")

    def _on_print(self):
        out = self._build_labels()
        if not out:
            return
        try:
            from .. import printer
        except ImportError:
            messagebox.showerror("Yazıcı", "Printer modülü yüklenemedi.")
            return
        cfg = self._active_printer_cfg()
        addr = printer.cfg_label(cfg)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        preview_dir = Path(__file__).resolve().parents[3] / "data" / "live_preview"
        preview_dir.mkdir(parents=True, exist_ok=True)
        sent = 0
        _lmm = (getattr(self, "label_w_mm", 60.0), getattr(self, "label_h_mm", 40.0))
        _gmm = getattr(self, "label_gap_mm", 2.0)
        _dpi = getattr(self, "printer_dpi", 203)
        for i, (r, img) in enumerate(out):
            p = preview_dir / f"manual_{ts}_{i}.png"
            img.save(p)
            try:
                printer.send_image(p, cfg, label_mm=_lmm, gap_mm=_gmm, dpi=_dpi)
                sent += 1
            except Exception as e:
                messagebox.showerror("Yazıcı hatası",
                                     f"{r.name}\n\nYazıcı: {addr}\n{e}")
                break
        self.status.set(f"🖨 {sent} etiket {addr} yazıcısına gönderildi.")

    # ------------------------------------------------------------------
    # Otomatik (Medula) sekme — watcher + UI handler'lar
    # ------------------------------------------------------------------
    def _update_watcher_btn(self):
        """Üst banttaki durum göstergesini + (açıksa) Ayarlar'daki toggle butonunu
        mevcut watcher durumuna göre günceller."""
        status = self.var_watcher_status.get()

        # --- Üst banttaki salt-okunur durum etiketi (her zaman var) ---
        lbl = getattr(self, "_watcher_status_lbl", None)
        if lbl is not None:
            try:
                if "Çalışıyor" in status:
                    col = COLORS["accent_green"]
                elif "HATA" in status:
                    col = COLORS.get("accent_orange", "#f97316")
                else:
                    col = COLORS["text_muted"]
                lbl.config(foreground=col)
            except Exception:
                pass

        # --- Ayarlar penceresindeki Başlat/Durdur butonu (yalnız pencere açıkken) ---
        btn = getattr(self, "_btn_watcher", None)
        if btn is not None:
            try:
                if not btn.winfo_exists():
                    self._btn_watcher = None
                    btn = None
            except Exception:
                self._btn_watcher = None
                btn = None
        if btn is None:
            return
        if "Çalışıyor" in status:
            btn.config(text="■  Durdur", background=COLORS["accent_red"],
                       command=self._stop_watcher)
        elif "HATA" in status:
            btn.config(text="⚠  Yeniden Başlat", background=COLORS.get("accent_orange", "#f97316"),
                       command=self._start_watcher)
        else:
            btn.config(text="▶  Başlat", background=COLORS["accent_green"],
                       command=self._start_watcher)

    def _start_watcher(self):
        if self._watcher is not None:
            self.var_watcher_status.set("● Çalışıyor")
            self._update_watcher_btn()
            return
        try:
            self._watcher = MedulaWatcher(
                on_recete=self._watcher_callback,
                on_paper_tick=self._on_paper_tick,
                on_state=self._on_medula_state,
                interval=1.0,
                target_page_kinds=("e_recete_detay", "e_recete_basarili",
                                   "kagit_recete_basarili", "karekod_onay"),
            )
            self._watcher.start()
            self.var_watcher_status.set("● Çalışıyor")
            self._update_watcher_btn()
            self.status.set("Medula izleyici başladı (e-reçete + kağıt reçete).")
            self._register_print_hotkey()
        except Exception as e:
            log.exception("Watcher başlatılamadı")
            self.var_watcher_status.set("● HATA")
            self._update_watcher_btn()
            messagebox.showerror("Watcher", f"Başlatılamadı:\n{e}")

    def _stop_watcher(self):
        if self._watcher is None:
            return
        try:
            self._watcher.stop(timeout=2.0)
        except Exception:
            pass
        self._watcher = None
        self.var_watcher_status.set("● Kapalı")
        self._update_watcher_btn()
        self.status.set("Medula izleyici durduruldu.")
        # Watcher durunca pencere çerçevesini gizle
        ov = getattr(self, "_medula_overlay", None)
        if ov is not None:
            ov.set_state(None, None)

    def _on_medula_state(self, hwnd, theme):
        """Watcher thread'inden çağrılır: ön plandaki Medula penceresi + reçete teması.

        Tk işlemleri ana thread'de yapılmalı → self.after(0, ...) ile marshal edilir.
        """
        ov = getattr(self, "_medula_overlay", None)
        if ov is None:
            return
        try:
            self.after(0, lambda: ov.set_state(hwnd, theme))
        except Exception:
            pass

    # ==================================================================
    # Medula oturum yönetimi: canlı tutma + eski pencere kapatma
    # ==================================================================
    def _toggle_keepalive(self):
        if self.var_keepalive.get():
            self._show_keepalive_type_popup()
        else:
            self._cancel_keepalive()
            self._keepalive_countdown_var.set("")
            self.status.set("Medula canlı tutma kapatıldı.")

    def _show_keepalive_type_popup(self):
        """Canlı tut tipi seçim penceresi (A/B/C/D)."""
        popup = tk.Toplevel(self)
        popup.title("Canlı Tut — Tetikleme Tipi")
        popup.resizable(False, False)
        popup.grab_set()

        popup.update_idletasks()
        px = self.winfo_rootx() + self.winfo_width() // 2 - 195
        py = self.winfo_rooty() + self.winfo_height() // 2 - 130
        popup.geometry(f"390x285+{px}+{py}")

        tk.Label(popup, text="Hareketsizlik sonrası ne yapılsın?",
                 font=("Segoe UI", 10, "bold"), pady=10).pack()

        # Geri sayım süresi (saniye) — ayarlanabilir
        sec_frm = tk.Frame(popup)
        sec_frm.pack(fill="x", padx=20, pady=(0, 6))
        tk.Label(sec_frm, text="Geri sayım süresi (sn):",
                 font=("Segoe UI", 9)).pack(side="left")
        sec_var = tk.StringVar(value=str(self.KEEPALIVE_SECONDS))
        tk.Entry(sec_frm, textvariable=sec_var, width=6,
                 font=("Segoe UI", 9), justify="center").pack(side="left", padx=8)

        tip_var = tk.StringVar(value=self._keepalive_type)
        frm = tk.Frame(popup)
        frm.pack(fill="x", padx=20)
        tk.Radiobutton(frm,
                       text="A — F5 (Yenile) + Yeniden Dene kapat + Enter",
                       variable=tip_var, value="A",
                       font=("Segoe UI", 9)).pack(anchor="w", pady=3)
        tk.Radiobutton(frm,
                       text="B — \"Sonra >\" butonuna bas",
                       variable=tip_var, value="B",
                       font=("Segoe UI", 9)).pack(anchor="w", pady=3)
        tk.Radiobutton(frm,
                       text="C — E-Reçete Sorgula sayfasına tıkla",
                       variable=tip_var, value="C",
                       font=("Segoe UI", 9)).pack(anchor="w", pady=3)
        tk.Radiobutton(frm,
                       text="D — Giriş butonuna tıkla",
                       variable=tip_var, value="D",
                       font=("Segoe UI", 9)).pack(anchor="w", pady=3)

        _TIP_LABELS = {
            "A": "F5+Enter",
            "B": "Sonraki Butonu",
            "C": "E-Reçete Sorgu",
            "D": "Giriş Butonu",
        }

        def _on_ok():
            self._keepalive_type = tip_var.get()
            # Geri sayım süresini uygula (geçersiz/aralık dışı girişte 119'a düş)
            try:
                secs = int(float(sec_var.get().strip().replace(",", ".")))
            except (ValueError, AttributeError):
                secs = 119
            secs = max(5, min(3600, secs))
            self.KEEPALIVE_SECONDS = secs
            self.KEEPALIVE_MS = secs * 1000
            popup.destroy()
            tip_label = _TIP_LABELS.get(self._keepalive_type, self._keepalive_type)
            self.status.set(
                f"Medula canlı tutma AÇIK [{tip_label}] — "
                f"tıklama olmazsa {secs} sn sonra tetiklenir."
            )
            self._schedule_keepalive()
            self._keepalive_activity_poll()
            self._keepalive_countdown_tick()

        def _on_cancel():
            self.var_keepalive.set(False)
            popup.destroy()

        btn_frm = tk.Frame(popup)
        btn_frm.pack(pady=10)
        tk.Button(btn_frm, text="Tamam", width=10, command=_on_ok).pack(side="left", padx=8)
        tk.Button(btn_frm, text="İptal", width=10, command=_on_cancel).pack(side="left", padx=8)
        popup.protocol("WM_DELETE_WINDOW", _on_cancel)

    def _schedule_keepalive(self):
        """119 sn boşta sayacını (yeniden) başlat; geri sayım bitiş zamanını günceller."""
        for attr in ("_keepalive_after_id", "_keepalive_enter_after_id"):
            after_id = getattr(self, attr, None)
            if after_id is not None:
                try:
                    self.after_cancel(after_id)
                except Exception:
                    pass
                setattr(self, attr, None)
        import time
        self._keepalive_deadline_ms = time.monotonic() * 1000 + self.KEEPALIVE_MS
        self._keepalive_after_id = self.after(self.KEEPALIVE_MS, self._keepalive_tick)

    def _cancel_keepalive(self):
        """Tüm keep-alive zamanlayıcılarını durdur."""
        for attr in ("_keepalive_after_id", "_keepalive_enter_after_id",
                     "_keepalive_poll_after_id", "_keepalive_tick_after_id"):
            after_id = getattr(self, attr, None)
            if after_id is not None:
                try:
                    self.after_cancel(after_id)
                except Exception:
                    pass
                setattr(self, attr, None)
        self._keepalive_deadline_ms = None

    def _keepalive_countdown_tick(self):
        """Saniyede bir geri sayım etiketini günceller."""
        if not self.var_keepalive.get():
            return
        import time
        deadline = self._keepalive_deadline_ms
        if deadline is not None:
            remaining = max(0, deadline - time.monotonic() * 1000)
            secs = int(remaining / 1000) + 1
            self._keepalive_countdown_var.set(f"({secs:3d}s)")
        self._keepalive_tick_after_id = self.after(1000, self._keepalive_countdown_tick)

    def _keepalive_activity_poll(self):
        """Medula'ya yapılan tıklamaları dinler; her tıklamada 119 sn sayacı sıfırlar."""
        if not self.var_keepalive.get():
            return
        try:
            import ctypes
            u = ctypes.windll.user32
            lb = u.GetAsyncKeyState(0x01)   # VK_LBUTTON
            rb = u.GetAsyncKeyState(0x02)   # VK_RBUTTON
            down = bool(lb & 0x8000) or bool(rb & 0x8000)
            clicked_since = bool(lb & 0x0001) or bool(rb & 0x0001)
            prev = self._keepalive_mouse_down
            self._keepalive_mouse_down = down
            if (down and not prev) or clicked_since:
                from .. import medula_capture
                if medula_capture.is_medula_foreground():
                    self._schedule_keepalive()
                    self.status.set("Medula'da tıklama algılandı — geri sayım "
                                    f"sıfırlandı ({self.KEEPALIVE_SECONDS} sn).")
        except Exception:
            pass
        self._keepalive_poll_after_id = self.after(
            self.KEEPALIVE_POLL_MS, self._keepalive_activity_poll)

    def _keepalive_tick(self):
        """119 sn boşta kalınca: seçili tipe göre Medula'yı canlı tutar."""
        if not self.var_keepalive.get():
            return
        try:
            t = self._keepalive_type
            if t == "B":
                ok = click_sonraki_button()
                msg = ("Medula — \"Sonra >\" butonuna basıldı."
                       if ok else
                       "Medula — \"Sonra >\" butonu bulunamadı (A tipine geçin?).")
                if self.var_close_old.get():
                    closed = close_old_medula_windows()
                    if closed:
                        msg += f"  {len(closed)} eski pencere kapatıldı."
                self.status.set(msg)
            elif t == "C":
                ok = click_erecete_sorgu_button()
                self.status.set(
                    "Medula — E-Reçete Sorgu butonuna tıklandı." if ok else
                    "Medula — E-Reçete Sorgu butonu bulunamadı (sayfayı kontrol edin)."
                )
            elif t == "D":
                ok = click_giris_button()
                self.status.set(
                    "Medula — Giriş butonuna tıklandı." if ok else
                    "Medula — Giriş butonu bulunamadı (giriş ekranında olmalısınız)."
                )
            else:
                # A Tipi: F5 + Yeniden Dene kapat + Enter (varsayılan)
                targets = keep_alive_refresh()
                msg = f"Medula yenilendi ({len(targets)} pencere) — 1,5 sn sonra Enter."
                if self.var_close_old.get():
                    closed = close_old_medula_windows()
                    if closed:
                        msg += f"  {len(closed)} eski pencere kapatıldı."
                self.status.set(msg)
                self._keepalive_enter_after_id = self.after(
                    self.KEEPALIVE_ENTER_DELAY_MS,
                    lambda t=targets: self._keepalive_send_enter(t),
                )
        except Exception as e:
            log.warning("keep-alive hatası: %s", e)
            self.status.set(f"Canlı tutma hatası: {e}")
        finally:
            if self.var_keepalive.get():
                self._schedule_keepalive()

    def _keepalive_send_enter(self, targets):
        """F5'ten 1 sn sonra çalışır: yenilenen Medula sayfasına Enter gönderir."""
        self._keepalive_enter_after_id = None
        if not self.var_keepalive.get():
            return
        try:
            keep_alive_enter(targets)
        except Exception as e:
            log.warning("keep-alive Enter hatası: %s", e)

    def _on_toggle_close_old(self):
        """'Eski Pencereleri Kapat' işaretlendiğinde hemen bir kez uygula."""
        if self.var_close_old.get():
            try:
                closed = close_old_medula_windows()
                if closed:
                    self.status.set(f"{len(closed)} eski Medula penceresi kapatıldı: "
                                    + ", ".join(t[:24] for t in closed))
                else:
                    self.status.set("Kapatılacak eski Medula penceresi yok "
                                    "(ana pencere ve aktif pencere korunur).")
            except Exception as e:
                log.warning("eski pencere kapatma hatası: %s", e)
                self.status.set(f"Pencere kapatma hatası: {e}")
        else:
            self.status.set("Eski pencere kapatma kapatıldı.")

    def _start_bridge_if_enabled(self):
        from .. import printer as _printer
        if getattr(self, "print_bridge_enabled", False):
            self._start_bridge_server()

    def _start_bridge_server(self):
        from .. import printer as _printer
        if self._bridge_server and self._bridge_server.running:
            return
        port = getattr(self, "print_bridge_port", _printer.PRINT_BRIDGE_PORT)
        self._bridge_server = _printer.PrintBridgeServer(
            port=port,
            printer_cfg_fn=self._active_printer_cfg,
        )
        try:
            self._bridge_server.start()
            log.info("Köprü sunucu başlatıldı (port %s)", port)
        except Exception as e:
            log.error("Köprü sunucu başlatılamadı: %s", e)
            self._bridge_server = None

    def _stop_bridge_server(self):
        if self._bridge_server:
            self._bridge_server.stop()
            self._bridge_server = None

    # ------------------------------------------------------------------
    # İlk açılış kurulum sihirbazı — köprü rolü (köprübaşı / istemci)
    # ------------------------------------------------------------------
    def _maybe_first_run_setup(self):
        """İlk açılışta yazıcı/köprü rolü kurulum sihirbazını aç.

        - setup_done=1 ise hiç gösterme.
        - setup_done değil ama yazıcı zaten Ayarlar'dan yapılandırılmışsa
          (eski kurulum, printers_json mevcut) sihirbazı gösterme; sessizce
          tamamlandı işaretle.
        - Aksi halde (taze kurulum) ARKA PLANDA otomatik tespit dener; tek ve
          net sonuç varsa kendisi kurar, belirsizse sihirbazı açar.
        """
        if getattr(self, "setup_done", False):
            return
        if getattr(self, "_had_printers_json", False):
            self._mark_setup_done()
            return
        # Otomatik tespit (arka planda): net sonuç varsa kendisi kurar
        # (tek yazıcı → köprübaşı, tek köprü → istemci); 0 veya birden fazla
        # (belirsiz) ise sihirbazı açar.
        try:
            threading.Thread(target=self._auto_first_run_detect, daemon=True).start()
        except Exception:
            log.exception("Otomatik ilk-kurulum başlatılamadı")
            self._open_first_run_wizard_safe()

    def _open_first_run_wizard_safe(self):
        """Sihirbazı aç; açılamazsa kullanıcıyı sürekli rahatsız etme."""
        try:
            self._first_run_setup()
        except Exception:
            log.exception("İlk açılış sihirbazı açılamadı")
            self._mark_setup_done()

    def _auto_first_run_detect(self):
        """Arka planda yazıcı/köprü tespiti yapar. TEK ve net sonuç varsa
        sıfır-tık kurar; 0 veya birden fazla (belirsiz) ise sihirbazı açar."""
        from .. import printer as _printer
        try:
            local = _printer.detect_local_label_printers()
        except Exception:
            local = []
        if len(local) == 1:
            self.after(0, lambda c=dict(local[0]): self._auto_apply_host(c))
            return
        if len(local) >= 2:
            self.after(0, self._open_first_run_wizard_safe)   # hangi yazıcı? → sor
            return
        # Yerel etiket yazıcısı yok → ağda köprü sunucusu ara
        try:
            bridges = _printer.scan_bridge_servers()
        except Exception:
            bridges = []
        if len(bridges) == 1:
            self.after(0, lambda b=dict(bridges[0]): self._auto_apply_client(b))
            return
        # 0 veya birden fazla köprü → kullanıcı karar versin
        self.after(0, self._open_first_run_wizard_safe)

    def _auto_apply_host(self, cfg: dict):
        """Tek yerel etiket yazıcısı bulundu → bu PC'yi köprübaşı yap (soru yok)."""
        try:
            cfg.setdefault("type", "windows")
            cfg["name"] = cfg.get("name") or cfg.get("win_name") or "Etiket Yazıcısı"
            nm = self._setup_save_printer(cfg, as_bridge_server=True)
            self._mark_setup_done()
            self.status.set(f"✓ Yazıcı otomatik kuruldu (köprübaşı): {nm}")
        except Exception:
            log.exception("Otomatik köprübaşı kurulamadı → sihirbaz")
            self._open_first_run_wizard_safe()

    def _auto_apply_client(self, b: dict):
        """Ağda tek köprü bulundu → bu PC'yi ona istemci yap (soru yok)."""
        from .. import printer as _printer
        try:
            host = b.get("ip") or b.get("host") or ""
            cfg = {"name": f"Köprü ({host})", "type": "bridge",
                   "host": host, "port": _printer.PRINT_BRIDGE_PORT}
            nm = self._setup_save_printer(cfg, as_bridge_server=False)
            self._mark_setup_done()
            self.status.set(f"✓ Köprüye otomatik bağlanıldı (istemci): {host}")
        except Exception:
            log.exception("Otomatik istemci kurulamadı → sihirbaz")
            self._open_first_run_wizard_safe()

    def _mark_setup_done(self):
        from ..db import get_connection, save_setting
        self.setup_done = True
        try:
            with get_connection() as conn:
                save_setting(conn, "setup_done", "1")
        except Exception:
            log.exception("setup_done kaydedilemedi")

    def _start_update_check(self):
        """Önceki güncelleme artıklarını temizle + GitHub'dan yeni sürüm denetle.
        Geliştirme makinesinde ({app}\\.git) updater kendini devre dışı bırakır."""
        try:
            from .. import updater
            updater.cleanup_after_launch()
            updater.check_async(self)
        except Exception:
            log.exception("Güncelleme denetimi başlatılamadı")

    def _setup_save_printer(self, cfg: dict, *, as_bridge_server: bool) -> str:
        """Sihirbazda seçilen yazıcıyı listeye ekleyip aktif yap + ayarları kaydet.

        as_bridge_server True → bu makine köprübaşı: köprü sunucu etkinleştirilir
        ve başlatılır. False → istemci: köprübaşı işareti konmaz.
        Eklenen yazıcının (benzersizleştirilmiş) adını döndürür.
        """
        from .. import printer as _printer
        from ..db import get_connection, save_setting

        names = {p.get("name") for p in self.printers}
        base = cfg.get("name") or _printer.cfg_label(cfg)
        name, k = base, 2
        while name in names:
            name = f"{base} ({k})"
            k += 1
        cfg["name"] = name
        self.printers.append(cfg)
        self.printer_active = name
        self._sync_active_printer()
        if as_bridge_server:
            self.print_bridge_enabled = True

        with get_connection() as conn:
            save_setting(conn, "printers_json",
                         json.dumps(self.printers, ensure_ascii=False))
            save_setting(conn, "printer_active", self.printer_active)
            if cfg.get("type") == "tcp":
                save_setting(conn, "printer_host", cfg.get("host", ""))
                save_setting(conn, "printer_port", str(cfg.get("port", 9100)))
            if as_bridge_server:
                save_setting(conn, "print_bridge_enabled", "1")

        if as_bridge_server:
            self._start_bridge_server()
        return name

    def _first_run_setup(self):
        from .. import printer as _printer

        win = tk.Toplevel(self)
        win.title("İlk Kurulum — Etiket Yazıcısı")
        win.geometry("580x440")
        win.transient(self)
        try:
            apply_app_theme(win)
        except Exception:
            pass
        win.grab_set()

        ttk.Label(win, text="🖨  Etiket Yazıcısı Kurulumu",
                  font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        ttk.Label(win, wraplength=540, justify="left",
                  text=("Bu bilgisayarın etiket yazıcısıyla ilişkisini belirleyelim. "
                        "Yazıcının bağlı olduğu bilgisayar 'köprübaşı', diğerleri "
                        "'istemci' olur.")).pack(anchor="w", padx=16)

        body = ttk.Frame(win, padding=(16, 10))
        body.pack(fill="both", expand=True)

        status = tk.StringVar(value="")
        ttk.Label(win, textvariable=status, foreground="#1565c0",
                  wraplength=540, justify="left").pack(anchor="w", padx=16, pady=(0, 8))

        def _clear():
            for w in body.winfo_children():
                w.destroy()

        def _finish(msg: str):
            self._mark_setup_done()
            try:
                win.grab_release()
            except Exception:
                pass
            try:
                win.destroy()
            except Exception:
                pass
            try:
                self.status.set(msg)
            except Exception:
                pass

        # --- ADIM: İSTEMCİ (köprübaşı bilgisayarı seç) ---
        def _show_client_step():
            _clear()
            ttk.Label(body, text="Yazıcının bağlı olduğu bilgisayarı (köprübaşı) seçin:",
                      font=("Segoe UI", 10, "bold")).pack(anchor="w")
            lst = tk.Listbox(body, height=5, font=("Consolas", 9))
            lst.pack(fill="both", expand=True, pady=4)
            found: list[dict] = []

            man = ttk.Frame(body)
            man.pack(fill="x", pady=2)
            ttk.Label(man, text="veya IP elle:").pack(side="left")
            var_ip = tk.StringVar(value="192.168.1.")
            ttk.Entry(man, textvariable=var_ip, width=18,
                      font=("Consolas", 10)).pack(side="left", padx=4)

            def _scan():
                status.set("🔎 Ağ taranıyor (köprü sunucuları)…")
                lst.delete(0, "end")
                found.clear()

                def _work():
                    try:
                        res = _printer.scan_bridge_servers()
                    except Exception as e:
                        self.after(0, lambda: status.set(f"✗ Tarama hatası: {e}"))
                        return

                    def _fill():
                        for r in res:
                            label = r["ip"] + (f"  ({r['name']})" if r.get("name") else "")
                            found.append(r)
                            lst.insert("end", label)
                        if res:
                            status.set(f"✓ {len(res)} köprü bilgisayarı bulundu.")
                            lst.selection_set(0)
                        else:
                            status.set("Köprü bulunamadı. Yazıcının bağlı olduğu "
                                       "bilgisayarda İlacTarif açık ve köprü etkin "
                                       "olmalı. IP'yi elle de girebilirsiniz.")
                    self.after(0, _fill)

                threading.Thread(target=_work, daemon=True).start()

            ttk.Button(man, text="🔄 Tekrar Tara", command=_scan).pack(side="left", padx=4)
            ttk.Label(body, wraplength=520, justify="left", foreground="#555",
                      text=("Bu bilgisayar İSTEMCİ olur (köprübaşı işareti konmaz). "
                            "Etiketler seçtiğiniz köprü bilgisayar üzerinden basılır. "
                            "Önce yazıcının bağlı olduğu bilgisayarda kurulumu "
                            "tamamlayın.")).pack(anchor="w", pady=(8, 4))

            btns = ttk.Frame(body)
            btns.pack(fill="x", side="bottom", pady=6)

            def _do_client():
                sel = lst.curselection()
                host = found[sel[0]]["ip"] if sel else var_ip.get().strip()
                if not host or host.endswith("."):
                    status.set("Bir köprü seçin veya geçerli bir IP girin.")
                    return
                ok = _printer.port_open(host, _printer.PRINT_BRIDGE_PORT, 1.5)
                if not ok and not messagebox.askyesno(
                        "Köprü",
                        f"{host}:{_printer.PRINT_BRIDGE_PORT} yanıt vermiyor "
                        "(köprü-PC kapalı olabilir). Yine de kaydedeyim mi?",
                        parent=win):
                    return
                cfg = {"name": f"Köprü ({host})", "type": "bridge",
                       "host": host, "port": _printer.PRINT_BRIDGE_PORT}
                nm = self._setup_save_printer(cfg, as_bridge_server=False)
                _finish(f"✓ İstemci kuruldu: {nm}")

            ttk.Button(btns, text="✓ Bu Köprüye Bağlan", style="Accent.TButton",
                       command=_do_client).pack(side="right", padx=4)
            ttk.Button(btns, text="Şimdilik geç",
                       command=lambda: _finish(
                           "Kurulum atlandı — Ayarlar → Köprü'den ayarlayabilirsiniz.")
                       ).pack(side="left", padx=4)
            _scan()

        # --- ADIM: KÖPRÜBAŞI (bu PC'de yerel etiket yazıcısı bulundu) ---
        def _show_host_step(label_cfgs):
            _clear()
            ttk.Label(body, text="Bu bilgisayara bağlı etiket yazıcısı bulundu:",
                      font=("Segoe UI", 10, "bold")).pack(anchor="w")
            var_pick = tk.StringVar(value=label_cfgs[0]["win_name"])
            for c in label_cfgs:
                ttk.Radiobutton(body, text="🖨  " + c["win_name"],
                                value=c["win_name"], variable=var_pick).pack(
                    anchor="w", padx=10, pady=2)
            ttk.Label(body, wraplength=520, justify="left", foreground="#555",
                      text=("Bu makineyi KÖPRÜBAŞI yapalım: yazıcı buraya bağlı kalır, "
                            "ağdaki diğer bilgisayarlar etiketleri bu bilgisayar üzerinden "
                            "bastırır (köprü sunucusu otomatik açılır).")).pack(
                anchor="w", pady=(10, 6))

            btns = ttk.Frame(body)
            btns.pack(fill="x", side="bottom", pady=6)

            def _do_host():
                pick = var_pick.get()
                cfg = next((dict(c) for c in label_cfgs
                            if c["win_name"] == pick), None)
                if not cfg:
                    return
                cfg["name"] = pick
                nm = self._setup_save_printer(cfg, as_bridge_server=True)
                _finish(f"✓ Köprübaşı kuruldu: {nm} — köprü sunucu açık (port "
                        f"{getattr(self, 'print_bridge_port', _printer.PRINT_BRIDGE_PORT)}).")

            ttk.Button(btns, text="✓ Köprübaşı Yap (önerilen)", style="Accent.TButton",
                       command=_do_host).pack(side="right", padx=4)
            ttk.Button(btns, text="Yazıcı bu bilgisayarda değil →",
                       command=_show_client_step).pack(side="left", padx=4)
            ttk.Button(btns, text="Şimdilik geç",
                       command=lambda: _finish(
                           "Kurulum atlandı — Ayarlar → Köprü'den ayarlayabilirsiniz.")
                       ).pack(side="left", padx=4)

        # Başlangıç: bu PC'ye yerel etiket yazıcısı bağlı mı?
        try:
            local_labels = _printer.detect_local_label_printers()
        except Exception:
            local_labels = []
        if local_labels:
            _show_host_step(local_labels)
        else:
            status.set("Bu bilgisayarda yerel etiket yazıcısı görünmüyor → "
                       "istemci kurulumu.")
            _show_client_step()

    def _on_close(self):
        """Pencere ✕ ile kapatılınca: kullanıcıya SOR — tepsiye küçült mü,
        programı tamamen kapat mı?

        Tepsiye küçültülürse Medula izleyici, köprü sunucusu ve kısayollar
        arka planda çalışmaya devam eder; program saat yanındaki tepsi
        ikonundan geri açılır. Tepsi ikonu (pystray) kurulamadıysa küçültme
        seçeneği anlamsız → doğrudan gerçek çıkışa düşer.
        """
        if getattr(self, "_tray", None) is None:
            self._real_quit()
            return
        self._ask_close_action()

    def _ask_close_action(self):
        """✕ diyaloğu: 'Tepsiye küçült / Tamamen kapat / Vazgeç' üçlü seçim."""
        C = COLORS
        dlg = tk.Toplevel(self)
        dlg.title("İlaç Tarif — Kapat")
        dlg.transient(self)
        dlg.resizable(False, False)
        dlg.configure(background=C.get("bg_panel", "#f0f0f0"))

        body = ttk.Frame(dlg, style="Panel.TFrame", padding=(18, 14))
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Programı kapatmak üzeresiniz",
                  style="Panel.TLabel",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w")
        ttk.Label(
            body,
            text=("Programı komple kapatmak mı, yoksa sistem tepsisine\n"
                  "küçültmek mi istiyorsunuz?\n\n"
                  "Tepsiye küçültülürse arka planda çalışmaya devam eder\n"
                  "(Medula izleyici, kısayollar ve yazıcı köprüsü açık kalır);\n"
                  "saat yanındaki 💊 simgesinden geri açılır."),
            style="Panel.TLabel", justify="left").pack(anchor="w", pady=(6, 12))

        btns = ttk.Frame(body, style="Panel.TFrame")
        btns.pack(fill="x")

        def _tray():
            dlg.destroy()
            self._hide_to_tray()

        def _quit():
            dlg.destroy()
            self._real_quit()

        ttk.Button(btns, text="🔽 Sistem Tepsisine Küçült",
                   style="Accent.TButton", command=_tray).pack(
            side="left", padx=(0, 6))
        ttk.Button(btns, text="⏻ Programı Tamamen Kapat",
                   style="Warn.TButton", command=_quit).pack(
            side="left", padx=(0, 6))
        ttk.Button(btns, text="Vazgeç", command=dlg.destroy).pack(side="right")

        dlg.bind("<Return>", lambda e: _tray())
        dlg.bind("<Escape>", lambda e: dlg.destroy())
        dlg.protocol("WM_DELETE_WINDOW", dlg.destroy)

        # Ana pencerenin ortasına konumla, modal yap
        dlg.update_idletasks()
        try:
            px = self.winfo_rootx() + (self.winfo_width() - dlg.winfo_width()) // 2
            py = self.winfo_rooty() + (self.winfo_height() - dlg.winfo_height()) // 3
            dlg.geometry(f"+{max(0, px)}+{max(0, py)}")
        except Exception:
            pass
        try:
            dlg.grab_set()
        except Exception:
            pass
        dlg.focus_set()

    def _minimize_to_taskbar(self):
        """Pencereyi görev çubuğuna küçült (klasik simge durumu)."""
        try:
            self.iconify()
        except Exception:
            pass

    def _minimize_to_tray_btn(self):
        """'Tepsiye Küçült' butonu: tepsi varsa gizle, yoksa görev çubuğuna düş.

        pystray kurulamadıysa pencereyi tamamen gizlemek kullanıcıyı programa
        ulaşamaz bırakır — o durumda güvenli seçenek olarak iconify edilir.
        """
        if getattr(self, "_tray", None) is not None:
            self._hide_to_tray()
        else:
            self._minimize_to_taskbar()

    def _hide_to_tray(self):
        """Ana pencereyi gizle; program tepside çalışmaya devam eder."""
        try:
            self.withdraw()
        except Exception:
            pass
        tray = getattr(self, "_tray", None)
        if tray is not None:
            try:
                tray.notify(
                    "İlaç Tarif arka planda çalışıyor. Saat yanındaki simgeden "
                    "açabilir veya çıkabilirsiniz.",
                    "İlaç Tarif",
                )
            except Exception:
                pass

    def _real_quit(self):
        """Programı gerçekten kapat: tüm arka plan işleri durdur, tepsiyi kaldır."""
        tray = getattr(self, "_tray", None)
        if tray is not None:
            try:
                tray.stop()
            except Exception:
                pass
            self._tray = None
        self._cancel_keepalive()
        self._stop_watcher()
        self._stop_bridge_server()
        ov = getattr(self, "_medula_overlay", None)
        if ov is not None:
            try:
                ov.destroy()
            except Exception:
                pass
        try:
            self.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Sistem tepsisi (saat yanı) ikonu
    # ------------------------------------------------------------------
    def _setup_tray(self):
        """pystray ile tepsi ikonunu kur ve ayrı bir thread'de çalıştır.

        Menü: 'Göster' (varsayılan — çift tıkla da açılır) ve 'Çıkış'. Ikon
        tıklamaları pystray thread'inde çalışır; Tk'e her zaman self.after(0)
        ile geri dönülür (Tk yalnız ana thread'den güvenle güncellenir).
        """
        if getattr(self, "_tray", None) is not None:
            return
        try:
            import pystray
            from PIL import Image
        except Exception as e:
            log.warning("Tepsi ikonu kurulamadı (pystray yok): %s", e)
            self._tray = None
            # Gizli başlatma istendi ama tepsi yok → kullanıcı programa
            # ulaşamaz kalmasın, pencereyi göster.
            if getattr(self, "_start_hidden", False):
                try:
                    self.deiconify()
                    self.state("zoomed")
                except Exception:
                    pass
            return

        # Ikon görseli: assets/icon.png → yoksa .ico → yoksa düz kare
        image = None
        base = Path(__file__).resolve().parents[3] / "assets"
        for name in ("icon.png", "icon.ico"):
            p = base / name
            if p.exists():
                try:
                    image = Image.open(p)
                    break
                except Exception:
                    image = None
        if image is None:
            image = Image.new("RGB", (64, 64), (0, 120, 60))

        menu = pystray.Menu(
            pystray.MenuItem("Göster", self._tray_show, default=True),
            pystray.MenuItem("Çıkış", self._tray_quit),
        )
        try:
            self._tray = pystray.Icon(
                "ilactarif", image, "İlaç Tarif — Eczane Etiketleme", menu)
            threading.Thread(target=self._tray_run, daemon=True).start()
        except Exception as e:
            log.warning("Tepsi ikonu başlatılamadı: %s", e)
            self._tray = None
            if getattr(self, "_start_hidden", False):
                try:
                    self.deiconify()
                    self.state("zoomed")
                except Exception:
                    pass
            return

        # Gizli başlatma (boot / --tray): pencereyi tepsiye indir.
        if getattr(self, "_start_hidden", False):
            self.after(0, self._hide_to_tray)

    def _tray_run(self):
        try:
            self._tray.run()
        except Exception as e:
            log.warning("Tepsi ikonu çalışma hatası: %s", e)

    def _tray_show(self, icon=None, item=None):
        # pystray thread'inden Tk'e güvenli geçiş
        self.after(0, self._restore_window)

    def _restore_window(self):
        try:
            self.deiconify()
            try:
                self.state("zoomed")
            except Exception:
                pass
            self.lift()
            self.focus_force()
        except Exception:
            pass

    def _tray_quit(self, icon=None, item=None):
        self.after(0, self._real_quit)

    # ------------------------------------------------------------------
    # Otomatik başlangıç (Windows Başlangıç klasörü kısayolu)
    # ------------------------------------------------------------------
    def _startup_lnk_path(self) -> Optional[str]:
        """%APPDATA%\\...\\Startup\\İlaçTarif.lnk yolu (yoksa None)."""
        appdata = os.environ.get("APPDATA")
        if not appdata:
            return None
        return os.path.join(
            appdata, "Microsoft", "Windows", "Start Menu", "Programs",
            "Startup", "İlaçTarif.lnk")

    def _apply_autostart_setting(self):
        """Ayara göre başlangıç kısayolunu kur veya kaldır."""
        if getattr(self, "autostart_enabled", True):
            self._ensure_autostart()
        else:
            self._remove_autostart()

    def _on_toggle_autostart(self):
        """Ayarlar'daki 'otomatik başlat' kutusu değişince hemen uygula + kaydet."""
        enabled = bool(self.var_autostart.get())
        self.autostart_enabled = enabled
        try:
            with get_connection() as conn:
                save_setting(conn, "autostart_enabled", "1" if enabled else "0")
        except Exception as e:
            log.warning("autostart_enabled kaydedilemedi: %s", e)
        self._apply_autostart_setting()
        if hasattr(self, "status"):
            self.status.set(
                "Otomatik başlangıç açık — bilgisayar açılınca tepside başlar."
                if enabled else
                "Otomatik başlangıç kapatıldı.")

    def _ensure_autostart(self):
        """Başlangıç klasörüne, programı '--tray' ile açan kısayolu (yeniden) yaz.

        Şu an çalışan betiği (App.py / App.pyw) ve pythonw.exe'yi hedefler; her
        açılışta üzerine yazar ki yol taşınırsa kendini güncellesin. Yalnız
        Windows'ta ve win32com varsa çalışır; aksi halde sessizce atlar.
        """
        lnk_path = self._startup_lnk_path()
        if not lnk_path:
            return
        try:
            import win32com.client  # pywin32
        except Exception as e:
            log.info("Otomatik başlangıç atlandı (win32com yok): %s", e)
            return
        try:
            script = os.path.abspath(sys.argv[0])
            app_dir = os.path.dirname(script)
            pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
            if not os.path.exists(pythonw):
                pythonw = sys.executable
            icon = os.path.join(app_dir, "assets", "icon.ico")

            shell = win32com.client.Dispatch("WScript.Shell")
            lnk = shell.CreateShortcut(lnk_path)
            lnk.TargetPath = pythonw
            lnk.Arguments = f'"{script}" --tray'
            lnk.WorkingDirectory = app_dir
            if os.path.exists(icon):
                lnk.IconLocation = f"{icon},0"
            lnk.Description = "İlaçTarif — bilgisayar açılınca tepside başlar"
            lnk.Save()
            log.info("Otomatik başlangıç kısayolu kuruldu: %s", lnk_path)
        except Exception as e:
            log.warning("Otomatik başlangıç kurulamadı: %s", e)

    def _remove_autostart(self):
        """Başlangıç kısayolunu (varsa) sil."""
        lnk_path = self._startup_lnk_path()
        if not lnk_path:
            return
        try:
            if os.path.exists(lnk_path):
                os.remove(lnk_path)
                log.info("Otomatik başlangıç kısayolu kaldırıldı.")
        except Exception as e:
            log.warning("Otomatik başlangıç kaldırılamadı: %s", e)

    def _register_print_hotkey(self):
        """Tüm global kısayolları (yeniden) kaydet.

        Mevcut kayıtlı kısayolları önce siler, sonra settings'teki güncel
        değerlerle yeniden kurar. Ayarlar değişince de çağrılabilir.
        """
        try:
            import keyboard as kb
        except ImportError:
            log.warning("'keyboard' paketi yüklü değil — pip install keyboard")
            return

        # Önce eski kısayolları kaldır
        for combo in getattr(self, "_registered_combos", []):
            try:
                kb.remove_hotkey(combo)
            except Exception:
                pass
        self._registered_combos: list[str] = []

        def _reg(combo: str, fn):
            if not combo:
                return
            try:
                # DİKKAT: kb.add_hotkey'e suppress=True VERME — keyboard kütüphanesi
                # suppress ile Ctrl/Shift'in bırakılma olayını yutup tuşu sistem
                # genelinde asılı bırakabiliyor (Ctrl basılı kalmış gibi davranır).
                kb.add_hotkey(combo, fn)
                self._registered_combos.append(combo)
            except Exception as e:
                log.warning("Kısayol kurulamadı [%s]: %s", combo, e)

        _reg(getattr(self, "hotkey_recete_sonu",        "shift+f12"), self._print_last_captured)
        _reg(getattr(self, "hotkey_yazici_recete_basi", ""),         self._print_early_hotkey_fired)
        _reg(getattr(self, "hotkey_sadece_temel",       ""),         self._print_sadece_temel_hotkey_fired)
        _reg(getattr(self, "hotkey_recete_basi",        "shift+i"),  self._recete_basi_hotkey_fired)
        _reg(getattr(self, "hotkey_parekende",          "shift+p"),  self._botanik_hotkey_fired)
        _reg(getattr(self, "hotkey_etiket_sayfasi",     "shift+u"),  self._etiket_sayfasi_hotkey_fired)
        _reg(getattr(self, "hotkey_goster",             ""),         self._goster_hotkey_fired)
        _reg(getattr(self, "hotkey_hasta_etiketi", "shift+scroll_lock"), self._hasta_etiketi_hotkey_fired)
        _reg(getattr(self, "hotkey_emanet", "ctrl+shift+e"), self._emanet_etiketi_hotkey_fired)
        # suppress=True KULLANMA: keyboard kütüphanesi suppress ile Ctrl/Shift'in
        # bırakılma olayını yutup tuşu sistem genelinde asılı bırakabiliyor.
        # Kısayol bu yüzden Ctrl içermeyen shift+f9'a taşındı.
        _reg(getattr(self, "hotkey_emanet_hover", "shift+f9"),
             self._emanet_hover_hotkey_fired)
        _reg(getattr(self, "hotkey_karekod_bas", "ctrl+shift+g"), self._print_scanned_karekods_hotkey)
        _reg(getattr(self, "hotkey_odenmeyen_bas", "ctrl+shift+u"), self._print_unpaid_hotkey)
        # Geriye uyum: Ctrl+Shift+B her zaman Botanik'i açar
        _reg("ctrl+shift+b", self._botanik_hotkey_fired)

        combos_str = " | ".join(self._registered_combos)
        log.info("Kısayollar kayıtlı: %s", combos_str)
        # Butonların 2. satırındaki kısayol metnini güncel ayarla
        self._refresh_action_button_labels()

    def _botanik_hotkey_fired(self):
        """Shift+P / Ctrl+Shift+B → Botanik içe aktar (keyboard thread → Tk thread)."""
        log.info("Botanik kısayolu algılandı → içe aktarma başlıyor")
        try:
            self.after(0, self._import_botanik_sale)
        except Exception:
            log.exception("Botanik hotkey dispatch hatası")

    def _recete_basi_hotkey_fired(self):
        """Shift+İ → reçete başı: watcher seen listesini sıfırla, sayfayı yeniden oku."""
        log.info("Reçete başı kısayolu algılandı")
        def _dispatch():
            if self._watcher is not None:
                self._watcher.force_tick()
                self.status.set("↺ Reçete başı: Medula sayfası yeniden okunuyor…")
            else:
                self.status.set("⚠ Watcher çalışmıyor — ▶ Başlat ile başlatın.")
        try:
            self.after(0, _dispatch)
        except Exception:
            log.exception("Reçete başı hotkey dispatch hatası")

    def _etiket_sayfasi_hotkey_fired(self):
        """Shift+Ü → Medula/etiket sekmesine geç."""
        log.info("Etiket sayfası kısayolu algılandı")
        try:
            self.after(0, lambda: self.notebook.select(self.tab_auto))
        except Exception:
            log.exception("Etiket sayfası hotkey dispatch hatası")

    def _goster_hotkey_fired(self):
        """Etiket programı penceresini ön plana getir."""
        log.info("Etiket programı göster kısayolu algılandı")
        def _dispatch():
            try:
                self.deiconify()
                self.lift()
                self.focus_force()
                # Windows'ta görev çubuğundan geri getirmek için
                import ctypes
                hwnd = self.winfo_id()
                ctypes.windll.user32.SetForegroundWindow(hwnd)
            except Exception as e:
                log.warning("Pencere ön plana alınamadı: %s", e)
        try:
            self.after(0, _dispatch)
        except Exception:
            log.exception("Göster hotkey dispatch hatası")

    def _print_early_hotkey_fired(self):
        """Seçili/son reçetenin ERKEN (başı/taslak) etiketlerini yazıcıya gönder."""
        log.info("Reçete başı yazdır kısayolu algılandı")
        import threading
        threading.Thread(
            target=lambda: self._resolve_and_print_worker(force_stage="early"),
            daemon=True, name="early-print",
        ).start()

    def _print_sadece_temel_hotkey_fired(self):
        """Seçili/son reçetenin yalnızca A (temel) etiketlerini yazıcıya gönder."""
        log.info("Sadece temel etiket kısayolu algılandı")
        import threading
        threading.Thread(
            target=lambda: self._resolve_and_print_worker(force_only_basic=True),
            daemon=True, name="temel-print",
        ).start()

    def _get_selected_or_last_set(self) -> "Optional[ReceteSet]":
        """auto_tree seçiliyse onu, yoksa son yakalananı döndür."""
        sel = self.auto_tree.selection()
        if sel:
            idx = int(sel[0])
            if 0 <= idx < len(self._recete_sets):
                return self._recete_sets[idx]
        return self._recete_sets[-1] if self._recete_sets else None

    # ------------------------------------------------------------------
    # Hasta bilgi etiketi (tarih / ad-soyad / telefon / ödeme / toplam)
    # ------------------------------------------------------------------
    def _hasta_etiketi_hotkey_fired(self):
        """Shift+Scroll Lock → hasta etiketini basar (kutu işaretli olsun olmasın)."""
        log.info("Hasta etiketi kısayolu algılandı")
        import threading
        threading.Thread(
            target=self._resolve_and_print_patient_worker,
            daemon=True, name="hasta-etiketi-print",
        ).start()

    def _resolve_and_print_patient_worker(self):
        """Hasta etiketi worker'ı.

        1. Medula ön plandaysa ekrandaki reçeteyi yakala (tarih + ad-soyad).
        2. Değilse GUI'de seçili/son reçetenin capture'ını kullan.
        3. Telefon + ödeme + reçete toplamını WinForms ekranından (UIA) oku.
        4. Hasta etiketini üret ve yazıcıya gönder.
        """
        import comtypes
        comtypes.CoInitialize()
        cap = None
        cap_is_live = False   # cap doğrudan EKRANDAKİ reçeteden mi geldi? (kimlik güvenli)
        try:
            import ctypes as _ct
            from ..medula_capture import find_medula_windows, capture_one
            from ..medula_parser import parse_html

            fg_hwnd = _ct.windll.user32.GetForegroundWindow()
            wins = find_medula_windows()
            fg_win = next((w for w in wins if w.hwnd == fg_hwnd), None)
            if fg_win and fg_win.ie_servers:
                info = capture_one(fg_win.ie_servers[0])
                if "error" not in info and info.get("html"):
                    cap = parse_html(info["html"], document_url=info.get("url", ""))
                    # Yalnızca tam reçete sayfasındaki cap'i kullan. İTS/Karekod,
                    # ödeme onayı ve diğer sayfalar tarih/ad içermez ya da yarım
                    # bilgi verir — bu durumda aşağıda seçili/son reçetenin tam
                    # cap'ine düşülsün (hasta etiketi yine de çıksın).
                    if cap and cap.page_kind not in (
                        "e_recete_detay", "e_recete_basarili", "kagit_recete_basarili"
                    ):
                        cap = None
                    elif cap and (cap.hasta_ad or cap.recete_tarihi):
                        # cap EKRANDAKİ reçeteden geldi → WinForms tutarı da aynı
                        # ekrandan okunacağı için kimlik zaten tutarlı.
                        cap_is_live = True
        except Exception as e:
            log.warning("Hasta etiketi Medula capture hatası: %s", e)
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

        # Medula ön planda değilse / sayfa boşsa: seçili/son reçetenin cap'ini kullan
        s_target = None
        if cap is None or not (cap.hasta_ad or cap.recete_tarihi):
            cap_is_live = False
            s_target = self._get_selected_or_last_set()
            if s_target is not None:
                cap = s_target.cap_final or s_target.cap_early or cap
        if cap is None:
            self.after(0, lambda: self.status.set(
                "⚠ Hasta etiketi: yakalanan reçete yok (önce Medula'da bir reçete açın)."))
            return
        # Önizlemeyi de güncellemek için: cap'in reçete no'su ile eşleşen seti bul
        if s_target is None:
            rno = (cap.recete_no or "").strip()
            idx = self._key_to_idx.get(rno) if rno else None
            if idx is not None and 0 <= idx < len(self._recete_sets):
                s_target = self._recete_sets[idx]
        self._print_patient_label(
            cap, show_debt=bool(getattr(self, "_hasta_show_debt", True)),
            s=s_target, cap_is_screen=cap_is_live)

    def _print_patient_label(self, cap: PrescriptionCapture, show_debt: bool = True,
                             s: "Optional[ReceteSet]" = None,
                             cap_is_screen: bool = False) -> bool:
        """Verilen capture için hasta etiketini üretip yazıcıya gönderir.

        Telefon + tutarları WinForms ekranından (UIA) GÜNCEL okur. KİMLİK GÜVENLİĞİ:
        cap_is_screen=False ise (cap saklı bir setten geliyorsa) ekranda yüklü
        reçetenin kimliği (reçete no/ad) cap ile EŞLEŞMELİDİR — eşleşmezse YANLIŞ
        hastanın tutarını basmamak için iptal edilir. cap_is_screen=True ise cap zaten
        ekrandaki reçeteden geldiğinden tutar doğrudan kullanılır. `s` verilirse
        okunan veri o setin önizleme kartına da yansıtılır. Döndürür: True = basıldı.
        """
        import time as _t
        from ..patient_info import (read_patient_extra, has_extra_data,
                                    read_screen_identity, identity_matches)
        extra = None
        identity_bad = False
        for _ in range(6):                       # ~3 sn (hızlı native okuma)
            try:
                e = read_patient_extra(fast=True)
            except Exception:
                e = None
            if has_extra_data(e):
                # KİMLİK DOĞRULA: ekranda yüklü reçete bu etiketin hastası mı?
                srno, sad = read_screen_identity()
                if srno or sad:
                    if identity_matches(srno, sad, cap.recete_no, cap.hasta_ad):
                        extra = e
                        break
                    identity_bad = True   # ekranda KESİN başka hasta var
                    break
                # Kimlik okunamadı (Medula penceresi yok vb.): cap ekrandan geldiyse
                # (cap_is_screen) güven; yoksa GÜVENLİ taraf → uygulama.
                if cap_is_screen:
                    extra = e
                    break
                identity_bad = True
                break
            _t.sleep(0.5)

        if identity_bad:
            self.after(0, lambda: self.status.set(
                "⛔ Hasta etiketi İPTAL: ekranda BAŞKA bir reçete açık. Yanlış tutar "
                "basmamak için durduruldu — doğru reçeteyi açıp tekrar basın."))
            return False

        # Okunan GÜNCEL veriyi setin önizleme kartına da yansıt (ekran ↔ baskı tutarlı)
        if s is not None and has_extra_data(extra):
            self.after(0, lambda _s=s, _e=extra: self._apply_patient_extra(_s, _e))
        try:
            png = build_patient_label(
                cap, extra=extra, preview_dir=self._preview_dir, show_debt=show_debt,
                eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
            )
        except Exception:
            log.exception("Hasta etiketi üretme hatası")
            png = None
        if not png:
            self.after(0, lambda: self.status.set("⚠ Hasta etiketi için basılacak bilgi bulunamadı."))
            return False
        try:
            from .. import printer
            cfg = self._active_printer_cfg()
            printer.send_image(
                png, cfg,
                label_mm=(getattr(self, "label_w_mm", 60.0), getattr(self, "label_h_mm", 40.0)),
                gap_mm=getattr(self, "label_gap_mm", 2.0),
                dpi=getattr(self, "printer_dpi", 203),
            )
            addr = printer.cfg_label(cfg)
            self.after(0, lambda: self.status.set(f"🧾 Hasta etiketi {addr} yazıcısına gönderildi."))
            return True
        except Exception as e:
            log.exception("Hasta etiketi baskı hatası")
            self.after(0, lambda err=str(e): self.status.set(f"❌ Hasta etiketi yazdırılamadı: {err}"))
            return False

    # ------------------------------------------------------------------
    # Emanet etiketi — "BU İLAÇ SİZE EMANET VERİLMİŞTİR" + yazdırma tarihi
    # ------------------------------------------------------------------
    def _emanet_etiketi_hotkey_fired(self):
        """Ctrl+Shift+E → emanet etiketi tarih seçim diyaloğunu açar."""
        log.info("Emanet etiketi kısayolu algılandı")
        try:
            self.after(0, self._open_emanet_dialog)
        except Exception:
            log.exception("Emanet hotkey dispatch hatası")

    def _open_emanet_dialog(self, prefill: dict | None = None):
        """Emanet etiketi diyaloğu — İKİ SEKME:
          • ✍ Manuel       : ilaç adını DB/Botanik kataloğundan autocomplete ile yaz.
          • 💊 Meduladan Çek: açık Medula sayfasındaki ilaçlar combobox'a gelir.
        Her sekmede İKİ önizleme (hasta kutusu nüshası + eczane nüshası). Hasta/ilaç
        adının kutuya basılıp basılmayacağı ✕ düğmeleriyle açılıp kapanır.
        `prefill` (Ctrl+Shift+M): {ilac, barkod, hasta, telefon, tarih} → Medula sekmesi.
        """
        win = tk.Toplevel(self)
        win.title("📌 Emanet İlaç Etiketi")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()

        nb = ttk.Notebook(win)
        nb.pack(fill="both", expand=True, padx=6, pady=6)
        tab_manual = ttk.Frame(nb)
        tab_medula = ttk.Frame(nb)
        nb.add(tab_manual, text="  ✍ Manuel  ")
        nb.add(tab_medula, text="  💊 Meduladan Çek  ")

        self._build_emanet_tab(tab_manual, "manual", win, prefill=None)
        self._build_emanet_tab(tab_medula, "medula", win, prefill=prefill)
        if prefill:
            nb.select(tab_medula)

        win.bind("<Escape>", lambda _e: win.destroy())
        win.update_idletasks()
        px = self.winfo_rootx() + self.winfo_width() // 2 - win.winfo_width() // 2
        py = self.winfo_rooty() + 24
        win.geometry(f"+{max(0, px)}+{max(0, py)}")

    def _build_emanet_tab(self, parent, mode: str, win, prefill: dict | None = None):
        """Emanet diyaloğunun bir sekmesini kurar (mode='manual' | 'medula')."""
        from PIL import ImageTk
        from ..label_render import render_emanet_label, render_emanet_pharmacy_label
        today = datetime.date.today()
        pf = prefill or {}

        st = {"barkod": pf.get("barkod", ""), "telefon": pf.get("telefon", ""),
              "drugmap": {}}
        drug_results: list[dict] = []

        ilac_var = tk.StringVar(value=pf.get("ilac", ""))
        hasta_var = tk.StringVar(value=pf.get("hasta", ""))
        if mode == "manual" and not hasta_var.get():
            try:
                s = self._get_selected_or_last_set()
                if s is not None:
                    cap = getattr(s, "cap_final", None) or getattr(s, "cap_early", None)
                    if cap is not None:
                        hasta_var.set((getattr(cap, "hasta_ad", "") or "").strip())
            except Exception:
                pass
        _pfd = pf.get("tarih")
        if isinstance(_pfd, datetime.date):
            date_var = tk.StringVar(value=_pfd.strftime("%d.%m.%Y"))
        else:
            date_var = tk.StringVar(value=(_pfd or today.strftime("%d.%m.%Y")))
        show_hasta = tk.BooleanVar(value=True)
        show_ilac = tk.BooleanVar(value=True)
        BF = ("Segoe UI", 9, "bold")

        def _parse(s):
            s = (s or "").strip()
            for fmt in ("%d.%m.%Y", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%y"):
                try:
                    return datetime.datetime.strptime(s, fmt).date()
                except ValueError:
                    continue
            return None

        # ---- Girdi alanı ----
        inp = tk.Frame(parent)
        inp.pack(fill="x", padx=10, pady=(8, 2))

        r1 = tk.Frame(inp); r1.pack(fill="x", pady=2)
        tk.Label(r1, text="İlaç:", width=8, anchor="e", font=BF).pack(side="left")
        if mode == "manual":
            widget_ilac = tk.Entry(r1, textvariable=ilac_var, font=("Segoe UI", 11))
        else:
            widget_ilac = ttk.Combobox(r1, textvariable=ilac_var,
                                       font=("Segoe UI", 11), values=[], height=15)
        widget_ilac.pack(side="left", fill="x", expand=True, padx=(6, 4))
        btn_ix = tk.Button(r1, width=3)
        btn_ix.pack(side="left")

        lst = None
        if mode == "manual":
            lst = tk.Listbox(inp, height=4, font=("Consolas", 9))
            lst.pack(fill="x", padx=(70, 26), pady=(0, 2))
        else:
            tk.Button(inp, text="🔄 Medula sayfasından ilaçları çek",
                      command=lambda: _pull_medula()).pack(
                          anchor="w", padx=(70, 0), pady=(0, 2))

        r2 = tk.Frame(inp); r2.pack(fill="x", pady=2)
        tk.Label(r2, text="Hasta:", width=8, anchor="e", font=BF).pack(side="left")
        tk.Entry(r2, textvariable=hasta_var, font=("Segoe UI", 11)).pack(
            side="left", fill="x", expand=True, padx=(6, 4))
        btn_hx = tk.Button(r2, width=3)
        btn_hx.pack(side="left")

        r3 = tk.Frame(inp); r3.pack(fill="x", pady=2)
        tk.Label(r3, text="Tarih:", width=8, anchor="e", font=BF).pack(side="left")
        ent_date = tk.Entry(r3, textvariable=date_var, font=("Segoe UI", 13, "bold"),
                            width=13, justify="center")
        ent_date.pack(side="left", padx=(6, 8))

        try:
            from tkcalendar import Calendar
            ck = dict(selectmode="day", date_pattern="dd.mm.yyyy", firstweekday="monday",
                      showweeknumbers=False, font=("Segoe UI", 9))
            try:
                cal = Calendar(inp, locale="tr_TR", **ck)
            except Exception:
                cal = Calendar(inp, **ck)
            cal.pack(anchor="w", padx=(70, 0), pady=(2, 4))
            cal.bind("<<CalendarSelected>>", lambda _e: date_var.set(cal.get_date()))
        except Exception:
            log.exception("Emanet takvim oluşturulamadı")

        # ---- İki önizleme: hasta kutusu + eczane nüshası ----
        pv = tk.Frame(parent); pv.pack(padx=10, pady=(2, 2))
        c1 = tk.Frame(pv); c1.pack(side="left", padx=6)
        tk.Label(c1, text="HASTA KUTUSU NÜSHASI", font=("Segoe UI", 8, "bold")).pack()
        lbl_box = tk.Label(c1, relief="solid", borderwidth=1); lbl_box.pack()
        c2 = tk.Frame(pv); c2.pack(side="left", padx=6)
        tk.Label(c2, text="ECZANE NÜSHASI", font=("Segoe UI", 8, "bold")).pack()
        lbl_ecz = tk.Label(c2, relief="solid", borderwidth=1); lbl_ecz.pack()

        def _update(*_a):
            parsed = _parse(date_var.get())
            tarih = parsed if parsed is not None else (date_var.get().strip() or " ")
            try:
                box = render_emanet_label(
                    yazdirma_tarihi=tarih, hasta_adi=hasta_var.get().strip(),
                    ilac_adi=ilac_var.get().strip(),
                    show_hasta_adi=show_hasta.get(), show_ilac_adi=show_ilac.get(),
                    eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
                ).resize((288, 192))
                pb = ImageTk.PhotoImage(box)
                lbl_box.configure(image=pb); lbl_box.image = pb
                ecz = render_emanet_pharmacy_label(
                    hasta_adi=hasta_var.get().strip(), ilac_adi=ilac_var.get().strip(),
                    telefon=st.get("telefon", ""),
                    alis_tarihi=today.strftime("%d.%m.%Y"), yazdirma_tarihi=tarih,
                    eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
                ).resize((288, 192))
                pe = ImageTk.PhotoImage(ecz)
                lbl_ecz.configure(image=pe); lbl_ecz.image = pe
            except Exception:
                log.exception("Emanet önizleme hatası")

        # ✕ göster/gizle düğmeleri (hasta kutusu nüshası için)
        def _sync_btn(btn, var):
            if var.get():
                btn.configure(text="✕", fg="#b00020", relief="raised")
            else:
                btn.configure(text="○", fg="gray", relief="sunken")

        def _toggle(var, btn):
            var.set(not var.get())
            _sync_btn(btn, var)
            _update()

        btn_ix.configure(command=lambda: _toggle(show_ilac, btn_ix))
        btn_hx.configure(command=lambda: _toggle(show_hasta, btn_hx))
        _sync_btn(btn_ix, show_ilac)
        _sync_btn(btn_hx, show_hasta)

        # ---- mod'a özel ilaç doldurma ----
        if mode == "manual":
            def _search(_e=None):
                st["barkod"] = ""
                q = ilac_var.get().strip()
                lst.delete(0, "end"); drug_results.clear()
                if len(q) >= 2:
                    seen = set()
                    try:
                        from ..db import botanik_katalog_search
                        with get_connection() as conn:
                            for r in botanik_katalog_search(conn, q, limit=40):
                                ad = (r.get("ad") or "").strip(); bk = (r.get("barkod") or "").strip()
                                if ad and (ad, bk) not in seen:
                                    seen.add((ad, bk)); drug_results.append({"ad": ad, "barkod": bk})
                    except Exception:
                        log.exception("Emanet arama (katalog)")
                    try:
                        for r in self._search_drugs_by_name(q):
                            ad = (r["name"] or "").strip(); bk = (r["barcode"] or "").strip()
                            if ad and (ad, bk) not in seen:
                                seen.add((ad, bk)); drug_results.append({"ad": ad, "barkod": bk})
                    except Exception:
                        log.exception("Emanet arama (drugs)")
                for r in drug_results[:40]:
                    pre = f"{r['barkod']:14} | " if r["barkod"] else ""
                    lst.insert("end", f"{pre}{r['ad']}")

            def _pick(_e=None):
                sel = lst.curselection()
                if not sel:
                    return
                r = drug_results[sel[0]]
                ilac_var.set(r["ad"]); st["barkod"] = r["barkod"]; lst.delete(0, "end")

            widget_ilac.bind("<KeyRelease>", _search)
            lst.bind("<Double-Button-1>", _pick)
            lst.bind("<Return>", _pick)
        else:
            def _pull_medula():
                self.status.set("⏳ Medula sayfasındaki ilaçlar okunuyor…")

                def worker():
                    drugs, hasta, _rt, future = self._capture_medula_drugs()
                    tel = ""
                    try:
                        from ..patient_info import read_patient_extra
                        tel = (read_patient_extra().telefon or "").strip()
                    except Exception:
                        pass

                    def apply():
                        if drugs:
                            widget_ilac["values"] = [d[0] for d in drugs]
                            st["drugmap"] = {d[0]: d[1] for d in drugs}
                            if not ilac_var.get():
                                ilac_var.set(drugs[0][0]); st["barkod"] = drugs[0][1]
                            self.status.set(f"💊 {len(drugs)} ilaç Medula'dan alındı.")
                        else:
                            self.status.set("⚠ Medula'da ilaç bulunamadı (sayfa açık mı?).")
                        if hasta and not hasta_var.get():
                            hasta_var.set(hasta)
                        if future and date_var.get().strip() == today.strftime("%d.%m.%Y"):
                            date_var.set(future)
                        if tel:
                            st["telefon"] = tel
                        _update()
                    self.after(0, apply)

                threading.Thread(target=worker, daemon=True, name="emanet-medula").start()

            def _cmb_pick(_e=None):
                st["barkod"] = (st.get("drugmap") or {}).get(ilac_var.get(), "")

            widget_ilac.bind("<<ComboboxSelected>>", _cmb_pick)
            if not pf:
                parent.after(150, _pull_medula)   # sekme açılınca otomatik çek

        date_var.trace_add("write", _update)
        hasta_var.trace_add("write", _update)
        ilac_var.trace_add("write", _update)

        # Manuel sekmede telefonu arka planda oku (eczane önizlemesi için)
        if mode == "manual" and not st.get("telefon"):
            def _tel_worker():
                try:
                    from ..patient_info import read_patient_extra
                    tel = (read_patient_extra().telefon or "").strip()
                    if tel:
                        st["telefon"] = tel
                        self.after(0, _update)
                except Exception:
                    pass
            threading.Thread(target=_tel_worker, daemon=True, name="emanet-tel").start()

        def _on_print():
            parsed = _parse(date_var.get())
            if parsed is None and not date_var.get().strip():
                self.status.set("⚠ Emanet: tarih boş."); return
            ilac = ilac_var.get().strip()
            if not ilac:
                self.status.set("⚠ Emanet: ilaç adı boş."); return
            tarih = parsed if parsed is not None else date_var.get().strip()
            args = (tarih, hasta_var.get().strip(), ilac, st.get("barkod", ""),
                    show_hasta.get(), show_ilac.get(), st.get("telefon", ""))
            win.destroy()
            threading.Thread(target=lambda: self._print_emanet_labels(*args),
                             daemon=True, name="emanet-print").start()

        bf = tk.Frame(parent); bf.pack(pady=8)
        tk.Button(bf, text="💾 Kaydet ve Yazdır (2 etiket)", command=_on_print).pack(side="left", padx=8)
        tk.Button(bf, text="İptal", width=10, command=win.destroy).pack(side="left", padx=8)

        _update()
        if mode == "manual":
            widget_ilac.focus_set()

    def _capture_medula_drugs(self):
        """Açık Medula sayfasından (ad, barkod) ilaç listesi + hasta + reçete tarihi +
        'yazdırılması gereken tarih' tahmini (sayfadaki en ileri gelecek tarih) döndürür.

        Döner: (drugs:list[(ad,barkod)], hasta:str, recete_tarihi:str, future_date:str)
        """
        import comtypes
        comtypes.CoInitialize()
        today = datetime.date.today()
        try:
            import ctypes as _ct
            import re as _re
            from ..medula_capture import find_medula_windows, capture_one
            from ..medula_parser import parse_html
            fg = _ct.windll.user32.GetForegroundWindow()
            wins = find_medula_windows()
            ordered = sorted(wins, key=lambda w: 0 if getattr(w, "hwnd", None) == fg else 1)
            # İlaç tablosu, hasta adı ve tarih AYRI frame'lerde olabilir (e-Reçete
            # Sorgu formunda hasta adı var ama ilaç tablosu parse edilmez). Bu yüzden
            # tüm frame'leri dolaşıp her bilgiyi bulduğumuz yerden topla.
            drugs_out, hasta_out, rt_out, fut_out = [], "", "", ""
            for w in ordered:
                for ie in (getattr(w, "ie_servers", []) or []):
                    info = capture_one(ie)
                    if "error" in info or not info.get("html"):
                        continue
                    cap = parse_html(info["html"], document_url=info.get("url", ""))
                    if not drugs_out:
                        ds = [((getattr(dr, "ad", "") or "").strip(),
                               (getattr(dr, "barkod", "") or "").strip())
                              for dr in (cap.drugs or [])
                              if (getattr(dr, "ad", "") or "").strip()]
                        if ds:
                            drugs_out = ds
                            rt_out = (cap.recete_tarihi or "").strip()
                    if not hasta_out and (cap.hasta_ad or "").strip():
                        hasta_out = cap.hasta_ad.strip()
                    if not fut_out:
                        best = None
                        for dsx in _re.findall(r"\b(\d{2}[./]\d{2}[./]\d{4})\b", info["html"]):
                            try:
                                dd = datetime.datetime.strptime(
                                    dsx.replace("/", "."), "%d.%m.%Y").date()
                            except ValueError:
                                continue
                            if dd >= today and (best is None or dd > best):
                                best = dd
                        if best:
                            fut_out = best.strftime("%d.%m.%Y")
            return drugs_out, hasta_out, rt_out, fut_out
        except Exception:
            log.exception("Medula ilaç listesi okunamadı")
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass
        return [], "", "", ""

    def _emanet_hover_hotkey_fired(self):
        """Ctrl+Shift+M → Medula'da MOUSE ALTINDAKİ ilaç için emanet diyaloğunu açar
        (ilaç + hasta + tarih + telefon önceden doldurularak)."""
        log.info("Emanet hover (Ctrl+Shift+M) kısayolu algılandı")
        threading.Thread(target=self._emanet_hover_worker, daemon=True,
                         name="emanet-hover").start()

    def _emanet_hover_worker(self):
        """Mouse altındaki Medula ilaç metnini UIA ElementFromPoint ile okur; hasta/
        tarih/telefon bilgilerini de toplayıp emanet diyaloğunu prefill ile açar."""
        import comtypes, comtypes.client
        import ctypes as _ct
        from ctypes import wintypes as _wt
        import re as _re
        comtypes.CoInitialize()
        ilac_ad = barkod = row_date = ""
        try:
            pt = _wt.POINT()
            _ct.windll.user32.GetCursorPos(_ct.byref(pt))
            try:
                mod = comtypes.client.GetModule("UIAutomationCore.dll")
                iuia = comtypes.client.CreateObject(
                    mod.CUIAutomation, interface=mod.IUIAutomation)
                el = iuia.ElementFromPoint(pt)
                raw = (el.CurrentName or "").strip() if el else ""
            except Exception:
                log.exception("ElementFromPoint hatası")
                el = iuia = mod = None
                raw = ""
            m = _re.search(r"\((\d{8,14})\)", raw)
            if m:
                barkod = m.group(1)
            ilac_ad = _re.sub(r"\s*\(\d{8,14}\)\s*", "", raw).strip()

            # "Yazdırılması gereken tarih" hover edilen ilaçla AYNI SATIRDA. Elementin
            # atalarını (cell→row) gezip, ilacı İÇEREN ilk satırdaki tarih(ler)den en
            # ileri olanı (deadline) al.
            if el is not None and iuia is not None:
                try:
                    _UIA_CT_PROP, _UIA_TEXT, _DESC = 30003, 50020, 4
                    cond = iuia.CreatePropertyCondition(_UIA_CT_PROP, _UIA_TEXT)
                    walker = iuia.RawViewWalker
                    cur = el
                    drug_key = ilac_ad[:12]
                    for _lvl in range(4):
                        cur = walker.GetParentElement(cur)
                        if cur is None:
                            break
                        try:
                            arr = cur.FindAll(_DESC, cond)
                        except Exception:
                            continue
                        names = []
                        for i in range(arr.Length):
                            try:
                                names.append(arr.GetElement(i).CurrentName or "")
                            except Exception:
                                pass
                        blob = " ".join(names)
                        if drug_key and drug_key not in blob:
                            continue   # henüz satıra ulaşmadık (ilaç yok)
                        dts = []
                        for nm in names:
                            mm = _re.search(r"(\d{2}[./]\d{2}[./]\d{4})", nm)
                            if mm:
                                try:
                                    dts.append(datetime.datetime.strptime(
                                        mm.group(1).replace("/", "."), "%d.%m.%Y").date())
                                except ValueError:
                                    pass
                        if dts:
                            row_date = max(dts).strftime("%d.%m.%Y")
                            break
                except Exception:
                    log.exception("Hover satır tarihi okunamadı")
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

        # Hasta + (yedek) gelecek tarih (ayrı capture; kendi COM init'i var)
        try:
            _drugs, hasta, _rt, future = self._capture_medula_drugs()
        except Exception:
            hasta, future = "", ""
        future = row_date or future   # satır tarihi öncelikli
        telefon = ""
        try:
            from ..patient_info import read_patient_extra
            telefon = (read_patient_extra().telefon or "").strip()
        except Exception:
            pass

        pf = {"ilac": ilac_ad, "barkod": barkod, "hasta": hasta,
              "telefon": telefon, "tarih": future}
        self.after(0, lambda: self._open_emanet_dialog(prefill=pf))

    def _print_emanet_labels(self, tarih, hasta_adi: str = "", ilac_adi: str = "",
                             barkod: str = "", show_hasta: bool = True,
                             show_ilac: bool = True, telefon: str = "") -> bool:
        """Emanet kaydını DB'ye yazar ve İKİ etiket basar:
          1) Hasta kutusu nüshası (render_emanet_label) — kutuya yapıştırılır
          2) Eczane nüshası (render_emanet_pharmacy_label) — eczanede kalır

        `show_hasta`/`show_ilac`: hasta kutusu nüshasında bu satırlar basılsın mı.
        Telefon verilmemişse POS ekranından (read_patient_extra) okunur.
        `tarih` date ise gün/ay adıyla biçimlenir; str ise olduğu gibi.
        """
        from ..label_render import render_emanet_label, render_emanet_pharmacy_label

        # Telefon (eczane nüshası + kayıt için) — verilmemişse POS ekranından oku
        telefon = (telefon or "").strip()
        if not telefon:
            try:
                from ..patient_info import read_patient_extra
                telefon = (read_patient_extra().telefon or "").strip()
            except Exception:
                log.exception("Emanet: telefon okunamadı")

        alis = datetime.date.today().strftime("%d.%m.%Y")
        yaz_str = (tarih.strftime("%d.%m.%Y")
                   if isinstance(tarih, datetime.date) else str(tarih))
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        try:
            box = render_emanet_label(
                yazdirma_tarihi=tarih, hasta_adi=hasta_adi, ilac_adi=ilac_adi,
                show_hasta_adi=show_hasta, show_ilac_adi=show_ilac,
                eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
            )
            pharm = render_emanet_pharmacy_label(
                hasta_adi=hasta_adi, ilac_adi=ilac_adi, telefon=telefon,
                alis_tarihi=alis, yazdirma_tarihi=tarih,
                eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
            )
            box_path = self._preview_dir / f"emanet_box_{ts}.png"
            pharm_path = self._preview_dir / f"emanet_ecz_{ts}.png"
            box.save(box_path)
            pharm.save(pharm_path)
        except Exception:
            log.exception("Emanet etiketi üretme hatası")
            self.after(0, lambda: self.status.set("❌ Emanet etiketi üretilemedi."))
            return False

        # Kaydı DB'ye yaz (baskı başarısız olsa da kayıt kalsın)
        try:
            from ..db import save_emanet_record
            with get_connection() as conn:
                init_schema(conn)
                save_emanet_record(
                    conn, hasta_ad=hasta_adi, ilac_ad=ilac_adi, barkod=barkod,
                    telefon=telefon, alis_tarihi=alis, yazdirma_tarihi=yaz_str,
                )
        except Exception:
            log.exception("Emanet kaydı yazılamadı (etiket yine de basılacak)")

        try:
            from .. import printer
            cfg = self._active_printer_cfg()
            for p in (box_path, pharm_path):
                printer.send_image(
                    p, cfg,
                    label_mm=(getattr(self, "label_w_mm", 60.0), getattr(self, "label_h_mm", 40.0)),
                    gap_mm=getattr(self, "label_gap_mm", 2.0),
                    dpi=getattr(self, "printer_dpi", 203),
                )
            addr = printer.cfg_label(cfg)
            self.after(0, lambda: self.status.set(
                f"📌 Emanet kaydedildi · 2 etiket (hasta + eczane) {addr} yazıcısına gönderildi."))
            return True
        except Exception as e:
            log.exception("Emanet etiketi baskı hatası")
            self.after(0, lambda err=str(e): self.status.set(f"❌ Emanet etiketi yazdırılamadı: {err}"))
            return False

    # ------------------------------------------------------------------
    # Botanik perakende satış → etiket görünümüne içe aktar
    # ------------------------------------------------------------------
    def _import_botanik_sale(self):
        """Botanik satış grid'ini oku, ürünleri Medula etiket görünümüne ekle.

        UIA okuması ~1-2 sn sürebildiğinden arka plan thread'inde yapılır;
        sonuç Tk ana thread'inde ekrana basılır. Kullanıcı kullanımları
        '✎ Doz/Zaman' editörüyle doldurup basar.
        """
        self.status.set("⏳ Botanik satış ekranı okunuyor…")

        def worker():
            # pywinauto/UIA bu worker thread'de STA COM ister; Tk ana thread'i
            # COM'u başka modda kurmuş olduğundan burada açıkça CoInitialize
            # ÇAĞRILMAZSA "CoInitialize çağrılmamış" hatası alınır.
            import comtypes
            com_ok = False
            try:
                try:
                    comtypes.CoInitialize()
                    com_ok = True
                except Exception:
                    pass
                try:
                    pages = read_sale_pages()
                except BotanikNotFound:
                    self.after(0, lambda: self.status.set(
                        "❌ Botanik penceresi bulunamadı — program açık mı?"))
                    return
                if not pages:
                    self.after(0, lambda: self.status.set(
                        "⚠ Botanik satış ekranında ürün satırı bulunamadı."))
                    return

                # Her satış sayfası → AYRI bir "PERAKENDE SATIŞ N" satırı.
                today = datetime.date.today().strftime("%d/%m/%Y")
                results = []  # list[(cap, built, n_rows)]
                for idx, page in enumerate(pages, 1):
                    key = f"PERAKENDE SATIŞ {idx}"
                    cap = PrescriptionCapture(
                        page_kind="botanik_satis",
                        hasta_ad=key,
                        recete_no=key,
                        recete_tarihi=today,
                    )
                    for row in page.rows:
                        cap.drugs.append(CapturedDrug(
                            barkod=row.barkod, ad=row.ad, adet=row.adet or "1",
                        ))
                    built = build_labels_for_capture(
                        cap,
                        preview_dir=self._preview_dir,
                        eczane_adi=self.eczane_adi,
                        eczane_telefon=self.eczane_tel,
                    )
                    results.append((cap, built, len(page.rows)))
                self.after(0, lambda: self._post_botanik_pages(results))
            except Exception as exc:
                log.exception("Botanik içe aktarma hatası")
                # 'exc' except bloğu bitince silinir; lambda sonradan (Tk
                # thread'inde) çalıştığı için mesajı şimdi string'e bağla.
                err = str(exc)
                self.after(0, lambda: self.status.set(f"❌ Botanik okuma hatası: {err}"))
            finally:
                if com_ok:
                    try:
                        comtypes.CoUninitialize()
                    except Exception:
                        pass

        threading.Thread(target=worker, daemon=True).start()

    def _post_botanik_pages(self, results):
        """Her satış sayfasını ayrı satır olarak ekrana koy (Tk ana thread).

        results: list[(cap, built, n_rows)]
        """
        total_read = 0
        total_label = 0
        for cap, built, n_read in results:
            self._upsert_set(
                key=cap.recete_no, source_kind="botanik", built=built,
                stage="final", cap=cap, paper=None, diff_rows=[],
            )
            total_read += n_read
            total_label += len(built.items)
        msg = (f"🛒 Botanik: {len(results)} satış sayfası, {total_read} ürün, "
               f"{total_label} etiket hazır — kullanımları doldurup basın.")
        if total_label < total_read:
            msg += f"  ({total_read - total_label} ürün DB'de bulunamadı/atlandı)"
        self.status.set(msg)

    # ==================================================================
    # Watcher callback router — page_kind'a göre yönlendir
    # ==================================================================
    # ------------------------------------------------------------------
    # Yabancı uyruklu (TC 98/99) + geçici koruma DIŞI → Topkapı SGK kağıdı uyarısı
    # ------------------------------------------------------------------
    def _maybe_warn_foreign_no_temp_protection(self, cap: PrescriptionCapture):
        """Reçete KAYDEDİLDİĞİNDE: hasta yabancı uyruklu (TC 98/99) ama geçici koruma
        kapsamı DIŞINDA ise tüm ekranı kaplayan uyarıyı (bir kez) gösterir.

        Watcher thread'inden çağrılır → Tk işlemleri self.after ile ana thread'e taşınır.
        """
        try:
            from ..medula_parser import needs_foreign_paper_warning
            if not needs_foreign_paper_warning(cap):
                return
        except Exception:
            log.exception("Yabancı uyruklu kapsam denetimi hatası")
            return
        tc = (getattr(cap, "hasta_tc", "") or "").strip()
        key = f"{(cap.recete_no or '').strip()}|{tc}"
        if key in self._foreign_warn_shown:
            return
        self._foreign_warn_shown.add(key)
        ad = (getattr(cap, "hasta_ad", "") or "").strip()
        kapsam = (getattr(cap, "fatura_kapsami", "") or "").strip()
        self.after(0, lambda: self._show_foreign_warning(ad, tc, kapsam))

    def _show_foreign_warning(self, hasta_ad: str, hasta_tc: str, kapsam: str):
        """Tüm ekranı kaplayan kırmızı uyarı penceresi (iki kapatma butonlu)."""
        win = tk.Toplevel(self)
        win.title("DİKKAT — Yabancı Uyruklu Hasta")
        win.configure(bg=COLORS["accent_red"])
        # Tüm ekranı kapla + en üstte + kapatma tuşunu etkisizleştir (butonla kapanır)
        try:
            win.attributes("-fullscreen", True)
        except Exception:
            try:
                win.state("zoomed")
            except Exception:
                pass
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        win.protocol("WM_DELETE_WINDOW", lambda: None)
        try:
            win.grab_set()
        except Exception:
            pass
        try:
            win.bell()
        except Exception:
            pass

        wrap = tk.Frame(win, bg=COLORS["accent_red"])
        wrap.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(wrap, text="⚠  DİKKAT  DİKKAT  ⚠",
                 font=("Segoe UI", 48, "bold"),
                 fg="white", bg=COLORS["accent_red"]).pack(pady=(0, 24))
        tk.Label(
            wrap,
            text=("Bu hasta YABANCI UYRUKLUDUR ve\nGEÇİCİ KORUMA hastası DEĞİLDİR."),
            font=("Segoe UI", 28, "bold"),
            fg="white", bg=COLORS["accent_red"], justify="center",
        ).pack(pady=(0, 18))
        tk.Label(
            wrap,
            text=("SGK'lı yabancı uyrukluların\nTOPKAPI SGK'dan KAĞIT getirmesi gerekmektedir."),
            font=("Segoe UI", 24), fg="white", bg=COLORS["accent_red"],
            justify="center",
        ).pack(pady=(0, 26))

        # Hasta bağlamı (ad / TC / kapsam)
        ctx = " · ".join(p for p in (
            hasta_ad,
            (f"TC: {hasta_tc}" if hasta_tc else ""),
            (f"Kapsam: {kapsam}" if kapsam else ""),
        ) if p)
        if ctx:
            tk.Label(wrap, text=ctx, font=("Segoe UI", 14),
                     fg="#ffe4e4", bg=COLORS["accent_red"]).pack(pady=(0, 30))

        def _close():
            try:
                win.grab_release()
            except Exception:
                pass
            win.destroy()

        btns = tk.Frame(wrap, bg=COLORS["accent_red"])
        btns.pack()
        tk.Button(
            btns, text="✔  Tamam, kağıt getirmiş",
            font=("Segoe UI", 18, "bold"), fg="white", bg=COLORS["accent_green"],
            activebackground="#16a34a", activeforeground="white",
            relief="flat", padx=28, pady=16, cursor="hand2",
            command=lambda: (self.status.set(
                f"Yabancı uyruklu hasta — kağıt GETİRDİ olarak kapatıldı "
                f"(TC {hasta_tc})."), _close()),
        ).pack(side="left", padx=18)
        tk.Button(
            btns, text="✖  Hayır, kağıt yok",
            font=("Segoe UI", 18, "bold"), fg="white", bg="#7f1d1d",
            activebackground="#991b1b", activeforeground="white",
            relief="flat", padx=28, pady=16, cursor="hand2",
            command=lambda: (self.status.set(
                f"Yabancı uyruklu hasta — kağıt YOK olarak kapatıldı "
                f"(TC {hasta_tc})."), _close()),
        ).pack(side="left", padx=18)

        win.bind("<Escape>", lambda e: _close())
        try:
            win.focus_force()
        except Exception:
            pass

    def _watcher_callback(self, cap: PrescriptionCapture, html: str):
        if cap.page_kind == "e_recete_detay":
            # E-Reçete Görüntüle sayfası = HER ZAMAN REÇETE BAŞI (orijinal/taslak hali).
            # Reçete sonradan açılsa bile bu sayfa reçete başını besler.
            self._handle_erecete_early(cap, html)
        elif cap.page_kind == "e_recete_basarili":
            # Kaydedilmiş e-reçete (SGK onaylı) → REÇETE SONU.
            self._handle_erecete_final(cap, html)
        elif cap.page_kind == "kagit_recete_basarili":
            # Kaydedilmiş kağıt reçete (SGK reçete no atanmış) → REÇETE SONU.
            self._handle_paper_success(html)
        elif cap.page_kind == "karekod_onay":
            # İTS Karekod İşlemleri ekranı: okutulan karekodları arka planda say.
            self._handle_karekod_scan(cap)
        # diğer page_kind'lar göz ardı

    # ------------------------------------------------------------------
    # İTS Karekod İşlemleri — okutulan karekod sayımı (arka planda)
    # ------------------------------------------------------------------
    def _handle_karekod_scan(self, cap: PrescriptionCapture):
        """İTS Karekod İşlemleri ekranındaki okutulan karekodları sayar.

        Okutma baskı anahtarını DEĞİŞTİRMEZ; yalnız "barkod → kaç kutu okutuldu"
        sayımını ilgili reçete setinde biriktirir. "Sadece okutulan karekodları
        bas" kısayolu (Ctrl+Shift+Ğ) bu sayıma göre yalnız okutulan ilaçları basar.
        Yalnız ayar açıkken çalışır.
        """
        if not getattr(self, "_karekod_scan_print", False):
            return
        from collections import Counter
        from ..medula_parser import barcode_from_karekod
        counts: Counter = Counter()
        for line in (getattr(cap, "scanned_karekodlar", None) or []):
            bc = barcode_from_karekod(line)
            if bc:
                counts[bc] += 1
        if not counts:
            return
        rno = (cap.recete_no or "").strip()
        self.after(0, lambda r=rno, c=dict(counts): self._apply_karekod_counts(r, c))

    def _apply_karekod_counts(self, rno: str, counts: dict):
        # Hedef set: önce reçete-no eşleşmesi, yoksa seçili/son set.
        s = None
        if rno:
            idx = self._key_to_idx.get(rno)
            if idx is not None and 0 <= idx < len(self._recete_sets):
                s = self._recete_sets[idx]
        if s is None:
            s = self._get_selected_or_last_set()
        if s is None:
            return
        # Özellik yalnız REÇETE BAŞI OLMAYAN (doğrudan açılmış kayıtlı) reçetelerde.
        if s.early is not None:
            return
        # textarea her tick'te tüm okutulanları gösterir → barkod başına MAX al.
        changed = False
        for bc, n in counts.items():
            if n > s._karekod_counts.get(bc, 0):
                s._karekod_counts[bc] = n
                changed = True
        if changed:
            total = sum(s._karekod_counts.values())
            self.status.set(
                f"📦 Karekod okutuldu: {len(s._karekod_counts)} ilaç / {total} kutu "
                f"sayıldı (Ctrl+Shift+Ğ ile yalnız okutulanları bas)."
            )

    def _on_paper_tick(self, html: str, page_kind: str):
        """Her tick'te kağıt reçete giriş formu (kayıt öncesi) görüldüğünde."""
        from bs4 import BeautifulSoup
        try:
            soup = BeautifulSoup(html, "html.parser")
            form = parse_paper_form(soup)
        except Exception:
            log.exception("Paper form parse hatası")
            return
        if not (form.hasta_tc.strip() and form.filled_drugs):
            return
        # Hash karşılaştır — sadece form gerçekten değiştiyse erken etiket üret
        h = self._paper_form_hash(form)
        if h == self._last_paper_hash:
            return
        self._last_paper_hash = h
        self._last_paper_form = form
        # Erken etiketleri üret (background değil; tickte iş zaten arka plan
        # thread'de oluyor)
        self._build_and_post_paper_early(form)

    # ------------------------------------------------------------------
    # Doktor notu (drug.aciklama) senkronu
    # ------------------------------------------------------------------
    @staticmethod
    def _merge_drug_notes(target_cap: PrescriptionCapture,
                          source_cap: Optional[PrescriptionCapture]) -> bool:
        """source_cap.drugs içindeki doktor notlarını (drug.aciklama) barkod
        eşleşmesiyle target_cap.drugs'a taşır. Yalnız target'ta not BOŞSA yazar.

        Reçete sonu sayfası (e_recete_basarili) doktor notunu içermez; not yalnız
        reçete başı (e_recete_detay) sayfasında bulunur. Bu yüzden notu reçete
        başından reçete sonuna (veya tersine, hangisi önce geldiyse) taşıyoruz.
        Değişiklik yapıldıysa True döner (yeniden derleme gerekebilir).
        """
        if source_cap is None:
            return False
        notes = {d.barkod: d.aciklama for d in source_cap.drugs
                 if d.barkod and (d.aciklama or "").strip()}
        if not notes:
            return False
        changed = False
        for d in target_cap.drugs:
            if d.barkod in notes and not (d.aciklama or "").strip():
                d.aciklama = notes[d.barkod]
                changed = True
        return changed

    # ------------------------------------------------------------------
    # E-Reçete erken yakalama (detay sayfası)
    # ------------------------------------------------------------------
    def _handle_erecete_early(self, cap: PrescriptionCapture, html: str):
        # Reçete no'su henüz atanmamış ara sayfalar (muadil değişikliği vb.)
        # boş key ile listeye ghost satır açar; görmezden gel.
        if not cap.recete_no.strip():
            return
        try:
            built = build_labels_for_capture(
                cap,
                preview_dir=self._preview_dir,
                eczane_adi=self.eczane_adi,
                eczane_telefon=self.eczane_tel,
            )
        except Exception:
            log.exception("E-reçete erken etiket üretme hatası")
            return
        try:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            (self._preview_dir / f"raw_early_{ts}_{cap.recete_no}.html").write_text(
                html, encoding="utf-8"
            )
        except Exception:
            pass
        self._erecete_early_caps[cap.recete_no] = cap
        self.after(0, lambda: self._upsert_set(
            key=cap.recete_no, source_kind="e_recete",
            built=built, stage="early", cap=cap, paper=None, diff_rows=[],
        ))

        # Reçete sonu DAHA ÖNCE (eski reçete açılırken) notsuz yakalanmış olabilir.
        # Reçete başındaki doktor notlarını ona yansıt ve reçete sonu etiketlerini
        # notlarla yeniden üret (#3: not her iki sette de görünmeli).
        idx = self._key_to_idx.get(cap.recete_no)
        if idx is not None:
            s = self._recete_sets[idx]
            if s.cap_final is not None and self._merge_drug_notes(s.cap_final, cap):
                try:
                    built_final = build_labels_for_capture(
                        s.cap_final,
                        preview_dir=self._preview_dir,
                        eczane_adi=self.eczane_adi,
                        eczane_telefon=self.eczane_tel,
                    )
                except Exception:
                    log.exception("Reçete sonu notla yeniden üretme hatası")
                else:
                    cap_final = s.cap_final
                    diff_rows = s.diff_rows
                    self.after(0, lambda: self._upsert_set(
                        key=cap.recete_no, source_kind="e_recete",
                        built=built_final, stage="final", cap=cap_final,
                        paper=None, diff_rows=diff_rows,
                    ))

    # ------------------------------------------------------------------
    # E-Reçete final yakalama (kayıt başarılı)
    # ------------------------------------------------------------------
    def _handle_erecete_final(self, cap: PrescriptionCapture, html: str):
        # Kaydedilmiş (success/form-f) sayfada hasta/tarih/doktor eksik olabilir;
        # aynı reçete no ile erken yakalanan taslaktan tamamla (build'den ÖNCE).
        before_cap = self._erecete_early_caps.get(cap.recete_no)
        if before_cap is not None:
            if not cap.hasta_ad:      cap.hasta_ad = before_cap.hasta_ad
            if not cap.hasta_tc:      cap.hasta_tc = before_cap.hasta_tc
            if not cap.recete_tarihi: cap.recete_tarihi = before_cap.recete_tarihi
            if not cap.dr_ad:         cap.dr_ad = before_cap.dr_ad
            if not cap.recete_turu:   cap.recete_turu = before_cap.recete_turu
            # Doktor notu (drug.aciklama) yalnız reçete başı sayfasında bulunur;
            # reçete sonu etiketlerinde de görünmesi için barkod eşleşmesiyle taşı.
            self._merge_drug_notes(cap, before_cap)
            # Geçici koruma DIŞI yabancı uyruklu hastada Topkapı SGK kağıdı uyarısı
            # için reçete başı sayfasından okunan kapsamı da tamamla.
            if not (getattr(cap, "fatura_kapsami", "") or "").strip():
                cap.fatura_kapsami = getattr(before_cap, "fatura_kapsami", "") or ""

        # Reçete KAYDEDİLDİ: yabancı uyruklu (TC 98/99) + geçici koruma DIŞI denetimi.
        self._maybe_warn_foreign_no_temp_protection(cap)

        try:
            built = build_labels_for_capture(
                cap,
                preview_dir=self._preview_dir,
                eczane_adi=self.eczane_adi,
                eczane_telefon=self.eczane_tel,
            )
        except Exception:
            log.exception("E-reçete final etiket üretme hatası")
            return
        try:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            (self._preview_dir / f"raw_final_{ts}_{cap.recete_no}.html").write_text(
                html, encoding="utf-8"
            )
        except Exception:
            pass

        diff_rows: list[DiffRow] = []
        if before_cap is not None:
            try:
                diff_rows = compare_captures(before_cap, cap)
            except Exception:
                log.exception("compare_captures hatası")

        self.after(0, lambda: self._upsert_set(
            key=cap.recete_no, source_kind="e_recete",
            built=built, stage="final", cap=cap, paper=None,
            diff_rows=diff_rows,
        ))

    # ------------------------------------------------------------------
    # Kağıt reçete erken etiket (form tick)
    # ------------------------------------------------------------------
    def _paper_form_hash(self, form: PaperReceteForm) -> str:
        import hashlib
        parts = [
            form.hasta_tc, form.protokol_no, form.tesis_no, form.recete_tarihi,
            form.doktor_diploma,
        ]
        for d in form.filled_drugs:
            parts += [d.barkod, d.kutu, d.periyot_sayi, d.periyot_birim,
                      d.gunluk_kez, d.doz_adet]
        return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()

    def _paper_set_key(self, form: PaperReceteForm) -> str:
        # Kayıt öncesi reçete no yok → TC + protokol + tesis ile key
        return f"paper:{form.hasta_tc}:{form.protokol_no}:{form.tesis_no}"

    # İTS-satış / e-reçete duplikesini eşleştirmek için zaman penceresi (sn).
    # e-reçete ile İTS satış "arka arkaya" yakalanır; bu pencere dışındaki eski
    # bir e-reçete (aynı hasta, başka reçete) yanlışlıkla eşleşmesin.
    _ITS_MERGE_WINDOW_SEC = 300

    def _paper_is_its_duplicate(self, form: PaperReceteForm) -> bool:
        """Bu kağıt/İTS-satış formu, az önce yakalanmış bir e-reçetenin AYNISI mı?

        Kullanıcı ölçütü (hepsi birlikte): aynı hasta TC + ilaç barkodları örtüşür
        (formdaki barkodlar e-reçetede mevcut) + e-reçete arka arkaya / kısa süre
        içinde (_ITS_MERGE_WINDOW_SEC) yakalanmış. Hepsi sağlanırsa İTS satış,
        e-reçete satırının duplikesidir → ayrı satır açılmaz.
        """
        tc = (form.hasta_tc or "").strip()
        bks = {(d.barkod or "").strip() for d in form.filled_drugs if (d.barkod or "").strip()}
        if not tc or not bks:
            return False  # eşleştirilecek güvenilir sinyal yok → bastırma
        import time
        now = time.monotonic()
        best_ts = None
        for s in self._recete_sets:
            if s.source_kind != "e_recete":
                continue
            cap = s.cap_final or s.cap_early
            s_tc = (getattr(cap, "hasta_tc", "") or "").strip() if cap else ""
            if not s_tc or s_tc != tc:
                continue
            # İlaç barkodları: reçete başı + sonu birleşimi (muadil değişimi barkodu
            # değiştirdiğinden ikisi de bakılır). Formdaki TÜM barkodlar burada
            # bulunmalı (alt küme) → kısmi/farklı reçete yanlış eşleşmesin.
            s_bks: set[str] = set()
            for b in (s.early, s.final):
                if b:
                    s_bks |= {(it.barkod or "").strip() for it in b.items if (it.barkod or "").strip()}
            if not bks <= s_bks:
                continue
            ts = getattr(s, "_last_update_ts", None)
            if ts is None or (now - ts) > self._ITS_MERGE_WINDOW_SEC:
                continue
            # En son güncellenen (arka arkaya gelen) e-reçeteyi tercih et
            if best_ts is None or ts > best_ts:
                best_ts = ts
        return best_ts is not None

    def _build_and_post_paper_early(self, form: PaperReceteForm):
        # İTS satış, az önceki bir e-reçetenin duplikesiyse listeye ayrı satır
        # açma (e-reçete satırı zaten reçete başı + sonunu içeriyor).
        key = self._paper_set_key(form)
        if self._paper_is_its_duplicate(form):
            self._suppressed_paper_keys.add(key)
            self._last_paper_set_key = key
            return
        def _name_lookup(barkod: str) -> str:
            try:
                with get_connection() as conn:
                    row = conn.execute(
                        "SELECT name FROM drugs WHERE barcode=?", (barkod,)
                    ).fetchone()
                    return row["name"] if row else ""
            except Exception:
                return ""
        cap = paper_to_capture(form, _name_lookup)
        try:
            built = build_labels_for_capture(
                cap,
                preview_dir=self._preview_dir,
                eczane_adi=self.eczane_adi,
                eczane_telefon=self.eczane_tel,
            )
        except Exception:
            log.exception("Kağıt reçete erken etiket üretme hatası")
            return
        self._last_paper_set_key = key
        self.after(0, lambda: self._upsert_set(
            key=key, source_kind="kagit",
            built=built, stage="early", cap=None, paper=form,
            diff_rows=[],
        ))

    def _handle_paper_success(self, html: str):
        from bs4 import BeautifulSoup
        try:
            soup = BeautifulSoup(html, "html.parser")
            after_form = parse_paper_form(soup)
        except Exception:
            log.exception("Paper success parse hatası")
            return

        before_form = self._last_paper_form

        # Etiket üretmek için lookup
        def _name_lookup(barkod: str) -> str:
            try:
                with get_connection() as conn:
                    row = conn.execute(
                        "SELECT name FROM drugs WHERE barcode=?", (barkod,)
                    ).fetchone()
                    return row["name"] if row else ""
            except Exception:
                return ""

        cap = paper_to_capture(after_form, _name_lookup)
        # Kayıt başarı sayfasında isim alanları (f:t15/f:t16) görünmez;
        # erken yakalamadan hasta adını al.
        if not cap.hasta_ad and before_form is not None:
            cap.hasta_ad = before_form.hasta_full

        # Fatura kapsamı (form f 'Kapsam:' alanı) — yabancı uyruklu/geçici koruma
        # denetimi için. paper_to_capture taşımaz; doğrudan sayfadan oku.
        try:
            from ..medula_parser import _extract_fatura_kapsami
            cap.fatura_kapsami = _extract_fatura_kapsami(soup)
        except Exception:
            log.exception("Kağıt reçete kapsam okuma hatası")
        # Reçete KAYDEDİLDİ: yabancı uyruklu (TC 98/99) + geçici koruma DIŞI denetimi.
        self._maybe_warn_foreign_no_temp_protection(cap)

        # Final etiketleri üret
        try:
            built = build_labels_for_capture(
                cap,
                preview_dir=self._preview_dir,
                eczane_adi=self.eczane_adi,
                eczane_telefon=self.eczane_tel,
            )
        except Exception:
            log.exception("Kağıt reçete final etiket üretme hatası")
            return

        try:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            (self._preview_dir / f"raw_paper_final_{ts}_{after_form.recete_no or 'noid'}.html").write_text(
                html, encoding="utf-8"
            )
        except Exception:
            pass

        # Diff hesapla
        diff_rows: list[DiffRow] = []
        if before_form is not None and before_form.hasta_tc == after_form.hasta_tc:
            try:
                diff_rows = compare_paper_forms(before_form, after_form, _name_lookup)
            except Exception:
                log.exception("compare_paper_forms hatası")

        # Key: önce son kayıt-öncesi set key'i, yoksa yeniden hesapla
        key = self._last_paper_set_key or self._paper_set_key(after_form)
        self.after(0, lambda: self._upsert_set(
            key=key, source_kind="kagit",
            built=built, stage="final", cap=cap, paper=after_form,
            diff_rows=diff_rows,
        ))

    # ==================================================================
    # ReceteSet upsert (yeni/erken/final birleştirme)
    # ==================================================================
    def _upsert_set(
        self, *, key: str, source_kind: str, built: BuiltRecete,
        stage: str, cap: Optional[PrescriptionCapture],
        paper: Optional[PaperReceteForm], diff_rows: list[DiffRow],
    ):
        # İTS-satış duplikesi: aynı reçete e-reçete satırında zaten var; kağıt/İTS
        # akışından gelen bu set AYRI satır açmasın (bkz. _paper_is_its_duplicate).
        if source_kind == "kagit" and key in self._suppressed_paper_keys:
            return
        idx = self._key_to_idx.get(key)
        if idx is None:
            s = ReceteSet(key=key, source_kind=source_kind)
            self._recete_sets.append(s)
            idx = len(self._recete_sets) - 1
            self._key_to_idx[key] = idx
            self.auto_tree.insert("", "end", iid=str(idx),
                                  values=("", "", "", "", ""))
        else:
            s = self._recete_sets[idx]
        # Setin son güncellenme anı (İTS-satış "arka arkaya" eşleştirmesi için).
        import time
        s._last_update_ts = time.monotonic()

        # Reçete (YENİDEN) yakalandı → ilaç çıkarma/ekleme sonrası hasta tutarları
        # (reçete ödeme / veresiye) DEĞİŞMİŞ olabilir. Hasta verisi cache'ini geçersiz
        # kıl + generation'ı artır ki kart bir sonraki render'da GÜNCEL rakamları
        # yeniden poll'lasın; çalışan eski poll'ün eski veriyle uygulaması engellenir.
        s._patient_extra = None
        s._patient_enrich_active = False
        s._patient_gen = getattr(s, "_patient_gen", 0) + 1

        if stage == "early":
            s.early = built
            s.cap_early = cap
            s.paper_early = paper
        else:  # final
            s.final = built
            s.cap_final = cap
            s.paper_final = paper
            s.diff_rows = diff_rows
            # Final ekleniyor → final'da olan her ilaç default "final" seçili
            for it in built.items:
                s.chosen_per_drug.setdefault(it.barkod, "final")

        # Sol Treeview satırını güncelle
        icon = "📝 " if source_kind == "kagit" else ""
        self.auto_tree.item(str(idx), values=(
            f"{icon}{built.hasta_ad}",
            built.recete_no or "—",
            built.recete_tarihi or "—",
            len(built.items),
            s.status_label,
        ))
        # Yeni geleni otomatik seç + ön plana getir
        self.auto_tree.selection_set(str(idx))
        self.auto_tree.see(str(idx))
        self._render_set(s)
        pass  # bell() kaldırıldı: sistem sesi istenmiyor

        # Status bar mesajı
        if stage == "early":
            self.status.set(
                f"✏ Reçete başı yakalandı: {built.hasta_ad} ({built.recete_no or '—'}) "
                f"— {len(built.items)} ilaç"
            )
        else:
            extra = (f" · {len(diff_rows)} satır farklılık" if any(
                r.status != "same" for r in diff_rows) else " · değişiklik yok")
            self.status.set(
                f"✓ Reçete sonu yakalandı: {built.hasta_ad} ({built.recete_no or '—'}){extra}"
            )
            # Fark varsa status bar'da gösterilir; otomatik pencere açılmaz.

    # ==================================================================
    # Sağ panel: seçili ReceteSet'in chosen sürümünü render et
    # ==================================================================
    def _on_auto_select(self, event=None):
        sel = self.auto_tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        if 0 <= idx < len(self._recete_sets):
            s = self._recete_sets[idx]
            self._render_set(s)

    def _on_stage_change(self):
        """Geri uyumluluk: kullanılmıyor (per-drug switch'e geçildi)."""
        pass

    def _make_scroll_area(self, parent):
        """Dikey + yatay kaydırmalı alan oluşturur → (canvas, inner_frame) döner."""
        # Sarmalayıcı: ysb sağda, xsb altta, canvas ortada
        wrap = tk.Frame(parent, background=COLORS["bg_main"])
        wrap.pack(fill="both", expand=True)
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(wrap, background=COLORS["bg_main"], highlightthickness=0)
        ysb = ttk.Scrollbar(wrap, orient="vertical", command=canvas.yview)
        xsb = ttk.Scrollbar(wrap, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")

        inner = tk.Frame(canvas, background=COLORS["bg_main"])
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        _last_canvas_size = [0, 0]

        def _on_canvas_resize(e, cv=canvas, wid=win_id, _sz=_last_canvas_size):
            # Sadece gerçek boyut değişikliğinde relayout tetikle;
            # scroll sırasında da Configure ateşlenebilir ama w/h değişmez.
            if e.width == _sz[0] and e.height == _sz[1]:
                return
            _sz[0], _sz[1] = e.width, e.height
            stage = "early" if cv is getattr(self, "early_canvas", None) else "final"
            akey = f"_relayout_after_{stage}"
            old = getattr(self, akey, None)
            if old:
                try:
                    self.after_cancel(old)
                except Exception:
                    pass
            setattr(self, akey, self.after(80, lambda st=stage: self._relayout_stage_cards(st)))

        canvas.bind("<Configure>", _on_canvas_resize)
        canvas.bind("<MouseWheel>",
                    lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))
        canvas.bind("<Shift-MouseWheel>",
                    lambda e: canvas.xview_scroll(int(-e.delta / 120), "units"))
        return canvas, inner

    def _render_set(self, s: ReceteSet):
        """Reçete Başı ve Reçete Sonu etiketlerini AYRI sekmelere render eder.

        Her sekme: üstte hasta/doktor bilgi şeridi, altında o aşamaya ait
        ilaç etiketi kartları (numara + ad + durum + görsel + yazdır/atla radyo).
        """
        for inner in (self.early_inner, self.final_inner):
            for child in inner.winfo_children():
                child.destroy()
        self._auto_thumb_refs.clear()
        # Aşama bazlı kart listesi + grid kabı — responsive sütun yerleşimi için
        self._stage_cards = {"early": [], "final": []}
        self._stage_grid = {"early": None, "final": None}

        s.default_chosen()
        built_ref = s.final or s.early
        if built_ref is None:
            return

        # Hasta etiketi kutusu: her iki sekme (başı/sonu) AYNI değişkeni paylaşsın
        # → işaret senkron kalsın. Başlangıç = set tercihi (yoksa ayar varsayılanı).
        s._hasta_var = tk.BooleanVar(value=self._hasta_enabled(s))
        # Hasta kartı canlı referansları (telefon/tutar arka plan poll'ü günceller)
        s._patient_cards = {}

        diff_by_barcode: dict[str, DiffRow] = {r.barkod: r for r in s.diff_rows}
        early_items: dict[str, LabelItem] = {it.barkod: it for it in (s.early.items if s.early else [])}
        final_items: dict[str, LabelItem] = {it.barkod: it for it in (s.final.items if s.final else [])}

        # Barkod sırası: önce early sırası, sonra sadece final'da olanlar
        order_barcodes: list[str] = []
        for src in (s.early, s.final):
            if src:
                for it in src.items:
                    if it.barkod not in order_barcodes:
                        order_barcodes.append(it.barkod)

        self._render_stage(self.early_inner, s, "early", built_ref,
                           order_barcodes, early_items, final_items, diff_by_barcode)
        self._render_stage(self.final_inner, s, "final", built_ref,
                           order_barcodes, early_items, final_items, diff_by_barcode)

        for canvas, inner in ((self.early_canvas, self.early_inner),
                              (self.final_canvas, self.final_inner)):
            inner.update_idletasks()
            canvas.configure(scrollregion=canvas.bbox("all"))

    def _render_stage_header(self, inner, s: ReceteSet, built_ref, stage: str):
        """Bir sekmenin üst hasta/doktor bilgi şeridi."""
        C = COLORS
        hdr = tk.Frame(inner, background=C["bg_strip"])
        hdr.pack(fill="x", padx=8, pady=(8, 2))
        tk.Label(hdr, text="👤", background=C["bg_strip"], foreground=C["text_yellow"],
                 font=("Segoe UI Emoji", 14)).pack(side="left", padx=(10, 6), pady=8)
        tk.Label(hdr, text=built_ref.hasta_ad or '—',
                 background=C["bg_strip"], foreground=C["text_yellow"],
                 font=("Segoe UI", 14, "bold")).pack(side="left", pady=8)

        def _chip(text, bg=C["bg_card"], fg=C["text_dark"]):
            f = tk.Frame(hdr, background=C["bg_strip"])
            f.pack(side="left", padx=(12, 0), pady=8)
            tk.Label(f, text=f"  {text}  ", background=bg, foreground=fg,
                     font=("Segoe UI", 9, "bold")).pack()

        if built_ref.recete_no:
            _chip(f"REÇETE: {built_ref.recete_no}")
        if built_ref.recete_tarihi:
            _chip(f"📅 {built_ref.recete_tarihi}", bg=C["bg_card_alt"])
        if built_ref.dr_ad:
            _chip(f"👨‍⚕ Dr. {built_ref.dr_ad}", bg=C["accent_purple"], fg="white")
        label = "Reçete Başı (doktorun yazdığı)" if stage == "early" else "Reçete Sonu (SGK onayı)"
        _chip(f"📌 {label}", bg=C["accent_orange"] if stage == "early" else C["accent_green"], fg="white")

        # Hasta bilgi etiketi kutusu (her iki sekmede paylaşılan değişken). İşaretliyse
        # reçete yazdırılırken ilaç etiketlerinden sonra hasta etiketi de basılır.
        var = getattr(s, "_hasta_var", None)
        if var is not None:
            def _toggle(v=var, _s=s):
                _s.print_hasta = bool(v.get())
            ttk.Checkbutton(
                hdr, text="🧾 Hasta Etiketi", variable=var, command=_toggle,
                style="Strip.TCheckbutton",
            ).pack(side="left", padx=(12, 0), pady=8)

    def _render_stage(self, inner, s: ReceteSet, stage: str, built_ref,
                      order_barcodes, early_items, final_items, diff_by_barcode):
        """Bir aşamanın (early/final) tüm ilaç kartlarını sekmesine basar."""
        C = COLORS
        self._render_stage_header(inner, s, built_ref, stage)

        stage_built = s.early if stage == "early" else s.final
        if stage_built is None:
            msg = ("Reçete başı bu sette yakalanmadı."
                   if stage == "early" else "Reçete sonu (SGK) henüz gelmedi.")
            tk.Label(inner, text=f"  ⏳  {msg}", background=C["bg_main"],
                     foreground=C["text_muted"], font=("Segoe UI", 11, "italic")
                     ).pack(anchor="w", padx=20, pady=20)
            return

        # Kartları yan yana DİZMEK için grid kabı (header pack'lendiği için
        # kartları ayrı bir frame'e grid'liyoruz — aynı parent'ta pack+grid olmaz).
        grid_holder = tk.Frame(inner, background=C["bg_main"])
        grid_holder.pack(fill="both", expand=True, padx=4, pady=2)
        self._stage_grid[stage] = grid_holder

        stage_items = early_items if stage == "early" else final_items
        cards: list = []
        for i, bk in enumerate(order_barcodes, start=1):
            # Kağıt reçete karekod girişi temizliği: reçete sonu (SGK) geldikten
            # sonra, kayıt-öncesi okutulan HAM KAREKOD barkodu final listesinde
            # yoksa bu kayıt sahte "ÇIKARILDI" kartıdır (gerçek ilaç adlı kart
            # final'de zaten var). Hiçbir sekmede gösterme. (Final henüz
            # gelmediyse — okutulan karekodları görebilmek için — gizleme.)
            if (s.final is not None and bk not in final_items
                    and _is_raw_karekod(bk)):
                continue
            dr = diff_by_barcode.get(bk)
            status = (dr.status if dr else
                      ("same" if (bk in early_items and bk in final_items)
                       else "added" if bk in final_items else "removed"))
            card_item = stage_items.get(bk)
            removed_passive = False
            # SGK ÖDEMESE DE etiket REÇETE SONU sekmesinde görünsün/basılabilsin:
            # reçete sonu listesinde olmayan ama reçete başında GERİ ÖDEME YOK
            # bayraklı ilacın reçete başı (early) etiketine düş.
            if card_item is None and stage == "final":
                _early_it = early_items.get(bk)
                if _early_it is not None and getattr(_early_it, "geri_odeme_yok", False):
                    card_item = _early_it
                elif _early_it is not None and status == "removed":
                    # REÇETEDEN ÇIKARILDI (hasta istemedi / SGK ödemedi): reçete sonu
                    # sekmesinde early görseliyle PASİF "ÇIKARILDI" kartı göster.
                    # Baskı anahtarı ATLA'da başlar (baskıdan dışlanır); kullanıcı
                    # isterse karttan tekrar YAZDIR'a alabilir. İlk görülüşte 1 kez
                    # ATLA'ya çek; sonraki render'larda kullanıcı seçimini ezme.
                    card_item = _early_it
                    removed_passive = True
                    if bk not in s._removed_auto_skipped:
                        s.chosen_per_drug[bk] = "skip"
                        if hasattr(self, "_chosen_vars"):
                            self._chosen_vars.pop(f"{s.key}:{bk}", None)
                        s._removed_auto_skipped.add(bk)
                else:
                    # Final'da da early'de de yok (muadiline çevrildi) →
                    # reçete sonu sekmesinde silik boş kart gösterme, atla.
                    continue
            # REÇETE SONU GÖRÜNÜM FİLTRELERİ (yalnız final sekmesi):
            #  • "ödenmeyen ilacı gösterme" → SGK ödemeyen (geri_odeme_yok) kartları gizle
            #  • "çıkarılan ilaçları gösterme" → reçeteden çıkarılan (removed) kartları gizle
            # (Yazdırma ayrı: bu kartlar gizliyken bile Ctrl+Shift+Ü ile basılabilir.)
            if stage == "final":
                if (getattr(self, "_hide_unpaid_final", False)
                        and card_item is not None
                        and getattr(card_item, "geri_odeme_yok", False)):
                    continue
                if getattr(self, "_hide_removed_final", False) and removed_passive:
                    continue
            # STOK KONTROLÜ: ayar açıkken, kayıt sonrası stok verilecek kutu
            # adedi kadar eksiye düşmüşse (elde yok) etiketin baskı anahtarı
            # PASİF (ATLA) gelir; kullanıcı isterse karttan tekrar YAZDIR'a
            # alabilir. İlk görülüşte 1 kez ATLA'ya çek; sonraki render'larda
            # kullanıcının elle değiştirdiği seçimi ezme.
            if (stage == "final" and not removed_passive
                    and self._item_out_of_stock(card_item)
                    and bk not in s._stock_auto_skipped):
                s.chosen_per_drug[bk] = "skip"
                if hasattr(self, "_chosen_vars"):
                    self._chosen_vars.pop(f"{s.key}:{bk}", None)
                s._stock_auto_skipped.add(bk)
            block = self._build_single_card(
                grid_holder, s, i, bk, card_item,
                stage=stage, status=status, detail=(dr.detail if dr else ""),
                removed_passive=removed_passive,
            )
            cards.append(block)
        # İlaç etiketlerinden SONRA: hasta bilgi etiketi önizleme kartı (kutusu
        # varsayılan işaretsiz — kullanıcı isterse işaretler).
        pcard = self._build_patient_card(grid_holder, s, stage)
        if pcard is not None:
            cards.append(pcard)
        self._stage_cards[stage] = cards
        self._relayout_stage_cards(stage)

    # --------------------------------------------------------------
    # Izgara yerleşim — tam ekranda ~8 etiket sığacak şekilde dinamik ölçek
    # --------------------------------------------------------------
    _CARD_GAP = 6            # kartlar arası boşluk (px)
    _GRID_COLS = 4           # hedef sütun (4 × 2 = 8 etiket)
    _GRID_ROWS = 2           # hedef satır
    _LABEL_RATIO = 60 / 40   # etiket en/boy oranı (1.5)
    _CARD_OVERHEAD_W = 16    # kart genişliği − etiket genişliği (kenar/padding)
    _CARD_OVERHEAD_H = 68    # kart yüksekliği − etiket yüksekliği (başlık+anahtar)

    def _grid_label_px(self, W: int, H: int) -> tuple[int, int]:
        """Görünür alana (W×H) hedef etiket boyutu → (w, h).

        Küçük ekran modunda tek sütun: genişliği W'ye göre ölçekler.
        Normal modda 4×2=8 hedef: genişlik ve yükseklik kısıtının küçüğü.
        label_display_scale ayarı ile kullanıcı ek küçültme uygulayabilir.
        """
        gap = self._CARD_GAP
        scale = getattr(self, "_label_display_scale", 1.0)
        if getattr(self, "_layout_mode", "normal") == "small":
            # Küçük dikdörtgen pencere: 2 sütun × 1 satır hedef
            small_cols = 2
            small_rows = 1
            lw_w = (W - gap) / small_cols - gap - self._CARD_OVERHEAD_W
            lh_h = (H - gap) / small_rows - gap - self._CARD_OVERHEAD_H
            lw_from_h = lh_h * self._LABEL_RATIO
            lw = int(min(lw_w, lw_from_h) * scale)
            lw = max(120, lw)
            lh = int(lw / self._LABEL_RATIO)
            return lw, lh
        # Genişlik kısıtı: 4 sütun sığsın
        lw_w = (W - gap) / self._GRID_COLS - gap - self._CARD_OVERHEAD_W
        # Yükseklik kısıtı: 2 satır sığsın
        lh_h = (H - gap) / self._GRID_ROWS - gap - self._CARD_OVERHEAD_H
        lw_from_h = lh_h * self._LABEL_RATIO
        lw = int(min(lw_w, lw_from_h) * scale)
        lw = max(150, lw)                 # çok küçülmesin
        lh = int(lw / self._LABEL_RATIO)
        return lw, lh

    def _relayout_stage_cards(self, stage: str):
        """Etiket boyutunu 8 sığacak şekilde hesaplar, görselleri ölçekler, ızgaralar."""
        holder = getattr(self, "_stage_grid", {}).get(stage)
        cards = getattr(self, "_stage_cards", {}).get(stage) or []
        if holder is None or not cards:
            return
        canvas = self.early_canvas if stage == "early" else self.final_canvas
        W = canvas.winfo_width()
        H = canvas.winfo_height()
        if W <= 1:
            try:
                W = self.winfo_screenwidth() - 360
            except Exception:
                W = 1200
        if H <= 1:
            try:
                H = self.winfo_screenheight() - 300
            except Exception:
                H = 820

        lw, lh = self._grid_label_px(W, H)
        card_w = lw + self._CARD_OVERHEAD_W
        gap = self._CARD_GAP
        if getattr(self, "_layout_mode", "normal") == "small":
            # Küçük dikdörtgen pencere: 2 sütun hedef, yeterli yer varsa daha fazla.
            n_cols = max(2, (W - gap) // (card_w + gap))
        else:
            # Her zaman en az _GRID_COLS sütun; yeterli genişlik varsa daha fazla.
            n_cols = max(self._GRID_COLS, (W - gap) // (card_w + gap))

        for c in range(0, n_cols + 8):
            holder.grid_columnconfigure(c, weight=0)
        for idx, card in enumerate(cards):
            self._resize_card(card, lw, lh)
            r, c = divmod(idx, n_cols)
            card["block"].grid_configure(row=r, column=c, sticky="nw",
                                         padx=gap // 2, pady=gap // 2)

    def _resize_card(self, card: dict, lw: int, lh: int):
        """Bir kartın 'kağıt' alan(lar)ını ve görsel(ler)ini (lw×lh) boyutlandırır.

        Kartta birden çok etiket olabilir (kullanım + uyarı + …) → 'imgs' listesi.
        """
        imgs = card.get("imgs")
        if imgs:
            for e in imgs:
                pp = e.get("paper")
                pil = e.get("pil")
                content = e.get("content")
                if pp is not None:
                    pp.configure(width=lw, height=lh)
                if pil is not None and content is not None:
                    try:
                        photo = ImageTk.PhotoImage(pil.resize((lw, lh), Image.LANCZOS))
                        content.configure(image=photo)
                        content.image = photo  # referansı tut (birikmesin)
                    except Exception:
                        pass
            return
        # Geri uyumluluk: tek görsel / boş kart
        paper = card.get("paper")
        if paper is not None:
            paper.configure(width=lw, height=lh)
        pil = card.get("pil")
        content = card.get("content")
        if pil is not None and content is not None:
            try:
                photo = ImageTk.PhotoImage(pil.resize((lw, lh), Image.LANCZOS))
                content.configure(image=photo)
                content.image = photo
            except Exception:
                pass

    # Etiket tipi → kullanıcıya gösterilecek kısa ad (kutu başlığı / sağ-tık menüsü)
    _KIND_TITLE = {"A": "KULLANIM", "B": "HAZIRLAMA",
                   "C": "CİDDİ UYARILAR", "D": "DİKKAT EDİLECEKLER"}

    def _item_out_of_stock(self, item) -> bool:
        """Ayar ('Hastaya verilecek ilaç elde yok ise etiket çıkarma') açıkken,
        bu ilaç elimizde YOK mu?

        Kayıt sonrası stok, verilecek kutu adedi kadar (veya daha fazla) eksiye
        düşmüşse elde o ilaçtan kalmamış demektir:
          stok + kutu <= 0  → elde yok (etiket pasif).
        Örn. reçete 4 kutu, stok -4 → -4+4=0 ≤ 0 → yok. Reçete 4, stok -3 →
        -3+4=1 > 0 → 1 kutu var, basılır. stok ≥ 0 ise tam stokta, basılır.
        """
        if not getattr(self, "_suppress_out_of_stock", False):
            return False
        if item is None:
            return False
        stok = getattr(item, "stok", None)
        if stok is None:
            return False
        kutu = getattr(item, "kutu_adet", None) or 1
        return (stok + kutu) <= 0

    def _initial_label_checked(self, drug_id, kind: str, default_print: bool) -> bool:
        """Bir etiketin baskı kutusunun başlangıç durumu: kalıcı ezme tercihi
        (drug_label_prefs.print_override) varsa onu, yoksa hesaplanan varsayılanı kullan."""
        if drug_id is not None:
            try:
                with get_connection() as conn:
                    ov = get_label_print_override(conn, drug_id, kind)
                if ov is not None:
                    return ov
            except Exception:
                pass
        return bool(default_print)

    def _set_label_default(self, drug_id, kind: str, value, var: tk.BooleanVar,
                           bk: str, s: ReceteSet, default_print: bool):
        """Sağ-tık menüsünden: bu ilaç+etiket tipi için baskı varsayılanını kalıcı ez.
        value: True=zorla işaretli, False=zorla işaretsiz, None=hesaplanana dön."""
        if drug_id is None:
            messagebox.showinfo("Varsayılan", "Bu ilaç veritabanında eşleşmediği için "
                                "kalıcı varsayılan kaydedilemez.")
            return
        try:
            with get_connection() as conn:
                set_label_print_override(conn, drug_id, kind, value)
        except Exception:
            log.exception("Etiket baskı varsayılanı kaydedilemedi")
            return
        new_checked = value if value is not None else bool(default_print)
        var.set(new_checked)
        s.print_kinds.setdefault(bk, {})[kind] = new_checked
        title = self._KIND_TITLE.get(kind, kind)
        durum = ("zorla İŞARETLİ" if value is True else
                 "zorla İŞARETSİZ" if value is False else "hesaplanan varsayılan")
        self.status.set(f"✔ '{title}' etiketi için varsayılan: {durum} (kalıcı).")

    def _popup_label_default_menu(self, event, *, drug_id, kind: str,
                                  var: tk.BooleanVar, bk: str, s: ReceteSet,
                                  default_print: bool):
        """Etikete sağ-tıklayınca kalıcı baskı-varsayılanı menüsünü aç."""
        m = tk.Menu(self, tearoff=0)
        title = self._KIND_TITLE.get(kind, kind)
        m.add_command(label=f"« {title} » etiketi", state="disabled")
        m.add_separator()
        m.add_command(label="⛔ Bu etiketin işareti VARSAYILAN PASİF olsun",
                      command=lambda: self._set_label_default(
                          drug_id, kind, False, var, bk, s, default_print))
        m.add_command(label="✓ Bu etiketin işareti VARSAYILAN AKTİF olsun",
                      command=lambda: self._set_label_default(
                          drug_id, kind, True, var, bk, s, default_print))
        m.add_separator()
        m.add_command(label="↺ Hesaplanan (otomatik) varsayılana dön",
                      command=lambda: self._set_label_default(
                          drug_id, kind, None, var, bk, s, default_print))
        # Metin düzenleme — DB ile eşleşen HER etiket (A/B/C/D) için.
        if drug_id is not None:
            m.add_separator()
            anchor = getattr(event, "widget", None)
            m.add_command(
                label="✎ Metni düzenle (geçici — yalnız bu baskı)",
                command=lambda: self._open_label_text_editor(
                    drug_id, kind, bk, s, anchor, temporary=True))
            m.add_command(
                label="✎ Bu etiketin metnini düzenle (kalıcı)",
                command=lambda: self._open_label_text_editor(
                    drug_id, kind, bk, s, anchor))
        m.add_separator()
        m.add_command(
            label="↺ Muadil Çevir / Başka İlaca Çevir…",
            command=lambda: self._muadil_cevir(bk, s),
        )
        try:
            m.tk_popup(event.x_root, event.y_root)
        finally:
            m.grab_release()

    def _muadil_cevir(self, original_bk: str, s: ReceteSet):
        """Bir etiket kartını başka bir ilaçla (muadil) değiştir.

        Orijinal ilacın doz/sıklık bilgileri korunur; yalnız ilaç adı + barkod
        ve DB'den gelen etiket içeriği yeni ilacın verisine döner.
        """
        import copy
        from ..auto_label_builder import build_labels_for_capture
        from ..medula_parser import CapturedDrug, PrescriptionCapture

        # Orijinal CapturedDrug'ı bul (doz bilgilerini taşımak için)
        orig_cap_drug: Optional[CapturedDrug] = None
        for cap_ref in (s.cap_final, s.cap_early):
            if not cap_ref:
                continue
            for cd in cap_ref.drugs:
                if cd.barkod == original_bk:
                    orig_cap_drug = cd
                    break
            if orig_cap_drug:
                break

        # İlaç arama penceresi
        win = tk.Toplevel(self)
        win.title("Muadil İlaç Seç")
        win.resizable(False, False)
        win.grab_set()
        win.transient(self)

        tk.Label(win, text="İlaç adını yazın:", font=("Segoe UI", 10)).pack(
            padx=12, pady=(12, 2), anchor="w")
        var_q = tk.StringVar()
        ent = tk.Entry(win, textvariable=var_q, width=40, font=("Segoe UI", 10))
        ent.pack(padx=12, pady=(0, 4))
        ent.focus_set()

        listbox = tk.Listbox(win, height=10, width=60, font=("Consolas", 9),
                             selectmode="single")
        listbox.pack(padx=12, pady=(0, 4))
        _results: list = []

        def _search(*_):
            q = var_q.get().strip()
            listbox.delete(0, "end")
            _results.clear()
            if len(q) < 2:
                return
            rows = self._search_drugs_by_name(q)
            _results.extend(rows)
            for r in rows:
                listbox.insert("end", f"{r['barcode'] or '':15} | {r['name']}")

        var_q.trace_add("write", _search)

        def _confirm(*_):
            sel = listbox.curselection()
            if not sel:
                return
            row = _results[sel[0]]
            new_bk = row["barcode"] or ""
            new_name = row["name"]
            win.destroy()
            self._apply_muadil(original_bk, new_bk, new_name, s, orig_cap_drug)

        listbox.bind("<Double-Button-1>", _confirm)
        tk.Button(win, text="✓ Seç", command=_confirm,
                  font=("Segoe UI", 10, "bold")).pack(pady=(0, 12))
        ent.bind("<Return>", lambda e: (listbox.selection_set(0) if listbox.size() else None))
        listbox.bind("<Return>", _confirm)
        win.bind("<Escape>", lambda e: win.destroy())

    def _apply_muadil(self, original_bk: str, new_bk: str, new_name: str,
                      s: ReceteSet, orig_cap_drug):
        """Seçilen muadil ilaç için etiket üretir ve ReceteSet'e yerleştirir."""
        import copy, threading
        from ..auto_label_builder import build_labels_for_capture
        from ..medula_parser import CapturedDrug, PrescriptionCapture

        self.status.set(f"⏳ Muadil etiket üretiliyor: {new_name}…")

        def _worker():
            try:
                # Orijinal doz bilgilerini yeni barkod/adla kopyala
                if orig_cap_drug is not None:
                    new_cd = copy.copy(orig_cap_drug)
                else:
                    new_cd = CapturedDrug()
                new_cd.barkod = new_bk
                new_cd.ad = new_name

                # Referans capture'ı al (hasta adı / reçete no vs için)
                ref_cap = s.cap_final or s.cap_early
                if ref_cap is not None:
                    fake_cap = copy.copy(ref_cap)
                else:
                    fake_cap = PrescriptionCapture(
                        page_kind="e_recete_sorgu_sonuc",
                        saved=True,
                    )
                fake_cap.drugs = [new_cd]

                built = build_labels_for_capture(
                    fake_cap,
                    preview_dir=self._preview_dir,
                    eczane_adi=self.eczane_adi,
                    eczane_telefon=self.eczane_tel,
                )
                new_item = built.items[0] if built.items else None
            except Exception as exc:
                self.after(0, lambda: self.status.set(f"❌ Muadil etiket üretilemedi: {exc}"))
                return

            def _apply():
                if new_item is None:
                    self.status.set("❌ Muadil için etiket üretilemedi.")
                    return
                # Her iki aşamanın item listesinde değiştir
                for built_ref in (s.final, s.early):
                    if not built_ref:
                        continue
                    for i, it in enumerate(built_ref.items):
                        if it.barkod == original_bk:
                            built_ref.items[i] = new_item
                            break
                # chosen_per_drug güncelle
                chosen = s.chosen_per_drug.pop(original_bk, "final")
                s.chosen_per_drug[new_bk] = chosen
                # diff_rows'dan eski barkodu çıkar (artık muadil)
                s.diff_rows = [r for r in s.diff_rows if r.barkod != original_bk]
                # _label_print_vars temizle (yeni kart için yeniden yaratılacak)
                if hasattr(self, "_label_print_vars"):
                    for k in [k for k in self._label_print_vars if k.startswith(f"{s.key}:{original_bk}:")]:
                        del self._label_print_vars[k]
                if hasattr(self, "_chosen_vars"):
                    self._chosen_vars.pop(f"{s.key}:{original_bk}", None)
                self._render_set(s)
                self.status.set(f"✓ Muadil çevrildi: {new_name}")

            self.after(0, _apply)

        threading.Thread(target=_worker, daemon=True, name="muadil-build").start()

    def _open_label_text_editor(self, drug_id, kind: str, bk: str,
                                s: ReceteSet, anchor=None, temporary: bool = False):
        """Etiket metni düzenleme penceresi.

        temporary=False → metin DB'ye KALICI yazılır (drug_label_prefs.custom_text).
        temporary=True  → metin DB'ye YAZILMAZ; yalnız bu baskıdaki PNG güncellenir
        (render_label_preview ile; bir sonraki yeniden üretimde otomatiğe döner).
        """
        if drug_id is None:
            messagebox.showinfo("Düzenle", "Bu etiket bir DB ilacıyla eşleşmiyor; "
                                "metni düzenlenemez.")
            return
        # Hasta adı (başlık render'ı için) ve düzenleme durumu
        built_ref = s.final or s.early
        hasta_adi = (built_ref.hasta_ad if built_ref else "") or ""
        try:
            editable, text, title = get_label_edit_state(drug_id, kind, hasta_adi)
        except Exception as e:
            messagebox.showerror("Hata", f"Etiket metni okunamadı:\n{e}")
            return
        if not editable:
            messagebox.showinfo("Düzenle", "Bu etiketin metni düzenlenemiyor.")
            return

        def _on_saved(new_text: str):
            # Bu barkodun TÜM aşamalardaki (early/final) ilgili etiket görselini
            # yeniden üret ve PNG'leri güncelle, sonra re-render. Geçici modda
            # DB'ye yazılmaz (render_label_preview), kalıcı modda yazılır.
            attr = {"A": "p1", "B": "p2", "C": "p3", "D": "p4"}.get(kind)
            try:
                if temporary:
                    img = render_label_preview(drug_id, kind, new_text, hasta_adi)
                else:
                    img = save_label_text_and_render(drug_id, kind, new_text, hasta_adi)
            except Exception as e:
                messagebox.showerror("Hata", f"Etiket üretilemedi:\n{e}")
                return
            if img is not None and attr:
                for src in (s.early, s.final):
                    if not src:
                        continue
                    for it in src.items:
                        if it.barkod == bk:
                            p = getattr(it, attr, None)
                            if p:
                                try:
                                    img.save(p)
                                except Exception:
                                    log.exception("Etiket PNG yazma hatası")
            self._render_set(s)
            if temporary:
                durum = ("geçici metin temizlendi" if not new_text.strip()
                         else "geçici düzenlendi (kaydedilmedi)")
            else:
                durum = ("otomatiğe döndürüldü" if not new_text.strip()
                         else "kalıcı kaydedildi")
            self.status.set(f"✔ '{title}' etiketinin metni {durum}.")

        LabelTextEditor(self, drug_id=drug_id, kind=kind, title_text=title,
                        initial_text=text, hasta_adi=hasta_adi,
                        on_save=_on_saved, anchor=anchor, temporary=temporary)

    def _make_label_print_switch(self, parent, var: tk.BooleanVar, on_toggle):
        """Tek etikete özel iki segmentli YAZDIR/ATLA switch'i (boolean var).
        İlaç-bazlı _make_print_toggle ile aynı görsel dil, ama tek etiket için."""
        ON_G, OFF_G = "#16a34a", "#1f3a2c"
        ON_R, OFF_R = "#dc2626", "#3a2030"
        DIM = "#9aa3bf"
        wrap = tk.Frame(parent, background="#0f1830", highlightthickness=1,
                        highlightbackground="#3a4a78")
        seg_p = tk.Label(wrap, text="✓ YAZDIR", font=("Segoe UI", 8, "bold"),
                         padx=8, pady=2, cursor="hand2")
        seg_p.pack(side="left")
        seg_s = tk.Label(wrap, text="✕ ATLA", font=("Segoe UI", 8, "bold"),
                         padx=8, pady=2, cursor="hand2")
        seg_s.pack(side="left")

        def refresh():
            on = bool(var.get())
            seg_p.configure(background=ON_G if on else OFF_G,
                            foreground="white" if on else DIM)
            seg_s.configure(background=ON_R if not on else OFF_R,
                            foreground="white" if not on else DIM)

        def set_on(_=None):
            var.set(True); on_toggle(); refresh()

        def set_off(_=None):
            var.set(False); on_toggle(); refresh()

        seg_p.bind("<Button-1>", set_on)
        seg_s.bind("<Button-1>", set_off)

        # var dışarıdan da değişebilir (sağ-tık 'varsayılan pasif/aktif') → görseli
        # otomatik yenile. Widget yok olunca trace'i kaldır (birikmesin).
        def _on_var_write(*_):
            try:
                refresh()
            except tk.TclError:
                pass
        tid = var.trace_add("write", _on_var_write)

        def _cleanup(_=None):
            try:
                var.trace_remove("write", tid)
            except Exception:
                pass
        wrap.bind("<Destroy>", _cleanup)

        refresh()
        return wrap

    def _build_single_card(
        self, inner, s: ReceteSet, idx: int, barkod: str,
        item: Optional[LabelItem], *, stage: str, status: str, detail: str,
        removed_passive: bool = False,
    ) -> dict:
        """Tek ilaç kartı: başlık + sarı etiket görseli + YAZDIR/ATLA anahtarı.

        Görsel boyutu _relayout_stage_cards'da (8 etiket sığacak şekilde) ayarlanır.
        Yeniden boyutlandırma için widget referanslarını içeren dict döndürür.
        """
        C = COLORS
        # Başlangıç boyutu (relayout düzeltecek)
        if getattr(self, "_layout_mode", "normal") == "small":
            _init_w = max(280, (self.winfo_width() or self.winfo_screenwidth() // 6) - 20)
            lw0, lh0 = self._grid_label_px(_init_w, 9999)
        else:
            lw0, lh0 = self._grid_label_px(
                (self.winfo_screenwidth() or 1600) - 360,
                (self.winfo_screenheight() or 900) - 300,
            )

        drug_name = item.drug_ad if item else f"(Barkod: {barkod})"
        name_chars = max(12, (lw0 - 78) // 8)
        disp_name = drug_name if len(drug_name) <= name_chars else drug_name[:name_chars - 1] + "…"

        status_text = {
            "same": "Aynı", "changed": "Değişti",
            "removed": "SGK ✗", "added": "Eklendi",
        }.get(status, status)
        status_color = {
            "same": "#3f8f5b", "changed": "#b86b00", "removed": "#a00", "added": "#0b7a3b",
        }.get(status, "#445")
        if removed_passive:
            # Reçete sonu sekmesindeki PASİF "çıkarıldı" kartı: rozeti netleştir.
            status_text = "ÇIKARILDI"
            status_color = "#a00"
        empty_msg = ("Bu aşamada\nyok" if stage == "early"
                     else ("SGK\nödemedi" if status == "removed" else "Yok"))

        # --- Dış kart yüzeyi ---
        # Birden fazla etiketi olan ilaç (kullanım + hazırlama/uyarı/enjeksiyon...):
        # tüm etiketlerini bir arada KALIN SİYAH çerçeve içine al (görsel gruplama).
        _n_labels = 0
        if item is not None:
            _n_labels = sum(1 for p in (item.p1, item.p2, item.p3, item.p4)
                            if p and Path(p).exists())
        _multi = _n_labels >= 2
        block = tk.Frame(
            inner, background=C["bg_panel"],
            highlightthickness=(4 if _multi else 1),
            highlightbackground=("black" if _multi else "#3a4a78"),
            highlightcolor=("black" if _multi else "#3a4a78"),
        )

        # --- Başlık şeridi: numara + ilaç adı + durum rozeti ---
        bar = tk.Frame(block, background=C["bg_strip"])
        bar.pack(fill="x")
        tk.Label(bar, text=f"{idx}", background=C["bg_card"], foreground=C["text_dark"],
                 font=("Segoe UI", 9, "bold"), width=2).pack(side="left", padx=(3, 0), pady=2)
        tk.Label(bar, text=f" {status_text}", background=C["bg_strip"],
                 foreground="white", font=("Segoe UI", 7, "bold"),
                 anchor="e").pack(side="right", padx=3)
        tk.Frame(bar, background=status_color, width=6, height=14).pack(side="right", pady=2)
        tk.Label(bar, text=disp_name, background=C["bg_strip"], foreground=C["text_yellow"],
                 font=("Segoe UI", 8, "bold"), anchor="w", width=name_chars
                 ).pack(side="left", padx=(3, 3))

        # SGK geri ödeme yok uyarısı — etiket yine basılır (reçete başı), sadece bilgi
        if item is not None and getattr(item, "geri_odeme_yok", False):
            tk.Label(block, text="⛔ GERİ ÖDEME YOK — SGK ödemez (etiket yine basılır)",
                     background="#a00000", foreground="white",
                     font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x")

        # ELDE YOK uyarısı: stok eksiye düştü (verilecek ilaç stokta kalmadı) →
        # baskı anahtarı varsayılan PASİF. Kullanıcı isterse açıp basabilir.
        if not removed_passive and self._item_out_of_stock(item):
            _st = getattr(item, "stok", None)
            tk.Label(block,
                     text=f"📦 STOKTA YOK (stok {_st}) — ETİKET BASILMAZ "
                          f"(yazdırmak için işareti açın)",
                     background="#8a4b00", foreground="white",
                     font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x")

        # Reçeteden ÇIKARILAN ilaç (hasta istemedi / ikinci kayıtta kaldırıldı):
        # anahtar ATLA'da, Shift+End baskısına girmez. İstenirse karttan açılabilir.
        if removed_passive:
            tk.Label(block, text="🚫 REÇETEDEN ÇIKARILDI — BU ETİKET BASILMAYACAK",
                     background="#7a0000", foreground="white",
                     font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x")

        # --- Etiket görselleri — SARI "kağıt" (fiziksel sarı etiket) + ince çerçeve.
        # İlacın TÜM etiketleri alt alta gösterilir: p1 kullanım, p2 hazırlama,
        # p3 CİDDİ UYARI, p4 dikkat. Böylece uyarı etiketi de ana ekranda görünür
        # (yazıcıya giden ile birebir aynı). ---
        LABEL_BG = "#FFE680"
        imgs: list[dict] = []
        paper = None
        pil = None
        content = None
        label_specs: list[tuple] = []
        if item is not None:
            _disp_only_basic = self._only_basic_display()
            for p, kind in ((item.p1, "A"), (item.p2, "B"),
                            (item.p3, "C"), (item.p4, "D")):
                if _disp_only_basic and kind != "A":
                    continue
                if p and Path(p).exists():
                    label_specs.append((p, self._KIND_TITLE.get(kind, kind), kind))
        if not hasattr(self, "_label_print_vars"):
            self._label_print_vars = {}
        if label_specs:
            for p, cap, kind in label_specs:
                default_print = bool((item.label_default_print or {}).get(kind, True)) if item else True
                # Etiket-bazı baskı kutusu state'i (re-render'da korunur, _chosen_vars gibi)
                pvkey = f"{s.key}:{barkod}:{kind}"
                if pvkey not in self._label_print_vars:
                    existing = s.print_kinds.get(barkod, {}).get(kind)
                    init = (existing if existing is not None
                            else self._initial_label_checked(
                                item.drug_id if item else None, kind, default_print))
                    self._label_print_vars[pvkey] = tk.BooleanVar(value=init)
                    s.print_kinds.setdefault(barkod, {})[kind] = init
                pvar = self._label_print_vars[pvkey]
                s.print_kinds.setdefault(barkod, {})[kind] = pvar.get()

                # Kilit (düzenleme) durumu — re-render'lar arası korunur.
                if not hasattr(self, "_label_unlocked"):
                    self._label_unlocked = {}
                ukey = pvkey  # f"{s.key}:{barkod}:{kind}"
                _did = item.drug_id if item else None

                # Etiket tipi başlığı (görselin üstünde) + kilit butonu
                hdr = tk.Frame(block, background=C["bg_panel"])
                hdr.pack(fill="x", padx=4, pady=(1, 0))
                tk.Label(hdr, text=cap, background=C["bg_panel"],
                         foreground=C["text_yellow"], font=("Segoe UI", 7, "bold"),
                         anchor="w").pack(side="left")

                pp = tk.Frame(block, background=LABEL_BG, width=lw0, height=lh0,
                              highlightthickness=1, highlightbackground="black")
                pp.pack(padx=4, pady=(0, 1))
                pp.pack_propagate(False)
                # Sağ-tık: kalıcı baskı-varsayılanı menüsü (ilaç + etiket tipi bazlı)
                _menu = (lambda e, k=kind, v=pvar, dp=default_print:
                         self._popup_label_default_menu(
                             e, drug_id=(item.drug_id if item else None), kind=k,
                             var=v, bk=barkod, s=s, default_print=dp))
                pp.bind("<Button-3>", _menu)
                # Çift-sol-tık: yalnız KİLİT AÇIKSA metin düzenleyicisini aç.
                _dbl = (lambda e, k=kind, did=_did, key=ukey:
                        self._open_label_text_editor(
                            did, k, barkod, s, getattr(e, "widget", None))
                        if (did is not None and self._label_unlocked.get(key))
                        else None)
                pp.bind("<Double-Button-1>", _dbl)

                # Kilit butonu — yalnız DB ile eşleşen (düzenlenebilir) etikette.
                if _did is not None:
                    lock_btn = tk.Label(hdr, background=C["bg_panel"],
                                        foreground=C["text_yellow"],
                                        font=("Segoe UI", 9), cursor="hand2")
                    lock_btn.config(
                        text="🔓" if self._label_unlocked.get(ukey) else "🔒")
                    lock_btn.pack(side="right")

                    def _toggle_lock(e=None, key=ukey, b=lock_btn,
                                     k=kind, did=_did):
                        now = not self._label_unlocked.get(key)
                        self._label_unlocked[key] = now
                        b.config(text="🔓" if now else "🔒")
                        if now:
                            # Kilidi açınca doğrudan düzenleyiciyi aç.
                            self._open_label_text_editor(did, k, barkod, s, b)
                    lock_btn.bind("<Button-1>", _toggle_lock)
                    lock_btn.bind("<Enter>", lambda e: self.status.set(
                        "Kilidi aç → etiket metnini düzenle (çift tık da çalışır)"))
                    lock_btn.bind("<Leave>", lambda e: self.status.set(""))
                try:
                    im = Image.open(p).convert("RGB")
                    ct = tk.Label(pp, background=LABEL_BG, borderwidth=0)
                    ct.pack(fill="both", expand=True)
                    ct.bind("<Button-3>", _menu)
                    ct.bind("<Double-Button-1>", _dbl)
                    imgs.append({"paper": pp, "pil": im, "content": ct})
                except Exception as e:
                    tk.Label(pp, text=f"(görsel hata)\n{e}", background=LABEL_BG,
                             foreground="#a00", font=("Segoe UI", 8)).pack(expand=True)

                # Görselin ALTINDA: bu etikete özel YAZDIR/ATLA switch'i.
                # Yalnızca ilaçta BİRDEN FAZLA etiket varsa göster — tek etiketli
                # ilaçta alttaki büyük YAZDIR/ATLA ile aynı işi yapıp "ikili"
                # görünüyordu. (print_kinds varsayılanı yukarıda zaten set edildi,
                # bu yüzden anahtarı gizlemek baskı mantığını etkilemez.)
                if len(label_specs) > 1:
                    sw_row = tk.Frame(block, background=C["bg_panel"])
                    sw_row.pack(fill="x", padx=4, pady=(0, 3))

                    def _on_label_toggle(bk=barkod, k=kind, v=pvar):
                        s.print_kinds.setdefault(bk, {})[k] = bool(v.get())
                    self._make_label_print_switch(sw_row, pvar, _on_label_toggle
                                                  ).pack(side="left")
            if imgs:  # geri uyumluluk: ilk görseli ana referans olarak tut
                paper = imgs[0]["paper"]
                pil = imgs[0]["pil"]
                content = imgs[0]["content"]
        else:
            paper = tk.Frame(block, background=C["bg_card_soft"], width=lw0, height=lh0,
                             highlightthickness=1, highlightbackground="#caa700")
            paper.pack(padx=4, pady=4)
            paper.pack_propagate(False)
            tk.Label(paper, text=empty_msg, background=C["bg_card_soft"],
                     foreground="#8B7500", font=("Segoe UI", 11, "bold"),
                     justify="center").pack(expand=True)

        # --- Diff detayı (varsa) — ince uyarı şeridi ---
        if detail:
            tk.Label(block, text=f"⚠ {detail}", background=C["accent_orange"],
                     foreground="white", font=("Segoe UI", 8, "bold"),
                     anchor="w", wraplength=lw0).pack(fill="x", padx=8)

        # --- Alt kontrol şeridi: BÜYÜK YAZDIR/ATLA anahtarı + önizleme ---
        var_key = f"{s.key}:{barkod}"
        if not hasattr(self, "_chosen_vars"):
            self._chosen_vars = {}
        if var_key not in self._chosen_vars:
            self._chosen_vars[var_key] = tk.StringVar(
                value=s.chosen_per_drug.get(barkod, "final"))
        var = self._chosen_vars[var_key]

        def _on_choice(_=None):
            s.chosen_per_drug[barkod] = var.get()

        foot = tk.Frame(block, background=C["bg_panel"])
        foot.pack(fill="x", padx=4, pady=(0, 4))
        # Çıkarılan ilacın kartı reçete SONU sekmesinde ama görseli reçete BAŞINDAN
        # (early) geldiği için YAZDIR'a basılınca 'early' sürümü basılmalı — final'da
        # bu ilaç yok, 'final' seçilirse labels_to_print onu yine atlardı.
        toggle_stage = "early" if removed_passive else stage
        self._make_print_toggle(foot, var, toggle_stage, _on_choice, enabled=item is not None)
        if item is not None:
            ttk.Button(foot, text="👁", width=2, style="Yellow.TButton",
                       command=lambda it=item: self._show_label_print_preview(it)
                       ).pack(side="right")
            # Doz / kullanım zamanı düzenleme (kullanım etiketi olan ilaçlarda)
            if item.usage is not None:
                ttk.Button(foot, text="✎ Doz", style="Yellow.TButton",
                           command=lambda it=item, st=s, blk=block:
                               self._open_dose_editor(it, st, blk)
                           ).pack(side="right", padx=(0, 2))
                self._add_timing_buttons(foot, item, s, stage)

        return {"block": block, "paper": paper, "content": content, "pil": pil,
                "imgs": imgs}

    # ==================================================================
    # Hasta bilgi etiketi önizleme kartı (ilaç etiketlerinden sonra)
    # ==================================================================
    def _render_patient_preview_image(self, cap, extra, show_debt: bool = True):
        """Hasta etiketi önizleme görselini (PIL) üretir — tarih+ad daima,
        telefon/tutar varsa (extra) eklenir. show_debt=False ise TOPLAM BORÇ gizli."""
        from ..label_render import render_patient_label
        from ..patient_info import label_amounts
        amt = label_amounts(extra)
        return render_patient_label(
            hasta_adi=(cap.hasta_ad or "") if cap else "",
            tarih=(cap.recete_tarihi or "") if cap else "",
            telefon=getattr(extra, "telefon", "") or "",
            recete_tutari=amt["recete_tutari"],
            recete_paid=amt["recete_paid"],
            toplam_borc=amt["toplam_borc"],
            show_debt=show_debt,
            eczane_adi=self.eczane_adi, eczane_telefon=self.eczane_tel,
        ).convert("RGB")

    def _hasta_show_debt_for(self, s: "ReceteSet") -> bool:
        """Bu set için 'TOPLAM BORÇ' satırı görünsün mü? (genel ayar AÇIK ve set
        bazında ✕ ile gizlenmemiş)."""
        return bool(getattr(self, "_hasta_show_debt", True)) and not getattr(s, "hide_debt", False)

    def _build_patient_card(self, holder, s: "ReceteSet", stage: str) -> Optional[dict]:
        """Hasta bilgi etiketi önizleme kartı: başlık + 'Bas' kutusu (varsayılan
        işaretsiz, s._hasta_var ile başlık kutusuyla senkron) + etiket görseli.

        Telefon/tutar baskı anında WinForms'tan okunur; önizlemede başta yalnız
        tarih+ad gösterilir, ekranda okunabiliyorsa arka planda tamamlanır.
        """
        cap = s.cap_final if stage == "final" else s.cap_early
        if cap is None or not ((cap.hasta_ad or "").strip() or (cap.recete_tarihi or "").strip()):
            return None
        C = COLORS
        if getattr(self, "_layout_mode", "normal") == "small":
            _init_w = max(280, (self.winfo_width() or self.winfo_screenwidth() // 6) - 20)
            lw0, lh0 = self._grid_label_px(_init_w, 9999)
        else:
            lw0, lh0 = self._grid_label_px(
                (self.winfo_screenwidth() or 1600) - 360,
                (self.winfo_screenheight() or 900) - 300,
            )

        # İlaç kartlarıyla AYNI çerçeve/başlık yapısı (tek-etiket kart stili).
        block = tk.Frame(holder, background=C["bg_panel"],
                         highlightthickness=1, highlightbackground="#3a4a78",
                         highlightcolor="#3a4a78")
        bar = tk.Frame(block, background=C["bg_strip"])
        bar.pack(fill="x")
        tk.Label(bar, text="🧾", background=C["bg_card"], foreground=C["text_dark"],
                 font=("Segoe UI Emoji", 9), width=2).pack(side="left", padx=(3, 0), pady=2)
        tk.Label(bar, text=" Özet", background=C["bg_strip"], foreground="white",
                 font=("Segoe UI", 7, "bold"), anchor="e").pack(side="right", padx=3)
        tk.Frame(bar, background="#3f6f8f", width=6, height=14).pack(side="right", pady=2)
        tk.Label(bar, text="HASTA ETİKETİ", background=C["bg_strip"],
                 foreground=C["text_yellow"], font=("Segoe UI", 8, "bold"),
                 anchor="w").pack(side="left", padx=(3, 3))
        var = getattr(s, "_hasta_var", None)

        # İlaç kartlarındaki "KULLANIM" şeridiyle AYNI alt-başlık → görseller aynı
        # hizada başlasın: sol "HASTA BİLGİSİ" + sağda kilit ikonu. Hasta etiketi
        # otomatik doldurulduğundan kilit SABİT (🔒) — yalnız bilgi amaçlı.
        hdr = tk.Frame(block, background=C["bg_panel"])
        hdr.pack(fill="x", padx=4, pady=(1, 0))
        tk.Label(hdr, text="HASTA BİLGİSİ", background=C["bg_panel"],
                 foreground=C["text_yellow"], font=("Segoe UI", 7, "bold"),
                 anchor="w").pack(side="left")
        _plock = tk.Label(hdr, text="🔒", background=C["bg_panel"],
                          foreground=C["text_yellow"], font=("Segoe UI", 9))
        _plock.pack(side="right")
        _plock.bind("<Enter>", lambda e: self.status.set(
            "Hasta etiketi otomatik doldurulur (tarih · ad · telefon · tutar) — sabittir."))
        _plock.bind("<Leave>", lambda e: self.status.set(""))

        LABEL_BG = "#FFE680"
        pp = tk.Frame(block, background=LABEL_BG, width=lw0, height=lh0,
                      highlightthickness=1, highlightbackground="black")
        pp.pack(padx=4, pady=(0, 1))
        pp.pack_propagate(False)
        imgs: list[dict] = []
        try:
            im = self._render_patient_preview_image(
                cap, getattr(s, "_patient_extra", None),
                show_debt=self._hasta_show_debt_for(s))
            ct = tk.Label(pp, background=LABEL_BG, borderwidth=0)
            ct.pack(fill="both", expand=True)
            imgs.append({"paper": pp, "pil": im, "content": ct})
        except Exception as e:
            tk.Label(pp, text=f"(görsel hata)\n{e}", background=LABEL_BG,
                     foreground="#a00", font=("Segoe UI", 8)).pack(expand=True)

        card = {
            "block": block, "paper": pp,
            "content": (imgs[0]["content"] if imgs else None),
            "pil": (imgs[0]["pil"] if imgs else None),
            "imgs": imgs,
        }

        # 'TOPLAM BORÇ' (veresiye) satırını bu etiketten kaldıran ✕ — etiketin sağ-alt
        # köşesinde PASİF (soluk) görünür; basınca veresiye satırı silinir. Yalnız genel
        # ayar AÇIK, gizlenmemiş ve okunmuş bir borç değeri varken görünür.
        if imgs:
            x_btn = tk.Label(pp, text="✕", background=LABEL_BG, foreground="#b08900",
                             font=("Segoe UI", 10, "bold"), cursor="hand2")

            def _has_debt_value():
                from ..patient_info import label_amounts
                return bool(label_amounts(getattr(s, "_patient_extra", None))["toplam_borc"])

            def _refresh_debt_x():
                try:
                    if not pp.winfo_exists():
                        return
                except Exception:
                    return
                if self._hasta_show_debt_for(s) and _has_debt_value():
                    x_btn.place(relx=1.0, rely=1.0, x=-3, y=-2, anchor="se")
                else:
                    x_btn.place_forget()

            def _remove_debt(_=None):
                s.hide_debt = True
                try:
                    card["imgs"][0]["pil"] = self._render_patient_preview_image(
                        cap, getattr(s, "_patient_extra", None), show_debt=False)
                except Exception:
                    pass
                _refresh_debt_x()
                self._relayout_stage_cards(stage)

            x_btn.bind("<Button-1>", _remove_debt)
            card["_refresh_debt_x"] = _refresh_debt_x
            _refresh_debt_x()

        # Alt kontrol şeridi: ilaç kartlarıyla AYNI YAZDIR/ATLA anahtarı (s._hasta_var).
        # Başlık şeridindeki "🧾 Hasta Etiketi" kutusuyla aynı değişkeni paylaşır → senkron.
        if var is not None:
            def _toggle(v=var, _s=s):
                _s.print_hasta = bool(v.get())
            foot = tk.Frame(block, background=C["bg_panel"])
            foot.pack(fill="x", padx=4, pady=(0, 4))
            self._make_label_print_switch(foot, var, _toggle).pack(side="left")

        # Bu kartı sete kaydet — arka plan poll'ü (telefon/tutar gelince) günceller
        if imgs:
            if getattr(s, "_patient_cards", None) is None:
                s._patient_cards = {}
            s._patient_cards[stage] = card
            # Telefon/tutar henüz okunmadıysa ve poll çalışmıyorsa başlat
            if (getattr(s, "_patient_extra", None) is None
                    and not getattr(s, "_patient_enrich_active", False)):
                self._enrich_patient_card_async(s)
        return card

    def _enrich_patient_card_async(self, s: "ReceteSet"):
        """Telefon/tutar verisi Botanik WinForms panelinde GECİKMELİ dolduğundan
        (ilaç etiketleri anında HTML'den gelir), veriyi POLL/RETRY ile bekler.

        Hızlı yalnız-native okuma (~ms) ile ~8 sn boyunca 0,5 sn aralıkla dener;
        veri gelince setin canlı hasta kart(lar)ının görselini günceller. Veri hiç
        gelmezse `_patient_extra` None bırakılır → sonraki render/yenileme tekrar dener.
        Boş okuma ARTIK 'okundu' sayılmaz (eski hatada bir daha denenmiyordu).
        """
        import time
        gen = getattr(s, "_patient_gen", 0)   # bu poll'ün ait olduğu yakalama sürümü
        s._patient_enrich_active = True
        # Bu kartın ait olduğu hastanın kimliği — okunan tutar bu hastaya AİT DEĞİLSE
        # (ekran başka reçeteye geçtiyse) ASLA uygulanmaz.
        tcap = s.cap_final or s.cap_early
        target_rno = (tcap.recete_no if tcap else "") or ""
        target_ad = (tcap.hasta_ad if tcap else "") or ""

        def worker():
            from ..patient_info import (read_patient_extra, has_extra_data,
                                        read_screen_identity, identity_matches)
            extra = None
            for _ in range(16):                      # ~8 sn (0,5 sn × 16)
                # Reçete bu sırada YENİDEN yakalandıysa (gen değişti) bu poll bayat →
                # boşuna devam etme; yeni poll güncel rakamları okuyacak.
                if getattr(s, "_patient_gen", 0) != gen:
                    return
                try:
                    e = read_patient_extra(fast=True)
                except Exception:
                    e = None
                if has_extra_data(e):
                    # KİMLİK DOĞRULA: ekranda yüklü reçete bu kartın hastası mı?
                    srno, sad = read_screen_identity()
                    if identity_matches(srno, sad, target_rno, target_ad):
                        extra = e
                        break
                    # Ekranda BAŞKA hasta var → bu veriyi UYGULAMA, beklemeye devam et
                    # (kullanıcı bu reçeteye dönünce eşleşecek).
                time.sleep(0.5)

            def apply():
                # Bayat sürüm: daha yeni bir yakalama/poll devraldı → dokunma.
                if getattr(s, "_patient_gen", 0) != gen:
                    return
                s._patient_enrich_active = False
                if extra is None:
                    return  # veri gelmedi → _patient_extra None kalsın (sonra yine denenir)
                self._apply_patient_extra(s, extra)

            self.after(0, apply)

        threading.Thread(target=worker, daemon=True, name="hasta-card-enrich").start()

    def _apply_patient_extra(self, s: "ReceteSet", extra) -> None:
        """Okunan telefon/tutar verisini sete yaz + setin canlı hasta kart(lar)ının
        görselini güncelle (Tk ana thread'inde çağrılmalı)."""
        from ..patient_info import has_extra_data
        if not has_extra_data(extra):
            return
        s._patient_extra = extra
        cards = getattr(s, "_patient_cards", None) or {}
        stages = set()
        for st, card in list(cards.items()):
            if not card or not card.get("imgs"):
                continue
            try:
                if not card["block"].winfo_exists():
                    continue
            except Exception:
                continue
            cap = s.cap_final if st == "final" else s.cap_early
            try:
                card["imgs"][0]["pil"] = self._render_patient_preview_image(
                    cap, extra, show_debt=self._hasta_show_debt_for(s))
                rx = card.get("_refresh_debt_x")
                if rx:
                    rx()
                stages.add(st)
            except Exception:
                pass
        for st in stages:
            self._relayout_stage_cards(st)

    # ==================================================================
    # Saat aralığı / SÖAG butonları
    # ==================================================================
    def _add_timing_buttons(self, parent, item: "LabelItem", s: "ReceteSet", stage: str):
        """Etiket altına A/B tipi toggle ve S/Ö/A/G (günde-1 zaman) butonları ekler."""
        C = COLORS
        usage = item.usage
        kez = int(usage.gunluk_kez or 1)
        periyot = (usage.periyot or "Günde").strip().lower()
        is_daily = not periyot or periyot.startswith("gün") or periyot.startswith("gun")

        if not is_daily:
            return  # Haftada/Ayda için anlamsız

        sep = tk.Frame(parent, background=C["bg_panel"])
        sep.pack(side="right", padx=(0, 2))

        # S Ö A G — yalnızca günde 1 kez uygulamalarda
        if kez == 1:
            soag_frame = tk.Frame(sep, background=C["bg_panel"])
            soag_frame.pack(side="left")
            cur_zaman = {(z or "").strip().lower() for z in (usage.kullanim_zamani or [])}
            for z_key, z_lbl in [("sabah", "S"), ("öğlen", "Ö"), ("akşam", "A"), ("gece", "G")]:
                active = z_key in cur_zaman
                btn = tk.Button(
                    soag_frame, text=z_lbl, width=2,
                    font=("Segoe UI", 8, "bold"),
                    background="#2a4a20" if active else "#1a2a50",
                    foreground="#5aff5a" if active else "#9aa3bf",
                    activebackground="#3a6a30", relief="flat", cursor="hand2",
                    command=lambda zk=z_key, it=item, st=s:
                        self._apply_timing_zaman(it, st, zk),
                )
                btn.pack(side="left", padx=1)

        # A / B tipi toggle (kez >= 2: A=SABAH/AKŞAM ızgara, B=GÜNDE N KEZ/DOZ/X SAAT ARA İLE)
        if kez >= 2:
            mode_key = (stage, item.barkod)
            if not hasattr(self, "_saat_mode"):
                self._saat_mode: dict = {}
            active_saat = self._saat_mode.get(mode_key, getattr(usage, "interval_mode", False))

            ab_frame = tk.Frame(sep, background=C["bg_panel"])
            ab_frame.pack(side="left", padx=(4, 0))

            for lbl, is_b in [("A", False), ("B", True)]:
                is_active = (active_saat == is_b)
                ab_btn = tk.Button(
                    ab_frame, text=lbl, width=2,
                    font=("Segoe UI", 8, "bold"),
                    background="#2a4a20" if is_active else "#1a2a50",
                    foreground="#5aff5a" if is_active else "#9aa3bf",
                    activebackground="#3a6a30", relief="flat", cursor="hand2",
                    command=lambda mk=mode_key, it=item, st=s, b=is_b:
                        self._set_saat_mode(it, st, mk, b),
                )
                ab_btn.pack(side="left", padx=1)

    def _toggle_saat_mode(self, item: "LabelItem", s: "ReceteSet", mode_key: tuple):
        """interval_mode'u tersine çevirir (eski API — geriye uyumluluk)."""
        if not hasattr(self, "_saat_mode"):
            self._saat_mode = {}
        currently = self._saat_mode.get(mode_key, getattr(item.usage, "interval_mode", False))
        self._set_saat_mode(item, s, mode_key, not currently)

    def _set_saat_mode(self, item: "LabelItem", s: "ReceteSet", mode_key: tuple, new_state: bool):
        """A (False) veya B (True) tipini seçer, etiketi yeniler."""
        import copy
        if not hasattr(self, "_saat_mode"):
            self._saat_mode = {}
        self._saat_mode[mode_key] = new_state

        ul = copy.deepcopy(item.usage)
        ul.interval_mode = new_state
        if new_state:
            ul.kullanim_zamani = []
            ul.zaman_satirlari = []
        self._apply_usage_change(item, ul)
        self._render_set(s)

    def _apply_timing_zaman(self, item: "LabelItem", s: "ReceteSet", zaman_key: str):
        """S/Ö/A/G butonuna basıldığında günde-1 ilaça zaman belirler ve etiketi yeniler."""
        import copy
        ul = copy.deepcopy(item.usage)
        ul.interval_mode = False
        cur = {(z or "").strip().lower() for z in (ul.kullanim_zamani or [])}
        if zaman_key in cur:
            cur.discard(zaman_key)
        else:
            cur = {zaman_key}
        ul.kullanim_zamani = list(cur)
        ul.zaman_satirlari = []
        self._apply_usage_change(item, ul)
        self._render_set(s)

    def _apply_usage_change(self, item: "LabelItem", ul):
        """UsageLabel değişikliğini etikete yansıtır: görseli üretip p1'e kaydeder."""
        from ..label_render import render_usage_label
        if item.render_ctx is None:
            return
        try:
            img = render_usage_label(label=ul, **item.render_ctx)
            img.save(item.p1)
        except Exception:
            log.exception("_apply_usage_change render hatası")
            return
        item.usage.interval_mode = ul.interval_mode
        item.usage.kullanim_zamani = ul.kullanim_zamani
        item.usage.zaman_satirlari = ul.zaman_satirlari

    # ==================================================================
    # Doz / kullanım zamanı canlı düzenleyici (kullanım etiketi p1)
    # ==================================================================
    def _open_dose_editor(self, item: LabelItem, s: ReceteSet, anchor=None):
        if item.usage is None or item.render_ctx is None:
            messagebox.showinfo("Düzenle", "Bu etiket için doz düzenleme yok "
                                "(cihaz/kılavuz etiketi).")
            return
        LabelDoseEditor(self, item, on_applied=lambda: self._render_set(s),
                        anchor=anchor)

    # --------------------------------------------------------------
    # Büyük, göze çarpan YAZDIR/ATLA anahtarı (iki segmentli switch)
    # --------------------------------------------------------------
    def _make_print_toggle(self, parent, var: tk.StringVar, stage: str,
                           on_choice, *, enabled: bool = True):
        """Tıklanabilir iki segmentli anahtar: [ ✓ YAZDIR | ✕ ATLA ].

        Seçili segment parlak renkli (yeşil/kırmızı), diğeri soluk. var değeri
        'skip' ise ATLA, değilse stage ('early'/'final') seçilidir.
        """
        ON_GREEN, OFF_GREEN = "#16a34a", "#1f3a2c"
        ON_RED,   OFF_RED   = "#dc2626", "#3a2030"
        DIM = "#9aa3bf"

        wrap = tk.Frame(parent, background="#0f1830", highlightthickness=1,
                        highlightbackground="#3a4a78")
        wrap.pack(side="left")
        seg_print = tk.Label(wrap, text="✓ YAZDIR", font=("Segoe UI", 8, "bold"),
                             padx=6, pady=2, cursor="hand2")
        seg_print.pack(side="left")
        seg_skip = tk.Label(wrap, text="✕ ATLA", font=("Segoe UI", 8, "bold"),
                            padx=6, pady=2, cursor="hand2")
        seg_skip.pack(side="left")

        def refresh():
            printing = var.get() != "skip"
            seg_print.configure(background=ON_GREEN if printing else OFF_GREEN,
                                foreground="white" if printing else DIM)
            seg_skip.configure(background=ON_RED if not printing else OFF_RED,
                               foreground="white" if not printing else DIM)

        def set_print(_=None):
            if not enabled:
                return
            var.set(stage)
            on_choice()
            refresh()

        def set_skip(_=None):
            var.set("skip")
            on_choice()
            refresh()

        if enabled:
            seg_print.bind("<Button-1>", set_print)
        else:
            seg_print.configure(cursor="arrow")
        seg_skip.bind("<Button-1>", set_skip)
        refresh()
        return wrap

    # ==================================================================
    # Farklar tablosu (Toplevel)
    # ==================================================================
    def _on_show_diffs(self):
        sel = self.auto_tree.selection()
        if not sel:
            messagebox.showinfo("Farklar", "Önce listeden bir reçete seçin.")
            return
        idx = int(sel[0])
        if not (0 <= idx < len(self._recete_sets)):
            return
        s = self._recete_sets[idx]
        if not s.diff_rows and not (s.early and s.final):
            messagebox.showinfo("Farklar", "Henüz hem reçete başı hem reçete sonu yakalanmadı.")
            return
        self._show_diff_table(s)

    def _show_diff_table(self, s: ReceteSet):
        top = tk.Toplevel(self)
        top.title(f"Reçete Farkları — {s.early.recete_no if s.early else s.final.recete_no}")
        top.geometry("1100x520")

        # Üst başlık
        hdr = ttk.Frame(top, padding=10)
        hdr.pack(fill="x")
        built_ref = s.final or s.early
        ttk.Label(hdr, text=f"Hasta: {built_ref.hasta_ad}", font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Label(hdr, text=f"  ·  Reçete: {built_ref.recete_no or '—'}", foreground="#444").pack(side="left")
        ttk.Label(hdr, text=f"  ·  Tarih: {built_ref.recete_tarihi or '—'}", foreground="#444").pack(side="left")

        # Hızlı toplu seçim butonları (per-drug switch yan yana panelde)
        ver = ttk.Frame(top, padding=(10, 0))
        ver.pack(fill="x")
        ttk.Label(ver, text="Toplu seçim:", font=("Segoe UI", 9, "bold")).pack(side="left")
        def _bulk(choice):
            for bk in list(s.chosen_per_drug.keys()):
                s.chosen_per_drug[bk] = choice
            for vk, var in getattr(self, "_chosen_vars", {}).items():
                if vk.startswith(s.key + ":"):
                    var.set(choice)
            self._render_set(s)
        ttk.Button(ver, text="Hepsini Reçete Başı yap",
                   command=lambda: _bulk("early")).pack(side="left", padx=4)
        ttk.Button(ver, text="Hepsini Reçete Sonu yap (varsayılan)",
                   command=lambda: _bulk("final")).pack(side="left", padx=4)

        # Tablo
        wrap = ttk.Frame(top, padding=10)
        wrap.pack(fill="both", expand=True)

        cols = ("before", "after", "status", "detail")
        tv = ttk.Treeview(wrap, columns=cols, show="headings", height=14)
        tv.heading("before", text="Reçete Başı  (önceki hali)")
        tv.heading("after",  text="Reçete Sonu  (sistemin son hali)")
        tv.heading("status", text="Durum")
        tv.heading("detail", text="Açıklama")
        tv.column("before", width=320)
        tv.column("after",  width=320)
        tv.column("status", width=130)
        tv.column("detail", width=240)

        # Renk tag'leri
        tv.tag_configure("same",    background="#f6f6f6", foreground="#666")
        tv.tag_configure("changed", background="#fff4e0", foreground="#7a4d00")
        tv.tag_configure("removed", background="#ffe0e0", foreground="#900")
        tv.tag_configure("added",   background="#e0ffe0", foreground="#063")

        ysb = ttk.Scrollbar(wrap, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=ysb.set)
        tv.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")

        for r in s.diff_rows:
            tv.insert("", "end", values=(r.before_text, r.after_text, r.status_label, r.detail),
                      tags=(r.status,))

        # Alt: özet + kapat
        bot = ttk.Frame(top, padding=10)
        bot.pack(fill="x")
        change_n = sum(1 for r in s.diff_rows if r.status != "same")
        ttk.Label(
            bot,
            text=f"Toplam {len(s.diff_rows)} ilaç · değişiklik: {change_n}",
            foreground="#a00" if change_n else "#070",
        ).pack(side="left")
        ttk.Button(bot, text="Kapat", command=top.destroy).pack(side="right")

    def _refresh_diff_top(self, top: tk.Toplevel, s: ReceteSet):
        pass

    # ==================================================================
    # Yazıcı önizleme — fiziksel etiket nasıl çıkacak
    # ==================================================================
    def _show_label_print_preview(self, item: LabelItem):
        """Tek bir LabelItem için yazıcı çıktı önizlemesini Toplevel'de göster."""
        from .. import printer
        only_basic = self._only_basic()
        paths_to_show = [(t, p) for (t, p, k) in
                         (("Kullanım", item.p1, "A"), ("Hazırlama", item.p2, "B"),
                          ("Uyarı", item.p3, "C"), ("Dikkat", item.p4, "D"))
                         if p and Path(p).exists() and not (only_basic and k != "A")]
        if not paths_to_show:
            messagebox.showinfo("Önizleme", "Bu etiketin görsel dosyaları bulunamadı.")
            return
        self._open_preview_window(
            title=f"🖨 Yazıcı Önizleme — {item.drug_ad}",
            preview_list=[(item.drug_ad, t, p) for t, p in paths_to_show],
        )

    def _on_show_recete_print_preview(self):
        """Seçili reçete için tüm (chosen sürümlü) etiketleri yazıcı önizleme penceresinde göster."""
        sel = self.auto_tree.selection()
        if not sel:
            messagebox.showinfo("Önizleme", "Önce listeden bir reçete seçin.")
            return
        idx = int(sel[0])
        if not (0 <= idx < len(self._recete_sets)):
            return
        s = self._recete_sets[idx]
        items = s.labels_to_print()
        if not items:
            messagebox.showinfo("Önizleme", "Yazdırılacak etiket yok.")
            return
        only_basic = self._only_basic()
        preview_list = []
        for it in items:
            for tag, p, kind in (("Kullanım", it.p1, "A"), ("Hazırlama", it.p2, "B"),
                                 ("Uyarı", it.p3, "C"), ("Dikkat", it.p4, "D")):
                if only_basic and kind != "A":
                    continue
                if p and Path(p).exists():
                    preview_list.append((it.drug_ad, tag, p))
        if not preview_list:
            messagebox.showinfo("Önizleme", "Yazdırılacak etiket dosyası bulunamadı.")
            return
        built_ref = s.final or s.early
        self._open_preview_window(
            title=f"🖨 Yazıcı Önizleme — {built_ref.hasta_ad} · {built_ref.recete_no}",
            preview_list=preview_list,
        )

    def _open_preview_window(self, *, title: str, preview_list: list):
        """Genel önizleme penceresi: her satır = (drug_ad, etiket_turu, path)."""
        from .. import printer

        top = tk.Toplevel(self)
        top.title(title)
        top.geometry("900x720")

        # Yazıcı bilgi şeridi
        info = printer.get_printer_page_info()
        info_bg = "#e0f3e0" if info["ok"] else "#fff0e0"
        info_fg = "#063" if info["ok"] else "#a05500"
        bar = tk.Frame(top, background=info_bg)
        bar.pack(fill="x")
        status_icon = "✓" if info["ok"] else "⚠"
        info_text = (
            f" {status_icon}  Yazıcı: {info['name']}    "
            f"Sayfa: {info['page_w']}×{info['page_h']} px  "
            f"({info['mm_w']}×{info['mm_h']} mm)    "
            f"DPI: {info['dpi_x']}×{info['dpi_y']}"
        )
        tk.Label(bar, text=info_text, background=info_bg, foreground=info_fg,
                 font=("Segoe UI", 9, "bold"), anchor="w").pack(side="left", padx=10, pady=6)
        if not info["ok"]:
            tk.Label(bar, text="(yazıcı bulunamadı — varsayılan 60×40 mm @ 203 DPI ile önizleme)",
                     background=info_bg, foreground="#a05500",
                     font=("Segoe UI", 8, "italic")).pack(side="left", padx=4)

        # Aralık ölçek seçimi
        scale_bar = ttk.Frame(top, padding=(10, 4))
        scale_bar.pack(fill="x")
        ttk.Label(scale_bar, text="Görsel ölçek:").pack(side="left")
        scale_var = tk.IntVar(value=2)
        for s_label, s_val in (("1x", 1), ("2x", 2), ("3x", 3)):
            ttk.Radiobutton(scale_bar, text=s_label, variable=scale_var, value=s_val,
                            command=lambda: _redraw()).pack(side="left", padx=2)
        ttk.Label(scale_bar, text="  (yazıcıya gönderilen fiziksel boyut beyaz kağıt simülasyonudur)",
                  foreground="#555", font=("Segoe UI", 8, "italic")).pack(side="left", padx=8)

        # Scroll'lu canvas
        canvas_wrap = ttk.Frame(top)
        canvas_wrap.pack(fill="both", expand=True, padx=8, pady=8)
        pv_canvas = tk.Canvas(canvas_wrap, background="#bbb", highlightthickness=0)
        ysb = ttk.Scrollbar(canvas_wrap, orient="vertical", command=pv_canvas.yview)
        pv_canvas.configure(yscrollcommand=ysb.set)
        pv_canvas.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        inner = tk.Frame(pv_canvas, background="#bbb")
        pv_canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: pv_canvas.configure(scrollregion=pv_canvas.bbox("all")))
        # Mouse wheel
        pv_canvas.bind("<MouseWheel>",
                       lambda e: pv_canvas.yview_scroll(int(-e.delta/120), "units"))

        thumb_refs: list[ImageTk.PhotoImage] = []

        def _redraw():
            for ch in inner.winfo_children():
                ch.destroy()
            thumb_refs.clear()
            sc = scale_var.get()
            for i, (drug_ad, tag, path) in enumerate(preview_list, start=1):
                try:
                    preview_img, _ = printer.render_print_preview(path)
                except Exception as e:
                    tk.Label(inner, text=f"Hata: {e}", foreground="red",
                             background=COLORS["bg_main"]).pack(pady=6)
                    continue
                pw, ph = preview_img.size
                # Görüntülenecek boyut
                show_img = preview_img.resize((pw * sc, ph * sc), Image.NEAREST)
                photo = ImageTk.PhotoImage(show_img)
                thumb_refs.append(photo)

                # Etiket kartı — koyu çerçeve
                outer = tk.Frame(inner, background=COLORS["bg_card"], padx=3, pady=3)
                outer.pack(pady=14, padx=20)
                card = tk.Frame(outer, background=COLORS["bg_strip"])
                card.pack()

                # Başlık şeridi — koyu zemin sarı yazı
                hdr = tk.Frame(card, background=COLORS["bg_strip"])
                hdr.pack(fill="x")
                tk.Label(hdr, text=f"  {i}. {drug_ad}  ·  {tag}",
                         background=COLORS["bg_strip"], foreground=COLORS["text_yellow"],
                         font=("Segoe UI", 10, "bold"), anchor="w").pack(side="left")
                tk.Label(hdr,
                         text=f" 📏 {info['mm_w']:.0f}×{info['mm_h']:.0f} mm  @ {sc}x  ",
                         background=COLORS["bg_card"], foreground=COLORS["text_dark"],
                         font=("Segoe UI", 8, "bold")).pack(side="right", padx=4, pady=2)

                # Üst ölçü çubuğu (60 mm)
                tk.Label(card, text=f"|←  {info['mm_w']:.0f} mm  →|",
                         background=COLORS["bg_strip"], foreground=COLORS["text_muted"],
                         font=("Segoe UI", 8)).pack(pady=(4, 0))

                # Etiket kağıdı + sağ ölçü çubuğu
                row = tk.Frame(card, background=COLORS["bg_strip"])
                row.pack(padx=4, pady=4)
                tk.Label(row, image=photo, background="white",
                         borderwidth=0).pack(side="left")
                tk.Label(row, text=f"\n↑\n\n{info['mm_h']:.0f}\nmm\n\n↓\n",
                         background=COLORS["bg_strip"], foreground=COLORS["text_muted"],
                         font=("Segoe UI", 8)).pack(side="left", padx=6)

            inner.update_idletasks()
            pv_canvas.configure(scrollregion=pv_canvas.bbox("all"))

        _redraw()

        # Alt: kapat
        foot = ttk.Frame(top, padding=8)
        foot.pack(fill="x")
        ttk.Button(foot, text="Kapat", command=top.destroy).pack(side="right")

    def _clear_captured(self):
        if not self._recete_sets:
            return
        if not messagebox.askyesno(
            "Onay",
            f"{len(self._recete_sets)} yakalanan reçeteyi listeden temizle?",
        ):
            return
        self._recete_sets.clear()
        self._key_to_idx.clear()
        self._erecete_early_caps.clear()
        self._last_paper_hash = ""
        self._last_paper_form = None
        self._last_paper_set_key = None
        self._suppressed_paper_keys.clear()
        for iid in self.auto_tree.get_children():
            self.auto_tree.delete(iid)
        for inner in (self.early_inner, self.final_inner):
            for child in inner.winfo_children():
                child.destroy()
        self._auto_thumb_refs.clear()
        if self._watcher:
            try:
                self._watcher.reset_seen()
            except Exception:
                pass

    def _on_auto_print(self):
        sel = self.auto_tree.selection()
        if not sel:
            messagebox.showinfo("Yazdır", "Önce listeden bir reçete seçin.")
            return
        idx = int(sel[0])
        if not (0 <= idx < len(self._recete_sets)):
            return
        self._print_set(self._recete_sets[idx])

    def _print_last_captured(self):
        """Shift+F12: DAIMA reçete sonu (final/SGK onaylı) etiketlerini basar.
        Reçete başı etiketleri için ayrı kısayol (hotkey_yazici_recete_basi) kullanılır."""
        import threading
        threading.Thread(
            target=lambda: self._resolve_and_print_worker(force_stage="final"),
            daemon=True, name="shift-f12-print",
        ).start()

    def _print_scanned_karekods_hotkey(self):
        """Ctrl+Shift+Ğ: yalnız İTS'de karekodu OKUTULMUŞ ilaçların etiketlerini bas."""
        self.after(0, self._print_scanned_karekods)

    def _print_scanned_karekods(self):
        if not getattr(self, "_karekod_scan_print", False):
            self.status.set("⚠ 'Sadece okutulan karekodları bas' ayarı kapalı "
                            "(AYARLAR → Genel).")
            return
        s = self._get_selected_or_last_set()
        if s is None:
            self.status.set("⚠ Önce listeden bir reçete seçin.")
            return
        scanned = {bc for bc, n in getattr(s, "_karekod_counts", {}).items() if n >= 1}
        if not scanned:
            self.status.set("⚠ Bu reçetede okutulmuş karekod yok — hiçbir etiket basılmadı.")
            return
        self._print_set(s, only_barcodes=scanned)

    def _print_unpaid_hotkey(self):
        """Ctrl+Shift+Ü: reçete başında olup SGK'nın ödemediği (reçete sonunda
        olmayan, geri_odeme_yok) ilaçların etiketlerini bas."""
        self.after(0, self._print_unpaid_early)

    def _print_unpaid_early(self):
        s = self._get_selected_or_last_set()
        if s is None:
            self.status.set("⚠ Önce listeden bir reçete seçin.")
            return
        if s.early is None:
            self.status.set("⚠ Bu reçetenin reçete başı (taslak) verisi yok.")
            return
        final_bks = {it.barkod for it in s.final.items} if s.final else set()
        # Reçete başında olup SGK'nın ödemediği (geri_odeme_yok) ve reçete sonunda
        # olmayan ilaçlar.
        unpaid = {it.barkod for it in s.early.items
                  if getattr(it, "geri_odeme_yok", False) and it.barkod not in final_bks}
        if not unpaid:
            self.status.set("⚠ SGK'nın ödemediği (geri ödeme yok) ilaç bulunamadı.")
            return
        self._print_set(s, force_stage="early", only_barcodes=unpaid)

    def _resolve_and_print_worker(self, force_stage=None, force_only_basic=False):
        """Ortak baskı worker'ı.

        1. Medula ön plandaysa: ekrandaki reçeteyi yakala → GUI'de seç → yazdır.
           Reçete daha önce işlenmişse direkt seç; işlenmemişse canlı etiket üret.
        2. Medula ön planda değilse: GUI'de seçili/son reçeteyi yazdır.

        force_stage : "early" | "final" | None  → _print_set'e iletilir
        force_only_basic : True → yalnızca A etiketleri gönderilir
        """
        import comtypes
        comtypes.CoInitialize()
        try:
            import ctypes as _ct
            from ..medula_capture import find_medula_windows, capture_one
            from ..medula_parser import parse_html

            fg_hwnd = _ct.windll.user32.GetForegroundWindow()
            wins    = find_medula_windows()
            fg_win  = next((w for w in wins if w.hwnd == fg_hwnd), None)

            if fg_win and fg_win.ie_servers:
                cap_info = capture_one(fg_win.ie_servers[0])
                if "error" not in cap_info:
                    html = cap_info.get("html", "") or ""
                    url  = cap_info.get("url",  "") or ""
                    if html:
                        prescription = parse_html(html, document_url=url)
                        rno = prescription.recete_no.strip()

                        pk = prescription.page_kind
                        _PRINTABLE = ("e_recete_detay", "e_recete_basarili",
                                      "kagit_recete_basarili")

                        # 1) Yazdırılabilir sayfa + daha önce işlenmiş reçete → seç + bas.
                        #    İTS/ödeme/diğer sayfalar bu hızlı yola GİRMEZ; işlenmekte
                        #    olan reçete aşağıda (5) toleranslı çözülür.
                        idx = self._key_to_idx.get(rno) if rno else None
                        if idx is not None and pk in _PRINTABLE:
                            _s = self._recete_sets[idx]
                            _is_final_page = pk in (
                                "e_recete_basarili", "kagit_recete_basarili"
                            )
                            # Reçete sonu sayfasındaysak ama set'te final henüz yoksa
                            # (muadil değişikliği sonrası early'de orijinal ilaç kalır),
                            # doğrudan basmak yerine canlı sayfadan final üret ve sonra bas.
                            if _is_final_page and _s.final is None:
                                pass  # aşağıdaki "canlı etiket üret" bloğuna düş
                            else:
                                def _select_and_print(i=idx, fs=force_stage, fb=force_only_basic):
                                    s = self._recete_sets[i]
                                    self.auto_tree.selection_set(str(i))
                                    self.auto_tree.see(str(i))
                                    self._render_set(s)
                                    self._print_set(s, force_stage=fs, force_only_basic=fb)
                                self.after(0, _select_and_print)
                                return

                        # 2) force_stage="final" iken reçete başı sayfasında etiket üretme —
                        #    kullanıcı henüz reçeteyi kaydetmemiştir.
                        if force_stage == "final" and pk == "e_recete_detay":
                            self.after(0, lambda: self.status.set(
                                "⚠ Reçete sonu (SGK onayı) henüz gelmedi — "
                                "önce Medula'da reçeteyi kaydedin."
                            ))
                            return

                        # 3) Henüz işlenmemiş ama yazdırılabilir sayfa → canlı etiket üret
                        if pk in _PRINTABLE:
                            try:
                                built = build_labels_for_capture(
                                    prescription,
                                    preview_dir=self._preview_dir,
                                    eczane_adi=self.eczane_adi,
                                    eczane_telefon=self.eczane_tel,
                                )
                                stage = "early" if pk == "e_recete_detay" else "final"
                                key   = rno or f"live_{id(prescription)}"

                                def _post(p=prescription, b=built, sg=stage, k=key,
                                          fs=force_stage, fb=force_only_basic):
                                    self._upsert_set(
                                        key=k, source_kind="medula",
                                        built=b, stage=sg,
                                        cap=p, paper=None, diff_rows=[],
                                    )
                                    # _upsert_set zaten selection_set + _render_set yapıyor
                                    new_idx = self._key_to_idx.get(k)
                                    if new_idx is not None:
                                        self._print_set(
                                            self._recete_sets[new_idx],
                                            force_stage=fs, force_only_basic=fb,
                                        )

                                self.after(0, _post)
                                return
                            except Exception as e:
                                log.warning("Canlı etiket build hatası: %s", e)

                        # 4) Reçete YAZMA (taslak) ekranı: kullanıcı hâlâ düzenliyor;
                        #    eski reçeteyi basıp yanıltma — yalnız uyar.
                        if pk == "recete_yazma":
                            self.after(0, lambda: self.status.set(
                                "⚠ Reçete taslak ekranında — önce Medula'da reçeteyi kaydedin."
                            ))
                            return

                        # 5) İTS/Karekod, ödeme onayı, sorgu ve diğer TÜM tanınmayan
                        #    sayfalar: barkodlu tam ilaç verisi içermezler ama DAİMA
                        #    işlenmekte olan reçeteye aittir. Reçeteyi reçete no → hasta
                        #    adı → seçili/son sırasıyla çöz, eldeki sürümü bas —
                        #    kullanıcı hangi ekranda olursa olsun etiketler çıksın.
                        match_idx = idx
                        if match_idx is None:
                            pname = (prescription.hasta_ad or "").strip().lower()
                            if pname:
                                for i, st in enumerate(self._recete_sets):
                                    scap = st.cap_final or st.cap_early
                                    if scap and (scap.hasta_ad or "").strip().lower() == pname:
                                        match_idx = i
                                        break
                        self.after(0, lambda i=match_idx, fs=force_stage, fb=force_only_basic:
                                   self._print_resolved_set(i, force_stage=fs, force_only_basic=fb))
                        return
        except Exception as e:
            log.warning("Medula capture hatası: %s", e)
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

        # Fallback: GUI'deki seçili/son reçete
        self.after(0, lambda fs=force_stage, fb=force_only_basic:
                   self._print_selected_or_last(force_stage=fs, force_only_basic=fb))

    @staticmethod
    def _degrade_stage(s: "ReceteSet", force_stage):
        """İstenen sürüm (early/final) yoksa eldeki sürüme düş.

        İTS/ödeme gibi ekranlarda kullanıcı kaydedip hemen geçtiyse yalnız bir
        sürüm (early veya final) yakalanmış olabilir. İstenen yoksa eldeki basılır
        ki kullanıcı etiketsiz kalmasın. İkisi de yoksa None döner.
        """
        eff = force_stage
        if eff == "final" and s.final is None:
            eff = "early" if s.early is not None else None
        elif eff == "early" and s.early is None:
            eff = "final" if s.final is not None else None
        return eff

    def _print_resolved_set(self, i, force_stage=None, force_only_basic=False):
        """İndeksi verilen seti seç + render + (toleranslı sürümle) bas.

        i geçersizse seçili/son reçeteye düşer. İTS/ödeme/diğer tanınmayan Medula
        sayfalarından çağrılır — istenen sürüm yoksa eldeki sürüm basılır.
        """
        if i is None or not (0 <= i < len(self._recete_sets)):
            self._print_selected_or_last(force_stage=force_stage,
                                         force_only_basic=force_only_basic)
            return
        s = self._recete_sets[i]
        self.auto_tree.selection_set(str(i))
        self.auto_tree.see(str(i))
        self._render_set(s)
        eff = self._degrade_stage(s, force_stage)
        self._print_set(s, force_stage=eff, force_only_basic=force_only_basic)

    def _print_selected_or_last(self, force_stage=None, force_only_basic=False):
        """auto_tree'de seçili reçeteyi, yoksa son yakalanmış reçeteyi yazdır."""
        s = self._get_selected_or_last_set()
        if s is None:
            self.status.set("⚠ Henüz yakalanan reçete yok.")
            return
        # İstenen sürüm yoksa eldeki sürüme düş (etiketsiz kalma); ikisi de yoksa uyar.
        eff = self._degrade_stage(s, force_stage)
        if force_stage and eff is None:
            self.status.set("⚠ Bu reçete için yazdırılacak etiket yok.")
            return
        self._print_set(s, force_stage=eff, force_only_basic=force_only_basic)

    def _only_basic(self) -> bool:
        """'Sadece temel etiket' kutusu işaretli mi? (A dışı etiketler basılmaz)"""
        v = getattr(self, "_only_basic_var", None)
        return bool(v and v.get())

    def _only_basic_display(self) -> bool:
        """'Ekranda sadece temel' kutusu işaretli mi? (A dışı etiketler ekranda gösterilmez)"""
        v = getattr(self, "_only_basic_display_var", None)
        return bool(v and v.get())

    def _persist_only_basic_prefs(self):
        """İki 'sadece temel' kutusunun güncel durumunu DB'ye yaz — bir sonraki
        açılışta da geçerli kalsın (kullanıcı tekrar değiştirene kadar)."""
        from ..db import save_setting
        try:
            with get_connection() as conn:
                save_setting(conn, "only_basic_print",
                             "1" if self._only_basic_var.get() else "0")
                save_setting(conn, "only_basic_display",
                             "1" if self._only_basic_display_var.get() else "0")
        except Exception:
            pass

    def _on_only_basic_display_changed(self):
        """'Ekranda sadece temel' toggle'ı: tercihi kalıcı yap + reçeteyi yeniden render et."""
        self._persist_only_basic_prefs()
        s = self._get_selected_or_last_set()
        if s is not None:
            self._render_set(s)

    def _print_set(self, s: ReceteSet, *, force_stage: str | None = None,
                   force_only_basic: bool = False, only_barcodes: set | None = None):
        """Per-drug seçime göre etiketleri AĞ yazıcısına gönder (onay sormadan).

        force_stage: "early" veya "final" → chosen_per_drug'ı yoksayıp o sürümün
            BuiltRecete'sindeki tüm ilaçları kullanır. None = normal chosen_per_drug mantığı.
        force_only_basic: True → checkbox değerine bakılmaksızın yalnızca A etiketleri gönderilir.
        only_barcodes: verilirse YALNIZ bu barkodlardaki ilaçların etiketleri basılır
            (İTS karekod okutma filtresi); diğerleri atlanır.
        """
        if force_stage is not None:
            built = s.early if force_stage == "early" else s.final
            if built is None:
                self.status.set(f"⚠ Bu reçete için '{force_stage}' etiket yok.")
                return
            items = built.items
        else:
            items = s.labels_to_print()
        if only_barcodes is not None:
            items = [it for it in items if it.barkod in only_barcodes]
        if not items:
            self.status.set("⚠ Bu reçete için yazdırılacak etiket yok.")
            return
        try:
            from .. import printer
        except ImportError:
            messagebox.showerror("Yazıcı", "Printer modülü yüklenemedi.")
            return

        cfg = self._active_printer_cfg()
        addr = printer.cfg_label(cfg)
        self.status.set(f"🖨 Yazıcıya gönderiliyor: {addr} …")
        self.update_idletasks()
        only_basic = force_only_basic or self._only_basic()
        _lmm = (getattr(self, "label_w_mm", 60.0), getattr(self, "label_h_mm", 40.0))
        _gmm = getattr(self, "label_gap_mm", 2.0)
        _dpi = getattr(self, "printer_dpi", 203)
        sent = 0
        skipped = 0
        for it in items:
            pk = s.print_kinds.get(it.barkod, {})
            for p, kind in ((it.p1, "A"), (it.p2, "B"), (it.p3, "C"), (it.p4, "D")):
                if not (p and Path(p).exists()):
                    continue
                # "Sadece temel etiket" işaretliyse A dışındaki etiketler basılmaz.
                if only_basic and kind != "A":
                    continue
                # Etiket-bazı baskı seçimi: kullanıcı kutusu (varsa) yoksa
                # hesaplanan/kalıcı varsayılan. İşaretsizse bu etiket atlanır.
                checked = pk.get(kind)
                if checked is None:
                    checked = self._initial_label_checked(
                        it.drug_id, kind,
                        (it.label_default_print or {}).get(kind, True))
                if not checked:
                    skipped += 1
                    continue
                try:
                    printer.send_image(p, cfg, label_mm=_lmm, gap_mm=_gmm, dpi=_dpi)
                    sent += 1
                except Exception as e:
                    messagebox.showerror(
                        "Yazıcı hatası",
                        f"{it.drug_ad}\n\nYazıcı: {addr}\n{e}\n\n"
                        "Yazıcı açık ve ağda mı? IP doğru mu?",
                    )
                    self.status.set(f"⚠ Yazdırma kesildi: {it.drug_ad} ({e})")
                    return
        extra = f" · {skipped} etiket işaretsiz (atlandı)" if skipped else ""
        self.status.set(f"🖨 {sent} etiket {addr} yazıcısına gönderildi.{extra}")

        # Hasta bilgi etiketi: kutu işaretliyse ilaç etiketlerinden sonra basılır.
        # Telefon/ödeme okuması (UIA) ~1-2 sn sürebildiğinden arka planda yapılır.
        if self._hasta_enabled(s):
            cap = s.cap_final or s.cap_early
            if cap is not None:
                _sd = self._hasta_show_debt_for(s)
                threading.Thread(
                    target=lambda c=cap, sd=_sd, st=s: self._print_patient_label(c, show_debt=sd, s=st),
                    daemon=True, name="hasta-etiketi-set",
                ).start()

    def _hasta_enabled(self, s: ReceteSet) -> bool:
        """Set'in hasta etiketi kutusu işaretli mi? (None → ayardaki varsayılan)."""
        if s.print_hasta is None:
            return bool(getattr(self, "_hasta_label_default", False))
        return bool(s.print_hasta)

# ---------------------------------------------------------------------------
# Doz / kullanım zamanı canlı düzenleyici (kullanım etiketi p1)
# ---------------------------------------------------------------------------
class LabelDoseEditor(tk.Toplevel):
    """Kullanım etiketi (p1) için doz/periyot/kullanım-zamanı canlı düzenleyici.

    - Günlük kez (N):  − / +   (NxM'deki N)
    - Doz adedi (M):   − / +   (NxM'deki M; 0,5 adımlı)
    - Periyot:         Günde | Haftada | Ayda   ("Haftada 2x1" için)
    - Zaman:           SABAH / ÖĞLEN / AKŞAM / GECE (çoklu; günde-1'de saat ata)
    Değişiklikler canlı önizlenir; 'Uygula' p1 görselini yeniden üretir.
    """
    _TIMES = [("sabah", "SABAH"), ("öğlen", "ÖĞLEN"),
              ("akşam", "AKŞAM"), ("gece", "GECE")]
    _PERIODS = [("Günde", "GÜNDE"), ("Haftada", "HAFTADA"), ("Ayda", "AYDA")]
    # Etikete basılacak ters-renkli öğün rozeti seçenekleri (ilk = rozet yok).
    _NO_BADGE = "(yok)"
    _MEAL_BADGES = [_NO_BADGE, "AÇ", "TOK", "AÇ TOK FARKETMEZ",
                    "YEMEKTEN ÖNCE", "YEMEKTEN SONRA", "YEMEKLE", "YEMEK BAŞINDA"]

    def __init__(self, parent, item: LabelItem, on_applied=None, anchor=None):
        super().__init__(parent)
        import copy
        self.title(f"Doz / Zaman — {item.drug_ad}")
        self.configure(background=COLORS["bg_main"])
        self.item = item
        self.on_applied = on_applied
        self._anchor = anchor                 # üzerine açılacağı kart/etiket widget'ı
        self.ul = copy.deepcopy(item.usage)   # düzenleme kopyası

        self.kez = tk.IntVar(value=int(self.ul.gunluk_kez or 1))
        try:
            adet0 = float(item.doz_adet) if item.doz_adet is not None else 1.0
        except Exception:
            adet0 = 1.0
        self.adet = tk.DoubleVar(value=adet0 or 1.0)
        self.periyot = tk.StringVar(value=(self.ul.periyot or "Günde") or "Günde")
        cur = {(z or "").strip().lower() for z in (self.ul.kullanim_zamani or [])}
        self.time_vars = {k: tk.BooleanVar(value=(k in cur)) for k, _ in self._TIMES}
        # Öğün rozeti: etikette O AN görünen efektif rozeti seç (meal_badge
        # boşsa render yemek alanından türetir; combobox bununla tutarlı olsun).
        from ..label_render import _derive_meal
        _eff = (_derive_meal(self.ul) or "").strip().upper()
        self.meal_badge = tk.StringVar(
            value=_eff if _eff in self._MEAL_BADGES else self._NO_BADGE)

        self._build_ui()
        self._refresh_preview()
        self.transient(parent)
        self._place_over_anchor()
        self.grab_set()

    def _place_over_anchor(self):
        """Pencereyi tıklanan etiket kartının üzerine konumla (ekran dışına taşmasın)."""
        a = self._anchor
        try:
            if a is not None and a.winfo_exists():
                self.update_idletasks()
                x = a.winfo_rootx()
                y = a.winfo_rooty()
                sw = self.winfo_screenwidth()
                sh = self.winfo_screenheight()
                w = self.winfo_width() or 640
                h = self.winfo_height() or 360
                # Kart sağa/aşağı taşarsa ekran içine çek
                x = max(0, min(x, sw - w - 8))
                y = max(0, min(y, sh - h - 8))
                self.geometry(f"+{x}+{y}")
        except Exception:
            pass

    def _build_ui(self):
        C = COLORS
        body = tk.Frame(self, background=C["bg_main"])
        body.pack(side="left", fill="both", expand=True, padx=12, pady=12)

        # Günlük kez (NxM'deki N) 1..6; Doz adedi (M) 0,5..300 (insülinde 30/40/100
        # ünite olabildiği için üst sınır geniş). İkisi de elle yazılabilir.
        self._stepper(body, "Günlük kez (N):", self.kez, 1, 6, 1)
        self._stepper(body, "Doz adedi (M):", self.adet, 0.5, 300, 0.5)

        prow = tk.Frame(body, background=C["bg_main"])
        prow.pack(fill="x", pady=6)
        tk.Label(prow, text="Periyot:", width=16, anchor="w", background=C["bg_main"],
                 foreground=C["text_light"]).pack(side="left")
        for val, lbl in self._PERIODS:
            tk.Radiobutton(prow, text=lbl, value=val, variable=self.periyot,
                           command=self._refresh_preview, background=C["bg_main"],
                           foreground=C["text_light"], selectcolor=C["bg_strip"],
                           activebackground=C["bg_main"], activeforeground=C["text_light"]
                           ).pack(side="left", padx=2)

        zrow = tk.Frame(body, background=C["bg_main"])
        zrow.pack(fill="x", pady=6)
        tk.Label(zrow, text="Kullanım zamanı:", width=16, anchor="w",
                 background=C["bg_main"], foreground=C["text_light"]).pack(side="left")
        for key, lbl in self._TIMES:
            tk.Checkbutton(zrow, text=lbl, variable=self.time_vars[key],
                           command=self._refresh_preview, background=C["bg_main"],
                           foreground=C["text_light"], selectcolor=C["bg_strip"],
                           activebackground=C["bg_main"], activeforeground=C["text_light"]
                           ).pack(side="left", padx=2)

        # Öğün rozeti — radio grubu (biri seçilince diğerleri pasif).
        # AÇ / TOK / AÇ TOK FARKETMEZ / YEMEKTEN ÖNCE … + (yok).
        mrow = tk.Frame(body, background=C["bg_main"])
        mrow.pack(fill="x", pady=6)
        tk.Label(mrow, text="Öğün rozeti:", width=16, anchor="nw",
                 background=C["bg_main"], foreground=C["text_light"]).pack(
                     side="left", anchor="n")
        mgrid = tk.Frame(mrow, background=C["bg_main"])
        mgrid.pack(side="left")
        for i, val in enumerate(self._MEAL_BADGES):
            r, c = divmod(i, 2)   # 2 sütunlu ızgara
            tk.Radiobutton(
                mgrid, text=val, value=val, variable=self.meal_badge,
                command=self._refresh_preview, background=C["bg_main"],
                foreground=C["text_light"], selectcolor=C["bg_strip"],
                activebackground=C["bg_main"], activeforeground=C["text_light"],
            ).grid(row=r, column=c, sticky="w", padx=2, pady=1)

        tk.Label(body, justify="left", background=C["bg_main"], foreground=C["text_muted"],
                 font=("Segoe UI", 8),
                 text=("Zaman seçilirse ızgara o saatlere dizilir; boşsa günlük kez\n"
                       "sayısından otomatik SABAH/ÖĞLEN/AKŞAM üretilir. Öğün rozeti\n"
                       "seçilirse etikete ters-renkli olarak basılır.")
                 ).pack(anchor="w", pady=(2, 8))

        btns = tk.Frame(body, background=C["bg_main"])
        btns.pack(fill="x", pady=(8, 0))
        ttk.Button(btns, text="✓ Uygula", style="Yellow.TButton",
                   command=self._apply).pack(side="left")
        ttk.Button(btns, text="İptal", command=self.destroy).pack(side="left", padx=6)

        pv = tk.Frame(self, background=C["bg_panel"])
        pv.pack(side="right", fill="both", padx=(0, 12), pady=12)
        tk.Label(pv, text="Önizleme", background=C["bg_panel"],
                 foreground=C["text_yellow"], font=("Segoe UI", 9, "bold")).pack(pady=(8, 2))
        self._preview_label = tk.Label(pv, background="#FFE680")
        self._preview_label.pack(padx=8, pady=8)

    def _stepper(self, parent, text, var, lo, hi, step):
        C = COLORS
        row = tk.Frame(parent, background=C["bg_main"])
        row.pack(fill="x", pady=6)
        tk.Label(row, text=text, width=16, anchor="w", background=C["bg_main"],
                 foreground=C["text_light"]).pack(side="left")

        def _bump(delta):
            # Mevcut değerden adımla; başlangıç değeri üst sınırın ÜSTÜNDEyse
            # (örn. insülin 30) aşağı KIRPMA — sadece [lo,hi] dışına ittirmeyi engelle.
            try:
                cur = float(var.get())
            except Exception:
                cur = lo
            v = cur + delta
            v = max(lo, min(hi, v))
            var.set(int(round(v)) if isinstance(var, tk.IntVar) else round(v, 2))
            self._refresh_preview()

        ttk.Button(row, text="−", width=3, command=lambda: _bump(-step)).pack(side="left")
        # Elle de yazılabilsin diye Spinbox (değer kutusuna 30 yazılabilir)
        sb = tk.Spinbox(row, from_=lo, to=hi, increment=step, textvariable=var,
                        width=6, justify="center", font=("Segoe UI", 11, "bold"),
                        command=self._refresh_preview)
        sb.pack(side="left", padx=4)
        sb.bind("<KeyRelease>", lambda e: self._refresh_preview())
        sb.bind("<Return>", lambda e: self._refresh_preview())
        ttk.Button(row, text="+", width=3, command=lambda: _bump(step)).pack(side="left")

    @staticmethod
    def _safe_num(var, default):
        try:
            return float(var.get())
        except Exception:
            return default

    def _apply_to_label(self, ul):
        from ..drug_guess import format_dose_amount
        birim = self.item.doz_birim or ""
        kez = int(round(max(1, min(6, self._safe_num(self.kez, 1)))))
        adet = max(0.5, min(300, self._safe_num(self.adet, 1)))
        ul.gunluk_kez = kez
        ul.periyot = self.periyot.get() or "Günde"
        adet_s = format_dose_amount(adet)
        ul.doz = f"{adet_s} {birim}".strip() if birim else adet_s
        ul.kullanim_zamani = [k for k, _ in self._TIMES if self.time_vars[k].get()]
        ul.zaman_satirlari = []   # editör derivation'ı yönetsin
        ul.interval_mode = False  # editörden uygulama saat modunu sıfırlar
        # Öğün rozeti: "(yok)" → rozeti TAMAMEN kaldır (meal_badge + yemek
        # fallback'i de temizle). Aksi halde seçilen metni bas (render uppercase).
        _mb = (self.meal_badge.get() or "").strip()
        if _mb == self._NO_BADGE:
            ul.meal_badge = ""
            ul.yemek = ""
        else:
            ul.meal_badge = _mb

    def _render_image(self):
        from ..label_render import render_usage_label
        self._apply_to_label(self.ul)
        return render_usage_label(label=self.ul, **self.item.render_ctx)

    def _refresh_preview(self):
        try:
            img = self._render_image()
            self._pv_photo = ImageTk.PhotoImage(img.resize((300, 200), Image.LANCZOS))
            self._preview_label.configure(image=self._pv_photo, text="")
        except Exception as e:
            self._preview_label.configure(image="", text=f"(önizleme hata)\n{e}")

    def _apply(self):
        try:
            img = self._render_image()
            img.save(self.item.p1)
            self._apply_to_label(self.item.usage)   # kalıcı: asıl usage'a yansıt
            self.item.doz_adet = max(0.5, min(300, self._safe_num(self.adet, 1)))
        except Exception as e:
            messagebox.showerror("Hata", f"Etiket güncellenemedi:\n{e}")
            return
        if self.on_applied:
            try:
                self.on_applied()
            except Exception:
                log.exception("Doz düzenleyici on_applied hatası")
        self.destroy()


class LabelTextEditor(tk.Toplevel):
    """Etiket METNİNİ DB'de kalıcı düzenler (drug_label_prefs.custom_text).

    Her SATIR bir madde/adım olur. Canlı önizleme KALICI yazmadan (rollback ile)
    gösterilir. 'Kaydet' custom_text'i kalıcı yazar; 'Otomatiğe dön' custom_text'i
    siler (üretilen metne geri döner). 'İptal' hiçbir şey yazmaz.
    """
    def __init__(self, parent, *, drug_id: int, kind: str, title_text: str,
                 initial_text: str, hasta_adi: str = "", on_save=None, anchor=None,
                 temporary: bool = False):
        super().__init__(parent)
        self.drug_id = drug_id
        self.kind = kind
        self.title_text = title_text
        self.hasta_adi = hasta_adi
        self.on_save = on_save
        self._anchor = anchor
        self.temporary = temporary
        mod = "geçici" if temporary else "kalıcı"
        self.title(f"Etiket metni ({mod}) — {title_text}")
        self.configure(background=COLORS["bg_main"])
        self._build_ui(initial_text)
        self._refresh_preview()
        self.transient(parent)
        self._place_over_anchor()
        self.grab_set()

    def _build_ui(self, initial_text: str):
        C = COLORS
        body = tk.Frame(self, background=C["bg_main"])
        body.pack(side="left", fill="both", expand=True, padx=12, pady=12)

        tk.Label(body, text=f"« {self.title_text} » etiketi",
                 background=C["bg_main"], foreground=C["text_yellow"],
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(body, justify="left", background=C["bg_main"],
                 foreground=C["text_muted"], font=("Segoe UI", 8),
                 text=("Her SATIR bir madde/adım olur. En çok 4-5 kısa satır\n"
                       "etikete sığar. Boş bırakıp kaydederseniz otomatik metne döner.")
                 ).pack(anchor="w", pady=(2, 6))

        self.txt = tk.Text(body, width=44, height=8, wrap="word",
                           font=("Segoe UI", 10), background="#101a30",
                           foreground="#e6ecff", insertbackground="#e6ecff",
                           relief="flat", highlightthickness=1,
                           highlightbackground="#3a4a78")
        self.txt.pack(fill="both", expand=True)
        self.txt.insert("1.0", initial_text or "")
        self.txt.bind("<KeyRelease>", lambda e: self._refresh_preview())

        btns = tk.Frame(body, background=C["bg_main"])
        btns.pack(fill="x", pady=(10, 0))
        save_lbl = "✓ Uygula (geçici)" if self.temporary else "✓ Kaydet (kalıcı)"
        ttk.Button(btns, text=save_lbl, style="Yellow.TButton",
                   command=self._save).pack(side="left")
        ttk.Button(btns, text="↺ Otomatiğe dön",
                   command=self._reset).pack(side="left", padx=6)
        ttk.Button(btns, text="İptal", command=self.destroy).pack(side="left")

        pv = tk.Frame(self, background=C["bg_panel"])
        pv.pack(side="right", fill="both", padx=(0, 12), pady=12)
        tk.Label(pv, text="Önizleme (kaydedilmeden)", background=C["bg_panel"],
                 foreground=C["text_yellow"], font=("Segoe UI", 9, "bold")
                 ).pack(pady=(8, 2))
        self._preview_label = tk.Label(pv, background="#FFE680")
        self._preview_label.pack(padx=8, pady=8)

    def _place_over_anchor(self):
        a = self._anchor
        try:
            if a is not None and a.winfo_exists():
                self.update_idletasks()
                x = max(0, min(a.winfo_rootx(),
                               self.winfo_screenwidth() - (self.winfo_width() or 720) - 8))
                y = max(0, min(a.winfo_rooty(),
                               self.winfo_screenheight() - (self.winfo_height() or 380) - 8))
                self.geometry(f"+{x}+{y}")
        except Exception:
            pass

    def _current_text(self) -> str:
        return self.txt.get("1.0", "end").strip()

    def _refresh_preview(self):
        try:
            img = render_label_preview(self.drug_id, self.kind,
                                       self._current_text(), self.hasta_adi)
            if img is None:
                self._preview_label.configure(image="", text="(önizleme yok)")
                return
            self._pv_photo = ImageTk.PhotoImage(img.resize((300, 200), Image.LANCZOS))
            self._preview_label.configure(image=self._pv_photo, text="")
        except Exception as e:
            self._preview_label.configure(image="", text=f"(önizleme hata)\n{e}")

    def _save(self):
        if self.on_save:
            self.on_save(self._current_text())
        self.destroy()

    def _reset(self):
        msg = ("Bu etikette yapılan geçici metin değişikliği kaldırılıp otomatik "
               "üretilen metne dönülecek. Onaylıyor musunuz?" if self.temporary else
               "Bu etiketin özel metni silinip otomatik üretilen metne "
               "dönülecek. Onaylıyor musunuz?")
        if not messagebox.askyesno("Otomatiğe dön", msg):
            return
        if self.on_save:
            self.on_save("")   # boş = otomatik metne dön (kalıcı modda custom_text siler)
        self.destroy()


# ---------------------------------------------------------------------------
# Satır düzenleme dialogu
# ---------------------------------------------------------------------------
class DrugEditorPanel(tk.Frame):
    """Manuel sekmeye gömülü, seçili ilacı CANLI düzenleyen panel.

    Doz (N×M), periyot, kullanım zamanı, öğün rozeti, kategori/talimat/uyarı/not
    alanlarını içerir. Her değişiklik anında bağlı DrugRow'a yazılır; etiket
    önizlemesi ve (on_change ile) sol liste güncellenir. Kaydet butonu YOKTUR —
    düzenleme doğrudan ekranda yapılır.
    """
    # Doz/zaman/öğün seçenekleri (Medula doz editörüyle aynı sözlük).
    _TIMES = [("sabah", "SABAH"), ("öğlen", "ÖĞLEN"),
              ("akşam", "AKŞAM"), ("gece", "GECE")]
    _PERIODS = [("Günde", "GÜNDE"), ("Haftada", "HAFTADA"), ("Ayda", "AYDA")]
    _NO_BADGE = "(yok)"
    _MEAL_BADGES = [_NO_BADGE, "AÇ", "TOK", "AÇ TOK FARKETMEZ",
                    "YEMEKTEN ÖNCE", "YEMEKTEN SONRA", "YEMEKLE", "YEMEK BAŞINDA"]

    def __init__(self, parent, app, on_change=None):
        super().__init__(parent, background=COLORS["bg_main"])
        self.app = app
        self.on_change = on_change
        self.row: Optional[DrugRow] = None
        self._loading = False
        self._preview_after = None
        self._preview_photo = None
        self._cur_pil = None
        self._fit_after = None

        # Tk değişkenleri (varsayılan; set_row ile bağlı satırdan doldurulur)
        self.var_name = tk.StringVar(value="İlaç seçili değil")
        self.var_kategori = tk.StringVar(value="")
        self.var_kez = tk.IntVar(value=1)
        self.var_adet = tk.DoubleVar(value=1.0)
        self.var_birim = tk.StringVar(value="Tane")
        self.var_sure = tk.StringVar(value="7")
        self.var_periyot = tk.StringVar(value="Günde")
        self.time_vars = {k: tk.BooleanVar(value=False) for k, _ in self._TIMES}
        self.var_meal = tk.StringVar(value=self._NO_BADGE)

        self._build()
        self.set_row(None)

    # --- Temalı yardımcı widget'lar -----------------------------------
    def _section(self, parent, title):
        C = COLORS
        outer = tk.LabelFrame(parent, text=title, background=C["bg_panel"],
                              foreground=C["text_yellow"], font=("Segoe UI", 9, "bold"),
                              labelanchor="nw", bd=1, relief="groove", padx=8, pady=6)
        outer.pack(fill="x", pady=4)
        return outer

    def _radio(self, parent, text, value, var):
        C = COLORS
        return tk.Radiobutton(
            parent, text=text, value=value, variable=var,
            command=self._on_edit, font=("Segoe UI", 9),
            background=C["bg_panel"], foreground=C["text_light"],
            selectcolor=C["bg_strip"], activebackground=C["bg_panel"],
            activeforeground=C["text_light"])

    def _check(self, parent, text, var):
        C = COLORS
        return tk.Checkbutton(
            parent, text=text, variable=var,
            command=self._on_edit, font=("Segoe UI", 9),
            background=C["bg_panel"], foreground=C["text_light"],
            selectcolor=C["bg_strip"], activebackground=C["bg_panel"],
            activeforeground=C["text_light"])

    def _stepper(self, parent, var, lo, hi, step):
        C = COLORS
        f = tk.Frame(parent, background=C["bg_panel"])
        tk.Button(f, text="−", width=2, font=("Segoe UI", 10, "bold"),
                  command=lambda: self._bump(var, -step, lo, hi)).pack(side="left")
        e = tk.Entry(f, textvariable=var, width=5, justify="center",
                     font=("Segoe UI", 11))
        e.pack(side="left", padx=3)
        e.bind("<KeyRelease>", lambda ev: self._on_edit())
        tk.Button(f, text="+", width=2, font=("Segoe UI", 10, "bold"),
                  command=lambda: self._bump(var, step, lo, hi)).pack(side="left")
        return f

    def _bump(self, var, delta, lo, hi):
        try:
            v = float(var.get())
        except Exception:
            v = lo
        v = max(lo, min(hi, v + delta))
        if isinstance(var, tk.IntVar):
            var.set(int(round(v)))
        else:
            var.set(round(v, 1))
        self._on_edit()

    def _build(self):
        C = COLORS
        root = tk.Frame(self, background=C["bg_main"])
        root.pack(fill="both", expand=True)

        # SOL: form (sabit dar genişlik)  |  SAĞ: BÜYÜK canlı önizleme (kalan alan)
        left = tk.Frame(root, background=C["bg_main"], width=430)
        left.pack(side="left", fill="y", padx=(2, 10), pady=2)
        left.pack_propagate(False)
        right = tk.Frame(root, background=C["bg_panel"])
        right.pack(side="left", fill="both", expand=True, pady=2)

        tk.Label(left, textvariable=self.var_name, background=C["bg_main"],
                 foreground=C["text_yellow"], font=("Segoe UI", 13, "bold"),
                 anchor="w", wraplength=420, justify="left").pack(fill="x", pady=(0, 4))

        # --- DOZ (N × M) ---
        doz_sec = self._section(left, "💊  Doz  (N × M)")
        drow = tk.Frame(doz_sec, background=C["bg_panel"])
        drow.pack(fill="x", pady=2)
        tk.Label(drow, text="Kez (N):", width=8, anchor="w",
                 background=C["bg_panel"], foreground=C["text_light"]).pack(side="left")
        self._stepper(drow, self.var_kez, 1, 6, 1).pack(side="left")
        tk.Label(drow, text="× Adet (M):", anchor="e",
                 background=C["bg_panel"], foreground=C["text_light"]).pack(side="left", padx=(10, 0))
        self._stepper(drow, self.var_adet, 0.5, 300, 0.5).pack(side="left")
        drow2 = tk.Frame(doz_sec, background=C["bg_panel"])
        drow2.pack(fill="x", pady=(4, 0))
        tk.Label(drow2, text="Birim:", width=8, anchor="w",
                 background=C["bg_panel"], foreground=C["text_light"]).pack(side="left")
        cb = ttk.Combobox(drow2, textvariable=self.var_birim, width=12,
                          values=["Tane", "Tablet", "Kapsül", "ML", "Damla", "Puf",
                                  "Ölçek", "Uygulama", "Fitil", "ünite"])
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self._on_edit())
        cb.bind("<KeyRelease>", lambda e: self._on_edit())
        self.lbl_nm = tk.Label(drow2, text="", background=C["bg_strip"],
                               foreground=C["text_yellow"], font=("Consolas", 14, "bold"),
                               anchor="e", padx=10)
        self.lbl_nm.pack(side="right", fill="x", expand=True, padx=(8, 0))

        # --- PERİYOT ---
        per_sec = self._section(left, "📅  Periyot")
        prow = tk.Frame(per_sec, background=C["bg_panel"])
        prow.pack(fill="x")
        for val, lbl in self._PERIODS:
            self._radio(prow, lbl, val, self.var_periyot).pack(side="left", padx=6)

        # --- KULLANIM ZAMANI ---
        z_sec = self._section(left, "🕐  Kullanım zamanı")
        zrow = tk.Frame(z_sec, background=C["bg_panel"])
        zrow.pack(fill="x")
        for key, lbl in self._TIMES:
            self._check(zrow, lbl, self.time_vars[key]).pack(side="left", padx=6)
        tk.Label(z_sec, text="Seçilmezse günlük keze göre SABAH/ÖĞLEN/AKŞAM otomatik dizilir.",
                 background=C["bg_panel"], foreground=C["text_muted"],
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(2, 0))

        # --- ÖĞÜN ROZETİ (AÇ / TOK) ---
        m_sec = self._section(left, "🍽  Öğün rozeti  (AÇ / TOK)")
        mgrid = tk.Frame(m_sec, background=C["bg_panel"])
        mgrid.pack(fill="x")
        for i, val in enumerate(self._MEAL_BADGES):
            r, c = divmod(i, 2)
            self._radio(mgrid, val, val, self.var_meal).grid(
                row=r, column=c, sticky="w", padx=4, pady=1)

        # --- METİNLER: kategori / süre / talimat / uyarı / not ---
        t_sec = self._section(left, "📝  Kategori · Talimat · Uyarı · Not")
        g = tk.Frame(t_sec, background=C["bg_panel"])
        g.pack(fill="both", expand=True)

        def _txtlabel(text, r):
            tk.Label(g, text=text, background=C["bg_panel"], foreground=C["text_light"],
                     anchor="nw").grid(row=r, column=0, sticky="nw", padx=4, pady=2)

        _txtlabel("Kategori:", 0)
        e_kat = ttk.Entry(g, textvariable=self.var_kategori, width=30)
        e_kat.grid(row=0, column=1, sticky="we", padx=4, pady=2)
        e_kat.bind("<KeyRelease>", lambda e: self._on_edit())

        _txtlabel("Süre (gün):", 1)
        e_sure = ttk.Entry(g, textvariable=self.var_sure, width=8)
        e_sure.grid(row=1, column=1, sticky="w", padx=4, pady=2)
        e_sure.bind("<KeyRelease>", lambda e: self._on_edit())

        _txtlabel("Talimat:", 2)
        self.txt_talimat = tk.Text(g, width=30, height=3, font=("Segoe UI", 10), wrap="word")
        self.txt_talimat.grid(row=2, column=1, sticky="we", padx=4, pady=2)
        self.txt_talimat.bind("<KeyRelease>", lambda e: self._on_edit())

        _txtlabel("UYARI:", 3)
        self.txt_uyari = tk.Text(g, width=30, height=3, font=("Segoe UI", 10), wrap="word")
        self.txt_uyari.grid(row=3, column=1, sticky="we", padx=4, pady=2)
        self.txt_uyari.bind("<KeyRelease>", lambda e: self._on_edit())

        _txtlabel("NOT (etikete basılır):", 4)
        self.txt_not = tk.Text(g, width=30, height=2, font=("Segoe UI", 10), wrap="word")
        self.txt_not.grid(row=4, column=1, sticky="we", padx=4, pady=2)
        self.txt_not.bind("<KeyRelease>", lambda e: self._on_edit())
        g.columnconfigure(1, weight=1)

        # --- SAĞ: BÜYÜK canlı etiket önizleme (pencereyle ölçeklenir) ---
        tk.Label(right, text="ETİKET ÖNİZLEME", background=C["bg_panel"],
                 foreground=C["text_yellow"], font=("Segoe UI", 10, "bold")).pack(
                     pady=(6, 4), padx=14)
        # Görsel, kalan alanı doldurur; en/boy oranı (480:320) korunarak ortalanır.
        self.prev_holder = tk.Frame(right, background=C["bg_panel"])
        self.prev_holder.pack(fill="both", expand=True, padx=12, pady=(0, 6))
        self.prev_img = tk.Label(self.prev_holder, background=C["bg_panel"], borderwidth=0)
        self.prev_img.pack(expand=True)
        self.prev_holder.bind("<Configure>", self._on_prev_resize)
        tk.Label(right, text="(Değişiklikler anında yansır)", background=C["bg_panel"],
                 foreground=C["text_muted"], font=("Segoe UI", 8, "italic")).pack(pady=(0, 6))

    # --- Bağlı satır yönetimi -----------------------------------------
    def set_row(self, row: Optional[DrugRow]):
        """Düzenleyiciyi bir DrugRow'a bağla (None → boş/önizleme yok)."""
        self.row = row
        self._loading = True   # değişken set'i _on_edit'i tetiklemesin
        try:
            if row is None:
                self.var_name.set("İlaç seçili değil")
                self.var_kategori.set("")
                for t in (self.txt_talimat, self.txt_uyari, self.txt_not):
                    t.delete("1.0", "end")
                self._update_nm()
                self._clear_preview()
                return
            self.var_name.set(row.name)
            self.var_kategori.set(row.kategori or "")
            self.var_kez.set(int(row.gunluk_kez or 1))
            try:
                self.var_adet.set(float(row.doz_adet) or 1.0)
            except Exception:
                self.var_adet.set(1.0)
            self.var_birim.set(row.doz_birim or "Tane")
            self.var_sure.set(str(row.sure_gun or 7))
            self.var_periyot.set(row.periyot or "Günde")
            cur = {(z or "").strip().lower() for z in (row.kullanim_zamani or [])}
            for k, v in self.time_vars.items():
                v.set(k in cur)
            mb = (row.meal_badge or "").strip().upper()
            self.var_meal.set(mb if mb in self._MEAL_BADGES else self._NO_BADGE)
            for t, val in ((self.txt_talimat, row.talimat),
                           (self.txt_uyari, row.uyari),
                           (self.txt_not, row.not_metni)):
                t.delete("1.0", "end")
                t.insert("1.0", val or "")
        finally:
            self._loading = False
        self._update_nm()
        self._refresh_preview()

    # --- Canlı uygulama / önizleme ------------------------------------
    def _doz_str(self) -> str:
        try:
            adet = float(self.var_adet.get())
        except Exception:
            adet = 1.0
        s = str(int(adet)) if float(adet).is_integer() else f"{adet:.1f}".replace(".", ",")
        birim = (self.var_birim.get() or "").strip()
        return f"{s} {birim}" if birim else s

    def _selected_times(self) -> list[str]:
        return [k for k, _ in self._TIMES if self.time_vars[k].get()]

    def _collect(self, target: DrugRow):
        """Mevcut form değerlerini bağlı DrugRow'a yaz."""
        try:
            target.doz_adet = float(self.var_adet.get())
        except Exception:
            target.doz_adet = 1.0
        target.doz_birim = (self.var_birim.get() or "").strip()
        try:
            target.gunluk_kez = int(float(self.var_kez.get()))
        except Exception:
            target.gunluk_kez = 1
        try:
            target.sure_gun = int(self.var_sure.get())
        except Exception:
            target.sure_gun = 7
        target.kategori = self.var_kategori.get().strip()
        target.talimat = self.txt_talimat.get("1.0", "end").strip()
        target.uyari = self.txt_uyari.get("1.0", "end").strip()
        target.not_metni = self.txt_not.get("1.0", "end").strip()
        target.periyot = self.var_periyot.get() or "Günde"
        target.kullanim_zamani = self._selected_times()
        mb = self.var_meal.get()
        target.meal_badge = "" if mb == self._NO_BADGE else mb

    def _update_nm(self):
        try:
            if self.row is None:
                self.lbl_nm.config(text="")
            else:
                self.lbl_nm.config(
                    text=f"  {int(float(self.var_kez.get()))} × {self._doz_str()}")
        except Exception:
            pass

    def _on_edit(self, *_):
        """Herhangi bir alan değişince: satıra yaz + listeyi + önizlemeyi tazele."""
        self._update_nm()
        if self._loading or self.row is None:
            return
        self._collect(self.row)
        if self.on_change:
            try:
                self.on_change(self.row)
            except Exception:
                log.exception("editör on_change hatası")
        self.schedule_preview()

    def schedule_preview(self):
        if self._preview_after:
            try:
                self.after_cancel(self._preview_after)
            except Exception:
                pass
        self._preview_after = self.after(160, self._refresh_preview)

    def _clear_preview(self):
        self._cur_pil = None
        self._preview_photo = None
        try:
            self.prev_img.configure(image="", text="İlaç ekleyin / soldan seçin",
                                    foreground=COLORS["text_muted"],
                                    font=("Segoe UI", 12, "bold"))
        except Exception:
            pass

    def _refresh_preview(self):
        self._preview_after = None
        if self.row is None:
            self._clear_preview()
            return
        try:
            hasta = (self.app.var_hasta.get() or "").strip().upper() or "HASTA ADI"
            r_date = self.app._manual_recete_date()
            img = self.app._manual_label_image(self.row, hasta, r_date)
            self._cur_pil = img.convert("RGB")
            self._fit_preview()
        except Exception:
            log.exception("Düzenleyici önizleme hatası")

    def _on_prev_resize(self, event=None):
        """Önizleme alanı yeniden boyutlanınca görseli oranı koruyarak yeniden ölçekle."""
        old = getattr(self, "_fit_after", None)
        if old:
            try:
                self.after_cancel(old)
            except Exception:
                pass
        self._fit_after = self.after(60, self._fit_preview)

    def _fit_preview(self):
        """Önbellekteki etiket görselini, holder alanına 480:320 oranıyla sığdır."""
        self._fit_after = None
        pil = getattr(self, "_cur_pil", None)
        if pil is None:
            return
        try:
            W = self.prev_holder.winfo_width()
            H = self.prev_holder.winfo_height()
            if W <= 1 or H <= 1:
                W, H = 520, 360
            ratio = 480 / 320
            w = W - 6
            h = int(w / ratio)
            if h > H - 6:
                h = H - 6
                w = int(h * ratio)
            w = max(120, w)
            h = max(80, h)
            photo = ImageTk.PhotoImage(pil.resize((w, h), Image.LANCZOS))
            self.prev_img.configure(image=photo, text="")
            self._preview_photo = photo
        except Exception:
            log.exception("Önizleme ölçekleme hatası")


def main():
    handlers = [logging.StreamHandler()]
    # pythonw altında stderr boşa gider; tanı için dosyaya da yaz.
    try:
        log_dir = Path(__file__).resolve().parents[3] / "data" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_dir / "ui.log", encoding="utf-8"))
    except Exception:
        pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
        handlers=handlers,
    )
    # DPI-farkındalık: Tk penceresi oluşmadan ÖNCE ayarlanmalı. Aksi halde
    # Windows ölçeklendirmesi (125%/150%) olan bilgisayarlarda arayüz sıkışır,
    # butonlar üst üste biner. shcore (Win 8.1+) yoksa eski user32'ye düş.
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)  # SYSTEM_DPI_AWARE
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

    app = ManualLabelApp()
    app.mainloop()


if __name__ == "__main__":
    main()
