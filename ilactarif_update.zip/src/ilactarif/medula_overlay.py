"""Medula penceresinin etrafına reçete durumuna göre renkli ÇERÇEVE çizen overlay.

Reçete yaşam döngüsü (medula_parser.compute_medula_theme) bir tema rengi üretir:
  • yeşil  — reçete sonlanmış (karekod tamamlandı)
  • turuncu — karekod ekranında eksik karekod var, sonlandırılmamış
  • mavi   — reçete açık / işlem sürüyor

Bu modül o rengi, Medula penceresinin dört kenarına oturan ince, üstte duran
(topmost) ve TIKLAMAYI GEÇİREN (click-through) dört küçük Tk penceresiyle çizer.
Medula sayfasının kendisine DOKUNMAZ; yalnızca pencerenin etrafına çerçeve koyar.

Mimari:
  • set_state(hwnd, theme) watcher thread'inden değil, Tk ana thread'inden
    çağrılmalıdır (UI bunu self.after ile marshal eder). Yalnız son durumu saklar.
  • Tk tarafında kendi after() döngüsü (~250 ms) çerçeveyi yeniden konumlandırır
    ve Medula ön planda DEĞİLSE gizler. Böylece pencere taşınınca çerçeve takip
    eder ve başka uygulamaların üstüne taşmaz.
"""
from __future__ import annotations

import ctypes
import logging
import tkinter as tk
from ctypes import wintypes
from typing import Optional

log = logging.getLogger("medula_overlay")

_user32 = ctypes.windll.user32

# Tema rengi → kenar çerçevesi rengi
_THEME_COLORS = {
    "green":  "#16a34a",
    "orange": "#f97316",
    "blue":   "#2563eb",
}

# Genişletilmiş pencere stilleri (click-through + odak çalmadan + görev çubuğunda yok)
_GWL_EXSTYLE        = -20
_WS_EX_LAYERED      = 0x00080000
_WS_EX_TRANSPARENT  = 0x00000020
_WS_EX_NOACTIVATE   = 0x08000000
_WS_EX_TOOLWINDOW   = 0x00000080
_LWA_ALPHA          = 0x00000002

_THICKNESS = 6   # çerçeve kalınlığı (px)


def _get_window_rect(hwnd: int) -> Optional[tuple[int, int, int, int]]:
    r = wintypes.RECT()
    if not _user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    return r.left, r.top, r.right, r.bottom


def _pid_of(hwnd: int) -> int:
    pid = ctypes.c_ulong(0)
    _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def _is_window(hwnd: int) -> bool:
    return bool(hwnd) and bool(_user32.IsWindow(hwnd))


def _is_iconic(hwnd: int) -> bool:
    return bool(_user32.IsIconic(hwnd))


class MedulaThemeOverlay:
    """Medula penceresinin etrafına renkli çerçeve çizen yönetici."""

    POLL_MS = 250

    def __init__(self, root: tk.Misc, enabled: bool = True):
        self.root = root
        self.enabled = enabled
        self._hwnd: Optional[int] = None       # çerçevelenecek Medula penceresi
        self._theme: Optional[str] = None      # "green"/"orange"/"blue"
        self._edges: list[tk.Toplevel] = []     # 4 kenar penceresi (top,bottom,left,right)
        self._cur_color: Optional[str] = None
        self._visible = False
        self._after_id: Optional[str] = None
        self._poll()

    # ------------------------------------------------------------------ API
    def set_state(self, hwnd: Optional[int], theme: Optional[str]) -> None:
        """Watcher'ın bulduğu güncel (pencere, tema) durumunu sakla.

        Yalnız Tk ana thread'inden çağrılmalı (UI self.after ile marshal eder).
        """
        self._hwnd = hwnd
        self._theme = theme if theme in _THEME_COLORS else None

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled
        if not enabled:
            self._hide()

    def destroy(self) -> None:
        if self._after_id is not None:
            try:
                self.root.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None
        self._destroy_edges()

    # ------------------------------------------------------------- iç döngü
    def _poll(self) -> None:
        try:
            self._refresh()
        except Exception:
            log.debug("overlay refresh hatası", exc_info=False)
        finally:
            try:
                self._after_id = self.root.after(self.POLL_MS, self._poll)
            except Exception:
                self._after_id = None

    def _refresh(self) -> None:
        if not self.enabled or not self._theme or not _is_window(self._hwnd):
            self._hide()
            return
        if _is_iconic(self._hwnd):
            self._hide()
            return
        # Yalnız Medula ön plandayken göster (başka uygulamanın üstüne taşmasın).
        fg = _user32.GetForegroundWindow()
        if fg != self._hwnd and _pid_of(fg) != _pid_of(self._hwnd):
            self._hide()
            return
        rect = _get_window_rect(self._hwnd)
        if rect is None:
            self._hide()
            return
        self._draw(rect, _THEME_COLORS[self._theme])

    # --------------------------------------------------------------- çizim
    def _ensure_edges(self) -> None:
        if self._edges:
            return
        for _ in range(4):
            w = tk.Toplevel(self.root)
            w.overrideredirect(True)
            try:
                w.attributes("-topmost", True)
            except Exception:
                pass
            w.configure(bg="#000000")
            # Görünmez başlat — geometri ilk _draw'da verilir
            w.withdraw()
            self._edges.append(w)
            self._make_click_through(w)

    def _make_click_through(self, w: tk.Toplevel) -> None:
        """Kenar penceresini click-through + odak çalmaz + görev çubuğunda görünmez yap."""
        try:
            w.update_idletasks()
            hwnd = _user32.GetParent(w.winfo_id()) or w.winfo_id()
            style = _user32.GetWindowLongW(hwnd, _GWL_EXSTYLE)
            style |= (_WS_EX_LAYERED | _WS_EX_TRANSPARENT
                      | _WS_EX_NOACTIVATE | _WS_EX_TOOLWINDOW)
            _user32.SetWindowLongW(hwnd, _GWL_EXSTYLE, style)
            # WS_EX_LAYERED penceresi SetLayeredWindowAttributes çağrılmadan
            # görünmez kalır; tam opak (alpha 255) yaparak görünür kıl.
            _user32.SetLayeredWindowAttributes(hwnd, 0, 255, _LWA_ALPHA)
        except Exception:
            log.debug("click-through ayarlanamadı", exc_info=False)

    def _draw(self, rect: tuple[int, int, int, int], color: str) -> None:
        self._ensure_edges()
        L, T, R, B = rect
        w = max(0, R - L)
        h = max(0, B - T)
        if w <= 0 or h <= 0:
            self._hide()
            return
        th = _THICKNESS
        # (x, y, width, height) — top, bottom, left, right
        geo = [
            (L,        T,        w,  th),       # üst
            (L,        B - th,   w,  th),       # alt
            (L,        T,        th, h),        # sol
            (R - th,   T,        th, h),        # sağ
        ]
        for edge, (x, y, ew, eh) in zip(self._edges, geo):
            try:
                if color != self._cur_color:
                    edge.configure(bg=color)
                edge.geometry(f"{ew}x{eh}+{x}+{y}")
                edge.deiconify()
                edge.lift()
                edge.attributes("-topmost", True)
            except Exception:
                pass
        self._cur_color = color
        self._visible = True

    def _hide(self) -> None:
        if not self._visible:
            return
        for edge in self._edges:
            try:
                edge.withdraw()
            except Exception:
                pass
        self._visible = False

    def _destroy_edges(self) -> None:
        for edge in self._edges:
            try:
                edge.destroy()
            except Exception:
                pass
        self._edges = []
        self._visible = False
