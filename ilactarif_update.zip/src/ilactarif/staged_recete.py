"""İki aşamalı reçete (early/final) için fark karşılaştırma + sunum yardımcıları.

Hem e-reçete (PrescriptionCapture) hem kağıt reçete (PaperReceteForm) için
"reçete başı" (kayıt öncesi) vs "reçete sonu" (kayıt sonrası) karşılaştırması.
Sonuç: kullanıcının iki sütunlu tabloda göreceği DiffRow listesi.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .medula_parser import CapturedDrug, PrescriptionCapture
from .paper_recete import PaperDrug, PaperReceteForm


# ---------------------------------------------------------------------------
# Sunum yardımcıları: ilaç satırını "İlaç A · 3x1 · 5 kt · Ağızdan" formatına
# ---------------------------------------------------------------------------
def _doz_summary_captured(d: CapturedDrug) -> str:
    parts = []
    if d.doz_gunluk_kez and d.doz_birim_adedi is not None:
        kez = d.doz_gunluk_kez
        adet = d.doz_birim_adedi
        adet_s = (str(int(adet)) if float(adet).is_integer()
                  else f"{adet:.1f}".replace(".", ","))
        parts.append(f"{kez}x{adet_s}")
    elif d.doz_ham:
        parts.append(d.doz_ham)
    if d.adet:
        parts.append(f"{d.adet} kt")
    if d.kullanim_sekli:
        parts.append(d.kullanim_sekli)
    return " · ".join(parts) if parts else "—"


def _doz_summary_paper(d: PaperDrug) -> str:
    parts = []
    periyot = ""
    if d.periyot_sayi and d.periyot_sayi.strip() not in ("", "0"):
        periyot = f"{d.periyot_sayi} {d.periyot_birim.lower()} "
    if d.gunluk_kez and d.doz_adet:
        parts.append(f"{periyot}{d.gunluk_kez}x{d.doz_adet}".strip())
    if d.kutu and d.kutu.strip() not in ("", "0"):
        parts.append(f"{d.kutu} kt")
    return " · ".join(parts) if parts else "—"


def drug_line_captured(d: CapturedDrug) -> str:
    ad = d.ad or f"(barkod {d.barkod})"
    return f"{ad}  ·  {_doz_summary_captured(d)}"


def drug_line_paper(d: PaperDrug, name: str = "") -> str:
    # Öncelik: explicit name → drug.ad (Medula AJAX) → barkod fallback
    ad = name or d.ad or f"(barkod {d.barkod})"
    return f"{ad}  ·  {_doz_summary_paper(d)}"


# ---------------------------------------------------------------------------
# DiffRow — iki sütunlu tablodaki bir satır
# ---------------------------------------------------------------------------
@dataclass
class DiffRow:
    barkod: str
    before_text: str         # "İlaç A · 3x1 · 5 kt"
    after_text: str          # "İlaç A · 2x1 · 5 kt"  veya "—" (yok)
    status: str              # "same" | "changed" | "removed" | "added"
    detail: str = ""         # "Doz: 3x1 → 2x1"

    @property
    def status_label(self) -> str:
        return {
            "same":    "✓ Aynı",
            "changed": "⚠ Değişti",
            "removed": "✗ Çıkarıldı (SGK ödemiyor / hasta vermek istemiyor)",
            "added":   "+ Eklendi",
        }.get(self.status, self.status)


# ---------------------------------------------------------------------------
# Karşılaştırma fonksiyonları
# ---------------------------------------------------------------------------
def _changed_fields_captured(a: CapturedDrug, b: CapturedDrug) -> list[str]:
    out = []
    if (a.adet or "").strip() != (b.adet or "").strip():
        out.append(f"Kutu: {a.adet or '—'} → {b.adet or '—'}")
    az = str(a.doz_gunluk_kez or "")
    bz = str(b.doz_gunluk_kez or "")
    if az != bz:
        out.append(f"Günlük kez: {az or '—'} → {bz or '—'}")
    aa = str(a.doz_birim_adedi or "")
    bb = str(b.doz_birim_adedi or "")
    if aa != bb:
        out.append(f"Doz adet: {aa or '—'} → {bb or '—'}")
    if (a.doz_ham or "").strip() != (b.doz_ham or "").strip() and not out:
        # Sadece ham metin değiştiyse onu da göster
        out.append(f"Doz: «{a.doz_ham}» → «{b.doz_ham}»")
    return out


def compare_captures(
    before: PrescriptionCapture,
    after: PrescriptionCapture,
) -> list[DiffRow]:
    """E-reçete için: kayıt-öncesi vs kayıt-sonrası ilaç listesi karşılaştırma."""
    bmap = {d.barkod: d for d in before.drugs if d.barkod}
    amap = {d.barkod: d for d in after.drugs if d.barkod}
    rows: list[DiffRow] = []
    all_barcodes = list(bmap.keys()) + [bk for bk in amap if bk not in bmap]
    for bk in all_barcodes:
        b = bmap.get(bk)
        a = amap.get(bk)
        if b and not a:
            rows.append(DiffRow(
                barkod=bk,
                before_text=drug_line_captured(b),
                after_text="—",
                status="removed",
                detail="İlaç reçete sonu listesinde yok.",
            ))
            continue
        if a and not b:
            rows.append(DiffRow(
                barkod=bk,
                before_text="—",
                after_text=drug_line_captured(a),
                status="added",
                detail="İlaç reçete sonu listesinde sonradan eklendi.",
            ))
            continue
        # ikisi de var
        changed = _changed_fields_captured(b, a)
        rows.append(DiffRow(
            barkod=bk,
            before_text=drug_line_captured(b),
            after_text=drug_line_captured(a),
            status=("changed" if changed else "same"),
            detail=" · ".join(changed),
        ))
    return rows


def _changed_fields_paper(a: PaperDrug, b: PaperDrug) -> list[str]:
    out = []
    if (a.kutu or "").strip() != (b.kutu or "").strip():
        out.append(f"Kutu: {a.kutu or '—'} → {b.kutu or '—'}")
    if (a.gunluk_kez or "").strip() != (b.gunluk_kez or "").strip():
        out.append(f"Günlük kez: {a.gunluk_kez or '—'} → {b.gunluk_kez or '—'}")
    if (a.doz_adet or "").strip() != (b.doz_adet or "").strip():
        out.append(f"Doz adet: {a.doz_adet or '—'} → {b.doz_adet or '—'}")
    if (a.periyot_sayi or "").strip() != (b.periyot_sayi or "").strip():
        out.append(f"Periyot sayı: {a.periyot_sayi or '—'} → {b.periyot_sayi or '—'}")
    if (a.periyot_birim or "").strip() != (b.periyot_birim or "").strip():
        out.append(f"Periyot birim: {a.periyot_birim or '—'} → {b.periyot_birim or '—'}")
    return out


def compare_paper_forms(
    before: PaperReceteForm,
    after: PaperReceteForm,
    name_lookup=None,
) -> list[DiffRow]:
    """Kağıt reçete formu için: kayıt-öncesi vs kayıt-sonrası."""
    bmap = {d.barkod: d for d in before.filled_drugs if d.barkod}
    amap = {d.barkod: d for d in after.filled_drugs if d.barkod}
    rows: list[DiffRow] = []
    all_barcodes = list(bmap.keys()) + [bk for bk in amap if bk not in bmap]

    def _name(bk: str) -> str:
        if name_lookup:
            try:
                return name_lookup(bk) or ""
            except Exception:
                return ""
        return ""

    for bk in all_barcodes:
        b = bmap.get(bk)
        a = amap.get(bk)
        nm = _name(bk)
        if b and not a:
            rows.append(DiffRow(
                barkod=bk,
                before_text=drug_line_paper(b, nm),
                after_text="—",
                status="removed",
                detail="İlaç reçete sonu listesinde yok.",
            ))
            continue
        if a and not b:
            rows.append(DiffRow(
                barkod=bk,
                before_text="—",
                after_text=drug_line_paper(a, nm),
                status="added",
                detail="Reçete sonunda sonradan eklendi.",
            ))
            continue
        changed = _changed_fields_paper(b, a)
        rows.append(DiffRow(
            barkod=bk,
            before_text=drug_line_paper(b, nm),
            after_text=drug_line_paper(a, nm),
            status=("changed" if changed else "same"),
            detail=" · ".join(changed),
        ))
    return rows
