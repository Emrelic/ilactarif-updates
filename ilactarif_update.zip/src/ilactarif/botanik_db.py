"""Botanik EOS SQL veritabanına SALT-OKUNUR erişim (ürün adı / barkod / fiyat).

Botanik EOS, Microsoft SQL Server kullanır. Merkez sunucu (UMIT) üzerindeki
`eczane` veritabanından ürün kataloğu doğrudan SELECT ile okunur — UI Automation
ile ekran kazımaya ([[botanik_capture]]) gerek kalmaz.

GÜVENLİK: Bu modül YALNIZCA SELECT çalıştırır. Botanik veritabanına bağlanan
SQL kullanıcısı ('calede') yalnız db_datareader (SELECT) yetkisine sahip olacak
şekilde oluşturulur; veri ekleme/güncelleme/silme yapamaz. Yine de bu modülde de
hiçbir INSERT/UPDATE/DELETE yoktur.

Şema (eczane DB):
    Urun(UrunId, UrunAdi, UrunFiyatEtiket=satış, UrunFiyatKamu=SGK,
         UrunStokAcik, UrunAktif, UrunSilme)
    Barkod(BarkodUrunId→UrunId, BarkodAdi=barkod, BarkodSilme)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

log = logging.getLogger(__name__)

# Tercih sırasına göre denenecek ODBC sürücüleri (ilk kurulu olan kullanılır).
_PREFERRED_DRIVERS = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "ODBC Driver 13 for SQL Server",
    "ODBC Driver 11 for SQL Server",
    "SQL Server Native Client 11.0",
    "SQL Server",
]


@dataclass
class BotanikUrun:
    urun_id: int
    barkod: str
    ad: str
    fiyat: float | None
    kamu_fiyat: float | None
    stok: int | None


class BotanikDBError(RuntimeError):
    """Botanik SQL bağlantı/sorgu hatası (pyodbc yok, erişilemiyor, vb.)."""


def _pick_driver() -> str:
    """Kurulu ODBC sürücülerinden tercih edilen ilkini döndürür."""
    try:
        import pyodbc
    except ImportError as e:
        raise BotanikDBError(
            "pyodbc kurulu değil — Botanik SQL bağlantısı yapılamaz."
        ) from e
    have = set(pyodbc.drivers())
    for d in _PREFERRED_DRIVERS:
        if d in have:
            return d
    raise BotanikDBError(
        "SQL Server ODBC sürücüsü bulunamadı. 'ODBC Driver 17 for SQL Server' kurun."
    )


def build_conn_str(server: str, database: str, user: str, password: str) -> str:
    """SALT-OKUNUR amaçlı bağlantı dizesi. (Gerçek yazma engeli sunucudaki
    'calede' kullanıcısının yalnız-SELECT yetkisiyle sağlanır.)"""
    driver = _pick_driver()
    extra = "TrustServerCertificate=yes;Encrypt=no;" if "18" in driver else ""
    return (
        f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};"
        f"UID={user};PWD={password};{extra}"
    )


def _connect(server: str, database: str, user: str, password: str, timeout: int = 6):
    import pyodbc
    try:
        return pyodbc.connect(
            build_conn_str(server, database, user, password),
            timeout=timeout, readonly=True,
        )
    except Exception as e:  # pyodbc.Error dahil
        raise BotanikDBError(str(e)) from e


def settings_to_params(s: dict) -> dict:
    """settings sözlüğünden bağlantı parametrelerini çıkarır."""
    return {
        "server":   s.get("botanik_db_server", "") or "",
        "database": s.get("botanik_db_name", "eczane") or "eczane",
        "user":     s.get("botanik_db_user", "") or "",
        "password": s.get("botanik_db_pass", "") or "",
    }


def test_connection(server: str, database: str, user: str, password: str) -> tuple[bool, str]:
    """Bağlantıyı dener. (ok, mesaj) döndürür. Yazma denemez."""
    try:
        with _connect(server, database, user, password) as c:
            n = c.cursor().execute(
                "SELECT COUNT(*) FROM Urun WHERE UrunSilme=0 AND UrunAktif=1"
            ).fetchone()[0]
        return True, f"Bağlantı başarılı — {n} aktif ürün."
    except BotanikDBError as e:
        return False, str(e)


# Aktif ürünleri barkodlarıyla getiren sorgu (barkodsuz ürün de bir kez gelir).
_CATALOG_SQL = """
SELECT u.UrunId, ISNULL(b.BarkodAdi,'') AS Barkod, u.UrunAdi,
       u.UrunFiyatEtiket, u.UrunFiyatKamu, u.UrunStokAcik
FROM Urun u
LEFT JOIN Barkod b ON b.BarkodUrunId = u.UrunId AND b.BarkodSilme = 0
WHERE u.UrunSilme = 0 AND u.UrunAktif = 1
"""


def fetch_catalog(server: str, database: str, user: str, password: str) -> list[BotanikUrun]:
    """Tüm aktif ürünleri (ad+barkod+fiyat) salt-okunur çeker."""
    out: list[BotanikUrun] = []
    with _connect(server, database, user, password, timeout=30) as c:
        for r in c.cursor().execute(_CATALOG_SQL).fetchall():
            out.append(BotanikUrun(
                urun_id=int(r[0]),
                barkod=(r[1] or "").strip(),
                ad=(r[2] or "").strip(),
                fiyat=float(r[3]) if r[3] is not None else None,
                kamu_fiyat=float(r[4]) if r[4] is not None else None,
                stok=int(r[5]) if r[5] is not None else None,
            ))
    return out


def price_by_barcode(server: str, database: str, user: str, password: str,
                     barkod: str) -> BotanikUrun | None:
    """Tek bir barkod için CANLI fiyat sorgusu (salt-okunur)."""
    barkod = (barkod or "").strip()
    if not barkod:
        return None
    sql = """
    SELECT TOP 1 u.UrunId, ?, u.UrunAdi, u.UrunFiyatEtiket, u.UrunFiyatKamu, u.UrunStokAcik
    FROM Barkod b JOIN Urun u ON u.UrunId = b.BarkodUrunId
    WHERE b.BarkodSilme = 0 AND u.UrunSilme = 0 AND b.BarkodAdi = ?
    """
    with _connect(server, database, user, password) as c:
        r = c.cursor().execute(sql, barkod, barkod).fetchone()
    if not r:
        return None
    return BotanikUrun(
        urun_id=int(r[0]), barkod=barkod, ad=(r[2] or "").strip(),
        fiyat=float(r[3]) if r[3] is not None else None,
        kamu_fiyat=float(r[4]) if r[4] is not None else None,
        stok=int(r[5]) if r[5] is not None else None,
    )


def _fmt_phone(raw: str) -> str:
    """'5079477423'/'2125385056' → '0507 947 74 23' (10 hane → başına 0)."""
    d = "".join(ch for ch in (raw or "") if ch.isdigit())
    if len(d) == 10:
        d = "0" + d
    if len(d) == 11:
        return f"{d[0:4]} {d[4:7]} {d[7:9]} {d[9:11]}"
    return (raw or "").strip()


def _musteri_to_recipient(r) -> dict:
    tel = (r.MusteriTelCep or "").strip() or (r.MusteriTelEv or "").strip() \
        or (r.MusteriTelIs or "").strip()
    return {
        "ad": (r.MusteriAdiSoyadi or "").strip(),
        "tckn": (r.MusteriTCKN or "").strip(),
        "adres": (r.MusteriAdresi or "").strip(),
        "telefon": _fmt_phone(tel),
        "tip": "hasta",
        "kaynak": "botanik",
    }


def search_recipients(server: str, database: str, user: str, password: str,
                      query: str, limit: int = 15) -> list[dict]:
    """Kargo alıcısı ara: birey → Musteri (TC veya ad), kurum → Kurum (ad).

    TC (rakam) yazılırsa Musteri.MusteriTCKN ön-ekiyle; ad yazılırsa hem
    Musteri.MusteriAdiSoyadi hem Kurum.KurumAdi içinde aranır (adresi olanlar).
    Dönüş: {ad, tckn, adres, telefon, tip('hasta'|'kurum'), kaynak('botanik')}.
    """
    q = (query or "").strip()
    if len(q) < 3:
        return []
    digits = "".join(ch for ch in q if ch.isdigit())
    out: list[dict] = []
    with _connect(server, database, user, password) as c:
        cur = c.cursor()
        if digits and len(digits) >= 3 and len(digits) >= len(q) - 2:
            # TC araması (rakam ağırlıklı giriş)
            rows = cur.execute(
                "SELECT TOP (?) MusteriAdiSoyadi, MusteriTCKN, MusteriAdresi, "
                "MusteriTelCep, MusteriTelEv, MusteriTelIs FROM Musteri "
                "WHERE MusteriSilme=0 AND REPLACE(MusteriTCKN,' ','') LIKE ? "
                "ORDER BY CASE WHEN ISNULL(MusteriAdresi,'')='' THEN 1 ELSE 0 END, MusteriAdiSoyadi",
                limit, digits + "%").fetchall()
            out.extend(_musteri_to_recipient(r) for r in rows)
        else:
            like = "%" + q + "%"
            rows = cur.execute(
                "SELECT TOP (?) MusteriAdiSoyadi, MusteriTCKN, MusteriAdresi, "
                "MusteriTelCep, MusteriTelEv, MusteriTelIs FROM Musteri "
                "WHERE MusteriSilme=0 AND MusteriAdiSoyadi LIKE ? "
                "AND ISNULL(MusteriAdresi,'')<>'' ORDER BY MusteriAdiSoyadi",
                limit, like).fetchall()
            out.extend(_musteri_to_recipient(r) for r in rows)
            krows = cur.execute(
                "SELECT TOP (?) KurumAdi, KurumAdresi, KurumTelefon FROM Kurum "
                "WHERE KurumSilme=0 AND KurumAdi LIKE ? AND ISNULL(KurumAdresi,'')<>'' "
                "ORDER BY KurumAdi", limit, like).fetchall()
            out.extend({
                "ad": (r.KurumAdi or "").strip(), "tckn": "",
                "adres": (r.KurumAdresi or "").strip(),
                "telefon": _fmt_phone(r.KurumTelefon), "tip": "kurum", "kaynak": "botanik",
            } for r in krows)
    # Aynı (ad, adres) tekrarını ele
    seen, uniq = set(), []
    for r in out:
        k = (r["ad"], r["adres"])
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    return uniq[:limit]


def search_recipients_from_settings(settings: dict, query: str, limit: int = 15) -> list[dict]:
    """Botanik'ten kargo alıcısı (hasta/kurum) arar.

    NOT: 'botanik_db_enabled' yalnız FİYAT kaynağı içindir; alıcı adresi/telefonu
    için yerel kopya tutulmadığından (KVKK) bağlantı YAPILANDIRILMIŞSA (sunucu +
    kullanıcı + şifre dolu) her zaman canlı sorgulanır. Bağlantı yoksa/hata olursa
    boş döner (yerel adres defteri yine çalışır).
    """
    p = settings_to_params(settings)
    if not (p["server"] and p["user"] and p["password"]):
        return []
    try:
        return search_recipients(query=query, limit=limit, **p)
    except BotanikDBError as e:
        log.warning("Botanik alıcı arama hatası: %s", e)
        return []


def resolve_price(app_conn, settings: dict, barkod: str) -> dict | None:
    """Barkod için fiyat çözümle. 'botanik_db_enabled' AÇIKSA önce CANLI Botanik
    veritabanından dener; bağlantı/kayıt yoksa YEREL kataloga düşer. Kapalıysa
    doğrudan yerel katalogdan okur.

    Dönüş: {ad, barkod, fiyat, kamu_fiyat, stok, kaynak} ('botanik'|'yerel') veya None.
    """
    barkod = (barkod or "").strip()
    if not barkod:
        return None
    enabled = str(settings.get("botanik_db_enabled", "0")).strip() in ("1", "true", "True")
    if enabled:
        try:
            u = price_by_barcode(barkod=barkod, **settings_to_params(settings))
            if u is not None:
                return {"ad": u.ad, "barkod": u.barkod, "fiyat": u.fiyat,
                        "kamu_fiyat": u.kamu_fiyat, "stok": u.stok, "kaynak": "botanik"}
        except BotanikDBError as e:
            log.warning("Canlı Botanik fiyat alınamadı, yerel kataloga düşülüyor: %s", e)
    from .db import botanik_katalog_price
    row = botanik_katalog_price(app_conn, barkod)
    if row:
        return {"ad": row["ad"], "barkod": row["barkod"], "fiyat": row["fiyat"],
                "kamu_fiyat": row["kamu_fiyat"], "stok": row["stok"], "kaynak": "yerel"}
    return None
