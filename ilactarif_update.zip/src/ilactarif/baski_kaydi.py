"""Etiket BASILDI kaydı + etiket durum kuralları (yeşil / sarı / kırmızı çerçeve).

Kullanıcı kuralı (2026-11-28):
  • Reçete sonu kısayolu (Shift+End) etiketi basılan ilaç → kalıcı "basıldı"
    kaydı (YEŞİL çerçeve). Aynı reçetede Shift+End tekrar basılınca bunlar bir
    daha basılmaz.
  • Elde olmayan ilaç (stok yetmiyor) → basılmaz, kayıt oluşmaz (SARI çerçeve).
    Ecza deposundan gelip stoğa girilince sonraki Shift+End onu basar.
  • SGK'nın ödemediği ilaç → Shift+End basmaz (KIRMIZI çerçeve); yalnız
    "SGK Ödemediği İlaçları Bas" kısayolu/butonu basar → yeşile döner.

Kayıt ana DB'de (data/ilactarif.db, git'e giriyor) DEĞİL, ayrı yerel dosyada
(data/baski_kaydi.db, gitignore'da) tutulur: her baskıda değişen bir kayıt ana
DB'yi her seferinde değiştirip makineler arası git senkronunu bozardı. Kayıt
o bilgisayara özeldir (etiketi basan makine).
"""
from __future__ import annotations

import datetime
import logging
import sqlite3
from pathlib import Path
from typing import Iterable, Optional

from .db import PROJECT_ROOT

log = logging.getLogger(__name__)

KAYIT_DB_PATH = PROJECT_ROOT / "data" / "baski_kaydi.db"
# Bu kadar günden eski kayıtlar açılışta silinir (reçete artık tekrar basılmaz).
SAKLAMA_GUN = 120

# Etiket durumları (çerçeve rengi)
BASILDI = "basildi"        # yeşil
ODENMEYEN = "odenmeyen"    # kırmızı
STOK_YOK = "stok_yok"      # sarı
NORMAL = "normal"          # henüz basılmadı, basılabilir (varsayılan çerçeve)

DURUM_RENK = {
    BASILDI: "#1fa34a",
    ODENMEYEN: "#d01818",
    STOK_YOK: "#f2c200",
}


# ---------------------------------------------------------------------------
# Kurallar (saf fonksiyonlar — test edilir)
# ---------------------------------------------------------------------------
def stokta_yok(stok: Optional[int], kutu: Optional[int], kayitli: bool) -> bool:
    """İlaç elimizde YOK mu (etiket basılmamalı mı)?

    kayitli=True (reçete KAYDEDİLDİ, stok reçetedeki kutular kadar düşüldü):
        stok + kutu <= 0 → yok.  Örn. elde 3, reçete 4 → stok -1 → -1+4=3 > 0
        → 3 kutu verildi, basılır.  Elde 0, reçete 3 → stok -3 → 0 → basılmaz.
    kayitli=False (Reçete No 0, stok henüz düşülmedi):
        stok <= 0 → yok.  Elde en az 1 kutu varsa basılır.
    Stok okunamadıysa (None) → bilinmiyor, engellenmez.
    """
    if stok is None:
        return False
    if not kayitli:
        return stok <= 0
    k = kutu or 1
    return (stok + k) <= 0


def etiket_durumu(*, basildi: bool, odenmeyen: bool, stok_yok: bool) -> str:
    """Çerçeve durumu. Öncelik: basıldı > SGK ödemiyor > stok yok > normal."""
    if basildi:
        return BASILDI
    if odenmeyen:
        return ODENMEYEN
    if stok_yok:
        return STOK_YOK
    return NORMAL


# ---------------------------------------------------------------------------
# Kalıcı kayıt
# ---------------------------------------------------------------------------
_SCHEMA = """
CREATE TABLE IF NOT EXISTS etiket_baski (
    recete_key  TEXT NOT NULL,
    barkod      TEXT NOT NULL,
    drug_id     INTEGER,
    ilac_ad     TEXT NOT NULL DEFAULT '',
    kaynak      TEXT NOT NULL DEFAULT '',   -- recete_sonu / recete_basi / odenmeyen / elle
    zaman       TEXT NOT NULL,
    PRIMARY KEY (recete_key, barkod)
);
CREATE INDEX IF NOT EXISTS idx_etiket_baski_zaman ON etiket_baski(zaman);
"""


class BaskiKaydi:
    """recete_key + barkod → basıldı kaydı. Hatalar loglanır, baskıyı durdurmaz."""

    def __init__(self, path: Path | str | None = None):
        self.path = Path(path) if path else KAYIT_DB_PATH
        self._ok = False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._conn() as c:
                c.executescript(_SCHEMA)
                sinir = (datetime.datetime.now()
                         - datetime.timedelta(days=SAKLAMA_GUN)).isoformat(timespec="seconds")
                c.execute("DELETE FROM etiket_baski WHERE zaman < ?", (sinir,))
            self._ok = True
        except Exception:
            log.exception("Baskı kaydı DB açılamadı: %s", self.path)

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path, timeout=5)

    def basilanlar(self, recete_key: str) -> set[str]:
        """Bu reçetede etiketi basılmış barkodlar."""
        if not (self._ok and recete_key):
            return set()
        try:
            with self._conn() as c:
                rows = c.execute("SELECT barkod FROM etiket_baski WHERE recete_key = ?",
                                 (recete_key,)).fetchall()
            return {r[0] for r in rows}
        except Exception:
            log.exception("Baskı kaydı okunamadı")
            return set()

    def kaydet(self, recete_key: str, items: Iterable, kaynak: str) -> None:
        """Etiketi yazıcıya giden ilaçları 'basıldı' olarak kaydet."""
        if not (self._ok and recete_key):
            return
        now = datetime.datetime.now().isoformat(timespec="seconds")
        rows = [(recete_key, it.barkod, getattr(it, "drug_id", None),
                 getattr(it, "drug_ad", "") or "", kaynak, now)
                for it in items if getattr(it, "barkod", "")]
        if not rows:
            return
        try:
            with self._conn() as c:
                c.executemany(
                    "INSERT OR REPLACE INTO etiket_baski"
                    "(recete_key, barkod, drug_id, ilac_ad, kaynak, zaman) "
                    "VALUES (?, ?, ?, ?, ?, ?)", rows)
        except Exception:
            log.exception("Baskı kaydı yazılamadı")
