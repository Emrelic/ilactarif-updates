"""DB'den çekilen ilaç bilgisiyle etiket(ler) üretir.

Akış:
  1. drugs tablosundan ilaç metadata'sını al (form, doz, sıklık, yemek, kategori).
  2. drug_label_blocks'tan kritik bloğu al (dikkat → kısa UYARI metni).
  3. build_kullanim_talimati() ile büyük talimat cümlesini üret.
  4. Mevcut UsageLabel dataclass'ını doldur, render_usage_label() ile çiz.
  5. should_print_secondary() ile 2. etiket gerekiyorsa onu da üret:
       - hazirlama bloğu varsa → PreparationLabel (TİP B)
       - teknik bloğu varsa  → WarningLabel adımlar olarak (TİP A)
       - kritik ATC etkileşim → WarningLabel uyarı listesi (TİP C)

Tek noktadan çağrı: build_labels_for_drug(drug_id, hasta_adi, recete_tarihi)
                    → list[PIL.Image] (1 veya 2 görsel)
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Optional

from PIL import Image

from .db import get_connection
from .drug_guess import (
    build_kullanim_talimati,
    format_dose_amount,
    is_eye_ear_drop_name,
)
from .label_render import (
    _grid_dose_token,
    render_glucose_guide_label,
    render_preparation_label,
    render_usage_label,
    render_warning_label,
)
from .models import PreparationLabel, UsageLabel, WarningLabel
from .preparation_recipes import PREP_TITLE, prep_category


# Öğün ilişkisi → ters renkli rozet. Açıklayıcı metin basılır (yalnız AÇ/TOK'a
# indirgenmez); rozet metni uzunsa render sağa doğru uzatır.
_MEAL_BADGE_MAP: dict[str, str] = {
    "aç": "AÇ",
    "tok": "TOK",
    "fark etmez": "AÇ TOK FARKETMEZ",
    "yemekle": "YEMEKLE",
    "yemekten önce": "YEMEKTEN ÖNCE",
    "yemekten sonra": "YEMEKTEN SONRA",
    "yemeğin hemen başında": "YEMEKLE",
    "yemek başlangıcında": "YEMEK BAŞINDA",
}


@dataclass
class LabelSpec:
    """Bir etiketin görseli + UI'ın baskı/onay/düzenleme için ihtiyaç duyduğu meta.

    kind:          'A' (temel kullanım) | 'B' (hazırlama/teknik) | 'C' (ciddi uyarı)
    default_print: Baskı checkbox'ının VARSAYILAN durumu (A=her zaman True,
                   B=True, C=şiddet 'high' ise True, 'low' ise False)
    severity:      C için 'high' | 'low'; diğerlerinde ''
    editable:      Metni düzenlenebilir mi (B/C True, A False)
    edit_block:    Düzenleme ekranının güncelleyeceği drug_label_blocks.block_type
    custom_text:   Kullanıcı daha önce düzenlediyse mevcut özel metin
    """
    kind: str
    title: str
    image: Image.Image
    default_print: bool = True
    severity: str = ""
    editable: bool = False
    edit_block: str = ""
    custom_text: str = ""
    text_lines: list[str] = field(default_factory=list)  # düzenleme ekranı ön-doldurması


# ============================================================
# Kullanıcı tercihleri (drug_label_prefs): suppress + custom_text
# ============================================================

def get_label_pref(
    conn: sqlite3.Connection, drug_id: int, kind: str
) -> tuple[bool, str]:
    """(suppressed, custom_text) döner. Kayıt yoksa (False, '')."""
    row = conn.execute(
        "SELECT suppressed, custom_text FROM drug_label_prefs "
        "WHERE drug_id = ? AND label_kind = ?",
        (drug_id, kind),
    ).fetchone()
    if not row:
        return (False, "")
    return (bool(row["suppressed"]), row["custom_text"] or "")


def set_label_suppressed(
    conn: sqlite3.Connection, drug_id: int, kind: str, suppressed: bool = True
) -> None:
    """Bu ilaç için bu etiket tipini kalıcı kapat/aç ('bir daha gösterme')."""
    conn.execute(
        """
        INSERT INTO drug_label_prefs (drug_id, label_kind, suppressed, updated_at)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(drug_id, label_kind)
        DO UPDATE SET suppressed = excluded.suppressed, updated_at = CURRENT_TIMESTAMP
        """,
        (drug_id, kind, 1 if suppressed else 0),
    )
    conn.commit()


def get_label_print_override(
    conn: sqlite3.Connection, drug_id: int, kind: str
) -> Optional[bool]:
    """Baskı kutusu varsayılan ezme tercihi. None = hesaplanan varsayılanı kullan;
    True = zorla işaretli; False = zorla işaretsiz."""
    row = conn.execute(
        "SELECT print_override FROM drug_label_prefs "
        "WHERE drug_id = ? AND label_kind = ?",
        (drug_id, kind),
    ).fetchone()
    if not row or row["print_override"] is None:
        return None
    return bool(row["print_override"])


def set_label_print_override(
    conn: sqlite3.Connection, drug_id: int, kind: str, value: Optional[bool]
) -> None:
    """Baskı kutusu varsayılanını kalıcı ez. value: None = hesaplanana dön;
    True = zorla işaretli; False = zorla işaretsiz. Etiket GÖSTERİLMEYE devam eder."""
    ov = None if value is None else (1 if value else 0)
    conn.execute(
        """
        INSERT INTO drug_label_prefs (drug_id, label_kind, print_override, updated_at)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(drug_id, label_kind)
        DO UPDATE SET print_override = excluded.print_override, updated_at = CURRENT_TIMESTAMP
        """,
        (drug_id, kind, ov),
    )
    conn.commit()


def set_label_custom_text(
    conn: sqlite3.Connection, drug_id: int, kind: str, text: str
) -> None:
    """Kullanıcının düzenlediği etiket metnini kaydet (boş string = düzenlemeyi sıfırla)."""
    conn.execute(
        """
        INSERT INTO drug_label_prefs (drug_id, label_kind, custom_text, updated_at)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(drug_id, label_kind)
        DO UPDATE SET custom_text = excluded.custom_text, updated_at = CURRENT_TIMESTAMP
        """,
        (drug_id, kind, text or None),
    )
    conn.commit()


# ------------------------------------------------------------------
# Etiket METNİ düzenleme (sağ-tık → "metni kalıcı düzenle") yardımcıları
# ------------------------------------------------------------------
def get_label_edit_state(
    drug_id: int, kind: str, hasta_adi: str = ""
) -> tuple[bool, str, str]:
    """Bir etiketin (drug_id, kind) düzenleme durumunu döner.

    Döner: (düzenlenebilir_mi, mevcut_efektif_metin, başlık)
    Metin satır-satırdır (her satır bir madde/adım). custom_text varsa onu,
    yoksa otomatik üretilen satırları yansıtır — düzenleyiciye ön-dolgu olur.
    """
    conn = get_connection()
    try:
        for sp in build_label_plan(drug_id, hasta_adi, None, conn=conn):
            if sp.kind == kind:
                return (sp.editable, "\n".join(sp.text_lines), sp.title)
        return (False, "", "")
    finally:
        conn.close()


def render_label_preview(
    drug_id: int, kind: str, custom_text: str, hasta_adi: str = ""
) -> Optional[Image.Image]:
    """custom_text'i KALICI yazmadan etiket önizlemesini üretir.

    Geçici bağlantıda metni yazar, plana yansıtıp görseli alır, sonra rollback
    eder — DB'ye hiçbir kalıcı değişiklik yazılmaz.
    """
    conn = get_connection()
    try:
        conn.execute(
            """
            INSERT INTO drug_label_prefs (drug_id, label_kind, custom_text, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(drug_id, label_kind)
            DO UPDATE SET custom_text = excluded.custom_text
            """,
            (drug_id, kind, custom_text or None),
        )
        for sp in build_label_plan(drug_id, hasta_adi, None, conn=conn):
            if sp.kind == kind:
                return sp.image
        return None
    finally:
        conn.rollback()   # KALICI yazma yok
        conn.close()


def save_label_text_and_render(
    drug_id: int, kind: str, custom_text: str, hasta_adi: str = ""
) -> Optional[Image.Image]:
    """custom_text'i KALICI kaydeder (boş = otomatiğe dön) ve güncel görseli döner."""
    conn = get_connection()
    try:
        set_label_custom_text(conn, drug_id, kind, custom_text)  # commit eder
        for sp in build_label_plan(drug_id, hasta_adi, None, conn=conn):
            if sp.kind == kind:
                return sp.image
        return None
    finally:
        conn.close()


# C etiketinde "varsayılan işaretli" olacak YÜKSEK şiddet anahtar kelimeleri
_HIGH_SEVERITY_KEYWORDS = (
    "KAN SULANDIRICI", "GREYFURT", "DİSÜLFİRAM", "ANAFİLAKSİ",
    "HAYATİ", "CANLI AŞI", "KALP KRİZİ", "İNME", "ZEHİRLENME",
)


def _serious_severity(
    atc_code: str | None, etkilesim: str, dikkat: str
) -> str:
    """C etiketi şiddeti: 'high' (varsayılan işaretli) | 'low' (varsayılan işaretsiz)."""
    if atc_code:
        code = atc_code.upper()
        for pfx in CRITICAL_ATC_PREFIXES:
            if code.startswith(pfx):
                return "high"
    blob = f"{etkilesim or ''} {dikkat or ''}".upper()
    if any(k in blob for k in _HIGH_SEVERITY_KEYWORDS):
        return "high"
    return "low"


# ============================================================
# 2. ETİKET TETİKLEYİCİLERİ
# ============================================================

# Form bazlı: HAZIRLAMA gerektiren formlar (TİP B etiketi)
PREP_FORMS = {
    "powder_for_suspension",
}

# Form bazlı: UYGULAMA TEKNİĞİ gerektiren formlar (TİP A etiketi)
TECHNIQUE_FORMS = {
    "inhaler_pmdi",
    "inhaler_dpi",
    "nebule",
    "injection_sc",      # cilt altı (insulin, heparin — evde uygulanır)
    "eye_drop",
    "ear_drop",
    "nasal_spray",
    "nasal_drop",
    "sublingual_spray",  # Nitrolingual: oturarak + dil altına + 112 (kritik teknik)
    "suppository_rectal",
    "enema_rectal",      # lavman / rektal süspansiyon (aplikatörlü)
    "cream_rectal",      # hemoroid kremi/merhemi — makat bölgesine, kanül tekniği
    "vaginal_ovule_or_cream",
    "transdermal_patch",
}

# Astım/KOAH solunum inhalerleri — kullanım tekniği etiketinin (B) YANINDA ayrıca
# "DİKKAT EDİLECEK HUSUSLAR" ek etiketi (TİP D) basılan formlar.
INHALER_FORMS = {"inhaler_pmdi", "inhaler_dpi", "nebule"}

# Enjektabl formlar: ağızdan ALINMAZ → bloklardan gelen "yemekle alınız /
# su ile yutunuz / aç-tok karnına" tarzı ORAL tavsiyeler bu formlarda yanlış
# kaynaktan kopyalanmıştır; C etiketine sızdırılmaz.
_INJECTION_FORMS = {"injection_im", "injection_iv", "injection_sc"}


def _tr_lower(s: str) -> str:
    """Türkçe güvenli küçük harf (İ→i, I→ı; re.IGNORECASE İ'yi yakalayamaz)."""
    return (s or "").replace("İ", "i").replace("I", "ı").lower()


# Oral alım tavsiyesi kalıpları (tr_lower edilmiş metinde aranır)
_ORAL_ADVICE_RX = re.compile(
    r"yut(?!may)|çiğne|aç karn|tok karn|kahvaltı|suda erit|bir bardak"
    r"|yemekle (birlikte )?al|yemekten (hemen )?(sonra|önce)|öğün atla"
)


def _drop_oral_advice(items: list[str]) -> list[str]:
    """Enjektabl ilacın C maddelerinden oral alım tavsiyelerini ayıklar."""
    return [u for u in items if not _ORAL_ADVICE_RX.search(_tr_lower(u))]


# Deriye sürülen ürünün C maddelerine sızan SİSTEMİK-ORAL uyarı kalıpları:
# topikal jel/krem prospektüs blokları bazen aynı ATC'li ORAL ürünün
# şablonundan kopyalanmış oluyor (Tiyokas jel vakası — mide kanaması,
# varfarin/lityum/SSRI etkileşimi, alkol+uyku hali). Bunlar cilde sürülen
# üründe anlamsız/korkutucu. Gebelik, alerji, ciltte yanık gibi topikalde de
# geçerli uyarılar BİLEREK listede yok.
_SYSTEMIC_LEAK_RX = re.compile(
    r"varfarin|lityum|metotreksat|ssri|mide kanama|mide ülser|siyah dışkı"
    r"|kan kusma|kalp krizi|\binme\b|diş çekimi|alkol|uyku|sersemlik"
)


def _drop_systemic_for_topical(items: list[str]) -> list[str]:
    """Cilt-topikal ilacın C maddelerinden oral/sistemik sızıntıyı ayıklar."""
    return [
        u for u in items
        if not _SYSTEMIC_LEAK_RX.search(_tr_lower(u))
        and not _ORAL_ADVICE_RX.search(_tr_lower(u))
    ]

# ATC prefix bazlı: KRİTİK UYARI/ETKİLEŞİM gerektirenler (TİP C etiketi)
# Eşleşme: drug.atc_code o prefix ile başlıyorsa
CRITICAL_ATC_PREFIXES = (
    "B01AA",   # varfarin (K vitamini etkileşimi, ameliyat öncesi bırakma)
    "B01AC04", # klopidogrel (kanama, ameliyat)
    "B01AF",   # DOAK (rivaroksaban, apiksaban — kanama)
    "P01AB",   # metronidazol/ornidazol (ALKOL — disülfiram reaksiyonu)
    "H02A",    # sistemik kortikosteroid (ANİ KESME YASAK)
    "N03",     # antiepileptik (ani kesme yasak, gebelik)
    "H03AA",   # levotiroksin (sabah aç + 4 saat ara)
    "M05B",    # bisfosfonat (30 dk yatma yasak, diş işlemi)
    "M04AC01", # kolşisin (GREYFURT, statin tehlikesi)
    "C10AA",   # statin (greyfurt, kas ağrısı)
    "J01FA",   # makrolid (kalp ritm, statin)
    "L04",     # immün baskılayıcı (enfeksiyon, canlı aşı yasağı)
    "A10A",    # insülin (saklama + acil hipoglisemi)
    "D10AD",   # topikal retinoidler (tretinoin/adapalen/kombolar — gece+güneş+gebelik)
    "D10AE",   # benzoil peroksit (güneş hassasiyeti, kumaş ağartma)
    "D10AF02", # eritromisin topikal (temel kullanım bilgisi)
    "D10AF05", # nadifloksasin topikal (topikal kinolon — uygulama + güneş)
    "D10AX03", # azelaik asit (ilk haftalarda tolerans + gebelik notu)
    "D10AX03", # azelaik asit (ilk haftalarda tolerans + gebelik notu)
    "D10BA",   # oral izotretinoin (GEBELİKTE KESİN YASAK — ağır teratojen)
    "D05BB",   # oral asitretin/retinoid (GEBELİKTE KESİN YASAK)
    "G04BE",   # ereksiyon ilacı (NİTRATLI kalp ilacıyla ÖLÜMCÜL etkileşim)
    "S01XA18", # oftalmik siklosporin (Restasis/Depores — etki 3-6 ayda, bırakma riski)
    "D11AX11", # hidrokinon (Expigment — güneşten korunma şart, leke geri koyulaşır)
    "N02CC",   # triptan (atak zamanlaması + aşırı kullanım baş ağrısı)
    "N02CA",   # ergotamin kombinasyonu (günlük/haftalık sınır — ergotizm)
    "G03AA",   # kombine oral kontraseptif (tromboz belirtileri, sigara riski)
    "G03AB",   # faz-değişken oral kontraseptif (tromboz belirtileri)
    "S01ED",   # beta-bloker göz damlası (timolol vb. — astım/KOAH riski sistemik emilim)
    "S01EE",   # prostaglandin analog göz damlası (latanoprost — iris/kirpik kalıcı değişim)
    "C09AA",   # ACE inhibitörü (gebelik 2-3. trimester KESİN YASAK, potasyum/böbrek)
    "C09BA",   # ACE + diüretik kombinasyonu (aynı gebelik yasağı)
)


# Medikal malzeme / cihaz ATC prefiksleri — etiket BASILMAZ
# (V03 dahil edilebilir bazı durumda; V07 ve V08 net tıbbi yardımcı/malzeme)
MEDICAL_DEVICE_ATC_PREFIXES = (
    "V07",   # Diğer tıbbi olmayan ürünler (tıbbi malzeme, test çubuğu vb.)
    "V08",   # Radyolojik kontrast (zaten hastane uygulaması)
    "V09",   # Diagnostic radyofarmasötik
)

# Form yokken etiket basmamak için ATC adında "STRIP", "TEST", "ÇUBUK"
# geçen şüpheli ürünler — V07 ATC'si yoksa bile yakala
MEDICAL_DEVICE_KEYWORDS = (
    "CIHAZI", "CİHAZI", "CIHAZ", "CİHAZ",
    "TEST CUBUK", "TEST ÇUBUK", "TEST STRIP",
    "STRIP", "LANSET", "İĞNE UCU",
    "GLUKOMETRE", "TANSIYON ALETI", "TANSİYON ALETİ",
    "TERMOMETRE", "MASK", "MASKE",
    "BANDAJ", "FLASTER", "GAZLI BEZ",
    "OSTOMI", "OSTOMİ", "KATETER", "TORBA",
)


def is_medical_device(drug_row) -> bool:
    """Drug row'unun medikal malzeme/cihaz olup olmadığını tespit eder.

    Kriter (herhangi biri doğruysa):
      - ATC kodu V07*/V08*/V09* ile başlar
      - drug_type='SKRS' VE form=None VE indication_short=None (yapısal hiçbir bilgi yok)
      - İlaç adında medikal cihaz/malzeme anahtar kelimesi geçer
    """
    atc = (drug_row["atc_code"] or "").upper()
    for pfx in MEDICAL_DEVICE_ATC_PREFIXES:
        if atc.startswith(pfx):
            return True
    # Ad anahtar kelimesi (TORBA/FLASTER/MASKE...) tek başına yetmez: tedavi
    # edici ATC'si olan ürün GERÇEK ilaçtır (CAPD diyaliz TORBAsı B05D,
    # Durogesic N02AB transdermal FLASTER...) — classify_medical_device ile
    # aynı koruma; yoksa bu ilaçlara hiç etiket basılmıyordu.
    name = (drug_row["name"] or "").upper()
    if not atc:
        for kw in MEDICAL_DEVICE_KEYWORDS:
            if kw in name:
                return True
    # Son çare: SKRS kayıtlı ama yapısal bilgi YOK
    if (drug_row["drug_type"] == "SKRS"
            and not drug_row["form"]
            and not drug_row["indication_short"]):
        return True
    return False


# Medikal malzeme türüne göre etiket içeriği:
#   (kategori başlığı, sağ-sütun talimatı, küçük UYARI satırı)
# Bu ürünler İLAÇ DEĞİLDİR; "günde N kez bir bardak suyla yutunuz" basılmamalı.
DEVICE_LABEL_CONTENT: dict[str, tuple[str, str, str]] = {
    "glucose_strip": (
        "KAN ŞEKERİ ÖLÇÜM ÇUBUĞU",
        "PARMAK UCUNDAN ALINAN KAN İLE KAN ŞEKERİ ÖLÇÜMÜNDE KULLANILIR.",
        "Tıbbi malzemedir, ilaç değildir; ağızdan alınmaz. Cihaz kılavuzuna uyunuz.",
    ),
    "lancet": (
        "LANSET (İĞNE UCU)",
        "KAN ŞEKERİ ÖLÇÜMÜNDE PARMAK UCUNDAN KAN ALMAK İÇİN KULLANILIR.",
        "Her ölçümde yeni/steril lanset kullanınız; tek kullanımlıktır.",
    ),
    "glucometer": (
        "KAN ŞEKERİ ÖLÇÜM CİHAZI",
        "KULLANIM KILAVUZUNA GÖRE KAN ŞEKERİ ÖLÇÜMÜNDE KULLANILIR.",
        "Tıbbi cihazdır, ilaç değildir.",
    ),
    "device": (
        "TIBBİ MALZEME / CİHAZ",
        "TIBBİ MALZEMEDİR. KULLANIM TALİMATINA GÖRE KULLANINIZ.",
        "İlaç değildir; ağızdan alınmaz.",
    ),
}


# Bu cihaz türleri için iki sütunlu dozaj etiketi yerine TAM GENİŞLİKLİ
# "kan şekeri nasıl ölçülür" tarifi basılır (render_glucose_guide_label).
GUIDE_DEVICE_KINDS = frozenset({"glucose_strip", "glucometer"})

GLUCOSE_GUIDE_TITLE = "KAN ŞEKERİ NASIL ÖLÇÜLÜR?"

# Ölçüm adımları — her biri etikete tek satır sığacak kısalıkta, sadeleştirilmiş.
GLUCOSE_GUIDE_STEPS: list[str] = [
    "Ellerinizi sabun ve ılık suyla yıkayıp kurulayın.",
    "Cihaza yeni bir test çubuğu (strip) takın.",
    "Her ölçümde FARKLI bir parmağın ucunun yanını delin.",
    "Parmağı SIKMAYIN; kan damlası kendiliğinden oluşsun.",
    "İLK damlayı silin; ikinci damlayı çubuğa değdirin.",
    "Sonucu okuyup tarih–saat ile not edin.",
]

# Dikkat edilecek hususlar — sadeleştirilmiş, satır başına tek husus.
GLUCOSE_GUIDE_CAVEATS: list[str] = [
    "Açlık: sabah aç karnına; tokluk: yemekten 2 saat sonra ölçün.",
    "Genel hedef: açlık 80–130, tokluk <180 mg/dL (hekiminize danışın).",
    "70 mg/dL altında 15 g şeker alın (3 kesme şeker), 15 dk sonra ölçün.",
    "Parmağı alkol/kolonya ile silmeyin; sabun-su yeterlidir.",
    "Çubukları kapalı kutuda, serin-kuru yerde saklayın; SKT'ye dikkat.",
    "Her ölçümde yeni lanset kullanın, paylaşmayın.",
]


def classify_medical_device(name: str | None, atc_code: str | None = None) -> str:
    """İlaç adı (+varsa ATC) üzerinden medikal malzeme/cihaz türünü sınıflar.

    Gerçek ilaç ise '' döner. Döner:
        '' | 'glucose_strip' | 'lancet' | 'glucometer' | 'device'

    NOT: is_medical_device'ın "SKRS + form yok" sezgisini KULLANMAZ (çok geniş);
    sadece V07/V08/V09 ATC öneki veya net malzeme/çubuk/lanset adları yakalanır.
    Böylece gerçek bir ilacın dozaj/talimat bilgisi yanlışlıkla silinmez.
    """
    nm = (name or "").upper()
    atc = (atc_code or "").upper()

    # Kan şekeri ölçüm çubuğu (strip) tespiti — iki ayrı kalıpla:
    #  1) STRIP/STRIB + ölçüm bağlamı (ŞEKER/TEST/ÖLÇÜM…) — idrar/şeker stripleri.
    #     "STRIBILD" gibi ilaç adları tek başına STRIP/STRIB ile yakalanmaz; bağlam şart.
    #  2) ŞEKER/GLİKOZ bağlamı + ÇUBUK ifadesi. Türkçe yumuşak-g nedeniyle ad
    #     "ÖLÇÜM ÇUBUĞU / OLCUM CUBUGU" biçiminde gelir; "CUBUG/ÇUBUĞ" kökü ile
    #     yakalanır (örn. 'OKMETER DIRECT KAN SEKERI OLCUM CUBUGU', 'ACCU-CHEK …
    #     TEST CUBUGU'). Aksi halde V07 ATC'li ürün jenerik 'device' etiketine düşer.
    _sugar_ctx = ("SEKER", "ŞEKER", "GLIKOZ", "GLUKOZ", "GLİKOZ", "GLUCO")
    _strip_word = ("STRIP", "STRIB", "ÇUBUK", "CUBUK", "ÇUBUĞ", "CUBUG")
    # Bağımsız "STRIP" sözcüğü (STRIBILD'in gömülü "STRIB"i değil) + cihaz/şeker
    # bağlamı: 'ONE TOUCH ULTRA 50 STRIP', 'ACCU CHEK GO 50 STRIP', 'ONCALL
    # ADVANCED 50 STRIP' gibi marka glukometre striplerini yakalar. Bunlar V07
    # ATC'li olup adında ŞEKER/GLİKOZ geçmez; bağlam olarak V07/V08/V09 ATC önekini
    # ya da ATC'sizliği şart koşarak gerçek ilaçların (örn. J05'li STRIBILD) yanlış
    # sınıflanmasını önleriz.
    _tokens = set(nm.replace("-", " ").split())
    _strip_token = "STRIP" in _tokens and (
        any(k in nm for k in _sugar_ctx)
        or atc.startswith(MEDICAL_DEVICE_ATC_PREFIXES)
        or not atc
    )
    strip_hit = (
        (("STRIP" in nm or "STRIB" in nm)
         and any(k in nm for k in ("SEKER", "ŞEKER", "TEST", "OLCUM", "ÖLÇÜM", "GLIKOZ", "GLUKOZ")))
        or (any(k in nm for k in _sugar_ctx) and any(w in nm for w in _strip_word))
        or _strip_token
        or "TEST CUBUK" in nm or "TEST ÇUBUK" in nm
        or "OLCUM CUBUK" in nm or "ÖLÇÜM ÇUBUK" in nm
        or "OLCUM CUBUG" in nm or "ÖLÇÜM ÇUBUĞ" in nm
    )

    is_device = (
        strip_hit
        or any(atc.startswith(p) for p in MEDICAL_DEVICE_ATC_PREFIXES)
        or any(kw in nm for kw in MEDICAL_DEVICE_KEYWORDS)
    )
    if not is_device:
        return ""

    if "LANSET" in nm or "İĞNE UCU" in nm or "IGNE UCU" in nm:
        return "lancet"
    if strip_hit:
        return "glucose_strip"
    if (any(k in nm for k in ("CIHAZI", "CİHAZI", "GLUKOMETRE", "OLCME CIHAZ",
                              "OLCUM SISTEMI", "ÖLÇÜM SİSTEMİ"))
            and any(k in nm for k in ("SEKER", "ŞEKER", "GLIKOZ", "GLUKOZ"))):
        return "glucometer"

    # Genel malzeme: yalnızca cihaz ATC'si (V07/V08/V09) ya da ATC'si olmayan
    # ürünlerde güven. Tedavi edici ATC'si olanlar (örn. DUROGESIC=N02AB,
    # NICOTINELL=N07BA, CLIMARA=G03CA transdermal FLASTER; B05* diyaliz/serum
    # TORBA) GERÇEK ilaçtır — adında "FLASTER"/"TORBA" geçti diye talimatı
    # silinmemeli; bu yüzden tedavi edici ATC'de ilaç sayılır ('').
    if atc and not atc.startswith(MEDICAL_DEVICE_ATC_PREFIXES):
        return ""
    return "device"


# Kritik ATC için BÜYÜK PUNTO etiketine basılacak özel kısa mesaj
# (FLAGYL alkol uyarısı örneğindeki gibi 2-3 satıra sığacak)
CRITICAL_MESSAGES: dict[str, str] = {
    "B01AA":   ("KAN SULANDIRICI! Diş çekimi, ameliyat, yeni ilaç başlanması durumunda "
                "MUTLAKA doktorunuza bildirin. Aspirin/ağrı kesici ALMAYIN."),
    "B01AC04": ("KAN SULANDIRICI! Diş çekimi/ameliyat öncesi 5-7 gün önce bırakılması "
                "gerekebilir. KESİNLİKLE doktor önerisi olmadan bırakmayın."),
    "B01AF":   ("KAN SULANDIRICI! Diş çekimi/ameliyat öncesi doktora BİLDİRİN. "
                "Olağandışı kanama belirtilerini hemen bildirin."),
    "P01AB":   ("BU İLACI KULLANIRKEN KESİNLİKLE ALKOL TÜKETMEYİNİZ! "
                "Tedavi bittikten sonra da 3 GÜN ALKOL ALMAYINIZ. "
                "İDRAR KAHVERENGİ/KOYU RENK OLABİLİR — bu normaldir, endişelenmeyin."),
    "H02A":    ("KORTİZON İLACI — KESİNLİKLE ANİ BIRAKMAYIN! Kademeli azaltılmalı. "
                "Enfeksiyon belirtilerinde doktora başvurun. "
                "TUZ ALIMINI AZALTIN — şişlik ve tansiyon yapar. "
                "ŞEKERLİ VE NIŞASTALI YIYECEKLERI KISITLAYIN — kan şekerini yükseltir."),
    "N03":     ("ANTİEPİLEPTİK — KESİNLİKLE ani bırakmayın (nöbet riski). "
                "Gebelik planı varsa doktora bildirin."),
    "H03AA":   ("SABAH AÇ KARNINA, kahvaltıdan EN AZ 30-60 dk önce alınız. "
                "Demir/kalsiyum/soya ile 4 saat ara verin."),
    "M05B":    ("Aç karnına bol su ile alınız. 30-60 dk YATMAYIN, başka ilaç almayın. "
                "Diş işlemi öncesi bildirin."),
    "M04AC01": ("GREYFURT SUYU ile KULLANMAYIN. Şiddetli ishal, kas ağrısı veya kemik iliği "
                "belirtilerinde HEMEN doktora başvurun."),
    "C10AA":   ("GREYFURT SUYU ile KULLANMAYIN. Kas ağrısı, koyu idrar varsa doktora başvurun. "
                "Akşam alınması daha etkilidir."),
    "J01FA":   ("KALP RİTMİNE DİKKAT — kalp ritim bozukluğu (QT uzaması) yapabilir; "
                "kalp ilacı kullanıyorsanız veya kalp hastalığınız varsa doktorunuza bildirin. "
                "Astemizol, sisaprid, pimozid, terfenadin ile KULLANILMAZ. "
                "Statin kullanıyorsanız bildirin."),
    "L04":     ("BAĞIŞIKLIK BASKILANIYOR — enfeksiyona DİKKAT. CANLI AŞI YAPILMAZ. "
                "Düzenli kan testi şart."),
    "A10A":    ("İNSÜLİN — buzdolabında saklayın, kullanımdaki kalem oda sıcaklığında 28 gün. "
                "Düşük şeker kartınız ve glukagon yanınızda olsun."),
    # --- Yeni görünür kategoriler (2026-06: uyarı denetimi) ---
    "D10BA":   ("GEBELİKTE KESİNLİKLE YASAK — bebekte ağır sakatlık/ölüm. Tedaviden 1 ay "
                "önce başlayıp bitiminden 1 ay sonrasına kadar ETKİLİ korunma şart. "
                "Güneşten korunun; ALKOL ALMAYIN (karaciğer + trigliserid); kan bağışı yapmayın. "
                "Kuru dudak/cilt/göz/burun BEKLENİR — nemlendirici kullanın; "
                "dudak kremi, göz damlası yanınızda bulundurun. "
                "Tedavi süresince düzenli KAN TESTİ (lipid, karaciğer) zorunludur."),
    "D05BB":   ("GEBELİKTE KESİNLİKLE YASAK — bittikten sonra 3 YIL gebe kalmayın. "
                "Alkol ALMAYIN, kan bağışı yapmayın. Güneşten korunun."),
    "N05BA":   ("UYKU/SERSEMLİK yapar — araç ve tehlikeli makine KULLANMAYIN, ALKOL ALMAYIN. "
                "Bağımlılık yapar; aniden bırakmayın (doz kademeli azaltılır)."),
    "N02A":    ("UYKU/SERSEMLİK ve solunum baskılanması — araç/makine KULLANMAYIN, "
                "ALKOL ALMAYIN. Kabızlık sık görülür; aniden bırakmayın."),
    "M03B":    ("UYKU/SERSEMLİK yapar — araç ve tehlikeli makine kullanmaya dikkat. "
                "Alkol etkisini artırır."),
    "J01MA":   ("GÜNEŞE karşı cilt hassasiyeti — güneşten korunun. Süt/kalsiyum/demir ile "
                "2 saat ara verin. Tendon ağrısı olursa bırakıp doktora başvurun."),
    "J01AA":   ("GÜNEŞE karşı hassasiyet — güneşten korunun. Bol su ile DİK durarak alın, "
                "İÇTİKTEN SONRA EN AZ 1 SAAT YATMAYIN. Süt/kalsiyum/demir ile 2 saat ara verin."),
    "C01BD01": ("GÜNEŞE karşı çok hassaslaşır (ağır yanık, gri-mavi renk) — güneşten korunun. "
                "GREYFURT ile kullanmayın; düzenli kalp/tiroid/akciğer kontrolü şart."),
    # Topikal retinoidler (tretinoin/adapalen/izotretinoin) — fotosensitivite + gebelik.
    # D10AD: tretinoin (01), adapalen (03), kombolar (51=tretinoink 54=izotretinoin).
    "D10AD": ("AKŞAM (gece) yatmadan önce, temiz ve KURU cilde ince tabaka sürülür. "
              "Sabah kullanmayın — GÜNEŞE karşı hassaslaşır; gündüz GÜNEŞ KORUYUCU kullanın. "
              "Göz, ağız, burun delikleri ve dudaklardan UZAK tutun. "
              "İlk 2-4 haftada kızarıklık, soyulma, yanma OLAĞANDIR — birakmayin, azalır. "
              "GEBELİKTE KULLANILMAZ (A vitamini türevi); gebelik planıyorsanız doktorunuza danışın."),
    # Benzoil peroksit (BPO) — fotosensitivite + ağartma.
    "D10AE": ("Benzoil peroksit içerir — cilt GÜNEŞE karşı hassaslaşır. "
              "Gündüz güneşten korunun, GÜNEŞ KORUYUCU kullanın. "
              "Saç, kaş, kirpik ve renkli kumaşa (havlu, yastık kılıfı, elbise) temas etmesi ağartır. "
              "Akşam uygulanması önerilir."),
    # Benzoil peroksitli akne jelleri (Clindoxyl/Acnemix vb.) — fotosensitivite.
    "D10AF51": ("Benzoil peroksit içerir — cilt GÜNEŞE karşı hassaslaşır. Gündüz güneşten "
                "korunun, koruyucu krem kullanın. Saç, kaş ve renkli kumaşı ağartabilir."),
    "D10AF52": ("Benzoil peroksit içerir — cilt GÜNEŞE karşı hassaslaşır. Gündüz güneşten "
                "korunun, koruyucu krem kullanın. Saç, kaş ve renkli kumaşı ağartabilir."),
    # Nadifloksasin (topikal kinolon — D10AF05): kinolonlar için fotosensitvite
    # topikal formda sistemik kinolona göre çok daha düşük ama minimal uyarı yerinde.
    "D10AF05": ("Temiz ve kuru cilde, yalnızca akne olan bölgeye ince tabaka sürülür. "
                "Göz, ağız ve mukozadan uzak tutun. "
                "Uygulamadan sonra tedavi edilen cilt bölgesini gün içinde güneşe maruz bırakmayın."),
    # Eritromisin topikal (D10AF02) — temel kullanım + bölgesel antibiyotik uyarısı.
    "D10AF02": ("Temiz ve KURU cilde, yalnızca akneli bölgeye ince tabaka sürülür. "
                "Göz, ağız ve mukozadan uzak tutun; temas ederse bol su ile yıkayın. "
                "Etki yavaştır — belirgin düzelme 6-8 haftada; sabırla düzenli kullanın."),
    # Azelaik asit (D10AX03) — gebelikte görece güvenli; ilk haftalarda tolerans normal.
    "D10AX03": ("Temiz cilde günde 2 kez ince tabaka sürülür; gözden ve mukozadan uzak tutun. "
                "İlk 2-4 haftada hafif kızarıklık, yanma, soyulma OLAĞANDIR — devam edin, azalır. "
                "GEBELİKTE kullanmadan önce doktorunuza danışın."),
    # Ereksiyon ilaçları (sildenafil/tadalafil/vardenafil) — nitratla ölümcül
    # tansiyon düşmesi; kalp hastası efor riskini doktoruyla konuşmalı.
    "G04BE":   ("KALP İLACI kullanıyorsanız veya KALP HASTALIĞINIZ varsa doktorunuza "
                "DANIŞMADAN kullanmayın. NİTRAT içeren kalp ilacıyla (dilaltı tablet/sprey, "
                "İsordil vb.) ASLA birlikte almayın — tansiyon tehlikeli düşer. "
                "24 saatte 1 dozdan fazla almayın."),
    # Oftalmik siklosporin (Restasis/Depores/Ocurin) — etki birikerek aylar
    # içinde; hasta erken dönemde fayda görmeyince bırakıyor (2026-06-12,
    # KT/KÜB teyitli: en az 6 ay, optimum 1 yıl).
    "S01XA18": ("Bu ilacın etkisi YAVAŞ ve BİRİKEREK ortaya çıkar — göz kuruluğunda "
                "düzelme genellikle düzenli kullanımın 3-6. AYINDA görülür. Erken "
                "fayda görmeseniz de BIRAKMAYIN; en az 6 ay SABIRLA her gün kullanın. "
                "İlk haftalardaki yanma/batma genellikle geçicidir."),
    # Hidrokinon leke kremi (Expigment) — güneş, açılan lekeyi yeniden koyulaştırır.
    "D11AX11": ("Tedavi edilen bölgeyi GÜNEŞTEN KORUYUN — güneş ışığı ilacın açtığı "
                "lekeyi yeniden KOYULAŞTIRIR ve tedaviyi boşa çıkarır. Gündüz yüksek "
                "faktörlü GÜNEŞ KORUYUCU kullanın veya bölgeyi kapatın. Yalnız lekeli "
                "bölgeye ince tabaka, tercihen akşam uygulayın."),
    # Triptanlar — atak zamanlaması + ilaç aşırı kullanım baş ağrısı (2026-06-13
    # KT teyitli: ağrı fazında alınır, aura döneminde değil; yanıtsız atakta
    # 2. doz alınmaz; sık kullanım kronikleştirir).
    "N02CC":   ("ATAK İLACIDIR — baş ağrısı BAŞLAR BAŞLAMAZ alın; ağrı öncesi haberci "
                "(aura) döneminde almayın. İlaç fayda etmediyse AYNI atakta 2. doz "
                "almayın; işe yarayıp ağrı geri dönerse en az 2 saat ara ile günlük "
                "sınırı aşmadan alın. Ayda 10 günden sık migren ilacı kullanmak baş "
                "ağrısını KRONİKLEŞTİREBİLİR — sık atakta doktorunuza başvurun."),
    # Ergotaminli kombinasyonlar (Avmigran/Ergafein/Cafergot) — ergotizm riski.
    "N02CA":   ("Migren KRİZ ilacıdır — atağın İLK belirtisinde alın; her gün düzenli "
                "kullanılan koruyucu ilaç DEĞİLDİR. Günlük ve HAFTALIK doz sınırını "
                "KESİNLİKLE aşmayın (Avmigran: günde en çok 4, haftada 10 tablet) — "
                "damar büzülmesi (ergotizm) riski. GEBELİKTE KULLANILMAZ."),
    # Oral kontraseptifler (G03AA/G03AB) — tromboz belirtileri hasta tarafından
    # tanınmalı: DVT bacak ağrısı/şişme; PE nefes darlığı/göğüs ağrısı; inme.
    # >35 yaş + sigara kombinasyonu riski dramatik artırır (eczacı sorması gerekir).
    "G03AA":   ("DOĞUM KONTROL HAPI — her gün AYNI saatte alın. "
                "Bu belirtiler varsa ACİL DOKTORA: bacakta tek taraflı şişlik/ağrı "
                "(pıhtı), ani nefes darlığı, göğüs ağrısı, şiddetli baş ağrısı, "
                "görme değişikliği. "
                "SİGARA + doğum kontrol hapı = pıhtı riski KAT KAT ARTAR. "
                "Antibiyotik, sara ilacı etkinliği azaltabilir — ek koruma kullanın."),
    "G03AB":   ("DOĞUM KONTROL HAPI — her gün AYNI saatte alın. "
                "Bu belirtiler varsa ACİL DOKTORA: bacakta tek taraflı şişlik/ağrı "
                "(pıhtı), ani nefes darlığı, göğüs ağrısı, şiddetli baş ağrısı. "
                "SİGARA + doğum kontrol hapı = pıhtı riski KAT KAT ARTAR. "
                "Antibiyotik, sara ilacı etkinliği azaltabilir — ek koruma kullanın."),
    # ACE inhibitörleri (C09AA) — gebelik 2-3. trimester KESİN YASAK (böbrek
    # agenezisi/ölüm). 1. trimesterde de risk olduğu bildirilmiş; hamile kalındığında
    # derhal kesilir. Potasyum tutulumu → böbrek + K⁺ takibi.
    "C09AA":   ("GEBELİKTE KESİNLİKLE KULLANILMAZ — bebekte böbrek hasarı/ölüm. "
                "Hamile kaldığınızda DERHAL bırakın ve doktorunuza bildirin. "
                "Potasyum takviyesi/potasyum tutucu diüretikle dikkatli kullanın. "
                "KURU ÖKSÜRÜK yaparsa doktorunuza bildirin — ilaç değişimi gerekebilir."),
    "C09BA":   ("GEBELİKTE KESİNLİKLE KULLANILMAZ — bebekte böbrek hasarı/ölüm. "
                "Hamile kaldığınızda DERHAL bırakın ve doktorunuza bildirin. "
                "KURU ÖKSÜRÜK yaparsa doktorunuza bildirin."),
    # Beta-bloker göz damlası (S01ED: timolol/betaksolol/levobunolol) — sistemik
    # emilim var; astım/KOAH hastalarında bronkospazm, kalp yavaşlaması riski.
    "S01ED":   ("GLOKOM DAMLASI — gözü içten köşesine 1 dakika bastırın (sistemik "
                "emilimi azaltır). ASTIM veya KOAH hastasıysanız kesinlikle doktorunuza "
                "bildirin — bu damla nefes yollarını daraltabilir. Kalp ritim ilacı "
                "kullanıyorsanız da bildirin."),
    # Prostaglandin analog göz damlası (S01EE: latanoprost/travoprost/bimatoprost)
    # — iris rengi koyulaşması ve kirpik uzaması/koyulaşması KALICIdir; hasta
    # önceden bilgilendirilmezse tedaviyi bırakıyor veya endişeleniyor.
    "S01EE":   ("GLOKOM DAMLASI — İRİS RENGİ (gözbebeği çevresi) KOYULAŞIP "
                "KALICALAŞABİLİR; KİRPİKLER uzayabilir/koyulaşabilir. Bu etki normaldir, "
                "tehlikeli değildir; ancak kalıcıdır. Her iki göze kullanıyorsanız iki "
                "göz arasında renk farkı oluşabilir. Tedaviyi kendiniz bırakmayın — "
                "glokom kontrolsüz kalırsa görme kaybı olabilir."),
}


# Kritik ATC için 1. etikete basılacak KISA ters-renkli rozet (≤ ~14 karakter)
# Uzun CRITICAL_MESSAGES'tan farklı; bu sadece sol sütundaki küçük uyarı kutusu.
CRITICAL_BADGE: dict[str, str] = {
    "P01AB":   "ALKOL YOK",
    "B01AA":   "KAN SULANDIRICI",
    "B01AC04": "KAN SULANDIRICI",
    "B01AF":   "KAN SULANDIRICI",
    "H02A":    "ANİ KESME YOK",
    "N03":     "ANİ KESME YOK",
    "H03AA":   "AÇ KARNINA",
    "M05B":    "YATARAK ALMAYIN",
    "M04AC01": "GREYFURT YASAK",
    "C10AA":   "GREYFURT YASAK",
    # J01FA makrolid (klaritromisin/azitromisin) QT uzaması: "KALP RİTMİNE
    # DİKKAT" rozeti A etiketinden KALDIRILDI (2026-06-12, eczacı isteği —
    # çocuk antibiyotiği süspansiyonunda gereksiz korkutuyordu); ibare CİDDİ
    # UYARILAR (C) etiketinin ilk maddesinde (CRITICAL_MESSAGES["J01FA"]).
    "L04":     "CANLI AŞI KULLANMA",   # immünsüpresif (CellCept/mikofenolat vb.) —
                                       # "CANLI AŞI YOK" hastaca yanlış anlaşılıyordu
    "A10A":    "BUZDOLABINDA SAKLA",
    # --- Yeni görünür kategoriler (2026-06: uyarı denetimi) ---
    "D10BA":   "GEBELİKTE YASAK",   # izotretinoin
    "D05BB":   "GEBELİKTE YASAK",   # asitretin
    "N05BA":   "ARAÇ KULLANMA",     # benzodiazepin
    "N05CD":   "ARAÇ KULLANMA",     # benzodiazepin hipnotik
    "N05CF":   "ARAÇ KULLANMA",     # Z-ilaçları (zolpidem vb.)
    "N05CM":   "ARAÇ KULLANMA",     # diğer hipnotik/sedatif
    "N02A":    "ARAÇ KULLANMA",     # opioid analjezik
    "M03B":    "ARAÇ KULLANMA",     # kas gevşetici
    "J01MA":   "GÜNEŞTEN KORUN",    # kinolon
    "J01AA":   "GÜNEŞTEN KORUN",    # tetrasiklin (doksisiklin: Monodoks/Tetradox)
    "C01BD01": "GÜNEŞTEN KORUN",    # amiodaron
    "D10AD":   "GÜNEŞTEN KORUN",    # topikal retinoidler (tretinoin/adapalen/izotretinoin kombolar)
    "D10AE":   "GÜNEŞTEN KORUN",    # benzoil peroksit
    "D10AF51": "GÜNEŞTEN KORUN",    # klindamisin + benzoil peroksit (Clindoxyl vb.)
    "D10AF52": "GÜNEŞTEN KORUN",    # eritromisin + benzoil peroksit (Acnemix vb.)
    "D11AX11": "GÜNEŞTEN KORUN",    # hidrokinon (Expigment) — güneş lekeyi geri koyulaştırır
    # 1. kuşak sedatif antihistaminikler — SmPC'de resmi araç/makine uyarısı var,
    # DRUID Kategori II-III psikomotor bozucu. "ARAÇ KULLANMA" rozeti hem gece
    # önerisiyle hem de günde-2 kullanımında doğru mesajı verir.
    # R06AE (setirizin/levosetirizin) hafif sedatif → rozet YOK;
    # günde-1'de "TERCİHEN GECE" önerisi alır.
    "R06AA":   "ARAÇ KULLANMA",     # difenhidramin/doksilamin/dimenhidrinat/klemastin
    "R06AA10": "",                   # trimetobenzamid (Emedur/Ametik/Vomet) — antiemetik, sedatif değil
    "R06AB":   "ARAÇ KULLANMA",     # feniramin, klorfenamin
    "R06AD":   "ARAÇ KULLANMA",     # prometazin (fenotiazin türevi — güçlü sedatif)
    "R06AX02": "ARAÇ KULLANMA",     # siproheptadin (Sipraktin/Prakten)
    "R06AX17": "ARAÇ KULLANMA",     # ketotifen (Zaditen şurup/damla/tablet/SRO)
    "N05BB01": "ARAÇ KULLANMA",     # hidroksizin (Atarax/Hidrax/Validol) — güçlü sedatif
    # --- Sürüş/makine güvenliği denetimi (2026-06): sedatif / psikomotor bozucu
    # sınıflar (DRUID kategori II-III + FDA "medicines and driving"). Sol sütun
    # rozeti tek slot olduğundan ÇAKIŞANLAR bilinçli dışarıda:
    #   • N03 antiepileptik → rozet "ANİ KESME YOK"ta kalır (status epileptikus
    #     riski daha hayati); sürüş uyarısı N03 detay kartında zaten var.
    #   • R06AE/R06AX 2. nesil antihistaminik (setirizin/loratadin/feksofenadin/
    #     bilastin) → non-sedatif olmaları zaten tercih sebebi, rozet YOK.
    #   • İnsülin (A10A→BUZDOLABI) / sülfonilüre → risk hipoglisemi, sedasyon
    #     değil; farklı mesaj gerektirir, buraya alınmadı.
    "N05A":    "ARAÇ KULLANMA",     # antipsikotik (ketiapin/olanzapin/risperidon/aripiprazol)
    "N06AA":   "ARAÇ KULLANMA",     # trisiklik antidepresan (amitriptilin/klomipramin/opipramol)
    "N06AX":   "ARAÇ KULLANMA",     # diğer antidepresan (trazodon/mirtazapin/venlafaksin/duloksetin)
    "N04":     "ARAÇ KULLANMA",     # antiparkinson — dopaminerjikte ANİ UYKU ATAĞI + antikolinerjik sedasyon
    "G04BD":   "ARAÇ KULLANMA",     # üriner antikolinerjik (oksibutinin/solifenasin/tolterodin)
    "N07BC":   "ARAÇ KULLANMA",     # opioid bağımlılık tedavisi (Suboxone — buprenorfin/nalokson)
    "R05DA":   "ARAÇ KULLANMA",     # opioid öksürük kesici (kodein/dekstrometorfan)
    "N07CA02": "ARAÇ KULLANMA",     # sinarizin (sedatif antivertijinöz — Sefal)
    "N07CA03": "ARAÇ KULLANMA",     # flunarizin (Sibelium — sinarizinden de sedatif)
    "A03FA01": "ARAÇ KULLANMA",     # metoklopramid (sedasyon + ekstrapiramidal)
    "N02CA":   "ARAÇ KULLANMA",     # ergot türevi migren ilacı
    "N02CC":   "ARAÇ KULLANMA",     # triptan (uyku hali / baş dönmesi)
    "S01F":    "ARAÇ KULLANMA",     # midriyatik / siklopleji göz damlası — geçici bulanık görme
    # Ereksiyon ilacı (PDE5) — kalp ilacıyla (özellikle nitrat) birlikte
    # KULLANILMAZ; tam cümle sağ sütun ÖNERİ satırında + TİP C etiketinde.
    # Emir kipi tercih: "CANLI AŞI KULLANMA" kalıbıyla aynı.
    "G04BE":   "KALP İLACIYLA KULLANMA",
    # Oral kontraseptif — tromboz riski ana uyarı; sigara ile katlanır.
    "G03AA":   "TROMBOZ BELİRTİLERİNE DİKKAT",
    "G03AB":   "TROMBOZ BELİRTİLERİNE DİKKAT",
    # ACE inhibitörü — gebelik kontrendikasyonu; kuru öksürük sınıf etkisi.
    "C09AA":   "GEBELİKTE YASAK",
    "C09BA":   "GEBELİKTE YASAK",
    # Prostaglandin glokom damlası — iris/kirpik değişimi kalıcı ama tehlikeli değil.
    "S01EE":   "İRİS RENGİ DEĞİŞEBİLİR",
    # Beta-bloker göz damlası — astım/KOAH'ta bronkospazm riski sistemik emilimle.
    "S01ED":   "ASTIMDA DİKKAT",
}


# Deriye sürülen (yutulmayan, parenteral olmayan) üründe SİSTEMİK etki uyarısı
# anlamsızdır: tiyokolşikosid JEL/KREM (TIYOKAS, MUSCORIL merhem...) oral/IM
# muadiliyle aynı M03B ATC'sini taşır ama "ARAÇ KULLANMA" rozeti saçma olur.
# route_class: 2=deri, 9=saçlı deri/şampuan. Topikalde de GEÇERLİ kalan
# rozetler beyaz listede (benzoil peroksit jeli GÜNEŞTEN KORUN gibi).
_TOPICAL_SKIN_FORMS = {"gel_topical", "cream_or_ointment_topical",
                       "shampoo_medicated"}
_TOPICAL_OK_BADGES = {"GÜNEŞTEN KORUN", "GEBELİKTE YASAK", "BUZDOLABINDA SAKLA"}
# Uzun CRITICAL_MESSAGES için topikalde de anlamlı kalan ATC önekleri
_TOPICAL_OK_MSG_PREFIXES = (
    "D10AD",   # topikal retinoidler — fotosensitivite + gebelik mesajı
    "D10AE",   # benzoil peroksit — fotosensitivite + ağartma mesajı
    "D10AF02", # eritromisin topikal
    "D10AF05", # nadifloksasin topikal
    "D10AX03", # azelaik asit
    "D10AF51", "D10AF52",   # BPO kombinasyonları
    "D10BA", "D05BB", "D11AX11",
)


def _is_skin_topical(form: str | None, route_class: str | None) -> bool:
    """Yalnız deriye/saçlı deriye uygulanan ürün mü?

    Form biliniyorsa form belirleyicidir (yanlış route_class'a karşı koruma);
    form boşsa route_class kodlarının tamamı {2, 9} içinde olmalı.
    """
    if form:
        return form in _TOPICAL_SKIN_FORMS
    rc = {c.strip() for c in (route_class or "").split(",") if c.strip()}
    return bool(rc) and rc <= {"2", "9"}


def _critical_badge_for_atc(
    atc_code: str | None,
    form: str | None = None,
    route_class: str | None = None,
) -> str:
    """ATC koduna karşılık kısa ters-renkli rozet — en spesifik prefix kazanır.

    Deriye sürülen üründe sistemik rozetler (ARAÇ KULLANMA, UYKU YAPABİLİR,
    ALKOL YOK...) bastırılır; yalnız _TOPICAL_OK_BADGES geçer.
    """
    if not atc_code:
        return ""
    code = atc_code.upper()
    for pfx in sorted(CRITICAL_BADGE.keys(), key=len, reverse=True):
        if code.startswith(pfx):
            badge = CRITICAL_BADGE[pfx]
            if badge not in _TOPICAL_OK_BADGES and _is_skin_topical(
                    form, route_class):
                return ""
            return badge
    return ""


# Form bazlı sağ-sütun ana talimatı (hasta diliyle, emir kipi)
_INSTRUCTION_BY_FORM: dict[str, str] = {
    "tablet_normal":              "BİR BARDAK SU İLE YUTUNUZ",
    "tablet_enteric_or_extended": "BİR BARDAK SU İLE BÜTÜN YUTUNUZ",
    "capsule_normal":             "BİR BARDAK SU İLE YUTUNUZ",
    "capsule_pellet_open":        "BİR BARDAK SU İLE YUTUNUZ",
    "tablet_chewable":            "ÇİĞNEYEREK YUTUNUZ",
    "tablet_effervescent":        "BİR BARDAK SUDA ERİTİP İÇİNİZ",
    "tablet_sublingual":          "DİLALTINDA ERİTİNİZ",
    "syrup_or_suspension":        "İÇİNİZ",
    "powder_for_suspension":      "İÇİNİZ",
    "oral_drop":                  "AĞIZA VEYA BİR İÇECEĞE DAMLATIP İÇİNİZ",
    "sachet_oral":                "BİR BARDAK SUDA ÇÖZÜP İÇİNİZ",
    # Beslenme solüsyonları (Infasource/Ensure/Fortimel...) su ile YUTULMAZ.
    "nutritional_supplement_oral": "DOĞRUDAN İÇİNİZ (SULANDIRMAYINIZ)",
    "nutritional_powder_oral":    "KUTUDAKİ TARİFE GÖRE HAZIRLAYIP İÇİNİZ",
    "eye_drop":                   "ALT GÖZ KAPAĞININ İÇİNE DAMLATINIZ",
    "eye_ointment":               "ALT GÖZ KAPAĞININ İÇİNE SÜRÜNÜZ",
    "ear_drop":                   "KULAĞA DAMLATINIZ",
    "nasal_spray":                "BURUN İÇİNE SIKINIZ",
    "nasal_drop":                 "BURUN İÇİNE DAMLATINIZ",
    "oral_spray_throat":          "BOĞAZA SIKINIZ",
    "sublingual_spray":           "DİL ALTINA SIKINIZ",
    "gargara_mouthwash":          "YUTMADAN AĞIZDA ÇALKALAYIP TÜKÜRÜNÜZ",
    "inhaler_pmdi":               "DERİN NEFESLE İÇE ÇEKİNİZ",
    "inhaler_dpi":                "DERİN NEFESLE İÇE ÇEKİNİZ",
    "nebule":                     "NEBÜLİZATÖRLE SOLUYUNUZ",
    "injection_sc":               "CİLT ALTINA UYGULAYINIZ",
    "suppository_rectal":         "MAKATTAN UYGULAYINIZ",
    "enema_rectal":               "MAKATTAN UYGULAYINIZ",
    "cream_rectal":               "MAKAT BÖLGESİNE SÜRÜNÜZ",
    "vaginal_ovule_or_cream":     "VAJEN İÇİNE YERLEŞTİRİNİZ",
    "transdermal_patch":          "CİLDE YAPIŞTIRINIZ",
    "cream_or_ointment_topical":  "ETKİLENEN BÖLGEYE SÜRÜNÜZ",
    "gel_topical":                "ETKİLENEN BÖLGEYE SÜRÜNÜZ",
    "shampoo_medicated":          "SAÇA UYGULAYINIZ",
    "oromucosal_gel":             "AĞIZ İÇİNE SÜRÜNÜZ",
}

# Kullanmadan önce çalkalama gerektiren formlar (sağ-sütun teknik notu)
# inhaler_pmdi ve nasal_spray _technique_line içinde ÇÖZELTİ/SÜSPANSİYON
# ayrımıyla ayrıca ele alınır (çözelti çalkalanmaz).
_SHAKE_FORMS = {
    "syrup_or_suspension", "powder_for_suspension",
}


def _instruction_line(form: str | None, name: str = "") -> str:
    """Form bazlı kısa ana talimat satırı (sağ sütun).

    Topikal formda ad SPREY içeriyorsa "sürünüz" değil "püskürtünüz" denir
    (Rheumon/Majezik gibi ATC'si D olmayan topikal spreyleri de kapsar).
    """
    f = (form or "").lower()
    n = (name or "").upper()
    if f in ("cream_or_ointment_topical", "gel_topical") and (
            "SPREY" in n or "SPRAY" in n or "PÜSKÜRT" in n):
        return "ETKİLENEN BÖLGEYE PÜSKÜRTÜNÜZ"
    # Form boş/yanlış olsa bile adında GARGARA geçen ürün şurup gibi İÇİLMESİN —
    # ad-fallback ile çalkala-tükür talimatı (ANDOREX gibi form=None kayıtlar).
    if "GARGARA" in n and f in ("", "gargara_mouthwash", "syrup_or_suspension"):
        return _INSTRUCTION_BY_FORM["gargara_mouthwash"]
    return _INSTRUCTION_BY_FORM.get(f, "")


# Topikal dermatolojik (cilt/saç/tırnak) ilaçlar ASLA içilmez/yutulmaz/buruna
# sıkılmaz. ATC D = dermatolojik; ANCAK oral alt-sınıflar HARİÇ:
#   D01B (oral antifungal), D05B (oral retinoid/asitretin),
#   D10BA/D10BB (oral izotretinoin). Bunlar sistemik → yutulur.
_DERM_ORAL_ATC = ("D01B", "D05B", "D10BA", "D10BB")


def _topical_derm_instruction(atc, name, route="", indication="") -> str:
    """Topikal dermatolojik ürün için doğru uygulama cümlesi; değilse "".

    Çözelti/sprey/köpük/tırnak cilası gibi formların yanlışlıkla 'içilir/buruna'
    olmasını engeller (örn. Oceral çözelti, Exoderil dermal sprey, tırnak solüsyonu).
    """
    n = (name or "").upper()
    # Oral katı form → topikal DEĞİL (oral retinoid/antifungal tablet/kapsül).
    if any(k in n for k in ("TABLET", "KAPSÜL", "KAPSUL", "DRAJE")):
        return ""
    # Transdermal BANT (Durogesic/Exelon/Nicotinell/Climara) sürülmez,
    # YAPIŞTIRILIR — form bazlı "CİLDE YAPIŞTIRINIZ" talimatı ezilmesin.
    if any(k in n for k in ("FLASTER", "FLASTIR", "PATCH", " TTS")):
        return ""
    a = (atc or "").upper()
    is_derm = (
        (a.startswith("D") and not a.startswith(_DERM_ORAL_ATC)
         and not any(k in n for k in ("ENJ", "ŞIRINGA", "SIRINGA", "ENJEKTÖR", "AMPUL")))
        or (route or "").strip() == "cilt üzerine"
        or any(k in (indication or "").upper()
               for k in ("DIŞ KULLAN", "DIS KULLAN", "HARİCİ", "HARICI",
                         "TOPİK", "TOPIK"))
    )
    if not is_derm:
        return ""
    if "TIRNAK" in n or "TIRNAĞ" in n:
        return "TIRNAĞA UYGULAYINIZ"
    if a.startswith("D11AX01"):   # minoksidil — gövde derisi değil saçlı deri
        return ("SAÇLI DERİYE PÜSKÜRTÜNÜZ"
                if "SPREY" in n or "SPRAY" in n else "SAÇLI DERİYE UYGULAYINIZ")
    if "ŞAMPUAN" in n or "SAMPUAN" in n:
        return "SAÇA UYGULAYIP DURULAYINIZ"
    if "SAÇ" in n or "SCALP" in n:
        return "SAÇLI DERİYE UYGULAYINIZ"
    if "SPREY" in n or "SPRAY" in n or "PÜSKÜRT" in n or "PUSKURT" in n \
            or "AEROSOL" in n:
        return "ETKİLENEN BÖLGEYE PÜSKÜRTÜNÜZ"
    return "ETKİLENEN BÖLGEYE SÜRÜNÜZ"


def _spray_fis_doz(doz: str) -> str:
    """Sprey dozunu 'N FIS' biçimine getirir (sayıyı korur). '2 DOZ'→'2 FIS'.

    Burun/boğaz spreyleri 'fıs' (püskürtme) ile dozlanır; reçetedeki sayı kadar.
    """
    tok = (doz or "").strip().split(" ")
    n = tok[0] if tok and tok[0][:1].isdigit() else "1"
    return f"{n} FIS"


def _is_throat_spray(atc, name) -> bool:
    """Ağız/boğaz spreyi mi? (benzidamin/klorheksidin vb. — burun spreyi DEĞİL).

    Tantum Verde/Andorex/Kloroben/Tanflex/Benpain gibi A01A (stomatolojik) veya
    R02 (boğaz) ATC'li SPREY'ler; bazıları yanlışlıkla nasal_spray sınıflanmış.
    """
    n = (name or "").upper()
    a = (atc or "").upper()
    if "SPREY" not in n and "SPRAY" not in n:
        return False
    if a.startswith("A01A") or a.startswith("R02"):
        return True
    if "BOĞAZ" in n or "ORAL SPREY" in n:
        return True
    return False


def _is_topical_spray(atc, name, form="", route="") -> bool:
    """Cilde püskürtülen TOPİKAL/dermal sprey mi? (antifungal/antiseptik dermal
    sprey: Oceral/Exoderil/Lamisil sprey). Burun/boğaz/dilaltı spreyi DEĞİL.

    Bu spreyler 'tane' ile dozlanmaz; her sıkış = 1 PUF, etkilenen bölgeye
    püskürtülür. Form genelde cream_or_ointment_topical'a düşer (ayrı sprey formu
    yok), bu yüzden adda 'SPREY/SPRAY' + dermatolojik (D) ATC / cilt yolu aranır.
    """
    n = (name or "").upper()
    a = (atc or "").upper()
    if "SPREY" not in n and "SPRAY" not in n:
        return False
    # Burun / boğaz / dilaltı spreyleri bu kapsamın dışında (kendi doz birimleri var)
    if _is_throat_spray(a, n):
        return False
    if a.startswith("R01") or "BURUN" in n or "NAZAL" in n or "NASAL" in n:
        return False
    if (form or "") == "sublingual_spray" or "DİL ALTI" in n or "DILALTI" in n:
        return False
    # Topikal/dermal: dermatolojik (D) ATC ya da topikal form / cilt uygulama yolu
    r = (route or "").upper()
    if a.startswith("D"):
        return True
    if (form or "") in ("cream_or_ointment_topical", "gel_topical"):
        return True
    if any(k in r for k in ("CİLT", "DERİ", "HARİCEN", "TOPİK")):
        return True
    return False


def _topical_spray_puf_doz(doz: str) -> str:
    """Topikal sprey dozunu 'N PUF' biçimine getirir (sayıyı korur). '1 TANE'→'1 PUF'."""
    tok = (doz or "").strip().split(" ")
    n = tok[0] if tok and tok[0][:1].isdigit() else "1"
    return f"{n} PUF"


# Cilde SÜRÜLEN topikal formlar (krem/merhem/losyon/emülsiyon/jel/şampuan): uygulanan
# MİKTAR hastaya bir şey ifade etmez (ml/gram anlamsız) → sıklık "KEZ" ile verilir.
# DB formu yetkili sinyaldir; göz emülsiyonu (eye_drop) / oral-IV emülsiyon (form yok)
# bu kümeye girmediğinden yanlışlıkla "kez" olmaz. Sprey (PUF) ayrı ele alınır.
_TOPICAL_SURULEN_FORMS = frozenset({
    "cream_or_ointment_topical", "gel_topical", "shampoo_medicated",
})


def _topical_surulen_kez_doz(doz: str) -> str:
    """Sürülen topikal ürünün dozunu 'N KEZ' yapar ('1 ML'→'1 KEZ', boş→'1 KEZ')."""
    tok = (doz or "").strip().split(" ")
    n = tok[0] if tok and tok[0][:1].isdigit() else "1"
    return f"{n} KEZ"


def _drop_damla_doz(doz: str) -> str:
    """Göz/kulak/burun damlası dozunu 'N DAMLA' yapar ('1'→'1 DAMLA', boş→'1 DAMLA').

    Damlatılan formda birim DAİMA 'damla'dır; OFTALMİK ÇÖZELTİ gibi adlarda guess_unit
    boş/ml dönüp birimi düşürebiliyor → form yetkili kabul edilip damla'ya sabitlenir.
    """
    tok = (doz or "").strip().split(" ")
    # Damla sayısı tam sayıdır; kesirli ml (örn. "0,04 ml") sızarsa 1 damlaya düş.
    n = tok[0] if (tok and tok[0].isdigit()) else "1"
    return f"{n} DAMLA"


def _is_puff_inhaler(name) -> bool:
    """pMDI/DPI inhaler mı? (puf/nefesle içe çekilen astım-KOAH ilacı). Reçete
    kaydı formsuz olabildiğinden ADDAN tespit edilir; NEBÜL/NEBULİZASYON (ampul)
    HARİÇ — orada '1 ampul' (cihaza konan tek doz) doğrudur, 'sefer' değil.

    Bu ilaçlar 'tane' ile dozlanmaz; her uygulama bir 'SEFER' derin nefestir →
    "GÜNDE 4 KEZ İKİ SEFER" / "2 SEFER DERİN NEFES İLE İÇE ÇEKİLİR".
    """
    n = (name or "").upper()
    if "NEBUL" in n or "NEBÜL" in n or "NEBULIZ" in n:
        return False
    return any(k in n for k in (
        "İNHALASYON", "INHALASYON", "İNHALER", "INHALER", "AEROSOL",
        "TURBUHALER", "DISKUS", "DISKHALER", "DISCAIR", "HANDIHALER",
        "BREEZHALER", "ELLIPTA", "RESPIMAT", "SANOHALER", "CAPSAIR",
    ))


# Sulandırılarak kullanılan KONSANTRE gargaralar — flurbiprofen %0.25 ailesi
# (MAJEZIK/MAXIMUS/MAXIFLU/FLUREND): 1 ölçek yarım bardak suya katılır.
# Diğer tüm gargaralar (benzidamin/klorheksidin: TANFLEX, TANTUM VERDE,
# ANDOREX, KLOROBEN, KLORHEX...) KULLANIMA HAZIRDIR, sulandırılmaz
# (kullanıcı/eczacı düzeltmesi 2026-06-11).
_DILUTED_GARGARA_BRANDS = ("MAJEZIK", "MAXIMUS", "MAXIFLU", "FLUREND")


def is_diluted_gargara(name: str | None) -> bool:
    """Sulandırılarak kullanılan konsantre gargara mı (flurbiprofen %0.25)?"""
    n = (name or "").upper()
    if "GARGARA" not in n:
        return False
    return (n.startswith(_DILUTED_GARGARA_BRANDS)
            or "0.25" in n or "0,25" in n)


def _technique_line(form: str | None, name: str = "", atc: str | None = None) -> str:
    """Form bazlı teknik not (sağ sütun, çalkalama vb.).

    SÜSPANSİYON çalkalanır (çökeltili); berrak ŞURUP/SOLÜSYON çalkalanmaz
    (çözünmüş). syrup_or_suspension formu ikisini de kapsadığından ADA bakarız.
    """
    f = (form or "").lower()
    n = (name or "").upper()
    a = (atc or "").upper()
    if f == "syrup_or_suspension":
        if any(k in n for k in ("ŞURUP", "SURUP", "SOLÜSYON", "SOLUSYON",
                                "ÇÖZELTİ", "COZELTI", "ŞRP")) and \
                not any(k in n for k in ("SÜSPANS", "SUSPANS")):
            return ""   # berrak çözelti/şurup — çalkalama gerekmez
        return "KULLANMADAN ÖNCE ÇALKALAYINIZ"   # süspansiyon veya belirsiz → çalkala
    if f == "inhaler_pmdi":
        # ÇÖZELTİ aerosoller (Foster/Forbefix/Foterol-B: R03AK08 Modulite tipi)
        # çalkalanmaz — KT'lerinde çalkalama adımı yok. Süspansiyon aerosoller
        # (Ventolin, Flixotide, Seretide inhaler vb.) çalkalanır.
        if a.startswith("R03AK08") or any(
                k in n for k in ("ÇÖZELTİ", "COZELTI", "INH.COZ", "ÇÖZ.", "COZ.")):
            return ""
        return "KULLANMADAN ÖNCE ÇALKALAYINIZ"
    if f == "nasal_spray":
        # Burun spreylerinin çoğu ÇÖZELTİdir (Otrivine/ksilometazolin, deniz
        # suyu, azelastin) — KT'lerinde çalkalama adımı yok. Kortikosteroid
        # spreyler (R01AD: mometazon/flutikazon/budesonid/triamsinolon)
        # SÜSPANSİYONdur → KT "iyice çalkalayınız" der.
        if a.startswith("R01AD") or any(k in n for k in ("SÜSPANS", "SUSPANS")):
            return "KULLANMADAN ÖNCE ÇALKALAYINIZ"
        return ""
    if f in _SHAKE_FORMS:   # syrup_or_suspension (yukarıda), powder_for_suspension
        return "KULLANMADAN ÖNCE ÇALKALAYINIZ"
    if f == "gargara_mouthwash" or "GARGARA" in n:
        # Yalnız KONSANTRE gargaralar sulandırılır; gerisi kullanıma hazır.
        return "1 ÖLÇEK + YARI BARDAK SU" if is_diluted_gargara(n) else ""
    return ""


def _critical_message_for_atc(
    atc_code: str | None,
    form: str | None = None,
    route_class: str | None = None,
) -> str:
    """ATC koduna karşılık gelen kısa kritik mesaj — en spesifik prefix kazanır.

    Deriye sürülen üründe sistemik mesajlar (M03B "araç/makine" vb.) bastırılır;
    yalnız topikalde de geçerli önekler (_TOPICAL_OK_MSG_PREFIXES) kalır.
    """
    if not atc_code:
        return ""
    code = atc_code.upper()
    # En uzun (en spesifik) prefix önce
    for pfx in sorted(CRITICAL_MESSAGES.keys(), key=len, reverse=True):
        if code.startswith(pfx):
            if pfx not in _TOPICAL_OK_MSG_PREFIXES and _is_skin_topical(
                    form, route_class):
                return ""
            return CRITICAL_MESSAGES[pfx]
    return ""


def should_print_secondary(form: str | None, atc_code: str | None) -> tuple[bool, str]:
    """2. etiket gerekli mi karar verir.

    Döner: (gerekli_mi, tip) → tip ∈ {'prep', 'technique', 'critical', ''}
    """
    if form in PREP_FORMS:
        return True, "prep"
    if form in TECHNIQUE_FORMS:
        return True, "technique"
    if atc_code:
        for pfx in CRITICAL_ATC_PREFIXES:
            if atc_code.startswith(pfx):
                return True, "critical"
    return False, ""


# ============================================================
# UYARI metni çıkarıcı
# ============================================================

def _short_warning_from_dikkat(content: str, max_chars: int = 180) -> str:
    """drug_label_blocks.dikkat içeriğinden 1. etikete sığacak kısa uyarı çıkar.

    İlk 1-2 maddeyi (• ile başlayan) birleştirir, max_chars sınırını aşmamaya çalışır.
    """
    if not content:
        return ""
    lines = [ln.strip() for ln in content.split("\n") if ln.strip()]
    # • ile başlayan maddeleri al
    bullets = [ln.lstrip("•").strip() for ln in lines if ln.startswith("•")]
    if not bullets:
        bullets = lines

    # İlk 1-2 maddeyi yan yana koy
    out = ""
    for b in bullets[:2]:
        candidate = (out + " " + b).strip() if out else b
        if len(candidate) > max_chars:
            if not out:
                out = b[: max_chars - 1] + "…"
            break
        out = candidate
    return out


# ============================================================
# DB sorgu yardımcısı
# ============================================================

def _fetch_drug(conn: sqlite3.Connection, drug_id: int) -> sqlite3.Row | None:
    return conn.execute(
        """
        SELECT id, barcode, name, drug_type, indication_short, active_ingredient,
               form, route, dose_unit, default_dose,
               daily_freq, hours_apart, meal_relation, treatment_days,
               atc_code, atc_name, route_class
        FROM drugs WHERE id = ?
        """,
        (drug_id,),
    ).fetchone()


def _fetch_block(
    conn: sqlite3.Connection, drug_id: int, block_type: str
) -> str:
    """drug_label_blocks'tan en kaliteli kaynaklı içeriği çek.

    Kaynak önceliği: manual > prospektus_kt > general_knowledge.
    """
    rows = conn.execute(
        """
        SELECT source, content FROM drug_label_blocks
        WHERE drug_id = ? AND block_type = ?
        """,
        (drug_id, block_type),
    ).fetchall()
    if not rows:
        return ""
    priority = {"manual": 0, "prospektus_kt": 1, "general_knowledge": 2}
    rows = sorted(rows, key=lambda r: priority.get(r["source"], 9))
    return rows[0]["content"] or ""


def _settings(conn: sqlite3.Connection) -> dict[str, str]:
    out = {}
    for k, v in conn.execute("SELECT key, value FROM settings"):
        out[k] = v or ""
    return out


# ============================================================
# Cümle / metin üretici
# ============================================================

# ATC bazlı tercih edilen kullanım zamanı (daily_freq=1 olan ilaçlar için)
# "GÜNDE 1 DEFA" yerine "AKŞAM 1 TANE" gibi spesifik saat önerisi yapar.
ATC_PREFERRED_TIME: dict[str, list[str]] = {
    # Uzun etkili bazal insülin (glarjin/detemir/degludek) — günde 1 kez, her gün
    # AYNI SAATTE; yaygın pratik akşam/yatmadan önce. Sağ sütuna öneri olarak yazılır.
    "A10AE":  ["akşam"],
    # Statinler — kolesterol sentezi gece artar, akşam alınması daha etkili
    "C10AA":  ["akşam"],
    "C10AX":  ["akşam"],
    # Bisfosfonatlar — sabah aç karnına
    "M05BA":  ["sabah"],
    "M05BB":  ["sabah"],
    # Levotiroksin — sabah aç karnına
    "H03AA":  ["sabah"],
    # PPI'lar — sabah aç karnına
    "A02BC":  ["sabah"],
    # Antipsikotik (genelde gece)
    "N05AH":  ["gece"],
    # Uyku ilacı
    "N05C":   ["gece"],
    # Antialerjik (3. kuşak, genelde akşam)
    "R06AX27": ["akşam"],
    # Alfa-bloker prostat (gece — tansiyon düşmesini önle)
    "G04CA":  ["gece"],
    # DOAK kan sulandırıcı (akşam yemekle)
    "B01AF":  ["akşam"],
    # Kontakt/stimülan laksatif (Bekunis = sinameki) — etkisi 6-12 saatte başlar,
    # gece yatmadan alınınca sabaha doğru etki gösterir
    "A06AB":  ["gece"],
    # İdrar söktürücü (diüretik) — sabah; geç saatte alınırsa gece idrara çıkma uykuyu böler
    "C03":    ["sabah"],
    # Sistemik kortikosteroid (glukokortikoid) — sabah, vücudun doğal kortizol ritmine uyum
    "H02AB":  ["sabah"],
    # Oral demir preparatları — sabah aç karnına (C vitamini emilimi artırır, çay/süt azaltır)
    "B03A":   ["sabah"],
    # Sedatif (1. kuşak) antihistaminikler — uyku yapar, gece tercih edilir
    "R06AA":  ["gece"],   # difenhidramin vb.
    # R06AA şemsiyesindeki ANTİEMETİKLER alerji ilacı değil — gece önerisi
    # yanlış (taşıt tutmasında yolculuktan önce, bulantıda ihtiyaç anında).
    # En-spesifik-prefix kuralı sayesinde boş liste R06AA'yı ezer.
    "R06AA10": [],        # trimetobenzamid (Emedur/Ametik/Vomet)
    "R06AA11": [],        # dimenhidrinat (Dramamine/Anti-Em)
    "R06AB":  ["gece"],   # feniramin, klorfenamin
    "R06AD":  ["gece"],   # prometazin (fenotiazin türevi)
    # Hidroksizin (sedatif antihistaminik / anksiyolitik) — gece
    "N05BB":  ["gece"],
    # Melatonin zaten N05C (uyku ilacı) altında "gece" olarak kapsanıyor.
    # Sedatif antidepresanlar — gece (aktive edici olanları KAPSAMAMAK için spesifik kod)
    "N06AA":  ["gece"],     # trisiklik (amitriptilin vb.)
    "N06AX11": ["gece"],    # mirtazapin
    "N06AX05": ["gece"],    # trazodon
    # Bazı ARB'ler (akşam — sabah tansiyon yükselmesini önle)
    # C09CA: not, doktor tercihi — etiketleme yapmıyoruz
}


def _atc_preferred_time(atc_code: str | None) -> list[str]:
    """ATC koduna karşılık tercih edilen kullanım zamanını döner."""
    if not atc_code:
        return []
    code = atc_code.upper()
    # En spesifik (uzun) prefix önce
    for pfx in sorted(ATC_PREFERRED_TIME.keys(), key=len, reverse=True):
        if code.startswith(pfx):
            return list(ATC_PREFERRED_TIME[pfx])
    return []


# ATC tercih saatinin sağ-sütun ÖNERİ cümlesine çevrimi (günde 1 alınan ilaçlar)
# "Akşam alınması daha etkili" gibi yumuşak öneriler sol dozaj ızgarasına değil,
# sağ sütuna metin olarak yazılır.
_ZAMAN_ONERI_TEXT: dict[str, str] = {
    "sabah": "TERCİHEN SABAH KULLANINIZ",
    "akşam": "TERCİHEN AKŞAM KULLANINIZ",
    "gece":  "GECE YATMADAN ÖNCE KULLANINIZ",
}

# ATC bazlı ÖZEL öneri cümlesi — generic zaman önerisinin (TERCİHEN SABAH vb.)
# YERİNE geçer. Aç karnına + belirli zamanlama gerektiren ilaçlar için.
_ATC_ONERI_OZEL: dict[str, str] = {
    # Levotiroksin (tiroid): sabah erken, aç karnına, kahvaltıdan en az 30 dk önce
    "H03AA": "SABAH ERKEN — KAHVALTIDAN 30 DK ÖNCE",
    # Statinler (Ator/Tarden/Crestor/Alipza + ezetimib kombinleri): kolesterol
    # sentezi gece pik yapar → eczacı tercihi "gece yatmadan önce" (2026-06-12;
    # eskiden generic "TERCİHEN AKŞAM" idi).
    "C10AA": "TERCİHEN GECE YATMADAN ÖNCE KULLANINIZ",
    "C10BA": "TERCİHEN GECE YATMADAN ÖNCE KULLANINIZ",
    # Tizanidin (Sirdalud MR — günde 1): belirgin uyku hali/sersemlik yapar →
    # sedasyonu uykuya denk getir. (3x1 normal tablette öneri zaten basılmaz.)
    "M03BX02": "TERCİHEN GECE YATMADAN ÖNCE KULLANINIZ",
    # Flunarizin (Sibelium) — migren KORUYUCUSU: krizde etkisiz, her gün
    # düzenli; sedatif olduğundan gece alınır.
    "N07CA03": "KRİZDE ETKİSİZ — KORUYUCUDUR: HER GÜN, TERCİHEN GECE",
    # CGRP antikorları (Emgality/Ajovy/Aimovig) — ayda 1 koruyucu enjeksiyon.
    "N02CD": "KORUYUCU TEDAVİ — AYDA 1 KEZ UYGULANIR",
    # Sedatif antihistaminikler _sedating_antihistamine_oneri ile ele alınır
    # (form-duyarlı: şurup→İÇİNİZ, tablet→KULLANINIZ).
}

# Sağ sütun boş kalan ilaç gruplarına ATC bazlı "bonus" bilgi satırı.
# oneri_satiri henüz boşsa ve form oral/patch ise eklenir; enjeksiyon/topikal almaz.
# En uzun prefix önce eşleşir (sorted by len desc).
_BONUS_ONERI: dict[str, str] = {
    # Beta-blokerler: ani bırakma rebound taşikardi/anjin yapar
    "C07":   "ANİ BIRAKMAYINIZ — DOKTORSUZ BIRAKMAYIN",
    # ACE inhibitörleri (enalapril/ramipril/lisinopril/perindopril + kombinleri):
    # bradikinin kaynaklı KURU öksürük sınıf etkisi, %5-39 (ARB'lerde yok) —
    # hasta yan etki olduğunu bilmezse ilacı kendisi kesiyor (2026-06-12 teyit:
    # PMC/NEJM derlemeleri). C09C/C09D (ARB) bilinçli kapsam DIŞI.
    "C09A":  "KURU ÖKSÜRÜK YAPABİLİR — OLURSA DOKTORUNUZA BAŞVURUN",
    "C09B":  "KURU ÖKSÜRÜK YAPABİLİR — OLURSA DOKTORUNUZA BAŞVURUN",
    # Öksürük kesiciler (R05D: kodein/dextrometorfan/levodropropizin vb.) —
    # 1 haftadan uzun süren öksürük ayrı hastalık işareti olabilir.
    # Kodeinli (R05DA) preparatlar ek olarak uyku/konsantrasyon etkisi yapar;
    # onu aşağıdaki R05DA kaydı yakalar (daha uzun prefix önce eşleşir).
    "R05DA": "UYKU VE DİKKATİ ETKİLEYEBİLİR — ARAÇ KULLANIRKEN DİKKAT",
    "R05D":  "ÖKSÜRÜK 1 HAFTADAN UZUN SÜRERSE DOKTORA BAŞVURUN",
    # Mukolitikler (R05CB: Asist/Mukotik/NAC — asetilsistein/karbosistein/
    # erdostein): bol sıvı balgamı sulandırıp ilacın etkisini destekler.
    "R05CB": "BOL SU TÜKETİNİZ — BALGAMIN SÖKÜLMESİNİ KOLAYLAŞTIRIR",
    # Pizotifen (Sandomigran) — migren koruyucusu, atak ilacı değil.
    "N02CX": "KORUYUCU TEDAVİ — HER GÜN DÜZENLİ KULLANIN",
    # Diüretikler: gece sık idrara kalkma önlemek için sabah; potasyum kaybı
    # (furosemid/tiazid mineralokortikoid benzeri etki → K⁺ atılımı artar →
    # halsizlik, bacak krampı). Spironolakton potasyum TUTAR, bu uyarı o için değil;
    # ama genel C03 etiketi furosemid/tiazid ağırlıklı olduğu için dahil.
    "C03":   "SABAH KULLANINIZ — POTASYUM DÜŞEBİLİR; MUZ, KURU KAYISI TÜKETİN",
    # Metformin: GI yan etkiler ilk haftalarda yoğun, yemekle azalır; bu nedenle
    # bırakma en sık 1. ayda olur
    "A10BA": "İLK GÜNLERDE MİDE BULANTISI OLABİLİR — YEMEKLE ALIN",
    # Sülfonilüreler: en sık hipoglisemi yapar; yanında şeker bulundurmak şart
    "A10BB": "KAN ŞEKERİNİ ÇOK DÜŞÜREBİLİR — YANINDA ŞEKER BULUNDURUN",
    "A10BG": "KAN ŞEKERİNİ ÇOK DÜŞÜREBİLİR — YANINDA ŞEKER BULUNDURUN",
    # Allopurinol (gut): akut atak sırasında başlanmamalı, bol su iç
    # Allopurinol: bol su ürik asit atılımı için; diyet (kırmızı et/sakatat/alkol/
    # deniz ürünleri purin kaynağı → ürik asit → gut atağı tetikler); akut atak
    # süresince başlanmaz (atağı uzatır/şiddetlendirir).
    "M04AA": "BOL SU İÇİN — KIRMIZI ET, SAKATAT, ALKOL VE DENİZ ÜRÜNLERİNİ KISITLAYIN",
    # Kolşisin (gut/FMF): dar terapötik pencere, diyare erken toksisite işareti
    "M04AC": "İSHAL BAŞLARSA DOZU AZALTIN — DOKTORA BİLDİRİN",
    # Bisfosfonatlar oral (osteoporoz): yemek borusu yanığı önleme kritik
    "M05BA": "YUTUP EN AZ 30 DK DİK DURUN — YATMAYIN",
    "M05BB": "YUTUP EN AZ 30 DK DİK DURUN — YATMAYIN",
    # Oral kortikosteroidler: mide koruması, uzun süre bırakmada kademeli azalt
    "H02AB": "MİDE KORUYUCU İLE BIRLIKTE KULLANIN",
    # Tamoksifen (meme kanseri): eşzamanlı SSRI ile etkileşim (CYP2D6)
    "L02BA01": "BAZI ANTİDEPRESANLAR ETKİSİNİ AZALTABİLİR — DOKTORA BİLDİRİN",
}


def _bonus_oneri_satiri(atc: str | None, form: str, name_u: str = "") -> str:
    """oneri_satiri henüz boşsa sağ sütuna ek hasta bilgisi sağlar.

    Yalnızca oral/transdermal formlar için üretilir; enjeksiyon/topikal almaz.
    Eşleşme yoksa "" döner.
    """
    f = (form or "").lower()
    # Topikal/enjeksiyon/göz-kulak ürünlerine bonus yazılmaz
    if (f.startswith("injection") or f in (
            "eye_drop", "ear_drop", "cream", "gel", "ointment",
            "cream_rectal", "suppository_rectal", "vaginal_ovule_or_cream",
            "vaginal_cream", "nasal_spray", "nasal_drop", "lotion",
            "transdermal_patch", "topical_solution", "shampoo") or
            any(k in name_u for k in ("AMPUL", "ENJEKS", "FLAKON",
                                      "MERHEM", "KREM", "JEL", "OVÜL", "FİTİL"))):
        return ""
    code = (atc or "").upper()
    for pfx in sorted(_BONUS_ONERI.keys(), key=len, reverse=True):
        if code.startswith(pfx):
            return _BONUS_ONERI[pfx]
    return ""


# Sedatif (uyku yapan) antihistaminikler → tercihen gece yatmadan önce.
# R06AA/AB/AD (1. kuşak), R06AE (setirizin/levosetirizin), R06AX02 (siproheptadin),
# R06AX17 (ketotifen), N05BB01 (hidroksizin — Atarax; anksiyete/kaşıntıda güçlü
# sedatif). Non-sedatif R06AX (loratadin/feksofenadin/bilastin) DAHİL DEĞİL.
_SEDATING_AH_ATC = ("R06AA", "R06AB", "R06AD", "R06AE", "R06AX02", "R06AX17",
                    "N05BB01")

# R06AA şemsiyesindeki ANTİEMETİKLER alerji ilacı değildir; "gece yatmadan"
# yanlış yönlendirir (taşıt tutmasında yolculuktan 30-60 dk önce, bulantıda
# ihtiyaç anında alınır). Doksilamin+B6 (R06AA59 Prilam — gebelik bulantısı)
# HARİÇ tutulmaz: onun SmPC'si gerçekten gece yatarken der.
_SEDATING_AH_EXCLUDE = (
    "R06AA10",   # trimetobenzamid (Emedur/Ametik/Vomet — bulantı-kusma)
    "R06AA11",   # dimenhidrinat (Dramamine/Anti-Em — taşıt tutması)
)


def _sedating_antihistamine_oneri(atc, form, name) -> str:
    """Sedatif antihistaminik için 'TERCİHEN GECE YATMADAN ÖNCE …' öneri cümlesi.

    Şurup/süspansiyon/solüsyon/damla → İÇİNİZ; tablet/kapsül → KULLANINIZ.
    Sedatif değilse, antiemetikse veya enjeksiyon formuysa "".
    """
    a = (atc or "").upper()
    if not a.startswith(_SEDATING_AH_ATC) or a.startswith(_SEDATING_AH_EXCLUDE):
        return ""
    f = (form or "").lower()
    n = (name or "").upper()
    # Enjeksiyon formu (Avil/İnfenil IM ampul — akut alerjide sağlıkçı uygular):
    # eve "gece yatmadan kullanın" önerisi basılmaz.
    if f.startswith("injection") or any(
            k in n for k in ("AMPUL", "ENJEKS", "ENJ.", "FLAKON")):
        return ""
    sivi = (f in ("syrup_or_suspension", "oral_drop", "powder_for_suspension")
            or any(k in n for k in ("ŞURUP", "SURUP", "SÜSPANS", "SUSPANS",
                                    "SOLÜSYON", "SOLUSYON", "ŞRP", "DAMLA")))
    return "TERCİHEN GECE YATMADAN ÖNCE " + ("İÇİNİZ" if sivi else "KULLANINIZ")


def _cycle_start_oneri(atc_code: str | None, name: str | None) -> str:
    """Menstrüel döngünün BELİRLİ gününde başlanan ilaçlar için öneri satırı.

    Doğum kontrol hapları (G03A) + klomifen (G03GB02): ilk kutuya adetin hangi
    günü başlanacağı ve paket şeması (21 gün + 7 gün ara / aralıksız 28 gün).
    Ertesi gün hapları (G03AD) döngü gününe BAĞLI DEĞİLDİR — orada kritik bilgi
    "ilişkiden sonra en kısa sürede" olduğundan o yazılır (yanlışlıkla "adetin
    1. günü" denmez).

    Kapsam DIŞI (bilinçli):
      • G03AC08 implant / G02BA RİA → uygulamayı hekim yapar, hastaya gün
        talimatı verilmez.
      • G03D progestinleri (Primolut-N/Duphaston/Tarlusal) → başlangıç günü
        ENDİKASYONA göre değişir (16-25 / 5-25 / 11-25...); sabit gün basmak
        yanlış yönlendirir, reçete/hekim talimatı esastır.
      • G03GA gonadotropinler → kısırlık protokolü hekim takvimiyle yürür.
      • L02BG letrozol/anastrozol → birincil endikasyon meme kanseri; ovülasyon
        indüksiyonu off-label olduğundan döngü günü basılmaz.
    """
    code = (atc_code or "").upper()
    n = (name or "").upper()
    # Ertesi gün hapları — adet gününe bağlı değil, hız kritik.
    if code.startswith("G03AD02"):       # ulipristal (ELLA/JOSEI/ULPISAD)
        return "İLİŞKİDEN SONRA EN KISA SÜREDE — EN GEÇ 5 GÜN"
    if code.startswith("G03AD"):         # levonorgestrel (ERTES/POSTPILL/NORLEVO)
        return "İLİŞKİDEN SONRA EN KISA SÜREDE — EN GEÇ 72 SAAT"
    if code.startswith("G03GB02"):       # klomifen (KLOMEN) — tam günü hekim seçer
        return "ADETİN 2-5. GÜNÜ BAŞLANIR · 5 GÜN KULLANILIR"
    if code.startswith("G03AC08"):       # etonogestrel implant — hekim uygular
        return ""
    if code.startswith("G03AC06"):       # depo medroksiprogesteron (DEPO-PROVERA)
        return "ADETİN İLK 5 GÜNÜ İÇİNDE YAPILIR · 3 AYDA BİR"
    if not code.startswith("G03A"):
        return ""
    if any(k in n for k in ("ENJEKT", "AMPUL", "FLAKON", "IMPLANT", "İMPLANT")):
        # Aylık kombine enjeksiyon (MESIGYNA): ilk doz adetin 1. günü.
        return "ADETİN 1. GÜNÜ YAPILIR · AYDA BİR"
    if code.startswith("G03AC"):         # mini hap (CERAZETTE/DESIRETT/ZLYNDA)
        return "ADETİN 1. GÜNÜ BAŞLAYIN · ARA VERMEDEN AYNI SAATTE"
    if code.startswith(("G03AA", "G03AB")):
        # Kombine hap — şema paket büyüklüğünden (addaki tablet sayısı):
        #   21 (ve 63 = 3×21'lik) → 21 gün kullan + 7 gün ara
        #   24+4 / 28 → aralıksız her gün (plasebo/vitamin haftası dahili)
        if "24+4" in n or re.search(r"\b28\b", n):
            return "ADETİN 1. GÜNÜ BAŞLAYIN · ARA VERMEDEN HER GÜN"
        if re.search(r"\b(21|63)\b", n):
            return "ADETİN 1. GÜNÜ BAŞLAYIN · 21 GÜN KULLANIP 7 GÜN ARA"
        return "ADETİN 1. GÜNÜ BAŞLAYIN"
    return ""


# ============================================================
# Mikronize progesteron yumuşak kapsül (G03DA04) — ÇİFT kullanım yolu
# ============================================================
def _dual_route_progesterone(atc_code: str | None, name: str | None) -> bool:
    """PROGESTAN/PROGYNEX yumuşak kapsülü mü? (hem AĞIZDAN hem VAJİNAL kullanılır)

    Mikronize progesteron kapsülünü doktor endikasyona göre bazen ağızdan
    yutturur, bazen vajinaya yerleştirtir; kutu/DB formu ise hep 'kapsül'dür.
    Yol bilgisi İLAÇTAN değil REÇETEDEN gelir → talimat reçetedeki "Kullanım
    Şekli"ne göre seçilir (bkz. _progesterone_route_override). Vajinal-TEK
    yollu ürünler (CRINONE jel, LUTINUS vajinal tb, CYCLOGEST ovül) ve IM
    ampuller kapsam DIŞIDIR — onlarda form zaten tek kanalı söyler.
    """
    n = (name or "").upper()
    if "KAPS" not in n:                    # KAPSÜL / KAPSUL / KAPS.
        return False
    code = (atc_code or "").upper()
    if code:
        return code.startswith("G03DA04")
    # ATC'siz kayıt / DB ile eşleşmeyen reçete satırı: ad bazlı yakala
    return any(k in n for k in ("PROGESTAN", "PROGYNEX", "PROGESTERON"))


def _progesterone_route_override(usage, atc_code: str | None,
                                 name: str | None) -> None:
    """Çift-yollu progesteron kapsülünde A talimatını reçetedeki yola göre kurar.

    usage.kullanim_sekli (Medula e-reçete "Kullanım Şekli" alanı) + doktor notu:
      • vajinal ibare ("Vajinal", "İntravajinal"...) e-reçetede VEYA reçete
        açıklamasında ("fitil olarak kullanınız" vb.) → "DOKTORUN ÖNERDİĞİ
        ŞEKİLDE OVÜL OLARAK VAJİNAYA YERLEŞTİRİNİZ"
      • ağızdan/oral → BİR BARDAK SU İLE YUTUNUZ
      • boş/bilinmiyor (kağıt reçete, reçete-sonu ekranından toplanan veri,
        DB akışı) → "DOKTORUN ÖNERDİĞİ ŞEKİLDE YUTUNUZ" + öneri satırında
        "DOKTORUNUZ VAJİNAYA KOY DEMİŞ İSE FİTİL OLARAK KULLANINIZ"
        (ibareler eczacı isteği, 2026-06-11; hasta diliyle "fitil").
    Vajinal ve belirsiz durumda aç/tok rozeti kaldırılır (yalnız orala anlamlı).
    """
    if not _dual_route_progesterone(atc_code, name):
        return
    ks = (usage.kullanim_sekli or "").upper().replace("İ", "I").replace("Ğ", "G")
    # Reçete açıklaması / doktor notu (Medula 'Açıklama'): "fitil olarak
    # kullanınız", "vajinal uygulanacak" gibi ibareler de yolu kesinleştirir.
    dn = (getattr(usage, "doktor_notu", "") or "").upper().replace("İ", "I").replace("Ğ", "G")
    if ("VAJ" in ks or "VAGIN" in ks
            or "VAJ" in dn or "VAGIN" in dn or "FITIL" in dn):
        # E-reçetede intravajinal ibare → büyük cümleyi vajinal kanalla yeniden
        # kur (route_class kilidi rc='1' oral kayıtta cümleyi YUTULUR'a geri
        # çevirmesin diye form + sınıf burada açıkça vajinal verilir).
        _periyot = (getattr(usage, "periyot", "") or "").strip().lower()
        _is_gunluk = (not _periyot) or _periyot.startswith(("gün", "gun"))
        usage.kullanim_talimati = build_kullanim_talimati(
            drug_name=name or "",
            gunluk_kez=usage.gunluk_kez if _is_gunluk else None,
            saat_arasi=usage.saat_arasi,
            kullanim_zamani=usage.kullanim_zamani,
            yemek="",
            doz_str=usage.doz,
            kullanim_sekli=usage.kullanim_sekli,
            form="vaginal_ovule_or_cream",
            route_class="13",
        )
        usage.talimat_satiri = ("DOKTORUN ÖNERDİĞİ ŞEKİLDE "
                                "OVÜL OLARAK VAJİNAYA YERLEŞTİRİNİZ")
        usage.yemek = ""
        usage.meal_badge = ""
    elif "AGIZ" in ks or "ORAL" in ks:
        # E-reçetede açıkça ağızdan → büyük cümle zaten oral kanalda.
        usage.talimat_satiri = "BİR BARDAK SU İLE YUTUNUZ"
    else:
        # Yol belli değil: doktorun sözlü önerisi esastır. Ana satır oral yolu
        # söyler; vajinal seçenek ("fitil olarak") öneri satırına iner — sağ
        # sütun en çok 4 satır bastığından iki cümle tek satıra sığmıyordu.
        usage.talimat_satiri = "DOKTORUN ÖNERDİĞİ ŞEKİLDE YUTUNUZ"
        usage.oneri_satiri = ("DOKTORUNUZ VAJİNAYA KOY DEMİŞ İSE "
                              "FİTİL OLARAK KULLANINIZ")
        if usage.kullanim_talimati:
            usage.kullanim_talimati = (
                usage.kullanim_talimati
                .replace(" AÇ VEYA TOK KARNINA", "")
                .replace(" TOK KARNINA", "")
                .replace(" AÇ KARNINA", "")
                .replace("BİR BARDAK SUYLA YUTULUR",
                         "DOKTORUNUZUN ÖNERDİĞİ ŞEKİLDE YUTUNUZ veya "
                         "DOKTORUNUZ VAJİNAYA KOY DEMİŞ İSE "
                         "FİTİL OLARAK KULLANINIZ")
            )
        usage.yemek = ""
        usage.meal_badge = ""


def _anthelmintic_repeat_oneri(atc_code: str | None, name: str | None) -> str:
    """Bağırsak antiparaziter ilaçlarda (P02C) 2. doz/rapel öneri satırı.

    İlaç erişkin solucanı öldürür ama YUMURTAYI öldürmez; yumurtadan çıkan yeni
    solucanlar olgunlaşınca reenfeksiyon olur. Bu yüzden çoğu bağırsak
    antiparaziterinde belirli bir aradan sonra ikinci doz/kür gerekir
    (özellikle kıl kurdu — Enterobius). Aralık etken maddeye göre değişir:
      • Albendazol/Mebendazol/Pirantel/Pirvinyum → tek doz, 2 (pirvinyumda 2-3)
        hafta sonra TEKRAR (kıl kurdu eradikasyonu için standart).
      • Piperazin → 7 günlük kür; ~1 hafta ara ile ikinci kür gerekebilir.
      • Levamizol → tek doz; 1 hafta sonra tekrarlanabilir (kancalı kurt vb.).
      • İvermektin → uyuz/strongyloides/kıl kurdunda 7-14 gün sonra 2. doz.
    Niklozamid (P02DA01, YOMESAN) KAPSAM DIŞI: birincil kullanım şerit (tenya) —
    tek kür yeterli; rapel yalnız cüce tenyada (H. nana) gerekir, hekim belirler.

    Cümle "GEREKEBİLİR" (kesin değil, hekime bağlı) tonundadır.
    "2. DOZ" ibaresi hastaya tedavinin TEKRARINI anlatmıyordu (kutudan bir
    tane daha almak sanılıyor) → "İKİNCİ UYGULAMA"; süreler halk diliyle
    GÜN olarak yazılır ("2 hafta" yerine "15 gün").
    """
    code = (atc_code or "").upper()
    if code.startswith(("P02CA",          # mebendazol / albendazol
                        "P02CC")):        # pirantel
        return "15 GÜN SONRA İKİNCİ UYGULAMA GEREKEBİLİR"
    if code.startswith("P02CX"):          # pirvinyum pamoat (PIROK)
        return "15-20 GÜN SONRA İKİNCİ UYGULAMA GEREKEBİLİR"
    if code.startswith("P02CB"):          # piperazin (kür şeklinde verilir)
        return "7 GÜN SONRA TEDAVİ TEKRARI GEREKEBİLİR"
    if code.startswith("P02CE"):          # levamizol (SITRAKS/PARAKS)
        return "7 GÜN SONRA İKİNCİ UYGULAMA GEREKEBİLİR"
    if code.startswith("P02CF"):          # ivermektin (ARMEC/ZIVER)
        return "7-15 GÜN SONRA İKİNCİ UYGULAMA GEREKEBİLİR"
    return ""


# ============================================================
# Uyuz / bit (P03) topikalleri — A etiketi düzeltmesi + TİP B protokolü
# ============================================================
def _parasite_kind(atc_code: str | None, name: str | None, form: str | None) -> str:
    """P03 (bit/uyuz) ürün türü: 'scabies' | 'scabies_benzyl' | 'lice' | ''.

    Aynı ATC (P03AC04 permetrin) İKİ AYRI hastalıkta kullanılır:
      • %5 krem/losyon → UYUZ (boyundan aşağı TÜM vücut, 8-12 saat bekletme)
      • %1 / %0.6 şampuan → BİT (nemli saçta 5-10 dk bekletip durulama)
    Ayrımı form/ad (ŞAMPUAN) yapar. Benzil benzoat (P03AX01: Benzogale/Scabin)
    uyuzda farklı bekletme (24 saat, ardışık geceler) kullanır → ayrı tür.
    """
    code = (atc_code or "").upper()
    if not code.startswith("P03"):
        return ""
    n = (name or "").upper()
    if ((form or "") == "shampoo_medicated"
            or any(k in n for k in ("SAMPUAN", "ŞAMPUAN", "SHAMPOO"))):
        return "lice"
    if code.startswith("P03AX01"):
        return "scabies_benzyl"
    return "scabies"


def _parasite_a_overrides(kind: str) -> tuple[str, str, str]:
    """A etiketi P03 düzeltmeleri: (kategori, talimat_satiri, oneri_satiri).

    Varsayılan krem talimatı "ETKİLENEN BÖLGEYE SÜRÜNÜZ" uyuzda YANLIŞ
    yönlendirir — uyuz ilacı sağlam görünen deri dahil tüm vücuda uygulanır.
    """
    if kind == "lice":
        return ("BİT İLACI", "NEMLİ SAÇA UYGULAYINIZ",
                "5-10 DK BEKLETİP DURULAYIN · 7-9 GÜN SONRA TEKRAR")
    if kind == "scabies_benzyl":
        return ("UYUZ İLACI", "BOYUNDAN AŞAĞI TÜM VÜCUDA SÜRÜNÜZ",
                "24 SAAT CİLTTE KALIR · EV HALKI BİRLİKTE TEDAVİ")
    if kind:
        return ("UYUZ İLACI", "BOYUNDAN AŞAĞI TÜM VÜCUDA SÜRÜNÜZ",
                "8-12 SAAT BEKLETİP YIKAYIN · EV HALKI BİRLİKTE TEDAVİ")
    return ("", "", "")


# TİP B uygulama protokolü (tam genişlikli adım + dikkat etiketi,
# render_glucose_guide_label düzeniyle basılır).
_PARASITE_PROTOCOLS: dict[str, dict[str, object]] = {
    "scabies": {
        "title": "UYUZ İLACI UYGULAMA",
        "steps": [
            "Ilık duş alın, cildi iyice KURULAYIN; ilaç serin ve kuru cilde uygulanır.",
            "BOYUNDAN AŞAĞI TÜM VÜCUDA ince tabaka sürün — sağlam görünen yerler dahil.",
            "Parmak araları, bilek, koltuk altı, kasık ve tırnak altlarını atlamayın; tırnakları kısa kesin.",
            "8-12 SAAT bekletin: akşam sürüp sabah yıkamak en uygunudur.",
            "Bekleme süresinde elinizi yıkarsanız ellere ilacı TEKRAR sürün.",
            "Süre dolunca duş alın; TEMİZ iç çamaşırı ve giysi giyin.",
        ],
        "caveats": [
            "Evde yaşayan HERKES, belirtisi olmasa da AYNI GÜN tedavi edilmelidir.",
            "Çamaşır/nevresim/havlu 60°C üstünde yıkanır; yıkanamayanlar 3 gün ağzı kapalı poşette bekletilir.",
            "Kaşıntı tedaviden sonra 2-4 hafta sürebilir — ilacın etkisiz olduğunu göstermez.",
            "Doktor önerisiyle 7-14 gün sonra ikinci uygulama yapılır.",
        ],
    },
    "scabies_benzyl": {
        "title": "UYUZ İLACI UYGULAMA",
        "steps": [
            "Ilık duş alın, cildi iyice KURULAYIN; ilaç serin ve kuru cilde uygulanır.",
            "BOYUNDAN AŞAĞI TÜM VÜCUDA sürün — sağlam görünen yerler dahil.",
            "Parmak araları, bilek, koltuk altı, kasık ve tırnak altlarını atlamayın; tırnakları kısa kesin.",
            "İlacı 24 SAAT ciltte bırakın; doktorunuz üst üste birkaç gece uygulanmasını isteyebilir.",
            "Bekleme süresinde elinizi yıkarsanız ellere ilacı TEKRAR sürün.",
            "Tedavi bitince duş alın; TEMİZ iç çamaşırı ve giysi giyin.",
        ],
        "caveats": [
            "Evde yaşayan HERKES, belirtisi olmasa da AYNI GÜN tedavi edilmelidir.",
            "Çamaşır/nevresim/havlu 60°C üstünde yıkanır; yıkanamayanlar 3 gün ağzı kapalı poşette bekletilir.",
            "Kaşıntı tedaviden sonra 2-4 hafta sürebilir — ilacın etkisiz olduğunu göstermez.",
        ],
    },
    "lice": {
        "title": "BİT İLACI UYGULAMA",
        "steps": [
            "Saçı normal şampuanla yıkayıp havluyla kurulayın (NEMLİ kalsın).",
            "İlacı saç diplerine ve saçın tamamına iyice yedirin.",
            "5-10 DAKİKA bekletin (kutudaki süreye uyun); göze kaçırmayın.",
            "Bol su ile iyice durulayın.",
            "Sık dişli tarakla ölü bitleri ve sirkeleri (yumurtaları) tarayın.",
            "7-9 GÜN sonra uygulamayı tekrarlayın (yeni çıkan bitler için).",
        ],
        "caveats": [
            "Ev halkının saçını kontrol edin; bit görülen herkes AYNI GÜN tedavi edilmelidir.",
            "Tarak, toka, şapka ve yastık kılıfı 60°C'de yıkanır veya 2 gün kapalı poşette bekletilir.",
            "Tedaviden sonra saçta kalan ölü sirkeler tarakla temizlenir.",
        ],
    },
}


# ============================================================
# Yara izi (nedbe) jelleri — Contractubex/Noskar; A düzeltmesi + TİP B
# ============================================================
# Soğan ekstresi + heparin + allantoin jeller YARA İZİ (skar) tedavisidir:
# açık yaraya SÜRÜLMEZ, yara kapandıktan sonra başlanır; günde 2-3 kez tam
# emilene kadar hafif masaj; eski/sert izde gece bandaj altında; taze iz
# güneş/UV ve aşırı soğuktan korunur; tedavi haftalar-aylar sürer (KT teyitli,
# 2026-06-13). "YARA İYİLEŞTİRİCİ" kategorisi yanlış yönlendiriyordu.
_SCAR_GEL_BRANDS = ("CONTRACTUBEX", "KONTRAKTUBEKS", "NOSKAR")


def _is_scar_gel(name: str | None) -> bool:
    n = (name or "").upper().replace("İ", "I")
    return any(b in n for b in _SCAR_GEL_BRANDS)


_SCAR_PROTOCOL: dict[str, object] = {
    "title": "YARA İZİ JELİ UYGULAMA",
    "steps": [
        "Tedaviye yaranız TAM KAPANDIKTAN sonra başlayın — açık yaraya sürülmez.",
        "Jeli yalnız İZ (nedbe) dokusunun üzerine sürün.",
        "Tam emilene kadar HAFİF masajla yedirin; taze izde güçlü masajdan kaçının.",
        "GÜNDE 2-3 KEZ uygulayın.",
        "Sert/eski izlerde gece üzerini kapatarak (bandajla) uygulayabilirsiniz.",
    ],
    "caveats": [
        "Tedavi izin yaşına göre HAFTALAR-AYLAR sürer — sabırla düzenli kullanın.",
        "Taze izi GÜNEŞTEN/solaryumdan ve aşırı soğuktan koruyun (gerekirse kapatın).",
        "Buğday proteinine alerjiniz varsa kullanmayın.",
        "Göz ve mukozaya değdirmeyin; uygulamadan sonra ellerinizi yıkayın.",
    ],
}


# ============================================================
# Siğil/nasır solüsyonları (D11AF) — A düzeltmesi + TİP B protokolü
# ============================================================
def _wart_kind(atc_code: str | None, name: str | None) -> str:
    """Siğil/nasır solüsyonu türü: 'wart_5fu' | 'wart_keratolytic' | ''.

    İki farklı kimya, iki farklı şema (KT'lerden, 2026-06-12):
      • VERRUTOL (VERRUMAL muadili) = 5-FLUOROURASİL + salisilik asit —
        SİTOSTATİK: gebelikte kesinlikle kullanılmaz; günde 2-3 kez; eski film
        tabakası soyulur; geniş alana uygulanmaz.
      • DUODERM (Duofilm tipi) = salisilik + laktik asit kollodyon —
        siğilde günde 1, nasırda günde 2; önce ılık suda bekletilir;
        yüz/genital/ben üzerine ve diyabette kullanılmaz.
    """
    n = (name or "").upper().replace("İ", "I")
    code = (atc_code or "").upper()
    if not (code.startswith("D11AF")
            or "SIGIL" in n or "SİĞİL" in (name or "").upper()):
        return ""
    if any(b in n for b in ("VERRUTOL", "VERRUMAL", "FLUOROURASIL", "FLUOROURACIL")):
        return "wart_5fu"
    return "wart_keratolytic"


def _wart_a_overrides(kind: str) -> tuple[str, str, str]:
    """Siğil solüsyonu A etiketi: (kategori, talimat_satiri, oneri_satiri)."""
    if kind == "wart_5fu":
        return ("SİĞİL İLACI",
                "YALNIZ SİĞİLİN ÜZERİNE SÜRÜNÜZ",
                "GEBELİKTE KULLANILMAZ · SAĞLAM DERİYE TAŞIRMAYIN")
    return ("SİĞİL / NASIR İLACI",
            "YALNIZ SİĞİL/NASIR ÜZERİNE SÜRÜNÜZ",
            "SAĞLAM DERİYE TAŞIRMAYIN")


_WART_PROTOCOLS: dict[str, dict[str, object]] = {
    "wart_keratolytic": {
        "title": "SİĞİL/NASIR İLACI UYGULAMA",
        "steps": [
            "Bölgeyi 5 dakika ılık suda bekletin, iyice KURULAYIN.",
            "Çevredeki sağlam deriyi korumak için etrafına vazelin sürebilirsiniz.",
            "Fırçayla YALNIZ siğil/nasır üzerine ince tabaka sürün; kurusun (beyaz film).",
            "SİĞİLDE günde 1 kez · NASIRDA günde 2 kez uygulayın.",
            "Her seferinde eski beyaz tabakayı soyun; ölü deriyi ponza ile NAZİKÇE alın.",
            "Sağlam deriye taşarsa hemen silin, gerekirse su ile yıkayın.",
        ],
        "caveats": [
            "İyileşme 6-12 HAFTA sürebilir — sabırla her gün uygulayın.",
            "YÜZ, koltuk altı/kasık, genital bölge ve BEN'lerin üzerine UYGULANMAZ.",
            "Şeker hastaları ve dolaşım bozukluğu olanlar doktora danışmadan kullanmamalı.",
            "Yanıcıdır — ateşten uzak tutun; kapağı sıkıca kapatın (çabuk kurur).",
        ],
    },
    "wart_5fu": {
        "title": "SİĞİL İLACI UYGULAMA",
        "steps": [
            "Çevredeki sağlam deriyi korumak için siğilin etrafına vazelin sürün.",
            "Kapaktaki fırçayla YALNIZ siğilin üzerine ince tabaka sürün; kurusun.",
            "GÜNDE 2-3 KEZ uygulayın.",
            "Yeni uygulamadan önce eski film tabakasını soyup çıkarın.",
            "Ölü dokuyu törpü/ponza ile nazikçe alın — derine inip KANATMAYIN.",
        ],
        "caveats": [
            "GEBELİKTE ve emzirmede KESİNLİKLE kullanılmaz (sitostatik içerir).",
            "Ortalama tedavi ~6 hafta; siğil düşse de doktorun önerdiği süre devam edin.",
            "Aynı anda çok sayıda siğile / geniş alana uygulamayın.",
            "Yüz ve genital bölgede doktora danışmadan kullanmayın; göze değdirmeyin.",
        ],
    },
}


# ============================================================
# Diyaliz solüsyonları — "İÇİNİZ" / İV SOLÜSYON yanlışına karşı koruma
# ============================================================
def _dialysis_kind(atc_code: str | None, name: str | None) -> str:
    """Diyaliz çözeltisi türü: 'peritoneal' | 'hemo' | ''.

    PHYSIONEAL/EXTRANEAL/CAPD/BALANCE periton diyaliz torbaları İÇİLMEZ,
    damara da verilmez — karın içi (periton) kateterinden uygulanır. Bazı
    kayıtlarda form yanlışlıkla şurup kaldığından talimat "İÇİNİZ" çıkıyordu.
    ATC B05D (periton) / B05Z (hemodiyaliz konsantresi) veya addaki
    DİYALİZ/DİALİZ ibaresi ile yakalanır.
    """
    n = (name or "").upper().replace("İ", "I")
    code = (atc_code or "").upper()
    if code.startswith("B05D"):
        return "peritoneal"
    if code.startswith("B05Z"):
        return "hemo"
    if "DIYALIZ" in n or "DIALIZ" in n or "DIALYSIS" in n:
        return "hemo" if "HEMOD" in n else "peritoneal"
    return ""


def _dialysis_a_overrides(kind: str) -> tuple[str, str]:
    """Diyaliz çözeltisi A etiketi: (kategori, talimat_satiri)."""
    if kind == "hemo":
        return ("DİYALİZ SOLÜSYONU",
                "DİYALİZ MAKİNESİNDE KULLANILIR — İÇİLMEZ")
    return ("PERİTON DİYALİZ SOLÜSYONU",
            "ÖĞRETİLDİĞİ ŞEKİLDE KARIN (PERİTON) KATETERİNDEN UYGULANIR")


# ============================================================
# Tırnak mantarı cilası / solüsyonu — A etiketi düzeltmesi + TİP B protokolü
# ============================================================
def _nail_kind(atc_code: str | None, name: str | None) -> str:
    """Tırnak mantarı ürün türü: 'ciclopirox' | 'amorolfine' | 'tioconazole' | ''.

    Üç ayrı uygulama şeması vardır (KT'lerden, 2026-06-12):
      • Siklopiroks %8 cila SETİ (D01AE14: OPILOX/NIBULEN %8/SIROKSIL/MICLAST/
        TINEAX) → 1. ay GÜN AŞIRI, 2. ay haftada 2, 3. aydan sonra haftada 1;
        haftada 1 kez tüm cila alkollü mendille silinir + tırnak törpülenir;
        en çok 6 ay.
      • Amorolfin %5 (D01AE16: LOCERYL/FUNGINAIL) → HAFTADA 1-2 kez;
        her seferinde törpüle → alkollü mendille sil → sür; el 6 / ayak 9-12 ay.
      • Tiokonazol %28 solüsyon (D01AC07: DERMO-TROSYD/DERMO-REST) → GÜNDE 2 kez
        fırçayla tırnak + çevre deriye; 6 ay (12 aya uzayabilir).
    Ayrım adda "TIRNAK" şartıyla yapılır — aynı ATC'lerin krem/dermal çözelti
    formları (NIBULEN %1 krem, CANOLEN) tırnak protokolü ALMAZ.
    """
    n = (name or "").upper().replace("İ", "I")
    if "TIRNAK" not in n:
        return ""
    code = (atc_code or "").upper()
    if code.startswith("D01AE16"):
        return "amorolfine"
    if code.startswith("D01AC07"):
        return "tioconazole"
    if code.startswith("D01AE14"):
        return "ciclopirox"
    # ATC'siz kayıt (SKRS): marka bazlı ayrım
    if any(b in n for b in ("LOCERYL", "FUNGINAIL")):
        return "amorolfine"
    if any(b in n for b in ("TROSYD", "DERMO-REST", "DERMO REST")):
        return "tioconazole"
    if any(b in n for b in ("OPILOX", "NIBULEN", "SIROKSIL", "MICLAST",
                            "TINEAX", "CILA")):
        return "ciclopirox"
    return ""


def _nail_a_overrides(kind: str) -> tuple[str, str, str]:
    """Tırnak ürünü A etiketi: (kategori, talimat_satiri, oneri_satiri)."""
    if kind == "amorolfine":
        return ("TIRNAK MANTARI İLACI",
                "HASTA TIRNAKLARA SÜRÜNÜZ",
                "HAFTADA 1-2 KEZ · ÖNCE TÖRPÜLEYİP ALKOLLÜ BEZLE SİLİN")
    if kind == "tioconazole":
        return ("TIRNAK MANTARI İLACI",
                "FIRÇAYLA TIRNAĞA VE ÇEVRESİNDEKİ DERİYE SÜRÜNÜZ",
                "10-15 DAKİKA KURUMAYA BIRAKIN")
    return ("TIRNAK MANTARI İLACI",            # ciclopirox
            "HASTA TIRNAĞA İNCE TABAKA SÜRÜNÜZ",
            "1. AY GÜN AŞIRI · UYGULAMA ADIMLARI ARKA ETİKETTE")


# TİP B uygulama protokolü (tam genişlikli adım + dikkat etiketi).
# Kaynak: OPILOX/LOCERYL/DERMO-TROSYD kullanma talimatları (2026-06-12).
_NAIL_PROTOCOLS: dict[str, dict[str, object]] = {
    "ciclopirox": {
        "title": "TIRNAK CİLASI UYGULAMA",
        "steps": [
            "Başlamadan önce hasta tırnağı makasla olabildiğince kesin, kalan hasta kısmı törpüleyin.",
            "Cilayı hasta tırnağın TAMAMINA ince tabaka halinde sürün, kurumasını bekleyin.",
            "1. AY: GÜN AŞIRI (iki günde bir) sürün.",
            "2. AY: haftada en az 2 kez · 3. AYDAN SONRA: haftada 1 kez.",
            "HAFTADA 1 KEZ tüm cila tabakasını alkollü mendille silin, hasta tırnağı yeniden törpüleyin.",
            "Kapağı her kullanımdan sonra SIKICA kapatın — solüsyon çabuk kurur.",
        ],
        "caveats": [
            "Tedavi 6 AYI geçmemelidir; düzelme yoksa doktorunuza başvurun.",
            "Hasta tırnakta kullandığınız törpüyü SAĞLAM tırnaklara değdirmeyin.",
            "Tedavi boyunca oje / takma tırnak kullanmayın.",
            "Yalnız tırnak içindir; göze ve yaraya değdirmeyin.",
        ],
    },
    "amorolfine": {
        "title": "TIRNAK CİLASI UYGULAMA",
        "steps": [
            "HAFTADA 1-2 KEZ uygulanır.",
            "Önce hasta tırnağın yüzeyini kutudan çıkan törpüyle iyice törpüleyin.",
            "Alkollü mendille tırnak yüzeyini silip temizleyin.",
            "Cilayı hasta tırnağın TAMAMINA sürün; 3-5 dakika kurumasını bekleyin.",
            "Her uygulamada aynı sırayı izleyin: TÖRPÜLE → SİL → SÜR.",
        ],
        "caveats": [
            "EL tırnağında ~6 AY, AYAK tırnağında 9-12 AY kesintisiz sürdürün — tırnak tamamen yenilenene kadar.",
            "Hasta tırnakta kullanılan törpü SAĞLAM tırnaklara değdirilmez.",
            "Tedavi boyunca oje / takma tırnak kullanmayın.",
            "Tiner gibi çözücülerle çalışırken eldiven giyin — cilayı çözer.",
        ],
    },
    "tioconazole": {
        "title": "TIRNAK SOLÜSYONU UYGULAMA",
        "steps": [
            "GÜNDE 2 KEZ uygulayın (sabah ve akşam, 12 saat ara ile).",
            "Şişenin fırçasıyla hasta tırnağın TAMAMINA ve çevresindeki deriye ince tabaka sürün.",
            "10-15 dakika kurumaya bırakın; hemen çorap/ayakkabı giymeyin.",
            "Tırnak kesme/törpüleme gerekiyorsa uygulamadan ÖNCE yapın.",
        ],
        "caveats": [
            "Tedavi genellikle 6 AY sürer; doktor önerisiyle 12 aya uzayabilir.",
            "Belirtiler geçse de tırnak tamamen yenilenene kadar bırakmayın.",
            "Tedavi boyunca oje / takma tırnak kullanmayın.",
        ],
    },
}


def _atc_oneri_satiri(
    atc_code: str | None,
    daily_freq: int | None,
    form: str = "",
    name: str = "",
) -> str:
    """Günde 1 alınan ilaçlarda ATC tabanlı kullanım zamanı önerisi (sağ sütun).

    Örn. statin (C10AA) → 'TERCİHEN AKŞAM KULLANINIZ'. Günde 2+ alınan ilaçlarda
    zaman dilimleri zaten sol dozaj ızgarasında göründüğü için öneri üretilmez.
    Bazı ilaçlarda (örn. levotiroksin) generic öneri yerine ÖZEL ibare yazılır.
    Enjeksiyon formuna (ampul — genelde sağlıkçı uygular, akut) saat önerisi
    basılmaz (örn. Avil IM ampule 'GECE YATMADAN' yazılmaz).
    """
    if daily_freq and daily_freq > 1:
        return ""
    if (form or "").lower().startswith("injection") or any(
            k in (name or "").upper()
            for k in ("AMPUL", "ENJEKS", "ENJ.", "FLAKON")):
        return ""
    code = (atc_code or "").upper()
    for pfx in sorted(_ATC_ONERI_OZEL.keys(), key=len, reverse=True):
        if code.startswith(pfx):
            return _ATC_ONERI_OZEL[pfx]
    for z in _atc_preferred_time(atc_code):
        txt = _ZAMAN_ONERI_TEXT.get((z or "").strip().lower())
        if txt:
            return txt
    return ""


def _kullanim_zamani_from(
    daily_freq: int | None,
    atc_code: str | None = None,
) -> list[str]:
    """daily_freq'ten sabah/öğle/akşam parça listesi türet.

    daily_freq=1 ve ATC için tercih edilen saat varsa onu kullan (örn. statin → akşam).
    """
    if not daily_freq:
        return []
    if daily_freq == 1:
        # ATC tercih edilen saat varsa onu kullan, yoksa boş (= "GÜNDE 1 DEFA")
        return _atc_preferred_time(atc_code)
    if daily_freq == 2:
        return ["sabah", "akşam"]
    if daily_freq == 3:
        return ["sabah", "öğle", "akşam"]
    if daily_freq == 4:
        return ["sabah", "öğle", "akşam", "gece"]
    return []


def _build_doz_str(
    default_dose: str | None,
    dose_unit: str | None,
    form: str | None = None,
    olcek_ml=None,
) -> str:
    """Form bazlı doz cümlesi üretir.

    Mantık: form'a göre doğal birim ve adet:
      - tablet/kapsül            → '1 TANE'
      - syrup/suspension         → '1 ÖLÇEK (5 ml)'
      - powder_for_suspension    → '1 ÖLÇEK (5 ml)'
      - oral_drop                → 'X DAMLA' (X = default_dose)
      - eye_drop/ear_drop/nasal_drop → '1 DAMLA'
      - inhaler                  → '2 PUF'  (varsayılan idame)
      - oral_spray_throat        → '1 PUF'
      - nasal_spray              → '1 PUF'
      - nebule                   → '1 AMPUL'
      - injection_sc             → '1 ENJEKTÖR'
      - suppository_rectal       → '1 FİTİL'
      - vaginal_ovule_or_cream   → '1 OVÜL'
      - sachet_oral              → '1 SAŞE'
      - cream/gel/shampoo        → '' (miktarsız, etkilenen bölge bazlı)
    """
    f = (form or "").lower()
    dose_dose = format_dose_amount((default_dose or "").strip()) or "1"

    # İnsülin "ünite" ile dozlanır → form'a (injection_sc) bakmadan ünite ile dön.
    if (dose_unit or "").strip().lower() in ("ünite", "unite", "iu", "u"):
        return f"{dose_dose} ÜNİTE"

    # Form bazlı net doz birimi
    if f in ("tablet_normal", "tablet_chewable", "tablet_effervescent",
             "tablet_enteric_or_extended", "tablet_sublingual",
             "capsule_normal", "capsule_pellet_open"):
        return f"{dose_dose} TANE"
    if f in ("syrup_or_suspension", "powder_for_suspension"):
        # Ölçek hacmi DB'den (Duphalac vb. ~30 ml; çoğu 5 ml). Tam sayıysa ondalık
        # gösterilmez: "1 ÖLÇEK (30 ml)" / "1 ÖLÇEK (5 ml)".
        _v = 5.0
        try:
            if olcek_ml and float(olcek_ml) > 0:
                _v = float(olcek_ml)
        except (TypeError, ValueError):
            _v = 5.0
        _vs = str(int(_v)) if _v.is_integer() else f"{_v:g}".replace(".", ",")
        return f"1 ÖLÇEK ({_vs} ml)"
    if f == "oral_drop":
        return f"{dose_dose} DAMLA"
    if f in ("eye_drop", "ear_drop", "nasal_drop"):
        return "1 DAMLA"
    if f == "eye_ointment":
        return "1 İNCE ŞERİT"
    if f in ("inhaler_pmdi", "inhaler_dpi"):
        # Her uygulama bir 'SEFER' derin nefes (puf yerine hasta diliyle); A ızgarasında
        # birim düşer, B'de "İKİ SEFER", talimatta "DERİN NEFESLE İÇE ÇEKİNİZ".
        return f"{dose_dose} SEFER"
    if f == "oral_spray_throat":
        return f"{dose_dose} FIS"
    if f == "nasal_spray":
        return f"{dose_dose} FIS"
    if f == "nebule":
        return "1 AMPUL"
    if f == "injection_sc":
        return "1 ENJEKTÖR"
    if f == "injection_im" or f == "injection_iv":
        return "1 DOZ"
    if f == "suppository_rectal":
        return "1 FİTİL"
    if f in ("enema_rectal", "cream_rectal"):
        # Lavman/rektal süspansiyon-krem FİTİL DEĞİLDİR — "1 FİTİL" yazılmaz;
        # miktarsız bırakılır, "GÜNDE X KEZ MAKATTAN UYGULAYINIZ" yeterli.
        return ""
    if f == "vaginal_ovule_or_cream":
        return "1 OVÜL"
    if f == "sachet_oral":
        return "1 SAŞE"
    if f == "gargara_mouthwash":
        return "1 ÖLÇEK (15 ml)"
    if f in ("cream_or_ointment_topical", "gel_topical", "shampoo_medicated",
             "oromucosal_gel", "transdermal_patch"):
        return ""  # miktarsız — "ETKİLENEN BÖLGEYE" bitiş cümlesi yeterli

    # Fallback: dose_unit'e güven
    if not dose_unit:
        return f"{dose_dose} TANE"
    unit_map = {
        "tablet":   "TANE",   "kapsül":   "TANE",
        "ml":       "ml",     "damla":    "DAMLA",
        "puf":      "PUF",    "ampul":    "AMPUL",
        "fitil":    "FİTİL",  "ovül":     "OVÜL",
        "saşe":     "SAŞE",   "uygulama": "",
        "doz":      "DOZ",    "bant":     "BANT",
    }
    unit_tr = unit_map.get(dose_unit, dose_unit.upper())
    return f"{dose_dose} {unit_tr}" if unit_tr else ""


def _build_usage_label(
    drug: sqlite3.Row,
    usage_note: str = "",
    saklama_badge: str = "",
    custom_talimat: str = "",
    parenteral_route_mode: str = "",
) -> UsageLabel:
    """drugs row'undan A (Temel Kullanım) etiketini doldurur.

    NOT: A etiketi SADECE kullanım bilgisi içerir — alkol/kan sulandırıcı gibi
    ciddi uyarılar buraya BASILMAZ (onlar C etiketine gider). Buradaki tek metin
    'usage_note' yalnızca doktorun kullanımla ilgili notudur (varsa).
    """
    daily_freq = drug["daily_freq"]
    hours_apart = drug["hours_apart"]
    meal_relation = drug["meal_relation"] or ""
    kategori = (drug["indication_short"] or "").upper()
    form = drug["form"] or ""
    try:
        _ol = drug["olcek_ml"]
    except (KeyError, IndexError):
        _ol = None
    doz_str = _build_doz_str(drug["default_dose"], drug["dose_unit"], form, olcek_ml=_ol)
    # Topikal/dermal sprey (Oceral/Exoderil/Lamisil sprey): form cream_or_ointment_
    # topical'a düştüğü için yukarıda doz boş kalır → "1 PUF" yaz (tane/miktarsız değil).
    if _is_topical_spray(drug["atc_code"], drug["name"] or "", form, drug["route"] or ""):
        doz_str = _topical_spray_puf_doz(doz_str or (drug["default_dose"] or ""))

    # kullanim_sekli — Medula'dan gelen "Kullanım Şekli" alanı yoksa, route'tan türet
    route_to_ks = {
        "göze":        "Göz üzerine",
        "buruna":      "Burun içine",
        "kulağa":      "Kulak içine",
        "vajinal":     "Vajinal",
        "rektal":      "Rektal",
        "cilt üzerine":"Cilt üzerine",
        "ağıza":       "Ağız içine",
    }
    kullanim_sekli = route_to_ks.get(drug["route"] or "", "")

    # Günde 1 alınan ilaçta ATC tercih saati (örn. statin → akşam) artık sol
    # ızgaraya değil sağ sütuna öneri olarak yazılır → atc geçmeyip boş bırakıyoruz.
    zaman_list = _kullanim_zamani_from(daily_freq, None)
    oneri_satiri = _atc_oneri_satiri(drug["atc_code"], daily_freq, form,
                                     drug["name"] or "")

    # Antidepresanlar (N06A: SSRI/SNRI/TCA/diğer) — etkisi GECİKMELİ başlar
    # (genelde 2-3 hafta). Bu, hasta uyumu için en kritik bilgi olduğundan sağ
    # sütun ÖNERİ satırına yazılır (sıklıktan bağımsız görünür). Öneri satırı
    # dar olduğundan (≈2 satır) yalnızca etki-başlangıcına ayrılır; sedatif
    # antidepresanların "gece" tercihi varsa SOL ızgaraya taşınır (kaybolmasın).
    _atc_u = (drug["atc_code"] or "").upper()
    if _atc_u.startswith("N06A"):
        if daily_freq == 1 and not zaman_list:
            pref = _atc_preferred_time(drug["atc_code"])   # sedatiflerde ['gece']
            if pref:
                zaman_list = pref
        oneri_satiri = "ETKİSİ 2-3 HAFTADA BAŞLAR"
    # Ereksiyon ilaçları (G04BE) — kalp ilacı kullanan hasta İÇMEMELİ,
    # önce doktora sormalı (nitrat etkileşimi TİP C etiketinde ayrıntılı).
    elif _atc_u.startswith("G04BE"):
        oneri_satiri = "KALP İLACI KULLANIYORSANIZ KULLANMAYIN, DOKTORUNUZA DANIŞIN"
    # Oftalmik siklosporin (Restasis/Depores) — etki aylar içinde birikir;
    # erken bırakma en sık başarısızlık nedeni (ayrıntı TİP C etiketinde).
    # Metin eczacının sadeleştirdiği hali; öneri satırı en çok 3 satır basar.
    elif _atc_u.startswith("S01XA18"):
        oneri_satiri = "ETKİSİ 3-6 AYDA YAVAŞ YAVAŞ ÇIKAR — DÜZENLİ, DİSİPLİNLİ KULLANIN"
    # Hidrokinon leke kremi (Expigment) — güneş açılan lekeyi geri koyulaştırır.
    elif _atc_u.startswith("D11AX11"):
        oneri_satiri = "GÜNEŞTEN KORUNUN — GÜNDÜZ GÜNEŞ KORUYUCU KULLANIN"
    # Triptanlar (N02CC: Relpax/Migrex/Migreout/Zomig/Imigran) — ATAK ilacı:
    # ağrı başlar başlamaz; koruyucu değil (ayrıntı TİP C etiketinde).
    elif _atc_u.startswith("N02CC"):
        oneri_satiri = "AĞRI BAŞLAR BAŞLAMAZ ALIN — KORUYUCU İLAÇ DEĞİLDİR"
    # Ergotaminli kombinasyonlar (N02CA: Avmigran/Ergafein/Cafergot) — krizin
    # ilk belirtisinde; günlük/haftalık sınır kritik (TİP C'de).
    elif _atc_u.startswith("N02CA"):
        oneri_satiri = "KRİZİN İLK BELİRTİSİNDE ALIN — DOZ SINIRINI AŞMAYIN"
    # Demir (B03A/B03B) — sabah aç karnına emilim daha iyi; çay/kahve/süt emilimi
    # dramatik düşürür (polifenol/kazein şelasyonu). Siyah dışkı normaldir — hasta
    # önceden bilmezse endişelenir ve ilacı bırakır.
    elif _atc_u.startswith("B03A") or _atc_u.startswith("B03B"):
        oneri_satiri = "SABAH AÇ KARNINA — ÇAY/KAHVE/SÜT İLE BIRLIKTE ALMAYIN; SİYAH DİŞKİ NORMALDIR"
    # Sistemik kortikosteroidler (H02AB: prednizolon/metilprednizolon/deksametazon)
    # — sabah alım (vücudun doğal kortizol ritmi) + mineralokortikoid etkisi nedeniyle
    # tuz tutulumu (ödem/HT) ve glukokortikoid etkisi nedeniyle hiperglisemi riski.
    elif _atc_u.startswith("H02AB") or _atc_u.startswith("H02A"):
        oneri_satiri = "TERCİHEN SABAH KULLANINIZ — TUZ VE ŞEKERLİ GIDALARDAN KAÇININ"
    # Tetrasiklinler (J01AA: doksisiklin Monodoks/Tetradox vb.) — yemek borusunu
    # tahriş eder; bol su ile DİK durarak alınıp içtikten sonra yatılmamalı.
    # (Güneş hassasiyeti ayrıca sol sütundaki "GÜNEŞTEN KORUN" rozetiyle verilir.)
    elif _atc_u.startswith("J01AA"):
        oneri_satiri = "İÇTİKTEN SONRA 1 SAAT DİK OTURUN, YATMAYIN"
    # Diğer antibiyotikler (J01) — belirtiler geçse de kür tamamlanmalı (direnç/
    # nüks). Tetrasiklin (J01AA) üstteki daha kritik "dik oturun" ibaresini korur;
    # öneri satırı dar (≈2 satır) olduğundan ikisi birden sığmaz.
    elif _atc_u.startswith("J01"):
        oneri_satiri = "BİTİRENE KADAR DÜZENLİ KULLANINIZ"
    # Montelukast + antihistaminik kombinleri (R03DC53: Desmont/Levmont) —
    # içinde antihistaminik (sedatif) var + montelukast akşam dozlanır →
    # tercihen gece. Sıklıktan bağımsız (freq=2 kayıtlı olsa da gösterilir).
    elif _atc_u.startswith("R03DC53"):
        oneri_satiri = "TERCİHEN GECE YATMADAN ÖNCE KULLANINIZ"
    # Bağırsak antiparaziterleri (P02C: albendazol/pirantel/pirvinyum/piperazin/
    # levamizol/ivermektin) — ilaç erişkin solucanı öldürür, yumurtayı öldürmez;
    # yumurtadan çıkan solucanlar için belirli aradan sonra 2. doz/kür gerekebilir.
    elif _rep := _anthelmintic_repeat_oneri(drug["atc_code"], drug["name"]):
        oneri_satiri = _rep
    # Menstrüel döngüye bağlı başlangıç: doğum kontrol hapı (adetin 1. günü +
    # 21+7 ara / aralıksız 28 şeması), ertesi gün hapı (en kısa sürede),
    # klomifen (adetin 2-5. günü). Ayrıntı: _cycle_start_oneri.
    elif _cyc := _cycle_start_oneri(drug["atc_code"], drug["name"]):
        oneri_satiri = _cyc
    # Sedatif antihistaminik (Sipraktin/Allerset vb.) — günde tek doz ise gece.
    elif daily_freq in (None, 1):
        _sah = _sedating_antihistamine_oneri(drug["atc_code"], form, drug["name"] or "")
        if _sah:
            oneri_satiri = _sah

    # Yukarıdaki gruplardan hiçbiri yakalamamışsa sağ sütunu doldurmak için
    # ATC bazlı bonus bilgi satırı (yan etki / etkileşim / kullanım ipucu).
    if not oneri_satiri:
        oneri_satiri = _bonus_oneri_satiri(drug["atc_code"], form, drug["name"] or "")

    # route_class güvenlik kilidi: kolon yoksa (eski DB) sessizce devre dışı
    try:
        _route_class = drug["route_class"] or ""
    except (IndexError, KeyError):
        _route_class = ""

    # Kas içi / damar içi enjeksiyonda öğün ifadesi talimat cümlesine yazılmaz
    # (aşağıda rozetin gizlenmesi gibi): oral muadilden kopyalanan meal_relation
    # "1 DOZ YEMEKTEN SONRA KAS İÇİNE UYGULANIR" gibi çelişkili cümle üretir.
    _talimat_yemek = "" if form in ("injection_im", "injection_iv") else meal_relation
    talimat = build_kullanim_talimati(
        drug_name=drug["name"] or "",
        gunluk_kez=daily_freq,
        saat_arasi=hours_apart,
        kullanim_zamani=zaman_list,
        yemek=_talimat_yemek,
        doz_str=doz_str,
        kullanim_sekli=kullanim_sekli,
        form=form,
        route_class=_route_class,
        parenteral_route_mode=parenteral_route_mode,
    )
    # Depo kontraseptif enjeksiyonlar — günlük değil PERİYODİK uygulanır;
    # "GÜNDE 1 DEFA" fallback'i tehlikeli biçimde yanlış olur.
    #   G03AC06 Depo-Provera → 3 ayda bir, Mesigyna (G03AA enjektör) → ayda bir.
    # IM depot enjeksiyonlardır; parenteral yol ayarına saygı gösterilir
    # (KAPALI → yol gizli genel cümle, AÇIK → "KAS İÇİNE").
    if parenteral_route_mode == "generic":
        _depot_end = "SAĞLIK PERSONELİ TARAFINDAN UYGULANIR"
    elif parenteral_route_mode == "recete":
        _depot_end = "SAĞLIK PERSONELİ TARAFINDAN KAS İÇİNE UYGULANIR"
    else:
        _depot_end = "KAS İÇİNE UYGULANIR (SAĞLIK PERSONELİ)"
    if _atc_u.startswith("G03AC06"):
        talimat = f"3 AYDA BİR 1 DOZ {_depot_end}."
    elif _atc_u.startswith("G03AA") and "ENJEKT" in (drug["name"] or "").upper():
        talimat = f"AYDA BİR 1 DOZ {_depot_end}."

    # --- Yeni tasarım: dozaj matrisi (sadece dolu zaman dilimleri) ---
    dose_tok = _grid_dose_token(doz_str)
    disp_map = {"sabah": "SABAH", "öğle": "ÖĞLEN", "akşam": "AKŞAM", "gece": "GECE"}
    zaman_satirlari: list[list[str]] = []
    for z in zaman_list:
        disp = disp_map.get((z or "").strip().lower())
        if disp:
            zaman_satirlari.append([disp, dose_tok])
    if not zaman_satirlari and daily_freq:
        seq = {
            1: ["GÜNDE"],
            2: ["SABAH", "AKŞAM"],
            3: ["SABAH", "ÖĞLEN", "AKŞAM"],
            4: ["SABAH", "ÖĞLEN", "AKŞAM", "GECE"],
        }.get(daily_freq, [f"GÜNDE {daily_freq}"])
        zaman_satirlari = [[s, dose_tok] for s in seq]

    meal_badge = _MEAL_BADGE_MAP.get(meal_relation.strip().lower(), "")
    # Kas içi / damar içi enjeksiyonda aç/tok rozeti anlamsız (ağızdan alınmaz).
    if form in ("injection_im", "injection_iv"):
        meal_badge = ""
    # "AÇ TOK FARKETMEZ" rozeti bilgi taşımıyor ve geniş kutusu sağ sütunu
    # kısaltıp kritik öneri satırını kırpıyor/düşürüyor → öneri satırı taşıyan
    # sınıflarda bastırılır (AÇ/TOK rozetleri kalır):
    #   G04BE "KALP İLACI ... KULLANMAYIN" (ORCAFIL vakası),
    #   C10AA/C10BA statin "TERCİHEN GECE YATMADAN ÖNCE" (ATOR vakası).
    # meal_relation da boşaltılır: render rozeti usage.yemek'ten yeniden türetiyor.
    if (_atc_u.startswith(("G04BE", "C10AA", "C10BA", "M03BX02", "N02CC", "N02CA", "N07CA03"))
            and meal_relation.strip().lower() == "fark etmez"):
        meal_badge = ""
        meal_relation = ""
    talimat_satiri = _instruction_line(form, drug["name"] or "")
    # Topikal dermatolojik (cilt/saç/tırnak) → içilir/buruna DEĞİL; bölgeye sürülür.
    _td = _topical_derm_instruction(drug["atc_code"], drug["name"] or "",
                                    drug["route"] or "", kategori)
    if _td:
        talimat_satiri = _td
    # Hemoroid preparatı (C05A) kremi/merhemi: form bayat 'topikal' kalmış
    # olsa bile "ETKİLENEN BÖLGEYE" değil REKTAL kullanım söylenir
    # (Proctoglyvenol/Kortos krem). Fitilleri form zaten doğru yönetir.
    if ((drug["atc_code"] or "").upper().startswith("C05A")
            and form in ("cream_or_ointment_topical", "gel_topical",
                         "cream_rectal")):
        talimat_satiri = "MAKAT BÖLGESİNE SÜRÜNÜZ"
    # Ağız/boğaz spreyi → buruna DEĞİL, boğaza sıkılır; kategori "boğaz spreyi".
    if _is_throat_spray(drug["atc_code"], drug["name"] or ""):
        talimat_satiri = "AĞIZ İÇİNDEN BOĞAZA SIKINIZ"
        kategori = "BOĞAZ / AĞIZ-DİŞ İLACI"
    # Hem göze HEM kulağa kullanılan damlalar (Onadron Simple, Cebedex vb.):
    # form 'göz' veya 'kulak'tan birine sabitlendiğinden ada bakıp düzeltiriz.
    if is_eye_ear_drop_name(drug["name"] or ""):
        talimat_satiri = "GÖZE VEYA KULAĞA DAMLATINIZ"
    # Burun MERHEMİ/POMADI (Sulfarhin vb.): form nasal_spray çıkarıldığından
    # "FIS ... SIKILIR" denir — merhem sıkılmaz, burun deliklerinin içine sürülür.
    _nm = (drug["name"] or "").upper()
    if form in ("nasal_spray", "nasal_drop") and ("MERHEM" in _nm or "POMAD" in _nm):
        talimat_satiri = "BURUN DELİKLERİNİN İÇİNE İNCE TABAKA SÜRÜNÜZ"
        talimat = talimat.replace("FIS BURUN İÇİNE SIKILIR",
                                  "MİKTAR BURUN İÇİNE SÜRÜLÜR")
    teknik_satiri = _technique_line(form, drug["name"] or "", drug["atc_code"])

    # Ereksiyon ilaçları (G04BE) yol düzeltmeleri:
    #  • Alprostadil enjeksiyonu (G04BE01, Jectera/Caverject) KAVERNÖZ içine
    #    yapılır — form injection_im'den gelen "KAS İÇİNE" talimatı YANLIŞ.
    #  • Sildenafil oral jel saşesi (Jeligra) yutulur; oromucosal_gel formundan
    #    gelen "AĞIZ İÇİNE SÜRÜNÜZ" talimatı yanıltıcı.
    if _atc_u.startswith("G04BE01") and form.startswith("injection"):
        talimat_satiri = "DOKTORUNUZUN ÖĞRETTİĞİ ŞEKİLDE PENİS İÇİNE UYGULANIR"
    elif _atc_u.startswith("G04BE") and "FILM" in _nm.replace("İ", "I") and (
            "DAGILAN" in _nm or "DAĞILAN" in _nm):
        # Ağızda dağılan film (Icarus): suda çözülmez, dil üstünde eritilir.
        talimat_satiri = "FİLMİ DİLİNİZİN ÜZERİNE KOYUN, ERİYİNCE YUTKUNUN"
    elif _atc_u.startswith("G04BE") and ("SAŞE" in _nm or "SASE" in _nm):
        talimat_satiri = "SAŞE İÇERİĞİNİ AĞZINIZA BOŞALTIP YUTUNUZ"

    # İnsülinler (ATC A10A* — A10B oral antidiyabetikler HARİÇ): cilt altı uygulama
    # bölgesi ve soğuk zincir için insüline özel ibareler.
    if (drug["atc_code"] or "").upper().startswith("A10A"):
        talimat_satiri = "KARIN, BACAK VE GÖBEK ÇEVRESİNE UYGULAYINIZ"
        saklama_badge = "BUZDOLABININ ORTA RAFINDA SAKLAYINIZ"
        teknik_satiri = "GÖBEK ÇEVRESİNİN 5 CM UZAĞINA UYGULAYIN"
        # İnsülin cilt altına uygulanır; aç/tok öğün rozeti anlamsız (bazal/prandiyal
        # zamanlama "kullanım zamanı" alanıyla verilir), bu yüzden rozet gösterilmez.
        meal_badge = ""

    # Uyuz/bit topikalleri (P03): form-bazlı "ETKİLENEN BÖLGEYE SÜRÜNÜZ" uyuzda
    # YANLIŞ — boyundan aşağı TÜM vücuda uygulanır; şampuanlar bit içindir.
    # Ayrıntılı adım listesi TİP B etiketinde (build_label_plan → _PARASITE_PROTOCOLS).
    _pk = _parasite_kind(drug["atc_code"], drug["name"], form)
    if _pk:
        kategori, talimat_satiri, oneri_satiri = _parasite_a_overrides(_pk)

    # Tırnak mantarı cilası/solüsyonu (Opilox/Nibulen/Loceryl/Dermo-Trosyd):
    # kategori + uygulama sıklığı türe göre yazılır; form yanlış kalmış olsa
    # bile (şurup sanılan tırnak solüsyonu) çalkalama/içme talimatı basılmaz.
    # Ayrıntılı adımlar TİP B etiketinde (build_label_plan → _NAIL_PROTOCOLS).
    _nk = _nail_kind(drug["atc_code"], drug["name"])
    if _nk:
        kategori, talimat_satiri, oneri_satiri = _nail_a_overrides(_nk)
        teknik_satiri = ""

    # Siğil/nasır solüsyonları (Duoderm/Verrutol): yalnız siğil üzerine —
    # ayrıntılı adımlar TİP B etiketinde (_WART_PROTOCOLS). Sıklık endikasyona
    # göre değişir (siğil 1 / nasır 2 / 5-FU 2-3) → ızgara basılmaz, sıklığı
    # B etiketi söyler.
    _wk = _wart_kind(drug["atc_code"], drug["name"])
    if _wk:
        kategori, talimat_satiri, oneri_satiri = _wart_a_overrides(_wk)
        teknik_satiri = ""
        zaman_satirlari = []
        zaman_list = []
        daily_freq = None

    # Yara izi jeli (Contractubex/Noskar): "yara iyileştirici" değil —
    # KAPANMIŞ iz dokusuna masajla; ayrıntı TİP B etiketinde (_SCAR_PROTOCOL).
    if _is_scar_gel(drug["name"]):
        kategori = "YARA İZİ (NEDBE) JELİ"
        talimat_satiri = "YARA İZİNE HAFİF MASAJLA, EMİLENE KADAR SÜRÜNÜZ"
        oneri_satiri = "YARA TAM KAPANDIKTAN SONRA BAŞLANIR"
        teknik_satiri = ""

    # Nistatin oral süspansiyon (Mikostatin/Fungostatin — pamukçuk): klasik
    # kullanım "ağızda gezdir, sonra yut" — düz "İÇİNİZ" tekniği anlatmıyor.
    if _atc_u.startswith("A07AA02") and form in ("syrup_or_suspension", ""):
        talimat_satiri = "AĞIZDA İYİCE GEZDİRİP SONRA YUTUNUZ"

    # Diyaliz çözeltileri (Physioneal/Extraneal/CAPD/Balance...): form yanlış
    # kalmış olsa bile "İÇİNİZ"/ölçek ızgarası basılmaz; değişim sayısı ve
    # tekniği diyaliz hemşiresinin eğitimine aittir.
    _dk = _dialysis_kind(drug["atc_code"], drug["name"])
    if _dk:
        kategori, talimat_satiri = _dialysis_a_overrides(_dk)
        oneri_satiri = ""
        teknik_satiri = ""
        zaman_satirlari = []
        daily_freq = None
        meal_relation = ""
        meal_badge = ""

    # Transdermal bantlarda değişim aralığı üründen ürüne farklı — "GÜNDE 1"
    # ızgarası fentanilde (72 saatte bir) ve haftalık bantlarda YANLIŞ.
    if form == "transdermal_patch":
        if _atc_u.startswith("N02AB"):       # fentanil (Durogesic)
            zaman_satirlari = []
            daily_freq = None
            oneri_satiri = "72 SAATTE BİR (3 GÜNDE 1) DEĞİŞTİRİLİR"
        elif _atc_u.startswith(("G03CA", "G03AA")):  # Climara / Evra — haftalık
            zaman_satirlari = []
            daily_freq = None
            oneri_satiri = "HAFTADA 1 KEZ DEĞİŞTİRİLİR"
        if not teknik_satiri:
            teknik_satiri = "ESKİ BANDI ÇIKARIN · HER SEFERİNDE FARKLI BÖLGEYE"

    # Soğuk zincir: saklama bloğundan rozet ÇIKMADIYSA (çoğu biyolojik/hormon/
    # immünoglobulin/sulandırılan antibiyotikte saklama bloğu yok) ATC/forma göre
    # buzdolabı rozetini KOD düzeyinde üret. İnsülin orta-raf rozeti yukarıda zaten
    # set edildiyse buraya girmez (saklama_badge dolu).
    if not saklama_badge:
        _ccb = cold_chain_badge(drug["atc_code"], form, drug["name"] or "")
        if _ccb:
            saklama_badge = _ccb

    # Kritik rozet saklama çerçevesiyle AYNI bilgiyi veriyorsa (insülin: rozet
    # "BUZDOLABINDA SAKLA" + çerçeve "BUZDOLABINDA SAKLAYINIZ") saklama çerçevesini
    # kaldır — rozet zaten mesajı taşıyor, tekrar etmeye gerek yok.
    kritik_rozet = _critical_badge_for_atc(drug["atc_code"], form, _route_class)
    if kritik_rozet and kritik_rozet.upper() in (saklama_badge or "").upper():
        saklama_badge = ""

    # Gargara (TANFLEX/KLOROBEN/BENPAIN/MAJEZİK vb.): lokal kullanımdır, şurupla
    # karıştırılıp İÇİLMESİN diye her sıklıkta görünen "YUTMAYINIZ" rozeti basılır.
    # A01AD'nin diş jeli/oral çözelti formlarına değil, YALNIZ gargaraya.
    if not kritik_rozet and (form == "gargara_mouthwash" or "GARGARA" in _nm):
        kritik_rozet = "YUTMAYINIZ"

    # Diyaliz çözeltisi şurup/mama sanılıp içilmesin — her sıklıkta görünen rozet.
    if not kritik_rozet and _dk:
        kritik_rozet = "İÇMEYİNİZ"

    ul = UsageLabel(
        kategori=kategori,
        kullanim_talimati=talimat,
        uyari_metni=usage_note,          # SADECE doktor notu (kullanım) — başka uyarı yok
        ilac_turu=kategori.title(),
        doz=doz_str,
        gunluk_kez=daily_freq,
        saat_arasi=hours_apart,
        kullanim_zamani=zaman_list,
        yemek=meal_relation,
        sure=f"{drug['treatment_days']} gün" if drug["treatment_days"] else "",
        sure_gun=drug["treatment_days"],
        kullanim_sekli=kullanim_sekli,
        # yeni yapısal alanlar
        zaman_satirlari=zaman_satirlari,
        meal_badge=meal_badge,
        talimat_satiri=talimat_satiri,
        oneri_satiri=oneri_satiri,       # kullanım zamanı önerisi (örn. statin → akşam)
        teknik_satiri=teknik_satiri,
        saklama_badge=saklama_badge,     # basit saklama: "BUZDOLABINDA" vb.
        # Kritik ATC (alkol/kan sulandırıcı/greyfurt vb.) → sağ sütunda ters renkli
        # kısa güvenlik rozeti. C etiketi ayrıntılı uyarıyı taşımaya devam eder;
        # bu rozet 1. etikette hastanın gözüne ilk çarpacak kısa hatırlatmadır.
        kritik_rozet=kritik_rozet,
    )

    # Çift-yollu progesteron kapsülü (PROGESTAN/PROGYNEX): DB akışında reçete
    # yolu BİLİNMEZ (kullanim_sekli oral route'tan türemez → boş) → talimat
    # "doktorunuzun önerdiği şekilde" iki yolu birden söyler; TOK rozeti kalkar.
    _progesterone_route_override(ul, drug["atc_code"], drug["name"])

    # Kullanıcı A etiketinin metnini kalıcı düzenlediyse (drug_label_prefs.custom_text)
    # ana talimatı onunla EZER — kod üretimi (üstteki istisnalar dahil) kullanıcı
    # düzenlemesine yenilir. Doz ızgarası/öğün rozeti yerinde kalır (onlar
    # "Doz/Zaman" editöründen yönetilir); burada yalnız sağ sütun talimat cümlesi.
    if custom_talimat and custom_talimat.strip():
        ul.talimat_satiri = " ".join(
            l.strip() for l in custom_talimat.split("\n") if l.strip()
        )

    return ul


def _build_preparation_label(
    drug: sqlite3.Row,
    hazirlama_content: str,
    saklama_content: str,
) -> PreparationLabel:
    """drug_label_blocks.hazirlama içeriğinden PreparationLabel doldurur."""
    # adımları • veya 1./2. ile böl
    raw = (hazirlama_content or "").strip()
    adimlar: list[str] = []
    if raw:
        for ln in raw.split("\n"):
            ln = ln.strip().lstrip("•").lstrip("- ").strip()
            if ln:
                adimlar.append(ln)
    # ilk cümleler tek paragraftaysa nokta ile böl
    if len(adimlar) == 1 and "." in adimlar[0]:
        adimlar = [s.strip() for s in adimlar[0].split(".") if s.strip()]

    # Adımlar zaten saklama bilgisi içeriyorsa (ör. "BUZDOLABINDA saklayın")
    # saklama meta'sını bastır — çelişkili/yinelenen satır oluşmasın.
    steps_have_storage = any(
        any(k in a.lower() for k in ("buzdolab", "saklay", "°c", "2-8"))
        for a in adimlar
    )

    # saklama — TEK satıra sığacak kadar kısa (adımlarla çakışmasın). Mümkünse
    # sulandırma sonrası saklama cümlesini öne al; yoksa ilk cümleyi kısalt.
    saklama_text = ""
    if saklama_content and not steps_have_storage:
        flat = " ".join(
            ln.strip() for ln in saklama_content.split("\n") if ln.strip()
        )
        low = flat.lower()
        # Hazırlama etiketi için en kritik bilgi sulandırma SONRASI saklamadır.
        for trig in ("sulandır", "hazırlan", "açıldık", "açıldıktan"):
            i = low.find(trig)
            if i != -1:
                flat = flat[i:]
                break
        # İlk cümle (nokta) veya ~40 karakter — TEK satıra sığsın (≈19px bold).
        # Kelime ortasından kesmemek için son boşluktan böl.
        first = flat.split(".")[0].strip()
        if len(first) > 40:
            cut = first.rfind(" ", 0, 40)
            first = first[:cut if cut > 0 else 40]
        saklama_text = first.strip()

    return PreparationLabel(
        gerekli=True,
        form=drug["form"] or "",
        adimlar=adimlar[:4],
        saklama=saklama_text,
    )


def _build_warning_label_from_blocks(
    block_content: str,
    max_items: int = 4,
) -> WarningLabel:
    """drug_label_blocks içeriğinden (teknik veya etkileşim) WarningLabel doldurur."""
    import re as _re
    raw = (block_content or "").strip()
    items: list[str] = []
    if "\n" in raw:
        # Çok satırlı: her satır bir madde
        for ln in raw.split("\n"):
            ln = ln.strip().lstrip("•").lstrip("- ").strip()
            if ln:
                items.append(ln)
    elif _re.search(r"\d+\)", raw):
        # Tek satır numaralı kalıp ("1) ... 2) ... 3) ...") — numaralı işaretten böl.
        # Cümle içindeki "ikinci/2." gibi noktalar yanlış bölmeye yol açmasın diye
        # nokta yerine "N)" işaretini sınır alıyoruz.
        parts = _re.split(r"\s*(?=\d+\))", raw)
        items = [p.strip().rstrip(".").strip() for p in parts if p.strip()]
    elif len(raw) > 100:
        # Numarasız uzun paragraf — cümle bazında böl
        items = [s.strip() + "." for s in raw.split(".") if s.strip()]
    elif raw:
        items = [raw]

    return WarningLabel(gerekli=True, uyarilar=items[:max_items])


# ============================================================
# A etiketi: basit saklama rozeti
# ============================================================

# Buzdolabı ifadesinin KOŞULLU olduğunu gösteren tetikleyiciler. Bu kelimelerden
# sonra gelen "buzdolabında saklanır" ifadesi yalnızca sulandırılmış SÜSPANSİYON /
# açılmış ürün içindir; katı tablet/kapsül için geçerli DEĞİLDİR.
_STORAGE_COND_TRIGGERS = (
    "sulandır", "süspansiyon", "suspansiyon", "hazırlan", "hazırlandık",
    "açıldıktan", "açıldık", "seyrelt", "çözündür", "damlat",
)
# Katı oral form adları (form bu kelimelerden birini içeriyorsa süspansiyona özel
# buzdolabı notu rozet olarak basılmaz).
_SOLID_FORM_HINTS = ("tablet", "kapsül", "kapsul", "capsule", "film",
                     "draje", "komprime", "efervesan", "saşe", "sase")

_COLD_KEYS = ("buzdolab", "2-8", "2 - 8", "+4", "soğukta", "soguk")

# Soğuk ifadesinin OLUMSUZ (yasaklayıcı) bağlamda olduğunu gösteren ekler.
# Örn: "buzdolabına KOYMAYINIZ", "buzdolabında SAKLAMAYINIZ", "buzdolabında veya
# sıcak yerde TUTMAYINIZ". Bir soğuk anahtarının hemen ardından (kısa pencere
# içinde) bunlardan biri geçiyorsa o geçiş "soğukta sakla" sinyali SAYILMAZ.
# DİKKAT: "dondurmayınız" (dondurucu yasağı) buraya dahil DEĞİLDİR — o, buzdolabı/
# soğuk saklamayı reddetmez; ayrı olarak ele alınır.
_COLD_NEGATION_STEMS = (
    "koymay", "saklamay", "tutmay", "bulundurmay", "muhafaza etmey",
    "konmaz", "konulmaz", "konmamal", "konulmamal", "saklanmamal",
    "tutulmamal",
)
# Soğuk anahtarından sonra negasyonu ararken bakılacak karakter penceresi.
_COLD_NEG_WINDOW = 40


def _has_positive_mention(
    s: str, keys: tuple[str, ...], neg_stems: tuple[str, ...],
    window: int = _COLD_NEG_WINDOW,
) -> bool:
    """`keys`'ten en az biri OLUMLU (yasaklayıcı olmayan) bağlamda geçiyor mu?

    Bir anahtarın hemen ardından (window karakter içinde) `neg_stems`'ten biri
    geliyorsa o geçiş yasaklayıcı sayılır ve olumlu kabul EDİLMEZ. Tüm geçişler
    yasaklayıcıysa False döner.
    """
    for k in keys:
        start = 0
        while True:
            i = s.find(k, start)
            if i < 0:
                break
            tail = s[i + len(k): i + len(k) + window]
            if not any(neg in tail for neg in neg_stems):
                return True
            start = i + len(k)
    return False


def _simple_storage_badge(saklama_content: str | None, form: str | None = None) -> str:
    """saklama bloğundan A etiketine basılacak BASİT saklama rozetini çıkarır.

    Sadece soğuk zincir gibi kritik/basit durumları döner; oda sıcaklığı (varsayılan)
    için boş döner — etiket sade kalsın.

    "buzdolabına koymayınız / saklamayınız / tutmayınız" gibi OLUMSUZ ifadeler rozet
    BASTIRMAZ (bkz. _has_positive_mention) — metin tam tersini söylüyor olabilir.

    form verilirse ve KATI oral form ise (tablet/kapsül), buzdolabı ifadesi yalnızca
    KOŞULLU bağlamda (süspansiyon sulandırıldıktan / açıldıktan sonra) geçiyorsa rozet
    BASILMAZ — çünkü bu uyarı süspansiyon formuna aittir, tablete değil.
    """
    s = (saklama_content or "").lower()
    if not s:
        return ""
    if _has_positive_mention(s, _COLD_KEYS, _COLD_NEGATION_STEMS):
        if form and any(h in form.lower() for h in _SOLID_FORM_HINTS):
            first_cold = min(s.find(k) for k in _COLD_KEYS if k in s)
            cond_pos = [s.find(t) for t in _STORAGE_COND_TRIGGERS if t in s]
            first_cond = min(cond_pos) if cond_pos else -1
            # Soğuk ifadesi yalnızca koşullu tetikleyiciden SONRA geçiyorsa → süspansiyon
            # notu; katı formda gösterme.
            if first_cond != -1 and first_cond < first_cold:
                return ""
        return "BUZDOLABINDA SAKLAYINIZ"
    # Dondurucu rozeti yalnızca "dondurucuda saklayınız" gibi OLUMLU ifadede basılır;
    # "dondurmayınız" (yasak) bunu tetiklemez.
    if "dondurucu" in s:
        return "DONDURUCUDA SAKLAYINIZ"
    return ""


# ============================================================
# Soğuk zincir (buzdolabı) — ATC/forma göre A etiketi rozeti
# ============================================================
# saklama bloğu (drug_label_blocks) çoğu soğuk-zincir ilacında YOK; bu yüzden
# _simple_storage_badge boş döner. Aşağıdaki sınıflandırıcı, ilacın ATC/formuna
# bakarak buzdolabı rozetini KOD düzeyinde üretir (insülin orta-raf rozetiyle
# aynı mantık). Böylece DB akışı (_build_usage_label) ve canlı Medula akışı
# (auto_label_builder) tutarlı çalışır.

# Açılmadan ÖNCE 2-8°C buzdolabında saklanması gereken ATC grupları. Büyük
# çoğunluğu parenteral biyolojik/hormon; oral KATI muadiller _is_oral_solid_form
# guard'ıyla elenir (ör. eltrombopag tabletleri, oral semaglutid Rybelsus).
_COLD_BEFORE_OPEN_ATC = (
    "J07",                       # aşılar
    "J06BA", "J06BB",            # immünoglobulinler (IVIG/SCIG, spesifik Ig)
    "L01F", "L01XC",             # monoklonal antikorlar
    "L03AA",                     # koloni uyarıcı faktörler (filgrastim)
    "L03AB",                     # interferonlar
    "L03AC",                     # interlökinler (aldeslökin)
    "L04AA", "L04AB", "L04AC", "L04AG",  # biyolojik immünsüpresanlar
    "B02BD",                     # pıhtılaşma faktörleri (hemofili)
    "B02BX04",                   # romiplostim (Nplate) — B02BX05 eltrombopag HARİÇ
    "B03XA",                     # eritropoietin (epoetin/darbepoetin)
    "H01AC",                     # büyüme hormonu (somatropin)
    "H01AX01",                   # pegvisomant (Somavert)
    "H01CB",                     # somatostatin analogları (oktreotid/lanreotid)
    "H05AA",                     # paratiroid hormonu / teriparatid (Forsteo)
    "H05BA",                     # kalsitonin (enjektabl + nazal)
    "H01BA02",                   # desmopresin (yalnız enjektabl/nazal — oral guard)
    "M03AX01",                   # botulinum toksini (Botox/Dysport/Xeomin)
    "S01LA",                     # anti-VEGF intravitreal (ranibizumab/aflibercept)
    "S01EE01",                   # latanoprost göz damlası (açılmadan önce)
    "G03GA",                     # gonadotropinler (FSH/hCG — Gonal-F, Menopur...)
    "A10BJ",                     # GLP-1 enjektabl (Byetta/Ozempic/Victoza/Trulicity)
)

# Sulandırıldıktan SONRA buzdolabında (2-8°C) saklanması gereken oral antibiyotik
# süspansiyonları. Listede OLMAYAN süspansiyonlar BİLEREK dışarıda bırakıldı:
#   • klaritromisin (J01FA09) / azitromisin (J01FA10) → soğukta JELLEŞİR, oda sıc.
#   • sefiksim (J01DD08) / sefdinir (J01DD15) / sefpodoksim (J01DD13) → oda sıc.
#   • ko-trimoksazol (J01EE01) / linezolid (J01XX08) → oda sıcaklığı
# Bunları buzdolabına koymak YANLIŞ olur; bu yüzden rozet basılmaz.
_FRIDGE_AFTER_RECON_ATC = (
    "J01CR02",  # amoksisilin-klavulanat (Augmentin/Aklav/Klavunat/Klamoks/Croxilex)
    "J01CR04",  # ampisilin-sulbaktam (Duocid/Sultamat)
    "J01CA01",  # ampisilin
    "J01CA04",  # amoksisilin
    "J01CE",    # penisilin V / feneticilin
    "J01DB01",  # sefaleksin (Sef/Maksipor)
    "J01DC04",  # sefaklor
    "J01DD14",  # seftibuten (Cedax)
)


def _is_oral_solid_form(form: str | None, name: str | None) -> bool:
    """Oral KATI form mu (tablet/kapsül/draje/dilaltı/melt)? Bu formdaki bir
    kayıt soğuk-zincir ATC grubuna düşse bile buzdolabı rozeti BASILMAZ —
    oral muadil (ör. eltrombopag B02BX, oral semaglutid A10BJ) soğuk gerektirmez.
    Enjeksiyon liyofilizatları (toz/flakon) buradan elenmez; onlar sulandırılıp
    enjekte edilir ve soğuk zincire dahildir.
    """
    f = (form or "").lower()
    if any(h in f for h in _SOLID_FORM_HINTS):
        return True
    n = (name or "").upper()
    solid_kw = ("TABLET", "KAPSÜL", "KAPSUL", "FILM KAPLI", "FİLM KAPLI",
                "DRAJE", "DİLALTI", "DILALTI", "MELT", "LİYOFİLİZAT",
                "LIYOFILIZAT")
    if any(k in n for k in solid_kw):
        # Enjeksiyon/infüzyon liyofilizatı oral değildir → guard'a takılmaz.
        if any(k in n for k in ("ENJ", "FLAKON", "INFUZYON", "İNFÜZYON",
                                "AMPUL", "SIRINGA", "ŞIRINGA", "KALEM")):
            return False
        return True
    return False


def cold_chain_badge(atc: str | None, form: str | None,
                     name: str | None = None) -> str:
    """ATC/forma göre A etiketi soğuk-zincir rozetini döndürür (yoksa "").

    Öncelik: insülin orta-raf > açılmadan-önce buzdolabı > sulandırma-sonrası.
    Oral KATI muadiller (tablet/kapsül/melt...) hiçbir grupta rozet almaz.
    """
    a = (atc or "").upper()
    if _is_oral_solid_form(form, name):
        return ""
    if a.startswith("A10A"):                       # insülin
        return "BUZDOLABININ ORTA RAFINDA SAKLAYINIZ"
    if any(a.startswith(p) for p in _COLD_BEFORE_OPEN_ATC):
        return "BUZDOLABINDA SAKLAYINIZ"
    if (form or "") == "powder_for_suspension" and any(
        a.startswith(p) for p in _FRIDGE_AFTER_RECON_ATC
    ):
        return "SULANDIKTAN SONRA BUZDOLABINDA SAKLAYINIZ"
    return ""


# ============================================================
# C etiketi: CİDDİ UYARILAR (ilaç/besin etkileşimi, ciddi yan etki, hayati risk)
# ============================================================

# C etiketini tetikleyen ciddi içerik anahtar kelimeleri (etkilesim/dikkat içinde)
_SERIOUS_KEYWORDS = (
    "ALKOL", "GREYFURT", "KAN SULANDIRICI", "KANAMA", "HAYATİ",
    "ANAFİLAKSİ", "ÖLÜM", "KALP KRİZİ", "İNME", "ZEHİRLENME",
    "BİRLİKTE KULLANILMAZ", "CANLI AŞI",
)


def _bullets(content: str | None) -> list[str]:
    """Blok içeriğini madde madde listeye böler (•/- işaretlerini temizler)."""
    out: list[str] = []
    for ln in (content or "").split("\n"):
        ln = ln.strip().lstrip("•").lstrip("-").strip()
        if ln:
            out.append(ln)
    return out


def _is_serious(
    atc_code: str | None,
    etkilesim: str,
    dikkat: str,
) -> bool:
    """C etiketi (ciddi uyarılar) basılmalı mı?

    Tetikleyiciler:
      - Kritik ATC sınıfı (CRITICAL_ATC_PREFIXES), VEYA
      - etkilesim/dikkat bloğunda ciddi anahtar kelime geçmesi.
    """
    if atc_code:
        code = atc_code.upper()
        for pfx in CRITICAL_ATC_PREFIXES:
            if code.startswith(pfx):
                return True
    blob = f"{etkilesim or ''} {dikkat or ''}".upper()
    return any(k in blob for k in _SERIOUS_KEYWORDS)


def _build_serious_warning(
    atc_code: str | None,
    etkilesim: str,
    sivi: str,
    yan_etki: str,
    dikkat: str,
    form: str | None = None,
    route_class: str | None = None,
) -> WarningLabel:
    """Bloklardan C etiketi için seçilmiş ciddi uyarı maddelerini derler."""
    items: list[str] = []

    # 1) Kritik ATC'ye özel, en kürate mesaj (alkol, greyfurt, kanama vb.)
    #    Topikal deride sistemik mesaj bastırılır (form/route_class kilidi).
    crit = _critical_message_for_atc(atc_code, form, route_class)
    if crit:
        items.append(crit)

    # 2) İlaç etkileşimi — ciddi maddeleri seç
    for b in _bullets(etkilesim):
        U = b.upper()
        if any(k in U for k in ("ALKOL", "GREYFURT", "BİRLİKTE KULLANILMAZ",
                                "KANAMA", "KAN SULANDIRICI", "CİDDİ")):
            items.append(b)
        if len(items) >= 4:
            break

    # 3) Besin/sıvı etkileşimi — tek satır
    for b in _bullets(sivi):
        U = b.upper()
        if any(k in U for k in ("ALINMAZ", "İÇİLMEZ", "BİRLİKTE", "KAHVE",
                                "ÇAY", "SÜT", "GREYFURT", "KOLA")):
            items.append(b)
            break

    # 4) Ciddi yan etki — tek satır
    for b in _bullets(yan_etki):
        if "CİDDİ" in b.upper() or "ACİL" in b.upper():
            items.append(b)
            break

    # 5) Hiçbir şey seçilmediyse dikkat bloğunun ilk maddeleri
    if not items:
        items = _bullets(dikkat)[:3]

    # Tekrarı önle, sırayı koru, ilk 5
    seen: set[str] = set()
    out: list[str] = []
    for it in items:
        key = it[:45].lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(it)

    return WarningLabel(gerekli=True, uyarilar=out[:5])


# ============================================================
# D etiketi: ASTIM/İNHALER — DİKKAT EDİLECEK HUSUSLAR
# ============================================================

def _parse_teknik_steps(teknik: str) -> list[str]:
    """teknik bloğunu numaralı işaretten ('N)') temiz adım listesine böler.

    Baştaki 'N)' numarası ve sondaki nokta atılır; render adımları kendisi
    yeniden numaralandırır (render_glucose_guide_label '1. 2. ...').
    """
    import re as _re
    raw = (teknik or "").strip()
    if not raw:
        return []
    parts = _re.split(r"\s*(?=\d+\))", raw) if _re.search(r"\d+\)", raw) else raw.split("\n")
    out: list[str] = []
    for p in parts:
        s = _re.sub(r"^\s*\d+\)\s*", "", p.strip()).strip().rstrip(".").strip()
        if s:
            out.append(s)
    return out


def _build_inhaler_caution_items(
    dikkat: str, hatirlatma: str, yan_etki: str, max_items: int = 7
) -> list[str]:
    """Astım/inhaler için 'DİKKAT EDİLECEK HUSUSLAR' etiketinin maddelerini derler.

    dikkat + hatirlatma maddelerini birleştirir, yan_etki bloğundan yalnız ACİL/CİDDİ
    satırını ekler. Tekrarları eler, max_items ile sınırlar. Etikete render aşamasında
    punto otomatik küçülerek tüm maddeler sığar (render_warning_label).
    """
    items: list[str] = []
    items += _bullets(dikkat)
    items += _bullets(hatirlatma)
    for b in _bullets(yan_etki):
        U = b.upper()
        if "ACİL" in U or "CİDDİ" in U:
            items.append(b)
            break
    seen: set[str] = set()
    out: list[str] = []
    for it in items:
        k = it[:40].lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(it)
    return out[:max_items]


# ============================================================
# YÜKSEK SEVİYE: bir ilaç için tüm etiketleri üret
# ============================================================

# TECHNIQUE_FORMS'taki tüm formlar ağızdan ALINMAYAN formlardır. Teknik bloğunda
# "yutunuz/yutabilirsiniz" gibi oral talimat görülürse blok yanlış kaynaktan
# gelmiştir (örn. tablet metni fitile yazılmış — PARANOX S vakası); o blok
# atılıp formun şablon içeriği kullanılır. "YUTMAYINIZ" uyarısı serbesttir.
_SWALLOW_RE = None  # lazy compile (modül importunda re maliyeti olmasın)


def _has_swallow_text(content: str) -> bool:
    """'yutunuz/yutabilirsiniz/yutulur' geçiyor mu? ('yutmayınız' uyarısı hariç)"""
    global _SWALLOW_RE
    if not content:
        return False
    if _SWALLOW_RE is None:
        import re as _re
        _SWALLOW_RE = _re.compile(r"yut(?!may)", _re.IGNORECASE)
    return bool(_SWALLOW_RE.search(content))


def _safe_teknik_for_form(form: str | None, content: str) -> str:
    """Ağızdan alınmayan formda 'yut...' talimatlı teknik bloğu etkisizleştirir.

    Rektal/vajinal formda ad ("SUPOZ/FİTİL/OVÜL") güvenilirdir → blok formun
    şablonuyla DEĞİŞTİRİLİR. Diğer teknik formlarda çelişki formun yanlış
    çıkarılmasından da olabilir (LARGOPEN tableti 'PEN' yüzünden injection_sc
    sayılmıştı) → yanlış teknik basmaktansa blok ATILIR (B etiketi çıkmaz).
    """
    if content and _has_swallow_text(content):
        f = (form or "").lower()
        if f in ("suppository_rectal", "enema_rectal", "cream_rectal",
                 "vaginal_ovule_or_cream"):
            from .application_techniques import TECHNIQUES
            return TECHNIQUES[f]["content"]
        return ""
    return content


_TECHNIQUE_TITLE = {
    "injection_sc": "ENJEKSİYON UYGULAMA",
    "inhaler_pmdi": "İNHALER KULLANIM",
    "inhaler_dpi":  "İNHALER KULLANIM",
    "nebule":       "İNHALER KULLANIM",
    "eye_drop":     "GÖZ DAMLASI KULLANIM",
    "ear_drop":     "KULAK DAMLASI KULLANIM",
    "nasal_spray":  "BURUN İLACI KULLANIM",
    "nasal_drop":   "BURUN İLACI KULLANIM",
    "sublingual_spray": "DİLALTI SPREY KULLANIM",
    "suppository_rectal":      "FİTİL UYGULAMA",
    "enema_rectal":            "REKTAL UYGULAMA",
    "cream_rectal":            "REKTAL KREM UYGULAMA",
    "vaginal_ovule_or_cream":  "VAJİNAL UYGULAMA",
    "transdermal_patch":       "BANT KULLANIM",
}


def build_label_plan(
    drug_id: int,
    hasta_adi: str,
    recete_tarihi: Optional[date] = None,
    *,
    bitis_tarihi_override: Optional[date] = None,
    conn: Optional[sqlite3.Connection] = None,
    doctor_note: str = "",
) -> list[LabelSpec]:
    """Bir ilaç için A / B / C etiket PLANINI (görsel + meta) üretir.

    - A) TEMEL KULLANIM (her zaman): sadece kullanım bilgisi.
    - B) HAZIRLAMA / ÖZEL TEKNİK (forma bağlı): süspansiyon hazırlama, subkutan
         enjeksiyon, inhaler/damla tekniği.
    - C) CİDDİ UYARILAR (ciddi ilaçlarda): ilaç/besin etkileşimi, ciddi yan etki.

    drug_label_prefs uygulanır: suppress edilen tip ÜRETİLMEZ; custom_text varsa
    bloklardan üretilen metin yerine o kullanılır. C için şiddet 'high/low' →
    default_print (UI baskı checkbox'ı varsayılanı).
    """
    close_conn = conn is None
    if conn is None:
        conn = get_connection()
    try:
        drug = _fetch_drug(conn, drug_id)
        if not drug:
            raise ValueError(f"Drug not found: id={drug_id}")

        # MEDİKAL MALZEME / CİHAZ — etiket basmaz
        if is_medical_device(drug):
            return []

        settings = _settings(conn)
        eczane_adi = settings.get("eczane_adi", "")
        eczane_telefon = settings.get("eczane_telefon", "")
        # Parenteral uygulama yolu ayarı: AÇIK → spesifik IM/IV/SC; KAPALI
        # (varsayılan) → yol gizli ("SAĞLIK PERSONELİ TARAFINDAN UYGULANIR").
        _par_mode = ("recete"
                     if settings.get("erecete_parenteral_route", "0") == "1"
                     else "generic")
        name = drug["name"] or ""

        # Bitiş tarihi
        if bitis_tarihi_override:
            bitis_tarihi = bitis_tarihi_override
        elif recete_tarihi and drug["treatment_days"]:
            bitis_tarihi = recete_tarihi + timedelta(days=drug["treatment_days"])
        else:
            bitis_tarihi = None

        specs: list[LabelSpec] = []

        # ----------------------------------------------------------------
        # A) TEMEL KULLANIM — her zaman
        # ----------------------------------------------------------------
        saklama_content = _fetch_block(conn, drug_id, "saklama")
        saklama_badge = _simple_storage_badge(saklama_content, drug["form"])
        usage_note = ""
        if doctor_note and doctor_note.strip():
            usage_note = doctor_note.strip()
            if len(usage_note) > 110:
                usage_note = usage_note[:107] + "…"
            usage_note = f"[Dr.] {usage_note}"
        # A etiketi metni kalıcı düzenlenmiş olabilir (sağ-tık → metni düzenle).
        _a_sup, a_custom = get_label_pref(conn, drug_id, "A")
        usage = _build_usage_label(drug, usage_note, saklama_badge, a_custom,
                                   parenteral_route_mode=_par_mode)
        # Düzenleyici ön-dolgusu: o anki ana talimat cümlesi.
        a_text = (usage.talimat_satiri or usage.kullanim_talimati or "").strip()
        specs.append(LabelSpec(
            kind="A", title="TEMEL KULLANIM",
            image=render_usage_label(
                hasta_adi=hasta_adi, ilac_adi=name, label=usage,
                recete_tarihi=recete_tarihi, bitis_tarihi=bitis_tarihi,
                eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
            ),
            default_print=True, editable=True, edit_block="",
            custom_text=a_custom, text_lines=[a_text] if a_text else [],
        ))

        # ----------------------------------------------------------------
        # B) HAZIRLAMA / ÖZEL TEKNİK — forma bağlı (suppress edilebilir)
        # ----------------------------------------------------------------
        form = drug["form"]
        b_sup, b_custom = get_label_pref(conn, drug_id, "B")
        if not b_sup:
            if form in INHALER_FORMS:
                # B: SADECE kullanım tekniği adımları — daha az içerik → daha büyük yazı.
                # C: SADECE dikkat/uyarı maddeleri — ayrı etikette, okunabilir punto.
                if b_custom:
                    steps = [l for l in b_custom.split("\n") if l.strip()][:6]
                else:
                    steps = _parse_teknik_steps(_fetch_block(conn, drug_id, "teknik"))[:6]
                if steps:
                    specs.append(LabelSpec(
                        kind="B", title="İNHALER KULLANIM TEKNİĞİ",
                        image=render_glucose_guide_label(
                            hasta_adi=hasta_adi, ilac_adi=name,
                            title="İNHALER KULLANIM TEKNİĞİ",
                            steps=steps, caveats=[],
                            eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                        ),
                        default_print=True, editable=True, edit_block="teknik",
                        custom_text=b_custom, text_lines=list(steps),
                    ))
                # C: inhaler'a özgü uyarılar (ciddi ilaç-ilaç etkileşimi C'si yerine)
                c_sup, c_custom = get_label_pref(conn, drug_id, "C")
                if not c_sup:
                    if c_custom:
                        inh_caveats = [l for l in c_custom.split("\n") if l.strip()]
                    else:
                        inh_caveats = _build_inhaler_caution_items(
                            _fetch_block(conn, drug_id, "dikkat"),
                            _fetch_block(conn, drug_id, "hatirlatma"),
                            _fetch_block(conn, drug_id, "yan_etki"),
                            max_items=7,
                        )
                    if inh_caveats:
                        specs.append(LabelSpec(
                            kind="C", title="İNHALER UYARILARI",
                            image=render_glucose_guide_label(
                                hasta_adi=hasta_adi, ilac_adi=name,
                                title="İNHALER UYARILARI",
                                steps=[], caveats=inh_caveats,
                                eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                            ),
                            default_print=True, editable=True, edit_block="dikkat",
                            custom_text=c_custom, text_lines=list(inh_caveats),
                        ))
            elif _ppk := _parasite_kind(drug["atc_code"], name, form):
                # Uyuz/bit topikalleri: uygulama protokolü kritik (tüm vücut /
                # bekletme süresi / ev halkı toplu tedavi / çamaşır hijyeni) —
                # tam genişlikli adım+dikkat düzeniyle TİP B etiketi basılır.
                proto = _PARASITE_PROTOCOLS[_ppk]
                if b_custom:
                    steps = [l for l in b_custom.split("\n") if l.strip()][:6]
                else:
                    steps = list(proto["steps"])
                specs.append(LabelSpec(
                    kind="B", title=str(proto["title"]),
                    image=render_glucose_guide_label(
                        hasta_adi=hasta_adi, ilac_adi=name,
                        title=str(proto["title"]),
                        steps=steps, caveats=list(proto["caveats"]),
                        eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    ),
                    default_print=True, editable=True, edit_block="teknik",
                    custom_text=b_custom, text_lines=list(steps),
                ))
            elif _is_scar_gel(name):
                # Yara izi jeli: kapanmış yaraya başlama, masaj tekniği, gece
                # bandajı, güneş/soğuk koruması — adım+dikkat TİP B etiketi.
                proto = _SCAR_PROTOCOL
                if b_custom:
                    steps = [l for l in b_custom.split("\n") if l.strip()][:6]
                else:
                    steps = list(proto["steps"])
                specs.append(LabelSpec(
                    kind="B", title=str(proto["title"]),
                    image=render_glucose_guide_label(
                        hasta_adi=hasta_adi, ilac_adi=name,
                        title=str(proto["title"]),
                        steps=steps, caveats=list(proto["caveats"]),
                        eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    ),
                    default_print=True, editable=True, edit_block="teknik",
                    custom_text=b_custom, text_lines=list(steps),
                ))
            elif _wwk := _wart_kind(drug["atc_code"], name):
                # Siğil/nasır solüsyonu: vazelinle koruma, film soyma, ponza,
                # bölge yasakları (yüz/genital/ben) — adım+dikkat TİP B etiketi.
                proto = _WART_PROTOCOLS[_wwk]
                if b_custom:
                    steps = [l for l in b_custom.split("\n") if l.strip()][:6]
                else:
                    steps = list(proto["steps"])
                specs.append(LabelSpec(
                    kind="B", title=str(proto["title"]),
                    image=render_glucose_guide_label(
                        hasta_adi=hasta_adi, ilac_adi=name,
                        title=str(proto["title"]),
                        steps=steps, caveats=list(proto["caveats"]),
                        eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    ),
                    default_print=True, editable=True, edit_block="teknik",
                    custom_text=b_custom, text_lines=list(steps),
                ))
            elif _nnk := _nail_kind(drug["atc_code"], name):
                # Tırnak mantarı cilası/solüsyonu: uygulama şeması türe göre
                # tamamen farklı (gün aşırı azalan / haftada 1-2 törpülü /
                # günde 2 fırçalı) — tam genişlikli adım+dikkat TİP B etiketi.
                proto = _NAIL_PROTOCOLS[_nnk]
                if b_custom:
                    steps = [l for l in b_custom.split("\n") if l.strip()][:6]
                else:
                    steps = list(proto["steps"])
                specs.append(LabelSpec(
                    kind="B", title=str(proto["title"]),
                    image=render_glucose_guide_label(
                        hasta_adi=hasta_adi, ilac_adi=name,
                        title=str(proto["title"]),
                        steps=steps, caveats=list(proto["caveats"]),
                        eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                    ),
                    default_print=True, editable=True, edit_block="teknik",
                    custom_text=b_custom, text_lines=list(steps),
                ))
            elif prep_category(name, form, drug["atc_code"]):
                # Hastanın evde HAZIRLADIĞI ilaçlar: kuru toz→süspansiyon,
                # ORS, oral saşe/granül, efervesan. Forma değil ada+forma bakar;
                # bu yüzden form=None Augmentin gibi ilaçları da yakalar.
                prep_content = _fetch_block(conn, drug_id, "hazirlama")
                if b_custom or prep_content or saklama_content:
                    if b_custom:
                        adimlar = [l for l in b_custom.split("\n") if l.strip()][:4]
                        prep = _build_preparation_label(drug, "", saklama_content)
                        prep.adimlar = adimlar
                    else:
                        prep = _build_preparation_label(drug, prep_content, saklama_content)
                    specs.append(LabelSpec(
                        kind="B", title=PREP_TITLE,
                        image=render_preparation_label(
                            hasta_adi=hasta_adi, ilac_adi=name, label=prep,
                            eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                            title_override=PREP_TITLE,
                        ),
                        default_print=True, editable=True, edit_block="hazirlama",
                        custom_text=b_custom, text_lines=list(prep.adimlar),
                    ))
            elif form in TECHNIQUE_FORMS:
                title = _TECHNIQUE_TITLE.get((form or "").lower(), "KULLANIM TEKNİĞİ")
                teknik_content = _safe_teknik_for_form(
                    form, _fetch_block(conn, drug_id, "teknik")
                )
                if b_custom or teknik_content:
                    if b_custom:
                        warn = WarningLabel(
                            gerekli=True,
                            uyarilar=[l for l in b_custom.split("\n") if l.strip()][:8],
                        )
                    else:
                        warn = _build_warning_label_from_blocks(teknik_content, max_items=8)
                    specs.append(LabelSpec(
                        kind="B", title=title,
                        image=render_warning_label(
                            hasta_adi=hasta_adi, ilac_adi=name, label=warn,
                            eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                            title_override=title,
                        ),
                        default_print=True, editable=True, edit_block="teknik",
                        custom_text=b_custom, text_lines=list(warn.uyarilar),
                    ))

        # ----------------------------------------------------------------
        # C) CİDDİ UYARILAR — ciddi ilaçlarda (suppress edilebilir)
        # İnhaler formlar için C zaten yukarıda "İNHALER UYARILARI" olarak
        # eklendi; ciddi etkileşim C'si tekrar eklenmez.
        # ----------------------------------------------------------------
        dikkat_content    = _fetch_block(conn, drug_id, "dikkat")
        etkilesim_content = _fetch_block(conn, drug_id, "etkilesim")
        if form not in INHALER_FORMS:
            c_sup, c_custom = get_label_pref(conn, drug_id, "C")
        if form not in INHALER_FORMS and not c_sup and _is_serious(drug["atc_code"], etkilesim_content, dikkat_content):
            if c_custom:
                warn_c = WarningLabel(
                    gerekli=True,
                    uyarilar=[l for l in c_custom.split("\n") if l.strip()][:5],
                )
            else:
                sivi_content     = _fetch_block(conn, drug_id, "sivi")
                # Ağızdan alınmayan formda "bir bardak su ile yutunuz" tarzı sivi
                # bloğu yanlış kaynaktan gelmiştir — C etiketine sızdırma.
                # Enjektablda sivi bloğunun tamamı anlamsızdır.
                if form in _INJECTION_FORMS:
                    sivi_content = ""
                elif form in TECHNIQUE_FORMS and _has_swallow_text(sivi_content):
                    sivi_content = ""
                yan_etki_content = _fetch_block(conn, drug_id, "yan_etki")
                warn_c = _build_serious_warning(
                    drug["atc_code"], etkilesim_content, sivi_content,
                    yan_etki_content, dikkat_content,
                    form=form, route_class=drug["route_class"],
                )
                # Enjektabl formda bloklardan seçilen maddelerde kalmış olabilecek
                # oral tavsiyeleri ("yemekle alınız", "aç karnına" vb.) ayıkla.
                if form in _INJECTION_FORMS:
                    warn_c.uyarilar = _drop_oral_advice(warn_c.uyarilar)
                # Deriye sürülen ürünlerde (jel/krem/pomad) oral şablondan
                # kopyalanmış sistemik uyarıları ayıkla (mide kanaması,
                # varfarin, alkol+uyku...). Hiç madde kalmazsa C basılmaz.
                elif _is_skin_topical(form, drug["route_class"]):
                    warn_c.uyarilar = _drop_systemic_for_topical(warn_c.uyarilar)
            if warn_c.uyarilar:
                sev = _serious_severity(drug["atc_code"], etkilesim_content, dikkat_content)
                specs.append(LabelSpec(
                    kind="C", title="CİDDİ UYARILAR",
                    image=render_warning_label(
                        hasta_adi=hasta_adi, ilac_adi=name, label=warn_c,
                        eczane_adi=eczane_adi, eczane_telefon=eczane_telefon,
                        title_override="CİDDİ UYARILAR",
                    ),
                    default_print=(sev == "high"), severity=sev,
                    editable=True, edit_block="etkilesim",
                    custom_text=c_custom, text_lines=list(warn_c.uyarilar),
                ))

        return specs
    finally:
        if close_conn:
            conn.close()


def build_labels_for_drug(
    drug_id: int,
    hasta_adi: str,
    recete_tarihi: Optional[date] = None,
    *,
    bitis_tarihi_override: Optional[date] = None,
    conn: Optional[sqlite3.Connection] = None,
    doctor_note: str = "",
) -> list[Image.Image]:
    """Geriye dönük sarmalayıcı: plandaki tüm (suppress edilmemiş) etiket görsellerini döner."""
    return [
        s.image for s in build_label_plan(
            drug_id, hasta_adi, recete_tarihi,
            bitis_tarihi_override=bitis_tarihi_override,
            conn=conn, doctor_note=doctor_note,
        )
    ]


# ============================================================
# Etiket KONTROL modülü: muadil-deduplike, en çok kullanılandan sırala
# ============================================================
def build_review_list(conn: sqlite3.Connection) -> list[dict]:
    """Kontrol için ilaç listesi: aynı etiketi üretenleri (ATC + form) tek
    temsilciye indirger, EN ÇOK SATILANDAN (rank=1 ilk) aşağı sıralar.

    Sıralama `rank` (satış sıralaması; 1=en çok satılan) iledir — en çok satan
    ilaçların sales_count'u 0 olabildiğinden rank daha güvenilir. rank yoksa
    ilaç listenin sonuna düşer (satış-sırası bilinmiyor). Muadiller (örn.
    Arveles/Dexofen/Rastel = M01AE17 tablet) tek grupta; temsilci grubun EN İYİ
    (en küçük) rank'lı ilacıdır. Tıbbi malzeme elenir; form boşsa ad+ATC'den çıkarım.

    Döner: [{rep_id, rep_name, atc, form, count, best_rank, max_sales}] (sıralı).
    """
    from .application_techniques import infer_form
    rows = conn.execute(
        "SELECT id, name, atc_code, form, drug_type, indication_short, "
        "       sales_count, rank "
        "FROM drugs"
    ).fetchall()
    BIG = 10 ** 9   # rank yoksa en sona
    groups: dict = {}
    for r in rows:
        try:
            if is_medical_device(r):
                continue
        except Exception:
            pass
        name = r["name"] or ""
        atc = (r["atc_code"] or "").strip().upper()
        form = (r["form"] or "").strip().lower() or (infer_form(name, "", atc) or "")
        if atc:
            key = (atc, form)
        else:
            first = name.upper().split(" ")[0] if name else "?"
            key = ("AD:" + first, form)
        rank = r["rank"] if r["rank"] is not None else BIG
        s = r["sales_count"] or 0
        g = groups.get(key)
        if g is None:
            groups[key] = {
                "rep_id": r["id"], "rep_name": name, "best_rank": rank,
                "rep_sales": s, "atc": atc, "form": form,
                "count": 1, "max_sales": s,
            }
        else:
            g["count"] += 1
            # Temsilci = en iyi (en küçük) rank'lı; eşitse en çok satan.
            if rank < g["best_rank"] or (rank == g["best_rank"] and s > g["rep_sales"]):
                g["rep_id"], g["rep_name"] = r["id"], name
                g["best_rank"], g["rep_sales"] = rank, s
            if rank < g["best_rank"]:
                g["best_rank"] = rank
            if s > g["max_sales"]:
                g["max_sales"] = s
    return sorted(groups.values(),
                  key=lambda g: (g["best_rank"], -g["max_sales"], g["rep_name"]))


def get_reviewed_ids(conn: sqlite3.Connection) -> set[int]:
    """Etiket Kontrol modülünde 'kontrol edildi' işaretlenmiş temsilci ilaç
    id'lerini (rep_id) döndürür."""
    try:
        rows = conn.execute(
            "SELECT drug_id FROM label_review_status WHERE reviewed = 1"
        ).fetchall()
    except Exception:
        return set()
    return {r["drug_id"] for r in rows}


def set_review_status(conn: sqlite3.Connection, drug_id: int, reviewed: bool) -> None:
    """Bir temsilci ilacın etiket kontrol durumunu ayarlar. reviewed=False ise
    işaret kaldırılır (kayıt silinir)."""
    if reviewed:
        conn.execute(
            "INSERT INTO label_review_status(drug_id, reviewed, reviewed_at) "
            "VALUES (?, 1, CURRENT_TIMESTAMP) "
            "ON CONFLICT(drug_id) DO UPDATE SET reviewed = 1, "
            "reviewed_at = CURRENT_TIMESTAMP",
            (drug_id,),
        )
    else:
        conn.execute(
            "DELETE FROM label_review_status WHERE drug_id = ?", (drug_id,)
        )
    conn.commit()


def reset_review_status(conn: sqlite3.Connection) -> int:
    """Tüm etiket kontrol işaretlerini siler (hepsi 'kontrol edilmemiş' olur).
    Silinen kayıt sayısını döndürür."""
    cur = conn.execute("DELETE FROM label_review_status")
    conn.commit()
    return cur.rowcount


def render_review_label(
    conn: sqlite3.Connection,
    drug_id: int,
    eczane_adi: str = "",
    eczane_telefon: str = "",
    gunluk_kez: int = 3,
) -> Optional[Image.Image]:
    """Kontrol modülü için TEMEL (A) etiketini seçilen günlük dozda üretir.

    gunluk_kez: 1 → GÜNDE 1; 2 → SABAH-AKŞAM; 3 → SABAH-ÖĞLE-AKŞAM;
    4 → SABAH-ÖĞLE-AKŞAM-GECE. İnceleyen, "2x1/3x1" gibi farklı dozlarda
    etiketin nasıl göründüğünü görebilsin diye ayarlanabilir.
    """
    drug = _fetch_drug(conn, drug_id)
    if not drug:
        return None
    saklama_content = _fetch_block(conn, drug_id, "saklama")
    saklama_badge = _simple_storage_badge(saklama_content, drug["form"])
    _par_mode = ("recete"
                 if _settings(conn).get("erecete_parenteral_route", "0") == "1"
                 else "generic")
    ul = _build_usage_label(drug, "", saklama_badge,
                            parenteral_route_mode=_par_mode)
    # Seçilen günlük kez ile ızgara üret (zaman_satirlari/kullanim_zamani boş →
    # _derive_grid gunluk_kez'den SABAH/ÖĞLEN/AKŞAM/GECE türetir).
    try:
        n = int(gunluk_kez)
    except (TypeError, ValueError):
        n = 3
    ul.periyot = ""
    ul.gunluk_kez = max(1, min(4, n))
    ul.kullanim_zamani = []
    ul.zaman_satirlari = []
    return render_usage_label(
        hasta_adi="— KONTROL —", ilac_adi=drug["name"] or "", label=ul,
        recete_tarihi=date.today(), eczane_adi=eczane_adi,
        eczane_telefon=eczane_telefon,
    )


def render_review_labels(
    conn: sqlite3.Connection,
    drug_id: int,
    eczane_adi: str = "",
    eczane_telefon: str = "",
    gunluk_kez: int = 3,
) -> list[tuple[str, Image.Image]]:
    """Kontrol için ilacın TÜM etiketlerini döndürür: [(başlık, görsel), …].

    A (TEMEL) seçilen günlük dozda; B (HAZIRLAMA/teknik), C (CİDDİ UYARI), D
    build_label_plan'den (gerçek içerik). Böylece hazırlama/uyarı etiketleri de
    tek tek incelenebilir.
    """
    out: list[tuple[str, Image.Image]] = []
    a = render_review_label(conn, drug_id, eczane_adi, eczane_telefon, gunluk_kez)
    if a is not None:
        out.append(("A · TEMEL KULLANIM", a))
    try:
        specs = build_label_plan(drug_id, "— KONTROL —", date.today(), conn=conn)
    except Exception:
        specs = []
    for sp in specs:
        if sp.kind in ("B", "C", "D") and sp.image is not None:
            out.append((f"{sp.kind} · {sp.title}", sp.image))
    return out
