"""İlaç adından farmasötik form / doz birimi tahminleri.

Bu yardımcılar, DB'de tarifi olmayan ilaçlar için Medula'dan gelen
"1.0" gibi çıplak bir doza anlamlı bir birim eklemek için kullanılır.

Örnekler:
    "ARVELES 25MG 20 FİLM TABLET"   → "tablet"
    "AMOKLAVIN BID FORTE ... SÜSPANSİYON" → "ml"
    "VISCOTEARS GOZ JELI 10 G"      → "damla" (kullanim_sekli='Göz üzerine' ise) / "doz"
    "NAZOFIX NAZAL SPREY"           → "doz"
    "DEVIT-3 ORAL DAMLA"            → "damla"
    "KETORAL %2 ŞAMPUAN"            → "uygulama"
"""
from __future__ import annotations

from .application_techniques import nutrition_form_for_name

_DOSE_FRACTION_WORDS = {0.25: "ÇEYREK", 0.5: "YARIM", 0.75: "DÖRTTE ÜÇ"}
_DOSE_WHOLE_WORDS = {1: "BİR", 2: "İKİ", 3: "ÜÇ", 4: "DÖRT", 5: "BEŞ", 6: "ALTI"}


def format_dose_amount(value) -> str:
    """Sayısal dozu Türkçe ifadeye çevirir.

    Örnekler:
        "0,5" / 0.5  → "YARIM"
        "0,25"       → "ÇEYREK"
        "1,5"        → "BİR BUÇUK"
        "2,5"        → "İKİ BUÇUK"
        "1" / 2      → "1" / "2"   (tam sayılar olduğu gibi)
        "" / None    → ""
    Sayıya çevrilemeyen metinler (örn. zaten "YARIM") olduğu gibi döner.
    """
    s = str(value if value is not None else "").strip()
    if not s:
        return ""
    try:
        f = float(s.replace(",", "."))
    except ValueError:
        return s
    if f < 0:
        return s
    if f.is_integer():
        return str(int(f))
    whole = int(f)
    frac = round(f - whole, 2)
    frac_word = _DOSE_FRACTION_WORDS.get(frac)
    if frac_word is None:
        # Bilinmeyen kesir — virgüllü göster (örn. "0,3")
        return f"{f:.2f}".rstrip("0").rstrip(".").replace(".", ",")
    if whole == 0:
        return frac_word                      # YARIM / ÇEYREK
    if frac == 0.5:
        return f"{_DOSE_WHOLE_WORDS.get(whole, str(whole))} BUÇUK"   # BİR BUÇUK
    return f"{whole} {frac_word}"             # nadir: "1 ÇEYREK"


def guess_unit(drug_name: str, kullanim_sekli: str = "") -> str:
    """İlaç adı ve (varsa) Medula'nın 'Kullanım Şekli' alanından birim tahmin et.

    Döndürür: kısa Türkçe birim. Bulamazsa "" döner.
    """
    name  = (drug_name or "").upper()
    sekli = (kullanim_sekli or "").upper()

    # İnsülinler "ünite" ile dozlanır (kalem/flakon). Marka ve kalem adlarıyla yakala.
    # (Asıl yetkili sinyal ATC A10A'dır; çağıran yer ATC'yi biliyorsa onu kullanır.)
    _INSULIN = (
        "İNSÜLİN", "INSÜLIN", "INSULIN", "FLEXPEN", "SOLOSTAR", "KWIKPEN",
        "PENFILL", "FLEXTOUCH", "INNOLET", "HUMAPEN", "LANTUS", "LEVEMIR",
        "TOUJEO", "TRESIBA", "NOVORAPID", "NOVOMIX", "NOVOLIN", "HUMALOG",
        "HUMULIN", "APIDRA", "BASAGLAR", "RYZODEG", "INSUMAN", "INSULATARD",
        "MIXTARD", "ACTRAPID", "PROTAPHANE", "XULTOPHY", "SOLIQUA", "GLARIN",
    )
    if any(k in name for k in _INSULIN):
        return "ünite"

    # En spesifik kuralları önce yaz
    if "DAMLA" in name or "DAMLALI" in name:
        return "damla"
    if "GÖZ" in sekli or "GÖZ" in name and any(k in name for k in ("DAML", "JELI", "JEL ")):
        return "damla"
    if "BURUN" in sekli or "NAZAL" in name:
        return "doz" if "SPREY" in name else "damla"
    if "SPREY" in name:
        return "doz"
    if "İNHALER" in name or "INHALER" in name:
        return "puf"
    # Oral süspansiyon/şurup ÖLÇEK ile dozlanır (1 ölçek = 5 ml); ml DEĞİL.
    if any(k in name for k in ("SÜSPANSIYON", "SÜSPANSİYON", "ŞURUP", "SURUP")):
        return "ölçek"
    # Oral solüsyon/çözelti genelde ml ile (şırınga/ölçü ile) dozlanır.
    if any(k in name for k in ("ORAL SOLÜSYON", "ORAL SOL", "SOLUSYON", "SOLÜSYON")):
        return "ml"
    # Gargara → ÖLÇEK (1 kapak = 1 ölçek). Hacim (ml) hastaya bir şey ifade etmez;
    # "GÜNDE 1 ÖLÇEK" / "GÜNDE 3 KEZ 1 ÖLÇEK" gibi ölçek cinsinden yazılır.
    if "GARGARA" in name:
        return "ölçek"
    if any(k in name for k in ("TABLET", "FİLM TB", "FILM TB", "FTB", "TB.",
                                "KAPSÜL", "KAPSUL", "DRAJE", "ÇİĞNEME",
                                "EFERVESAN", "AĞIZDA DAĞILAN", "AGIZDA DAGILAN")):
        return "tablet"
    if any(k in name for k in ("MERHEM", "POMAD", "KREM", "JEL ", " JEL")):
        return "uygulama"
    if "ŞAMPUAN" in name or "SAMPUAN" in name:
        return "uygulama"
    if "ENJEK" in name or "FLAKON" in name:
        return "doz"
    if "FİTİL" in name or "FITIL" in name or "SUPPOZ" in name:
        return "fitil"
    return ""


def medula_dose_display(
    amount,            # birim_doz_miktari (Medula: 1 adetin gerçek miktarı): 5/0.04/10/1
    unit: str,         # doz_birim (Medula): "Mililitre"/"Adet"/"Gram"/"Ünite"...
    count,             # doz_birim_adedi (her seferdeki adet, NxM'deki M)
    drug_name: str = "",
    olcek_ml=None,     # drugs.olcek_ml: bu ilacın BİR ölçeğinin ml hacmi (DB)
):
    """Medula birim-doz verisinden etiketteki (adet, birim) çiftini üretir.

    Medula "Adet/Periyot/Doz" sütunundaki birim-doz, "2x1"deki '1'in NE olduğunu
    söyler: 1 Adet→tablet, 5 ml→1 ölçek, 0,04 ml→1 damla, 10 ml→10 ml (gargara),
    1 Gram→1 gram. Burada o bilgiyle doğru birim+miktarı hesaplarız.

    ÖLÇEK hesabı: Medula'nın bildirdiği birim-doz miktarı (`amount`) bir ilacın
    BİR ölçeğidir — 1 adet/sefer = 1 ölçek. Bu yüzden ölçek sayısı = `count`
    (NxM'deki M), `amount`'a BÖLÜNMEZ. Aksi halde Duphalac gibi ölçeği 30 ml olan
    şuruplarda "Günde 1x1" (amount=30) → 30/5 = 6 ÖLÇEK gibi hatalı katlama olur;
    doğrusu "Günde 1 ÖLÇEK"tir. `olcek_ml` (DB) ile bilinen büyük ölçü kabı
    verildiğinde yalnızca GRUPLAMA yapılır (asla `count`'tan fazla ölçek üretmez):
    örn. ölçeği 30 ml olan ilaç 15 ml okunursa → 0,5 (YARIM) ÖLÇEK.

    Döner: (adet_değeri, birim) örn. (1,'ölçek') (3,'damla') (2,'tane') (10,'ml')
           (1,'gram'). Yorumlanamazsa None (çağıran eski tahmine düşer).
    """
    if amount is None:
        return None
    try:
        amount = float(amount)
    except (TypeError, ValueError):
        return None
    count = float(count) if (count not in (None, "")) else 1.0
    if count <= 0:
        count = 1.0
    u = (unit or "").strip().lower()
    name = (drug_name or "").upper()

    # Gargara → birim ne bildirilirse bildirilsin ÖLÇEK ile yaz (1 kapak = 1 ölçek).
    # Medula bazen "1 Adet" bildirir; "tane" yanlış olur → "GÜNDE N KEZ 1 ÖLÇEK".
    if any(k in name for k in ("GARGARA", "ÇALKAL", "CALKAL", "MOUTHWASH")):
        return (count, "ölçek")

    if u.startswith("adet") or u.startswith("tablet") or u.startswith("tane"):
        return (count * amount, "tane")
    if u.startswith("gram") or u in ("gr", "g"):
        return (count * amount, "gram")
    if u.startswith("ünite") or u.startswith("unite") or u in ("iu", "ui"):
        return (count * amount, "ünite")
    if u.startswith("damla"):
        return (count * amount, "damla")
    if u.startswith("ölçek") or u.startswith("olcek"):
        return (count * amount, "ölçek")
    if u.startswith("mililitre") or u in ("ml", "cc"):
        # Çok küçük tek doz (≤0,3 ml) = DAMLA (göz/kulak/burun/oral damla).
        # Her adet 1 damladır → damla sayısı = count.
        if amount <= 0.3:
            return (count, "damla")
        total = count * amount
        # (Gargara birim ne olursa olsun yukarıda ölçeğe çevrildi.)
        # Oral süspansiyon/şurup → ÖLÇEK. Birim-doz miktarı (`amount`) BİR ölçektir;
        # ölçek sayısı = count (amount'a BÖLÜNMEZ → 30 ml'lik Duphalac 1x1 = 6 değil
        # 1 ÖLÇEK). Bilinen büyük ölçü kabı (olcek_ml) verilmişse ve birim-dozdan
        # büyükse yalnızca gruplama için kullanılır (yarım/çeyrek ölçek mümkün).
        if any(k in name for k in ("SÜSPANS", "SUSPANS", "ŞURUP", "SURUP")):
            scoop = amount
            if olcek_ml and olcek_ml > amount:
                scoop = olcek_ml
            return (total / scoop, "ölçek") if scoop else (count, "ölçek")
        # 5 ml'nin katı (oral sıvı) → ölçek; değilse ml.
        if total >= 5 and abs(total % 5) < 1e-6:
            scoop = amount
            if olcek_ml and olcek_ml > amount:
                scoop = olcek_ml
            return (total / scoop, "ölçek") if scoop else (count, "ölçek")
        return (total, "ml")
    return None


def is_topical_surulen(drug_name: str, kullanim_sekli: str = "") -> bool:
    """Cilde sürülen (uygulama miktarı hastanın takdirine kalan) bir ilaç mı?

    Krem/merhem/pomad/jel/şampuan/losyon gibi formlarda "1 gram" gibi bir
    miktar hastaya hiçbir şey ifade etmez (hasta etkilenen bölgeye gerektiği
    kadar sürer). Bu formlarda dozaj ızgarasında miktar yerine kullanım
    sıklığını "kez" olarak gösteririz (örn. SABAH 1 KEZ).

    Göz / burun / kulak / vajinal / rektal gibi iç boşluk uygulamaları HARİÇ;
    onlarda damla/fitil gibi ölçülebilir birimler anlamlıdır.
    """
    name  = (drug_name or "").upper()
    sekli = (kullanim_sekli or "").upper()

    # İç boşluk / mukozal uygulamalar bu kapsamın dışında
    if any(k in name for k in ("GÖZ", "BURUN", "NAZAL", "KULAK", "VAJİN",
                                "VAJIN", "VAJEN", "REKTAL", "FİTİL", "FITIL",
                                "OVÜL", "OVUL", "SUPPOZ")):
        return False
    if any(k in sekli for k in ("GÖZ", "BURUN", "NAZAL", "KULAK", "VAJİN",
                                 "VAJIN", "VAJEN", "REKTAL", "MAKAT")):
        return False

    if any(k in name for k in ("KREM", "MERHEM", "POMAD", "LOSYON",
                                "ŞAMPUAN", "SAMPUAN")):
        return True
    # Jel ve emüljel/emülgel varyantları (EMULGEL içinde "JEL" geçmez)
    if any(k in name for k in ("JEL", "EMULGEL", "EMÜLGEL", "EMULJEL",
                                "EMÜLJEL", "EMÜLSİYON JEL")):
        return True
    if any(k in sekli for k in ("CİLT", "DERİ", "ÜZERİNE SÜR", "HARİCEN", "TOPİK")):
        return True
    return False


# Etken madde / marka adı → kategori eşlemesi.
# İlaç adında bu anahtar kelimelerden biri geçerse ilgili kategori atanır.
# Sıralama önemli: önce daha spesifik (uzun) eşleşmeler yazılmalı, generic'ler sonra.
ETKEN_MADDE_KATEGORI = [
    # ============ ANTİBİYOTİKLER ============
    ("AMOKSI", "ANTİBİYOTİK"), ("AMOKLAVIN", "ANTİBİYOTİK"),
    ("AUGMENTIN", "ANTİBİYOTİK"), ("KLAMOKS", "ANTİBİYOTİK"),
    ("CROXILEX", "ANTİBİYOTİK"), ("KLAVUNAT", "ANTİBİYOTİK"),
    ("LARGOPEN", "ANTİBİYOTİK"), ("ALFOXIL", "ANTİBİYOTİK"),
    ("DUOCID", "ANTİBİYOTİK"), ("DEVASILIN", "ANTİBİYOTİK"),
    ("SULTAMICILLIN", "ANTİBİYOTİK"), ("UNASYN", "ANTİBİYOTİK"),
    ("AZITRO", "ANTİBİYOTİK"), ("ZITROMAX", "ANTİBİYOTİK"),
    ("AZOMAX", "ANTİBİYOTİK"), ("ZIMAX", "ANTİBİYOTİK"),
    ("KLARITRO", "ANTİBİYOTİK"), ("KLAX", "ANTİBİYOTİK"),
    ("ERITROMISIN", "ANTİBİYOTİK"), ("ROKLARIN", "ANTİBİYOTİK"),
    ("KLINDA", "ANTİBİYOTİK"), ("DALACIN", "ANTİBİYOTİK"),
    ("DOKSI", "ANTİBİYOTİK"), ("MONODOKS", "ANTİBİYOTİK"),
    ("TETRA", "ANTİBİYOTİK"), ("OKSITETRA", "ANTİBİYOTİK"),
    ("SIPRO", "ANTİBİYOTİK"), ("CIPRO", "ANTİBİYOTİK"),
    ("CIPROXIN", "ANTİBİYOTİK"), ("ROXIBAN", "ANTİBİYOTİK"),
    ("LEVOFLOK", "ANTİBİYOTİK"), ("TAVANIC", "ANTİBİYOTİK"),
    ("MOKSIFL", "ANTİBİYOTİK"), ("AVELOX", "ANTİBİYOTİK"),
    ("OFLOKSAS", "ANTİBİYOTİK"),
    ("METRONIDAZOL", "ANTİBİYOTİK"), ("FLAGYL", "ANTİBİYOTİK"),
    ("NIDAZOL", "ANTİBİYOTİK"), ("TINIDAZOL", "ANTİBİYOTİK"),
    ("VANKO", "ANTİBİYOTİK"), ("TEKOPLAN", "ANTİBİYOTİK"),
    ("LINEZOLID", "ANTİBİYOTİK"), ("ZYVOX", "ANTİBİYOTİK"),
    ("SEFAD", "ANTİBİYOTİK"), ("SEFAZOL", "ANTİBİYOTİK"),
    ("SEFAKS", "ANTİBİYOTİK"), ("SEFOTAK", "ANTİBİYOTİK"),
    ("SEFTRIAKSON", "ANTİBİYOTİK"), ("ROCEPHIN", "ANTİBİYOTİK"),
    ("DESEFIN", "ANTİBİYOTİK"), ("EQUIPHIN", "ANTİBİYOTİK"),
    ("IESEF", "ANTİBİYOTİK"), ("SEFAGEN", "ANTİBİYOTİK"),
    ("SEFIKSIM", "ANTİBİYOTİK"), ("SUPRAX", "ANTİBİYOTİK"),
    ("SEFAKLOR", "ANTİBİYOTİK"), ("CEFAKLOR", "ANTİBİYOTİK"),
    ("SEFUROKSIM", "ANTİBİYOTİK"), ("CEFAKS", "ANTİBİYOTİK"),
    ("AKSEF", "ANTİBİYOTİK"), ("ZINNAT", "ANTİBİYOTİK"),
    ("SEFPODOKS", "ANTİBİYOTİK"), ("ORELOX", "ANTİBİYOTİK"),
    ("MEROPENEM", "ANTİBİYOTİK"), ("MERONEM", "ANTİBİYOTİK"),
    ("IMIPENEM", "ANTİBİYOTİK"), ("TIENAM", "ANTİBİYOTİK"),
    ("PIPERA", "ANTİBİYOTİK"), ("TAZOSIN", "ANTİBİYOTİK"),
    ("AMPISILIN", "ANTİBİYOTİK"), ("PEN-OS", "ANTİBİYOTİK"),
    ("PROCAIN", "ANTİBİYOTİK"), ("DEPOPEN", "ANTİBİYOTİK"),
    ("DEVAPEN", "ANTİBİYOTİK"), ("BENZATIN", "ANTİBİYOTİK"),
    ("FUSIDIN", "ANTİBİYOTİK"), ("STAFINE", "ANTİBİYOTİK"),
    ("SULFA", "ANTİBİYOTİK"), ("BAKTRIM", "ANTİBİYOTİK"),
    ("TRIMETOPRIM", "ANTİBİYOTİK"), ("SEPTRIN", "ANTİBİYOTİK"),
    ("NITROFURAN", "ANTİBİYOTİK"), ("FURADANTIN", "ANTİBİYOTİK"),
    ("PIYELOSEPTYL", "ANTİBİYOTİK"),

    # ============ AĞRI KESİCİ (NSAID) ============
    ("ARVELES", "AĞRI KESİCİ"), ("DEXOFEN", "AĞRI KESİCİ"),
    ("DEKSKETOPROFEN", "AĞRI KESİCİ"), ("DEKSALJIN", "AĞRI KESİCİ"),
    ("KETOPROFEN", "AĞRI KESİCİ"), ("PROFENID", "AĞRI KESİCİ"),
    ("BI-PROFENID", "AĞRI KESİCİ"),
    ("IBUPROFEN", "AĞRI KESİCİ"), ("BRUFEN", "AĞRI KESİCİ"),
    ("DOLVEN", "AĞRI KESİCİ"), ("PEDIFEN", "AĞRI KESİCİ"),
    ("IBUFEN", "AĞRI KESİCİ"), ("IBU-FORT", "AĞRI KESİCİ"),
    ("NUROFEN", "AĞRI KESİCİ"), ("IBURAMIN", "AĞRI KESİCİ"),
    ("NAPROKSEN", "AĞRI KESİCİ"), ("APRANAX", "AĞRI KESİCİ"),
    ("APRALJIN", "AĞRI KESİCİ"), ("APROL", "AĞRI KESİCİ"),
    ("NAPROSYN", "AĞRI KESİCİ"),
    ("DICLOFENAC", "AĞRI KESİCİ"), ("DIKLOFENAK", "AĞRI KESİCİ"),
    ("VOLTAREN", "AĞRI KESİCİ"), ("CATAFLAM", "AĞRI KESİCİ"),
    ("DIKLORON", "AĞRI KESİCİ"), ("DOLOREX", "AĞRI KESİCİ"),
    ("ETOL", "AĞRI KESİCİ"), ("ETODOLAK", "AĞRI KESİCİ"),
    ("MELOKSIKAM", "AĞRI KESİCİ"), ("MOBIC", "AĞRI KESİCİ"),
    ("EXEN", "AĞRI KESİCİ"), ("MELOX", "AĞRI KESİCİ"),
    ("NIMESULID", "AĞRI KESİCİ"), ("MESULID", "AĞRI KESİCİ"),
    ("NIMETON", "AĞRI KESİCİ"),
    ("LORNOK", "AĞRI KESİCİ"), ("XEFO", "AĞRI KESİCİ"),
    ("PIROKSIKAM", "AĞRI KESİCİ"), ("FELDEN", "AĞRI KESİCİ"),
    ("FLURBIPROFEN", "AĞRI KESİCİ"), ("MAJEZIK", "AĞRI KESİCİ"),
    ("INDOMETASIN", "AĞRI KESİCİ"), ("ENDOL", "AĞRI KESİCİ"),
    ("DEX-FORTE", "AĞRI KESİCİ"),
    ("TRAMADOL", "AĞRI KESİCİ"), ("CONTRAMAL", "AĞRI KESİCİ"),
    ("ZALDIAR", "AĞRI KESİCİ"), ("ULTRAM", "AĞRI KESİCİ"),
    ("KODEIN", "AĞRI KESİCİ"), ("KATAFAST", "AĞRI KESİCİ"),
    ("PONSTAN", "AĞRI KESİCİ"), ("MEFENAMIK", "AĞRI KESİCİ"),
    ("DOLO-PROXEN", "AĞRI KESİCİ"), ("GERALGINE", "AĞRI KESİCİ"),
    ("CABRAL", "AĞRI KESİCİ"), ("ETOPAN", "AĞRI KESİCİ"),

    # ============ AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ (Parasetamol) ============
    ("PARASETAMOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("PAROL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("TYLOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("MINOSET", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("VERMIDON", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("CALPOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("PANADOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("CASIPRA", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("NOVALGIN", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("METAMIZOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("ANDOLOR", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("ZERO-P", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),

    # ============ MİDE İLAÇLARI ============
    ("OMEPRAZOL", "MİDE İLACI"), ("OMEPRAL", "MİDE İLACI"),
    ("LANSOPRAZOL", "MİDE İLACI"), ("LANSOR", "MİDE İLACI"),
    ("DEGASTROL", "MİDE İLACI"), ("LANTON", "MİDE İLACI"),
    ("PANTOPRAZOL", "MİDE İLACI"), ("PANTO", "MİDE İLACI"),
    ("PANTRO", "MİDE İLACI"), ("PANTPAS", "MİDE İLACI"),
    ("PANTPRO", "MİDE İLACI"),
    ("ESOMEPRAZOL", "MİDE İLACI"), ("NEXIUM", "MİDE İLACI"),
    ("ESONIX", "MİDE İLACI"), ("ESOPRAZOL", "MİDE İLACI"),
    ("RABEPRAZOL", "MİDE İLACI"), ("PARIET", "MİDE İLACI"),
    ("RABIZA", "MİDE İLACI"), ("RABIUM", "MİDE İLACI"),
    ("FAMOTIDIN", "MİDE İLACI"), ("FAMODAR", "MİDE İLACI"),
    ("RANITIDIN", "MİDE İLACI"), ("ZANTAC", "MİDE İLACI"),
    ("RANIVER", "MİDE İLACI"),
    ("GAVISCON", "MİDE İLACI (REFLÜ)"), ("RENNIE", "MİDE İLACI"),
    ("TALCID", "MİDE İLACI"), ("MAALOX", "MİDE İLACI"),
    ("MUCAINE", "MİDE İLACI"), ("RIOPAN", "MİDE İLACI"),
    ("ALGINIK", "MİDE İLACI (REFLÜ)"),
    ("METPAMID", "BULANTI KESİCİ"), ("METOKLOPRAMID", "BULANTI KESİCİ"),
    ("ZOFER", "BULANTI KESİCİ"), ("ONDANSETRON", "BULANTI KESİCİ"),
    # Prilam = doksilamin + piridoksin (B6): gebeliğe bağlı bulantı-kusma
    # (FDA gebelik kat. A). ATC R06A altında olsa da ALERJİ ilacı DEĞİLDİR.
    ("PRILAM", "GEBELİKTE BULANTI İLACI"),
    ("DOMPERIDON", "BULANTI KESİCİ"), ("MOTILIUM", "BULANTI KESİCİ"),
    ("BUSCOPAN", "KARIN AĞRISI / KASILMA İLACI"),
    ("HYOSCIN", "KARIN AĞRISI / KASILMA İLACI"),
    ("DUSPATALIN", "KARIN AĞRISI / KASILMA İLACI"),

    # ============ TANSİYON ============
    ("AMLODIPIN", "TANSİYON İLACI"), ("AMLODIS", "TANSİYON İLACI"),
    ("NORVASC", "TANSİYON İLACI"), ("AMLOC", "TANSİYON İLACI"),
    ("AMLOPIN", "TANSİYON İLACI"), ("VASCALEX", "TANSİYON İLACI"),
    ("NIFEDIPIN", "TANSİYON İLACI"), ("ADALAT", "TANSİYON İLACI"),
    ("LERKANIDIPIN", "TANSİYON İLACI"), ("LERCADIP", "TANSİYON İLACI"),
    ("FELODIPIN", "TANSİYON İLACI"),
    ("LOSARTAN", "TANSİYON İLACI"), ("COZAAR", "TANSİYON İLACI"),
    ("LORISTA", "TANSİYON İLACI"), ("ARDUAN", "TANSİYON İLACI"),
    ("LOSTAR", "TANSİYON İLACI"),
    ("VALSARTAN", "TANSİYON İLACI"), ("DIOVAN", "TANSİYON İLACI"),
    ("VALTAN", "TANSİYON İLACI"),
    ("TELMISARTAN", "TANSİYON İLACI"), ("MICARDIS", "TANSİYON İLACI"),
    ("EDARBI", "TANSİYON İLACI"), ("KANDESARTAN", "TANSİYON İLACI"),
    ("ATACAND", "TANSİYON İLACI"),
    ("IRBESARTAN", "TANSİYON İLACI"), ("APROVEL", "TANSİYON İLACI"),
    ("OLMESARTAN", "TANSİYON İLACI"), ("OLMETEC", "TANSİYON İLACI"),
    ("ENALAPRIL", "TANSİYON İLACI"), ("VASOLAPRIL", "TANSİYON İLACI"),
    ("KONVERIL", "TANSİYON İLACI"),
    ("PERINDOPRIL", "TANSİYON İLACI"), ("COVERSYL", "TANSİYON İLACI"),
    ("COVERAM", "TANSİYON İLACI"), ("PRESTARIUM", "TANSİYON İLACI"),
    ("RAMIPRIL", "TANSİYON İLACI"), ("DELIX", "TANSİYON İLACI"),
    ("TRIATEC", "TANSİYON İLACI"),
    ("LISINOPRIL", "TANSİYON İLACI"), ("ZESTRIL", "TANSİYON İLACI"),
    ("KAPTOPRIL", "TANSİYON İLACI"), ("KAPRIL", "TANSİYON İLACI"),
    ("BISOPROLOL", "TANSİYON İLACI"), ("CONCOR", "TANSİYON İLACI"),
    ("BYOL", "TANSİYON İLACI"),
    ("METOPROLOL", "TANSİYON İLACI"), ("BELOC", "TANSİYON İLACI"),
    ("BELONOL", "TANSİYON İLACI"),
    ("ATENOLOL", "TANSİYON İLACI"), ("TENORMIN", "TANSİYON İLACI"),
    ("KARVEDILOL", "TANSİYON İLACI"), ("DILATREND", "TANSİYON İLACI"),
    ("NEBIVOLOL", "TANSİYON İLACI"), ("NEBILET", "TANSİYON İLACI"),
    ("PROPRANOLOL", "TANSİYON İLACI"), ("DIDERAL", "TANSİYON İLACI"),
    ("HIDROKLOROTIYAZID", "TANSİYON İLACI"),
    ("FUROSEMID", "TANSİYON İLACI"), ("LASIX", "TANSİYON İLACI"),
    ("DESAL", "TANSİYON İLACI"),
    ("SPIRONOLAKTON", "TANSİYON İLACI"), ("ALDACTONE", "TANSİYON İLACI"),
    ("INDAPAMID", "TANSİYON İLACI"), ("FLUDEKS", "TANSİYON İLACI"),
    ("EXFORGE", "TANSİYON İLACI"), ("EXTAVIA", "TANSİYON İLACI"),

    # ============ KOLESTEROL ============
    ("ATORVASTATIN", "KOLESTEROL İLACI"), ("LIPITOR", "KOLESTEROL İLACI"),
    ("LIPRIMAR", "KOLESTEROL İLACI"), ("ATOR", "KOLESTEROL İLACI"),
    ("LIPDOWN", "KOLESTEROL İLACI"),
    ("ROSUVASTATIN", "KOLESTEROL İLACI"), ("CRESTOR", "KOLESTEROL İLACI"),
    ("ROSUCOR", "KOLESTEROL İLACI"), ("ROSURI", "KOLESTEROL İLACI"),
    ("SIMVASTATIN", "KOLESTEROL İLACI"), ("ZOCOR", "KOLESTEROL İLACI"),
    ("SIMVA", "KOLESTEROL İLACI"),
    ("PRAVASTATIN", "KOLESTEROL İLACI"), ("PRAVACHOL", "KOLESTEROL İLACI"),
    ("FLUVASTATIN", "KOLESTEROL İLACI"), ("LESCOL", "KOLESTEROL İLACI"),
    ("EZETROL", "KOLESTEROL İLACI"), ("LIPIDIL", "KOLESTEROL İLACI"),
    ("FENOFIBRAT", "KOLESTEROL İLACI"),

    # ============ DİYABET ============
    ("METFORMIN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("GLIFOR", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("GLUCOPHAGE", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("GLUKOFEN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("DIAFORMIN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("GLIBENKLAMID", "DİYABET"),
    ("GLIKLAZID", "DİYABET"), ("DIAMICRON", "DİYABET"),
    ("GLIMEPIRID", "DİYABET"), ("AMARYL", "DİYABET"),
    ("GLIPIZID", "DİYABET"),
    ("SITAGLIPTIN", "DİYABET"), ("JANUVIA", "DİYABET"),
    ("VILDAGLIPTIN", "DİYABET"), ("GALVUS", "DİYABET"),
    ("LINAGLIPTIN", "DİYABET"), ("TRAJENTA", "DİYABET"),
    ("DAPAGLIFLOZIN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("FORZIGA", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("EMPAGLIFLOZIN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("JARDIANCE", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("INSULIN", "DİYABET"), ("LANTUS", "DİYABET"),
    ("LEVEMIR", "DİYABET"), ("NOVORAPID", "DİYABET"),
    ("HUMULIN", "DİYABET"), ("HUMALOG", "DİYABET"),
    ("TRESIBA", "DİYABET"), ("APIDRA", "DİYABET"),
    ("LIRAGLUTID", "DİYABET"), ("VICTOZA", "DİYABET"),
    ("OZEMPIC", "DİYABET"), ("SEMAGLUTID", "DİYABET"),
    ("DULAGLUTID", "DİYABET"), ("TRULICITY", "DİYABET"),

    # ============ KAN SULANDIRICI ============
    ("WARFARIN", "KAN SULANDIRICI"), ("COUMADIN", "KAN SULANDIRICI"),
    ("ASPIRIN", "KAN SULANDIRICI"), ("ECOPIRIN", "KAN SULANDIRICI"),
    ("CORASPIN", "KAN SULANDIRICI"), ("DISPRIL", "KAN SULANDIRICI"),
    ("ASOMA", "KAN SULANDIRICI"),
    ("KLOPIDOGREL", "KAN SULANDIRICI"), ("PLAVIX", "KAN SULANDIRICI"),
    ("KARDOGREL", "KAN SULANDIRICI"), ("PINGEL", "KAN SULANDIRICI"),
    ("TIKAGRELOR", "KAN SULANDIRICI"), ("BRILINTA", "KAN SULANDIRICI"),
    ("PRASUGREL", "KAN SULANDIRICI"), ("EFFIENT", "KAN SULANDIRICI"),
    ("APIKSABAN", "KAN SULANDIRICI"), ("ELIQUIS", "KAN SULANDIRICI"),
    ("RIVAROKSABAN", "KAN SULANDIRICI"), ("XARELTO", "KAN SULANDIRICI"),
    ("DABIGATRAN", "KAN SULANDIRICI"), ("PRADAXA", "KAN SULANDIRICI"),
    ("ENOKSAPARIN", "KAN SULANDIRICI (İĞNE)"),
    ("OKSAPAR", "KAN SULANDIRICI (İĞNE)"),
    ("KLEKSAN", "KAN SULANDIRICI (İĞNE)"),
    ("CLEXANE", "KAN SULANDIRICI (İĞNE)"),
    ("FRAXIPARIN", "KAN SULANDIRICI (İĞNE)"),
    ("FRAGMIN", "KAN SULANDIRICI (İĞNE)"),

    # ============ ANTİDEPRESAN / ANKSİYOLİTİK ============
    ("ESITALOPRAM", "ANTİDEPRESAN"), ("CIPRALEX", "ANTİDEPRESAN"),
    ("LEXAPRO", "ANTİDEPRESAN"),
    ("SITALOPRAM", "ANTİDEPRESAN"), ("CIPRAM", "ANTİDEPRESAN"),
    ("CITARO", "ANTİDEPRESAN"),
    ("FLUOKSETIN", "ANTİDEPRESAN"), ("PROZAC", "ANTİDEPRESAN"),
    ("DEPREXIT", "ANTİDEPRESAN"), ("ZEDPREX", "ANTİDEPRESAN"),
    ("SERTRALIN", "ANTİDEPRESAN"), ("LUSTRAL", "ANTİDEPRESAN"),
    ("ZOLOFT", "ANTİDEPRESAN"), ("SERTRALOFT", "ANTİDEPRESAN"),
    ("PAROKSETIN", "ANTİDEPRESAN"), ("PAROXAT", "ANTİDEPRESAN"),
    ("SEROXAT", "ANTİDEPRESAN"), ("XETANOR", "ANTİDEPRESAN"),
    ("VENLAFAKSIN", "ANTİDEPRESAN"), ("EFEXOR", "ANTİDEPRESAN"),
    ("DULOKSETIN", "ANTİDEPRESAN"), ("CYMBALTA", "ANTİDEPRESAN"),
    ("MIRTAZAPIN", "ANTİDEPRESAN"), ("REMERON", "ANTİDEPRESAN"),
    ("MIRTAS", "ANTİDEPRESAN"),
    ("BUPROPION", "ANTİDEPRESAN"), ("WELLBUTRIN", "ANTİDEPRESAN"),
    ("AMITRIPTILIN", "ANTİDEPRESAN"), ("LAROXYL", "ANTİDEPRESAN"),
    ("ALPRAZOLAM", "ANKSİYOLİTİK"), ("XANAX", "ANKSİYOLİTİK"),
    ("DIAZEPAM", "ANKSİYOLİTİK"), ("DIAZEM", "ANKSİYOLİTİK"),
    ("NERVIUM", "ANKSİYOLİTİK"),
    ("LORAZEPAM", "ANKSİYOLİTİK"), ("ATIVAN", "ANKSİYOLİTİK"),
    ("KLONAZEPAM", "ANKSİYOLİTİK"), ("RIVOTRIL", "ANKSİYOLİTİK"),
    ("BROMAZEPAM", "ANKSİYOLİTİK"), ("LEXOTANIL", "ANKSİYOLİTİK"),

    # ============ ANTİPSİKOTİK ============
    ("KETIAPIN", "ANTİPSİKOTİK"), ("SEROQUEL", "ANTİPSİKOTİK"),
    ("OLANZAPIN", "ANTİPSİKOTİK"), ("ZYPREXA", "ANTİPSİKOTİK"),
    ("REZAPIN", "ANTİPSİKOTİK"),
    ("RISPERIDON", "ANTİPSİKOTİK"), ("RISPERDAL", "ANTİPSİKOTİK"),
    ("ARIPIPRAZOL", "ANTİPSİKOTİK"), ("ABILIFY", "ANTİPSİKOTİK"),
    ("ABIZOL", "ANTİPSİKOTİK"),
    ("KLOZAPIN", "ANTİPSİKOTİK"), ("LEPONEX", "ANTİPSİKOTİK"),
    ("HALOPERIDOL", "ANTİPSİKOTİK"), ("NORODOL", "ANTİPSİKOTİK"),

    # ============ ANTİEPİLEPTİK ============
    ("VALPROAT", "ANTİEPİLEPTİK"), ("DEPAKIN", "ANTİEPİLEPTİK"),
    ("CONVULEX", "ANTİEPİLEPTİK"),
    ("LAMOTRIJIN", "ANTİEPİLEPTİK"), ("LAMICTAL", "ANTİEPİLEPTİK"),
    ("LEVETIRASETAM", "ANTİEPİLEPTİK"), ("KEPPRA", "ANTİEPİLEPTİK"),
    ("KARBAMAZEPIN", "ANTİEPİLEPTİK"), ("TEGRETOL", "ANTİEPİLEPTİK"),
    ("GABAPENTIN", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("NEURONTIN", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("PREGABALIN", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("LYRICA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("PRAGIOLA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("FENITOIN", "ANTİEPİLEPTİK"), ("EPANUTIN", "ANTİEPİLEPTİK"),

    # ============ ASTIM / KOAH ============
    ("SALBUTAMOL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("VENTOLIN", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("ASTHALIN", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("FORMOTEROL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("FORADIL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("OXIS", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("SALMETEROL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("SEREVENT", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("BUDESONID", "ASTIM İLACI (KORTİZON)"),
    ("PULMICORT", "ASTIM İLACI (KORTİZON)"),
    ("FLUTIKAZON", "ASTIM İLACI (KORTİZON)"),
    ("FLIXOTIDE", "ASTIM İLACI (KORTİZON)"),
    ("SYMBICORT", "ASTIM İLACI"), ("SERETIDE", "ASTIM İLACI"),
    ("RELVAR", "ASTIM İLACI"), ("FOSTER", "ASTIM İLACI"),
    ("TIOTROPIUM", "ASTIM İLACI"), ("SPIRIVA", "ASTIM İLACI"),
    ("IPRATROPIUM", "ASTIM İLACI"), ("ATROVENT", "ASTIM İLACI"),
    ("MONTELUKAST", "ASTIM İLACI"), ("ONCEAIR", "ASTIM İLACI"),
    ("AIRFLUS", "ASTIM İLACI"), ("SINGULAIR", "ASTIM İLACI"),

    # ============ ALERJİ / ANTİHİSTAMİNİK ============
    ("SETIRİZİN", "ALLERJİ / KAŞINTI İLACI"),
    ("ZYRTEC", "ALLERJİ / KAŞINTI İLACI"),
    ("ZYRTEX", "ALLERJİ / KAŞINTI İLACI"),
    ("CETRIN", "ALLERJİ / KAŞINTI İLACI"),
    ("LEVOSETIRİZİN", "ALLERJİ / KAŞINTI İLACI"),
    ("XYZAL", "ALLERJİ / KAŞINTI İLACI"),
    ("LORATADIN", "ALLERJİ / KAŞINTI İLACI"),
    ("CLARINEX", "ALLERJİ / KAŞINTI İLACI"),
    ("DESLORATADIN", "ALLERJİ / KAŞINTI İLACI"),
    ("AERIUS", "ALLERJİ / KAŞINTI İLACI"),
    ("DELODAY", "ALLERJİ / KAŞINTI İLACI"),
    ("FEKSOFENADIN", "ALLERJİ / KAŞINTI İLACI"),
    ("ALLEGRA", "ALLERJİ / KAŞINTI İLACI"),
    ("HIDROKSIZIN", "ALLERJİ / KAŞINTI İLACI"),
    ("ATARAX", "ALLERJİ / KAŞINTI İLACI"),
    ("RASTEL", "ALLERJİ / KAŞINTI İLACI"),
    ("PRIMOFENON", "ALLERJİ / KAŞINTI İLACI"),
    ("AVIL", "ALLERJİ / KAŞINTI İLACI"),

    # ============ KORTİZON (SİSTEMİK) ============
    ("PREDNIZOLON", "KORTİZON TEDAVİSİ"),
    ("DELTACORTRIL", "KORTİZON TEDAVİSİ"),
    ("PREDNOL", "KORTİZON TEDAVİSİ"),
    ("METILPREDNIZOLON", "KORTİZON TEDAVİSİ"),
    ("DEPOMEDROL", "KORTİZON TEDAVİSİ"),
    ("MEDROL", "KORTİZON TEDAVİSİ"),
    ("DEKSAMETAZON", "KORTİZON TEDAVİSİ"),
    ("DEKORT", "KORTİZON TEDAVİSİ"),
    ("BETAMETAZON", "KORTİZON TEDAVİSİ"),
    ("BETNESOL", "KORTİZON TEDAVİSİ"),
    ("BETACORTON", "KORTİZON TEDAVİSİ"),

    # ============ VİTAMİNLER VE MİNERALLER ============
    ("KOLEKALSIFEROL", "D VİTAMİNİ"), ("DEVIT", "D VİTAMİNİ"),
    ("DEPOSEK", "D VİTAMİNİ"), ("D-COLEFOR", "D VİTAMİNİ"),
    ("COLEDAN", "D VİTAMİNİ"), ("MAGNADD", "D VİTAMİNİ"),
    ("RAYACAL", "D VİTAMİNİ"), ("VIGANTOL", "D VİTAMİNİ"),
    ("KALSIYUM", "KALSİYUM DESTEĞİ"), ("CALCIMAX", "KALSİYUM DESTEĞİ"),
    ("OS-CAL", "KALSİYUM DESTEĞİ"), ("CACIT", "KALSİYUM DESTEĞİ"),
    ("DEMIR", "DEMİR DESTEĞİ"), ("FERRO", "DEMİR DESTEĞİ"),
    ("FERRUM", "DEMİR DESTEĞİ"), ("GLUKOFER", "DEMİR DESTEĞİ"),
    ("FERINJECT", "DEMİR DESTEĞİ"), ("VENOFER", "DEMİR DESTEĞİ"),
    ("MALTOFER", "DEMİR DESTEĞİ"),
    ("DODEX", "B12 VİTAMİNİ DESTEĞİ"), ("B12", "B12 VİTAMİNİ DESTEĞİ"),
    ("KOBAMAMID", "B12 VİTAMİNİ DESTEĞİ"),
    ("BENEXOL", "B VİTAMİNİ DESTEĞİ"), ("BEDOZE", "B VİTAMİNİ DESTEĞİ"),
    ("NEUROBION", "B VİTAMİNİ DESTEĞİ"),
    ("MULTİVİT", "VİTAMİN DESTEĞİ"), ("CENTRUM", "VİTAMİN DESTEĞİ"),
    ("SUPRADYN", "VİTAMİN DESTEĞİ"), ("BEROCCA", "VİTAMİN DESTEĞİ"),
    ("FOLIK", "FOLİK ASİT DESTEĞİ"), ("FOLBIOL", "FOLİK ASİT DESTEĞİ"),
    ("MAGNEZYUM", "MAGNEZYUM DESTEĞİ"),
    ("ZINK", "ÇİNKO DESTEĞİ"), ("ZINCO", "ÇİNKO DESTEĞİ"),

    # ============ TİROİD ============
    ("LEVOTIROKSIN", "GUATR İLACI"), ("LEVOTIRON", "GUATR İLACI"),
    ("EUTHYROX", "GUATR İLACI"), ("BITIRON", "GUATR İLACI"),
    ("TIROMEL", "GUATR İLACI"), ("PROPILTIYO", "GUATR İLACI"),

    # ============ ANTİVİRAL ============
    ("ASIKLOVIR", "ANTİVİRAL"), ("ZOVIRAX", "ANTİVİRAL"),
    ("VALASIKLOVIR", "ANTİVİRAL"), ("VALTREX", "ANTİVİRAL"),
    ("OSELTAMIVIR", "ANTİVİRAL"), ("TAMIFLU", "ANTİVİRAL"),

    # ============ ÜRİK ASİT / GUT ============
    ("ALLOPURINOL", "ÜRİK ASİT İLACI"), ("ÜROKSIM", "ÜRİK ASİT İLACI"),
    ("FEBUKSOSTAT", "ÜRİK ASİT İLACI"), ("ADENURIK", "ÜRİK ASİT İLACI"),
    ("KOLŞISIN", "FMF / GUT TEDAVİSİ"), ("COLCHICUM", "FMF / GUT TEDAVİSİ"),

    # ============ ÖKSÜRÜK / EKSPEKTORAN ============
    ("ERDOSTIN", "ÖKSÜRÜK KESİCİ"), ("BISOLVON", "ÖKSÜRÜK KESİCİ"),
    ("MUCOLIT", "ÖKSÜRÜK KESİCİ"), ("AMBROKSOL", "ÖKSÜRÜK KESİCİ"),
    ("BROMHEKSIN", "ÖKSÜRÜK KESİCİ"), ("BRONKO", "ÖKSÜRÜK KESİCİ"),
    ("DEXTROMETORFAN", "ÖKSÜRÜK KESİCİ"),
    ("PULMOTAB", "ÖKSÜRÜK KESİCİ"), ("KREVAL", "ÖKSÜRÜK KESİCİ"),
    ("KARMOLIS", "ÖKSÜRÜK KESİCİ"), ("THYMIPIN", "ÖKSÜRÜK KESİCİ"),

    # ============ GRİP ============
    ("A-FERIN", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("IBURAMIN COLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("THERAFLU", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("NUROFEN COLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("IBUCOLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("PARAFON", "GRİP / SOĞUK ALGINLIĞINDA"),

    # ============ GÖZ İLAÇLARI ============
    ("XALATAN", "GLOKOM İLACI"), ("LATANOPROST", "GLOKOM İLACI"),
    ("TRAVATAN", "GLOKOM İLACI"), ("TRAVOPROST", "GLOKOM İLACI"),
    ("TIMOL", "GLOKOM İLACI"), ("TIMOPRESS", "GLOKOM İLACI"),
    ("BRIMONIDIN", "GLOKOM İLACI"), ("ALPHAGAN", "GLOKOM İLACI"),
    ("AZARGA", "GLOKOM İLACI"), ("COSOPT", "GLOKOM İLACI"),
    ("GANFORT", "GLOKOM İLACI"),
    ("VISCOTEARS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("SYSTANE", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("TEARS NATURALE", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("REFRESH", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("THERA TEARS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("OPTIVE", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("BLEPHAGEL", "GÖZ KAPAĞI BAKIMI"),

    # ============ BURUN ============
    ("ILIADIN", "BURUN AÇICI"), ("OTRIVINE", "BURUN AÇICI"),
    ("OTRIVIN", "BURUN AÇICI"), ("RHINFANT", "BURUN AÇICI (BEBEK)"),
    ("OKSIMETAZOLIN", "BURUN AÇICI"), ("AFRIN", "BURUN AÇICI"),
    ("PHYSIOMER", "BURUN BAKIMI (TUZ)"),
    ("STERIMAR", "BURUN BAKIMI (TUZ)"), ("OCEAN", "BURUN BAKIMI (TUZ)"),
    ("NAZOFIX", "BURUN BAKIMI"), ("RHINASE", "BURUN İLACI"),
    ("NASONEX", "BURUN İLACI (KORTİZON)"),
    ("AVAMYS", "BURUN İLACI (KORTİZON)"),
    ("FLIXONASE", "BURUN İLACI (KORTİZON)"),

    # ============ KADIN HASTALIKLARI ============
    ("FLUKONAZOL", "MANTAR İLACI"), ("DIFLUCAN", "MANTAR İLACI"),
    ("FLUSER", "MANTAR İLACI"),
    ("KLOTRIMAZOL", "KADIN HASTALIKLARINDA"),
    ("CANESTEN", "KADIN HASTALIKLARINDA"),
    ("GINO-TRAVOGEN", "KADIN HASTALIKLARINDA"),
    ("FLUOMIZIN", "KADIN HASTALIKLARINDA"),
    ("LAGYL", "KADIN HASTALIKLARINDA"),
    ("MIKOGYN", "KADIN HASTALIKLARINDA"),
    ("TRAVAZOL", "MANTAR İLACI"),
    ("LAMISIL", "MANTAR İLACI"), ("TERBISIL", "MANTAR İLACI"),
    ("KETOKONAZOL", "MANTAR İLACI"), ("KETORAL", "MANTAR İLACI"),
    ("NIZORAL", "MANTAR İLACI"),
    ("MIKONAZOL", "MANTAR İLACI"), ("DAKTARIN", "MANTAR İLACI"),

    # ============ DOĞUM KONTROL / HORMON ============
    ("DİYANE", "DOĞUM KONTROL"), ("YASMIN", "DOĞUM KONTROL"),
    ("YAZ", "DOĞUM KONTROL"), ("MICROGYNON", "DOĞUM KONTROL"),
    ("CERAZETTE", "DOĞUM KONTROL"), ("BELARA", "DOĞUM KONTROL"),
    ("ETINIL", "DOĞUM KONTROL"),
    ("PROGESTERON", "HORMON"), ("CRINONE", "HORMON"),
    ("DUFASTON", "HORMON"), ("LUTORAL", "HORMON"),
    ("PROGYNOVA", "HORMON"), ("ESTROFEM", "HORMON"),

    # ============ PROSTAT ============
    ("FINASTERID", "PROSTAT İLACI"), ("PROSCAR", "PROSTAT İLACI"),
    ("DUTASTERID", "PROSTAT İLACI"), ("AVODART", "PROSTAT İLACI"),
    ("TAMSULOSIN", "PROSTAT İLACI"), ("FLOMAX", "PROSTAT İLACI"),
    ("URIMAX", "PROSTAT İLACI"), ("VESITRIM", "PROSTAT İLACI"),

    # ============ KEMİK / OSTEOPOROZ ============
    ("ALENDRON", "OSTEOPOROZ İLACI"), ("FOSAMAX", "OSTEOPOROZ İLACI"),
    ("FOSAVANCE", "OSTEOPOROZ İLACI"),
    ("RISEDRON", "OSTEOPOROZ İLACI"), ("ACTONEL", "OSTEOPOROZ İLACI"),
    ("DENOSUMAB", "OSTEOPOROZ İLACI"), ("PROLIA", "OSTEOPOROZ İLACI"),
    ("STRONTYUM", "OSTEOPOROZ İLACI"),

    # ============ KABIZLIK / İSHAL ============
    ("LAKTULOZ", "KABIZLIK İLACI"), ("DUPHALAC", "KABIZLIK İLACI"),
    ("LAKTITOL", "KABIZLIK İLACI"), ("LAEVOLAC", "KABIZLIK İLACI"),
    ("PEG", "KABIZLIK İLACI"), ("MOVICOL", "KABIZLIK İLACI"),
    ("BISAKODIL", "KABIZLIK İLACI"), ("DULCOLAX", "KABIZLIK İLACI"),
    ("SENNA", "KABIZLIK İLACI"), ("SENADE", "KABIZLIK İLACI"),
    ("LOPERAMID", "İSHAL KESİCİ"), ("DIAREST", "İSHAL KESİCİ"),
    ("LOPERIN", "İSHAL KESİCİ"), ("DIAFOR", "İSHAL KESİCİ"),
    ("SACCHAROMYCES", "PROBİYOTİK"), ("PROBIO", "PROBİYOTİK"),
    ("ENTEROGERMINA", "PROBİYOTİK"),

    # ============ GARGARALAR / AĞIZ ============
    ("KLOROBEN", "AĞIZ-DİŞ İLACI"), ("ANDOREX", "AĞIZ-DİŞ İLACI"),
    ("OROHEKS", "AĞIZ-DİŞ İLACI"), ("MAXIMUS", "BOĞAZ SPREYİ"),
    ("BENZIDAMIN", "AĞIZ-DİŞ İLACI"), ("TANTUM", "AĞIZ-DİŞ İLACI"),
    ("KLORHEKSIDIN", "AĞIZ-DİŞ İLACI"), ("HEXORAL", "AĞIZ-DİŞ İLACI"),
    ("STREPSILS", "BOĞAZ İLACI"), ("BENPAIN", "BOĞAZ SPREYİ"),

    # ============ CİLT (DIŞ KULLANIM) ============
    ("FITO", "CİLT İLACI (DIŞ KULLANIM)"),
    ("BEPANTHEN", "CİLT İLACI (DIŞ KULLANIM)"),
    ("MADECASSOL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("FUSIDIK", "CİLT İLACI (ANTİBİYOTİK)"),
    ("FUCIDIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("MUPIROSIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("BACTROBAN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("EFICAN", "CİLT İLACI"),
    ("BETNOVATE", "CİLT İLACI (KORTİZON)"),
    ("ELOCON", "CİLT İLACI (KORTİZON)"),
    ("ADVANTAN", "CİLT İLACI (KORTİZON)"),
    ("HYDROCORTISON", "CİLT İLACI (KORTİZON)"),
    ("PROTOPIC", "CİLT İLACI (EGZEMA)"),
    ("ELIDEL", "CİLT İLACI (EGZEMA)"),
    ("DAIVOBET", "SEDEF HASTALIĞI İLACI"),
    ("DAIVONEX", "SEDEF HASTALIĞI İLACI"),

    # ============ NÖROLOJİ (PARKİNSON / ALZHEİMER) ============
    ("LEVODOPA", "PARKİNSON İLACI"), ("MADOPAR", "PARKİNSON İLACI"),
    ("SINEMET", "PARKİNSON İLACI"),
    ("PRAMIPEKSOL", "PARKİNSON İLACI"), ("OPRYMEA", "PARKİNSON İLACI"),
    ("RIVASTIGMIN", "ALZHEİMER İLACI"), ("EXELON", "ALZHEİMER İLACI"),
    ("DONEPEZIL", "ALZHEİMER İLACI"), ("ARICEPT", "ALZHEİMER İLACI"),
    ("MEMANTIN", "ALZHEİMER İLACI"), ("EBIXA", "ALZHEİMER İLACI"),

    # ============ KASIK / KAS GEVŞETİCİ ============
    ("MYOLASTAN", "KAS GEVŞETİCİ"), ("TOLPERIZON", "KAS GEVŞETİCİ"),
    ("MYDOCALM", "KAS GEVŞETİCİ"), ("MUSCORIL", "KAS GEVŞETİCİ"),
    ("BENADON", "KAS GEVŞETİCİ"),
    ("TIYOKOLŞIKOSID", "KAS GEVŞETİCİ"),

    # ============ SİNİR AĞRISI ============
    ("TIAPRID", "SİNİR AĞRISI / VERTİGO"),
    ("BETAHIST", "VERTİGO İLACI"), ("VASOSERC", "VERTİGO İLACI"),
    ("MIKRONOR", "VERTİGO İLACI"),

    # ============ ZAYIFLAMA / İŞTAH KESİCİ ============
    ("ORLISTAT", "ZAYIFLAMA İLACI"), ("XENICAL", "ZAYIFLAMA İLACI"),
    ("MOUNJARO", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("TIRZEPATID", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),

    # ============ BATCH 1 — ANTİBİYOTİK (yaygın marka adları) ============
    ("SULCID", "ANTİBİYOTİK"), ("ALFASID", "ANTİBİYOTİK"),
    ("MACROL", "ANTİBİYOTİK"), ("KLAMER", "ANTİBİYOTİK"),
    ("CLASEM", "ANTİBİYOTİK"), ("ENFEXIA", "ANTİBİYOTİK"),
    ("CEFTINEX", "ANTİBİYOTİK"), ("AZELTIN", "ANTİBİYOTİK"),
    ("ZIMAKS", "ANTİBİYOTİK"), ("BITERAL", "ANTİBİYOTİK"),
    ("FIXEF", "ANTİBİYOTİK"), ("CEFDIFIX", "ANTİBİYOTİK"),
    ("ULTROX", "ANTİBİYOTİK"), ("CEMPES", "ANTİBİYOTİK"),
    ("IESPOR", "ANTİBİYOTİK"), ("NOVOSEF", "ANTİBİYOTİK"),
    ("UNACEFIN", "ANTİBİYOTİK"), ("MAKSIPOR", "ANTİBİYOTİK"),
    ("DEPOSILIN", "ANTİBİYOTİK"), ("ORNISID", "ANTİBİYOTİK"),
    ("BACTRIM", "ANTİBİYOTİK"), ("CLEOCIN", "ANTİBİYOTİK"),
    ("ANDAZOL", "BAĞIRSAK PARAZİTİ"),  # albendazol antiparaziter
    ("GENTA", "ANTİBİYOTİK"),    # gentamisin
    ("INFEX", "ANTİBİYOTİK"),    # siprofloksasin
    ("ZIVER", "ANTİVİRAL"),      # asiklovir
    ("AKLOVIR", "ANTİVİRAL"), ("ASIVIRAL", "ANTİVİRAL"),
    ("FLUCAN", "MANTAR İLACI"),
    ("DIAFURYL", "İSHAL KESİCİ"),
    ("MAFLOR", "PROBİYOTİK"),
    ("FUCITEC", "CİLT İLACI (ANTİBİYOTİK)"),

    # ============ BATCH 1 — TANSİYON ============
    ("HIPERSAR", "TANSİYON İLACI"), ("EXCALIBA", "TANSİYON İLACI"),
    ("IRDAPIN", "TANSİYON İLACI"), ("VASOXEN", "TANSİYON İLACI"),
    ("CARDURA", "TANSİYON İLACI"), ("CANDEXIL", "TANSİYON İLACI"),
    ("BETABLOK", "TANSİYON İLACI"), ("MONOPRIL", "TANSİYON İLACI"),
    ("DILTIZEM", "TANSİYON İLACI"), ("TRIPLIXAM", "TANSİYON İLACI"),
    ("TELMODIP", "TANSİYON İLACI"), ("CO-IRDA", "TANSİYON İLACI"),
    ("HYZAAR", "TANSİYON İLACI"), ("CANDECARD", "TANSİYON İLACI"),
    ("ENAPRIL", "TANSİYON İLACI"), ("SINOPRYL", "TANSİYON İLACI"),
    ("GOPTEN", "TANSİYON İLACI"), ("MONOVAS", "TANSİYON İLACI"),
    ("VASTAREL", "TANSİYON İLACI"),  # trimetazidin (angina)
    ("MONOKET", "TANSİYON İLACI"),   # isosorbid (angina)
    ("TANSIFA", "TANSİYON İLACI"),
    ("SANELOC", "TANSİYON İLACI"),   # metoprolol

    # ============ BATCH 1 — ANTİDEPRESAN / ANTİPSİKOTİK / ANKSİYOLİTİK ============
    ("CEDRINA", "ANTİPSİKOTİK"), ("QUET", "ANTİPSİKOTİK"),
    ("KETYA", "ANTİPSİKOTİK"), ("REXAPIN", "ANTİPSİKOTİK"),
    ("RIXPER", "ANTİPSİKOTİK"),
    ("CITOLES", "ANTİDEPRESAN"), ("PAXERA", "ANTİDEPRESAN"),
    ("SECITA", "ANTİDEPRESAN"), ("SELECTRA", "ANTİDEPRESAN"),
    ("REDEPRA", "ANTİDEPRESAN"), ("ZEDPRA", "ANTİDEPRESAN"),
    ("ADELEKS", "ANTİDEPRESAN"),  # essitalopram
    ("CITOL", "ANTİDEPRESAN"),    # sitalopram
    ("ZOLAX", "ANKSİYOLİTİK"),    # alprazolam

    # ============ BATCH 1 — AĞRI KESİCİ / KAS GEVŞETİCİ ============
    ("DICLOMEC", "AĞRI KESİCİ"), ("LEODEX", "AĞRI KESİCİ"),
    ("NIMES", "AĞRI KESİCİ"), ("KETAVEL", "AĞRI KESİCİ"),
    ("EDOLAR", "AĞRI KESİCİ"), ("DEXPASS", "AĞRI KESİCİ"),
    ("DOLINE", "AĞRI KESİCİ"),
    ("DUROGESIC", "AĞRI KESİCİ (KUVVETLİ)"),
    ("FENTANIL", "AĞRI KESİCİ (KUVVETLİ)"),
    ("MUSCOFLEX", "KAS GEVŞETİCİ"), ("TYOFLEX", "KAS GEVŞETİCİ"),
    ("TIYOKAS", "KAS GEVŞETİCİ"), ("FLEXO", "KAS GEVŞETİCİ"),

    # ============ BATCH 1 — DİYABET / MİDE / VİTAMİN ============
    ("GLIFIX", "DİYABET"),    # pioglitazon
    ("MATOFIN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("GLIMAX", "DİYABET"),
    ("GLUCOBAY", "DİYABET"),
    ("JANUMET", "DİYABET"),   # sitagliptin+metformin
    ("GALVIKS", "DİYABET"),   # vildagliptin+metformin
    ("ESMAX", "MİDE İLACI"),  # esomeprazol
    ("PULCET", "MİDE İLACI"), # pantoprazol
    ("BEMIKS", "B VİTAMİNİ DESTEĞİ"),
    ("DESIFEROL", "D VİTAMİNİ"),
    ("APIKOBAL", "B12 VİTAMİNİ DESTEĞİ"),
    ("MUCOVIT-C", "VİTAMİN DESTEĞİ"),

    # ============ BATCH 1 — ALERJİ / ASTIM / BURUN ============
    ("ALLERSET", "ALLERJİ / KAŞINTI İLACI"),
    ("ZADITEN", "ALLERJİ / KAŞINTI İLACI"),
    ("LEVMONT", "ASTIM İLACI"),  # levosetirizin+montelukast
    ("ZESPIRA", "ASTIM İLACI"),  # montelukast
    ("M-FURO", "CİLT İLACI (KORTİZON)"),
    ("MOMECON", "CİLT İLACI (KORTİZON)"),
    ("INFLACORT", "KORTİZON TEDAVİSİ"),
    ("BEKLAZON", "ASTIM İLACI"),

    # ============ BATCH 1 — ANTİEPİLEPTİK / SİNİR ============
    ("GABASET", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("EPIXX", "ANTİEPİLEPTİK"),   # levetirasetam
    ("TRILEPTAL", "ANTİEPİLEPTİK"),
    ("OKSKARBAZEPIN", "ANTİEPİLEPTİK"),

    # ============ BATCH 1 — KAN SULANDIRICI / ANEMİ ============
    ("HIBOR", "KAN SULANDIRICI (İĞNE)"),
    ("ARANESP", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("BINOCRIT", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("EPREX", "ANEMİ TEDAVİSİ (İĞNE)"),

    # ============ BATCH 1 — VERTİGO / KARIN AĞRISI / İSHAL ============
    ("BETASERC", "VERTİGO İLACI"),
    ("DEBRIDAT", "KARIN AĞRISI / KASILMA İLACI"),
    ("TRIBUDAT", "KARIN AĞRISI / KASILMA İLACI"),
    ("DICETEL", "KARIN AĞRISI / KASILMA İLACI"),

    # ============ BATCH 1 — HORMON / KADIN HASTALIKLARI ============
    ("PROGESTAN", "HORMON"),
    ("CRINONE", "HORMON"),  # zaten var ama
    ("MICTONORM", "AŞIRI AKTİF MESANE İLACI"),

    # ============ BATCH 1 — DEHB / EREKSİYON / ÜROLOJİ ============
    ("ATOMINEX", "DEHB İLACI"), ("ATTEX", "DEHB İLACI"),
    ("MEDIKINET", "DEHB İLACI"), ("CONCERTA", "DEHB İLACI"),
    ("METILFENIDAT", "DEHB İLACI"), ("ATOMOKSETIN", "DEHB İLACI"),
    ("CIALIS", "EREKSİYON İLACI"), ("SILDEGRA", "EREKSİYON İLACI"),
    ("TADALAFIL", "EREKSİYON İLACI"), ("SILDENAFIL", "EREKSİYON İLACI"),
    ("LIFTA", "EREKSİYON İLACI"),
    ("PRILIGY", "ERKEN BOŞALMA İLACI"),
    ("DAPOKSETIN", "ERKEN BOŞALMA İLACI"),

    # ============ BATCH 1 — CİLT / MANTAR ============
    ("ZALAIN", "MANTAR İLACI"), ("DERMIFIN", "MANTAR İLACI"),
    ("FUNIT", "MANTAR İLACI"), ("FLUZOLE", "MANTAR İLACI"),
    ("ITRAKONAZOL", "MANTAR İLACI"), ("TERBINAFIN", "MANTAR İLACI"),
    ("SERTAKONAZOL", "MANTAR İLACI"),
    ("DERMOVATE", "CİLT İLACI (KORTİZON)"),
    ("LOCODERM", "CİLT İLACI (KORTİZON)"),

    # ============ BATCH 1 — ÖKSÜRÜK / MUKOLİTİK ============
    ("ASIST", "ÖKSÜRÜK KESİCİ"),
    ("NAC", "ÖKSÜRÜK KESİCİ"),
    ("ASETILSISTEIN", "ÖKSÜRÜK KESİCİ"),
    ("MUKOTIK", "ÖKSÜRÜK KESİCİ"),
    ("NOTUSS", "ÖKSÜRÜK KESİCİ"),
    ("LEVOPRONT", "ÖKSÜRÜK KESİCİ"),
    ("COLDAWAY", "GRİP / SOĞUK ALGINLIĞINDA"),

    # ============ BATCH 1 — ROMATİZMA / İMMÜNOSUPRESİF ============
    ("METOART", "ROMATİZMA / İLTİHAP İLACI"),
    ("METOTREKSAT", "ROMATİZMA / İLTİHAP İLACI"),
    ("SANDIMMUN", "İMMÜNOSUPRESİF İLAÇ"),
    ("PROGRAF", "İMMÜNOSUPRESİF İLAÇ"),
    ("SIKLOSPORIN", "İMMÜNOSUPRESİF İLAÇ"),
    ("TAKROLIMUS", "İMMÜNOSUPRESİF İLAÇ"),
    ("ASACOL", "BAĞIRSAK İLTİHABI İLACI"),
    ("MESALAZIN", "BAĞIRSAK İLTİHABI İLACI"),

    # ============ BATCH 1 — KOLESTEROL / NÖROLOJİ ============
    ("ALVASTIN", "KOLESTEROL İLACI"),
    ("LIPANTHYL", "KOLESTEROL İLACI"),
    ("NOOTROPIL", "NÖROLOJİ İLACI"),   # piracetam
    ("PIRACETAM", "NÖROLOJİ İLACI"),

    # ============ BATCH 1 — KANSER İLACI ============
    ("TEMODAL", "KANSER İLACI"),
    ("TAMOXIFEN", "KANSER İLACI"),
    ("LUCRIN", "KANSER İLACI"),  # leuprolid

    # ============ BATCH 1 — KISIRLIK ============
    ("GONAL-F", "KISIRLIK TEDAVİSİ"),
    ("FOLITROPIN", "KISIRLIK TEDAVİSİ"),
    ("MENOPUR", "KISIRLIK TEDAVİSİ"),
    ("PUREGON", "KISIRLIK TEDAVİSİ"),

    # ============ BATCH 1 — BAĞIŞIKLIK / DİYALİZ ============
    ("CUVITRU", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("IMMUNOGLOBULIN", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("PHYSIONEAL", "PERİTON DİYALİZ SOLÜSYONU"),
    ("CAPD", "PERİTON DİYALİZ SOLÜSYONU"),

    # ============ BATCH 1 — CİLT BAKIM / DİĞER ============
    ("UREDERM", "CİLT İLACI (DIŞ KULLANIM)"),
    ("KENACORT-A", "CİLT İLACI (KORTİZON)"),

    # ============ BATCH 2 — Yeni marka eşlemeleri ============
    # ANTİBİYOTİK / ANTİVİRAL
    ("AZRO", "ANTİBİYOTİK"), ("MOLCEF", "ANTİBİYOTİK"),
    ("KLACID", "ANTİBİYOTİK"), ("LINKOMISIN", "ANTİBİYOTİK"),
    ("UROMISIN", "ANTİBİYOTİK (İDRAR YOLU)"),
    ("MONUROL", "ANTİBİYOTİK (İDRAR YOLU)"),
    ("FOSFOMISIN", "ANTİBİYOTİK (İDRAR YOLU)"),
    ("DIVERTIN", "ANTİBİYOTİK"), ("DEPOFEN", "ANTİBİYOTİK"),
    # TANSİYON
    ("BETANORM", "TANSİYON İLACI"),  # bisoprolol
    ("INHIBACE", "TANSİYON İLACI"),  # silazapril
    ("KARVEZIDE", "TANSİYON İLACI"),  # irbesartan+HCT
    ("ENZEVIN", "TANSİYON İLACI"),    # enalapril
    ("CARDOPAN", "TANSİYON İLACI"),
    ("ECTOPIX", "TANSİYON İLACI"),
    ("TRIATEC", "TANSİYON İLACI"),    # ramipril
    ("KARDORITM", "KALP RİTM İLACI"),
    ("CORDARONE", "KALP RİTM İLACI"),
    ("AMIODARON", "KALP RİTM İLACI"),
    ("RYTMONORM", "KALP RİTM İLACI"),
    ("ALDACTAZIDE", "TANSİYON İLACI"),
    # EREKSİYON
    ("VIAGRA", "EREKSİYON İLACI"),
    ("DEGRA", "EREKSİYON İLACI"),
    # PROSTAT / MESANE
    ("DETRUSITOL", "AŞIRI AKTİF MESANE İLACI"),
    ("MICTONORM", "AŞIRI AKTİF MESANE İLACI"),
    ("TOLTERODIN", "AŞIRI AKTİF MESANE İLACI"),
    ("OXYBUTININ", "AŞIRI AKTİF MESANE İLACI"),
    ("BETMIGA", "AŞIRI AKTİF MESANE İLACI"),
    ("VESICARE", "AŞIRI AKTİF MESANE İLACI"),
    # PARKİNSON
    ("PEXOLA", "PARKİNSON İLACI"),
    ("OPRYMEA", "PARKİNSON İLACI"),
    ("PRAMIPEKSOL", "PARKİNSON İLACI"),
    # ANTİPSİKOTİK
    ("OZAPRIN", "ANTİPSİKOTİK"),
    ("QUELEPT", "ANTİPSİKOTİK"),
    # ANTİEPİLEPTİK
    ("TOPAMAX", "ANTİEPİLEPTİK"),
    ("TOPIRAMAT", "ANTİEPİLEPTİK"),
    ("KARAZEPIN", "ANTİEPİLEPTİK"),
    # MİDE
    ("APRAZOL", "MİDE İLACI"),       # omeprazol jeneriği
    ("DEMEPRAZOL", "MİDE İLACI"),    # omeprazol jeneriği
    ("LANSAZOL", "MİDE İLACI"),
    ("GASTREN", "MİDE İLACI"),
    ("LATIXA", "MİDE İLACI"),
    ("ZOPROTEC", "MİDE İLACI"),
    ("ALIPZA", "MİDE İLACI"),
    ("REFCON", "MİDE İLACI (REFLÜ)"),  # alginat
    # KAN SULANDIRICI / KANAMA
    ("NEVPARIN", "KAN SULANDIRICI (İĞNE)"),
    ("HEPARIN", "KAN SULANDIRICI (İĞNE)"),
    ("FRAXODI", "KAN SULANDIRICI (İĞNE)"),
    ("TRANSAMINE", "KANAMA DURDURUCU"),
    ("TRANEKSAMIK", "KANAMA DURDURUCU"),
    # KONTRAST MADDESİ
    ("OMNIPAQUE", "RADYOLOJİK KONTRAST MADDESİ"),
    ("GADOVIST", "RADYOLOJİK KONTRAST MADDESİ"),
    ("DOTAREM", "RADYOLOJİK KONTRAST MADDESİ"),
    ("MAGNEVIST", "RADYOLOJİK KONTRAST MADDESİ"),
    # ANEMİ / DEMİR
    ("EPOBEL", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("EPOIETIN", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("FERIFER", "DEMİR DESTEĞİ"),
    # ÖKSÜRÜK
    ("MUCONEX", "ÖKSÜRÜK KESİCİ"),
    # CİLT / MANTAR / SEDEF / SİVİLCE
    ("PSORCUTAN", "SEDEF HASTALIĞI İLACI"),
    ("KALSIPOTRIOL", "SEDEF HASTALIĞI İLACI"),
    ("PSOVATE", "CİLT İLACI (KORTİZON)"),
    ("ACNELYSE", "SİVİLCE İLACI"),
    ("ROACCUTANE", "SİVİLCE İLACI"),
    ("ISOTRETINOIN", "SİVİLCE İLACI"),
    ("TRETINOIN", "SİVİLCE İLACI"),
    ("DIFFERIN", "SİVİLCE İLACI"),
    ("ADAPALEN", "SİVİLCE İLACI"),
    ("BUTEFIN", "MANTAR İLACI"),
    ("MIKOSTATIN", "MANTAR İLACI"),  # nistatin
    ("FUNGOSTATIN", "MANTAR İLACI"),
    ("NISTATIN", "MANTAR İLACI"),
    ("DERMATOP", "CİLT İLACI (KORTİZON)"),
    ("PSOBETAZOL", "CİLT İLACI (KORTİZON)"),
    # AĞRI / NSAID JEL
    ("DIFENAK", "AĞRI KESİCİ"),       # diklofenak jenerik
    ("PROFEN", "AĞRI KESİCİ"),
    # NEFES / ASTIM
    ("VENTOFOR", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("FIXHALER", "ASTIM İLACI"),
    ("FORADIL", "NEFES AÇICI (BRONKODİLATÖR)"),
    # BİTKİSEL / DİĞER
    ("TEBOKAN", "DOLAŞIM / HAFIZA DESTEĞİ"),
    ("GINGKO", "DOLAŞIM / HAFIZA DESTEĞİ"),
    ("NICOTINELL", "SİGARA BIRAKMA"),
    ("NICORETTE", "SİGARA BIRAKMA"),
    ("CHAMPIX", "SİGARA BIRAKMA"),
    ("VARENIKLIN", "SİGARA BIRAKMA"),
    # MS / İNTERFERON
    ("VEGAFERON", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("INTERFERON", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("REBIF", "MS İLACI"),
    ("AVONEX", "MS İLACI"),
    ("TYSABRI", "MS İLACI"),
    # HORMON / HİPOFİZ
    ("MINIRIN", "HORMON"),         # desmopressin
    ("DESMOPRESSIN", "HORMON"),
    # KEMOTERAPİ
    ("METOTREKSAT", "ROMATİZMA / İLTİHAP İLACI"),
    ("LEFLUNOMID", "ROMATİZMA / İLTİHAP İLACI"),
    ("ARAVA", "ROMATİZMA / İLTİHAP İLACI"),
    # BENZODİAZEPİN sürümleri
    ("KSANAKS", "ANKSİYOLİTİK"),
    ("APO-ZOLAM", "ANKSİYOLİTİK"),
    # OPİOİD / KUVVETLİ AĞRI
    ("MORFIN", "AĞRI KESİCİ (KUVVETLİ)"),
    ("TIRSED", "AĞRI KESİCİ (KUVVETLİ)"),
    ("OXYCONTIN", "AĞRI KESİCİ (KUVVETLİ)"),
    # BAŞ AĞRISI / MİGREN
    ("ZOMIG", "MİGREN İLACI"),
    ("IMIGRAN", "MİGREN İLACI"),
    ("SUMATRIPTAN", "MİGREN İLACI"),
    ("ZOLMITRIPTAN", "MİGREN İLACI"),
    ("ELETRIPTAN", "MİGREN İLACI"),
    ("FROVATRIPTAN", "MİGREN İLACI"),
    ("RIZATRIPTAN", "MİGREN İLACI"),
    ("MAXALT", "MİGREN İLACI"),
    ("INEGY", "KOLESTEROL İLACI"),
    # MULTİPL SKLEROZ / IMMÜN
    ("HUMIRA", "BİYOLOJİK İLAÇ"),
    ("ENBREL", "BİYOLOJİK İLAÇ"),
    ("REMICADE", "BİYOLOJİK İLAÇ"),
    ("MABTHERA", "BİYOLOJİK İLAÇ"),
    ("RITUXIMAB", "BİYOLOJİK İLAÇ"),
    ("ETANERSEPT", "BİYOLOJİK İLAÇ"),
    ("ADALIMUMAB", "BİYOLOJİK İLAÇ"),

    # ============ BATCH 3 — Daha fazla marka ============
    # DİYABET / İNSÜLİN
    ("NOVOMIX", "DİYABET"), ("RYZODEG", "DİYABET"),
    ("DROPIA-MET", "DİYABET"), ("DROPIA", "DİYABET"),
    ("SYNJARDY", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),  # empagliflozin+metformin
    ("XIGDUO", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),     # dapagliflozin+metformin
    ("XULTOPHY", "DİYABET"),  # insülin+liraglutid
    ("GLUCERNA", "BESLENME ÜRÜNÜ"),
    ("ENSURE", "BESLENME ÜRÜNÜ"), ("FRESUBIN", "BESLENME ÜRÜNÜ"),
    ("NUTREN", "BESLENME ÜRÜNÜ"), ("DIASIP", "BESLENME ÜRÜNÜ"),
    ("RESOURCE", "BESLENME ÜRÜNÜ"),
    # TANSİYON / KALP
    ("TARKA", "TANSİYON İLACI"),
    ("CIBADREX", "TANSİYON İLACI"),
    ("BENIPIN", "TANSİYON İLACI"),
    ("ZANIPRESS", "TANSİYON İLACI"),
    ("NEXIVOL", "TANSİYON İLACI"),
    ("KINZY", "TANSİYON İLACI"),
    ("MEXIA", "TANSİYON İLACI"),
    ("DOXAFIN", "TANSİYON İLACI / PROSTAT İLACI"),  # doksazosin
    ("DOXAZOSIN", "TANSİYON İLACI / PROSTAT İLACI"),
    ("UROREC", "PROSTAT İLACI"),  # silodozin
    ("SILODOZIN", "PROSTAT İLACI"),
    ("ALFUZOSIN", "PROSTAT İLACI"),
    ("RYZNADRA", "TANSİYON İLACI"),
    ("CARDORITM", "KALP RİTM İLACI"),
    # AĞRI / NSAID / KAS
    ("TADOLAK", "AĞRI KESİCİ"),   # etodolak
    ("RANTUDIL", "AĞRI KESİCİ"),  # akemetasin
    ("TANFLEX", "KAS GEVŞETİCİ"),  # tizanidin
    ("SIRDALUD", "KAS GEVŞETİCİ"),
    ("TIZANIDIN", "KAS GEVŞETİCİ"),
    ("TILCOTIL", "AĞRI KESİCİ"),  # tenoksikam
    ("TENOXIKAM", "AĞRI KESİCİ"),
    ("DIKLOJIK", "AĞRI KESİCİ"),
    ("SURGAM", "AĞRI KESİCİ"),    # tiaprofenik
    ("RHEUMON", "AĞRI KESİCİ"),   # etofenamat
    ("ETOFENAMAT", "AĞRI KESİCİ"),
    ("FELDEN", "AĞRI KESİCİ"),    # piroksikam
    # MİDE
    ("FAMODIN", "MİDE İLACI"),    # famotidin
    ("FAMOSER", "MİDE İLACI"),
    ("LANZEDIN", "MİDE İLACI"),   # lansoprazol
    ("ANTEPSIN", "MİDE İLACI"),   # sukralfat
    ("GASVIN", "MİDE İLACI (REFLÜ)"),
    ("PRABEX", "MİDE İLACI"),     # rabeprazol
    ("PANREF", "MİDE İLACI"),     # pantoprazol
    # ANTİDEPRESAN / ANTİPSİKOTİK
    ("DESYREL", "ANTİDEPRESAN"),  # trazodon
    ("TRAZODON", "ANTİDEPRESAN"),
    ("DUXET", "ANTİDEPRESAN"),    # duloksetin
    ("DULOXX", "ANTİDEPRESAN"),
    ("PAXIL", "ANTİDEPRESAN"),    # paroksetin
    ("ARIPA", "ANTİPSİKOTİK"),    # aripiprazol
    ("OLY", "ANTİPSİKOTİK"),      # olanzapin jenerik
    ("SOLIAN", "ANTİPSİKOTİK"),
    ("AMISULPIRID", "ANTİPSİKOTİK"),
    # ANTİBİYOTİK
    ("TERRAMYCIN", "ANTİBİYOTİK"),
    ("CIPRASID", "ANTİBİYOTİK"),
    ("ULTRACEF", "ANTİBİYOTİK"),
    ("ONCEFT", "ANTİBİYOTİK"),
    ("ATOKSILIN", "ANTİBİYOTİK"),
    ("ALFASILIN", "ANTİBİYOTİK"),
    ("SULBAKSIT", "ANTİBİYOTİK"),
    ("RIFOCIN", "ANTİBİYOTİK"),   # rifampisin
    ("RIFAMPISIN", "ANTİBİYOTİK"),
    ("MULTISEF", "ANTİBİYOTİK"),
    ("EQICEFT", "ANTİBİYOTİK"),
    ("ROVAGYL", "ANTİBİYOTİK"),   # rovamisin+metronidazol
    ("BIOMENT", "ANTİBİYOTİK"),   # amoks+klavu
    ("KLAVON", "ANTİBİYOTİK"),
    ("FACTIVE", "ANTİBİYOTİK"),   # gemifloksasin
    ("OPEMIN", "ANTİBİYOTİK"),
    ("CORSAL", "ANTİBİYOTİK"),    # sefuroksim aksetil
    # İSHAL / BAĞIRSAK
    ("ERCEFURYL", "İSHAL KESİCİ"),
    ("NIFUROKSAZID", "İSHAL KESİCİ"),
    # ANTİVİRAL
    ("ENFLUVIR", "ANTİVİRAL"),    # oseltamivir
    ("OSELTAMIVIR", "ANTİVİRAL"),
    # GUATR
    ("THYROMAZOL", "GUATR İLACI"),
    ("METIMAZOL", "GUATR İLACI"),
    # HORMON
    ("DOSTINEX", "HORMON"),       # kabergolin (prolaktin)
    ("KABERGOLIN", "HORMON"),
    ("CABASER", "HORMON"),
    ("ZOLADEX", "KANSER İLACI"),  # goserelin
    ("GOSERELIN", "KANSER İLACI"),
    ("GENOTROPIN", "BÜYÜME HORMONU"),
    ("OMNITROPE", "BÜYÜME HORMONU"),
    ("HUMATROPE", "BÜYÜME HORMONU"),
    ("NORDITROPIN", "BÜYÜME HORMONU"),
    # ASTIM / NEFES
    ("BRICANYL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("IPRAVENT", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("TRELEGY", "ASTIM İLACI"),
    ("RINOCLENIL", "BURUN İLACI (KORTİZON)"),
    ("AIRPLUS", "ASTIM İLACI"),
    ("BUDECORT", "ASTIM İLACI (KORTİZON)"),
    ("BEKLOMIL", "ASTIM İLACI (KORTİZON)"),
    ("LEVOSOL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("LEVOBRONS", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("LEVOMONT", "ASTIM İLACI"),
    ("AIRFIX", "ASTIM İLACI"),
    ("AIRCOMB", "ASTIM İLACI"),
    ("SIN-MONT", "ASTIM İLACI"),
    ("VENTOSAL", "NEFES AÇICI (BRONKODİLATÖR)"),
    # GRİP / ÖKSÜRÜK
    ("SUDAFED", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("VICKS", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("SINECOD", "ÖKSÜRÜK KESİCİ"),
    ("BUTAMIRAT", "ÖKSÜRÜK KESİCİ"),
    ("COLDFEN", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("GRIPIN", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("PARANOX", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("APIREKS", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("MUCOMAX", "ÖKSÜRÜK KESİCİ"),
    ("MUKOZERO", "ÖKSÜRÜK KESİCİ"),
    ("GRIBEX", "GRİP / SOĞUK ALGINLIĞINDA"),
    # ALERJİ
    ("CETRYN", "ALLERJİ / KAŞINTI İLACI"),
    ("KESTINE", "ALLERJİ / KAŞINTI İLACI"),
    ("HITRIZIN", "ALLERJİ / KAŞINTI İLACI"),
    ("ALLERGODIL", "ALLERJİ / KAŞINTI İLACI"),
    # MİGREN
    ("RELPAX", "MİGREN İLACI"),
    ("MIGREX", "MİGREN İLACI"),
    ("MIGREOUT", "MİGREN İLACI"),
    ("ZOMIG", "MİGREN İLACI"),
    # CİLT / SİVİLCE / DERMATO
    ("BELOGENT", "CİLT İLACI (KORTİZON)"),
    ("AKNETRENT", "SİVİLCE İLACI"),
    ("ZORETANIN", "SİVİLCE İLACI"),
    ("SILVERDIN", "CİLT İLACI (YANIK)"),
    ("HAMETAN", "CİLT İLACI (DIŞ KULLANIM)"),
    ("EXCIPIAL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("EXPIGMENT", "CİLT İLACI (LEKE)"),
    ("MINOXIL", "SAÇ DÖKÜLMESİ İLACI"),
    ("MINOXIDIL", "SAÇ DÖKÜLMESİ İLACI"),
    ("ROGAINE", "SAÇ DÖKÜLMESİ İLACI"),
    ("CLOVATE", "CİLT İLACI (KORTİZON)"),
    ("KLOBATE", "CİLT İLACI (KORTİZON)"),
    ("HIPOKORT", "CİLT İLACI (KORTİZON)"),
    ("KORTOS", "HEMOROİD İLACI"),  # C05AA01 hidrokortizon rektal krem/fitil
    ("GENKORT", "CİLT İLACI (KORTİZON)"),
    ("LOCOID", "CİLT İLACI (KORTİZON)"),
    ("PROCTO-GLYVENOL", "HEMOROİD İLACI"),
    ("PROCTOLOG", "HEMOROİD İLACI"),
    ("ANUSOL", "HEMOROİD İLACI"),
    ("DAFLON", "TOPLARDAMAR / VARİS İLACI"),
    ("VENORUTON", "TOPLARDAMAR / VARİS İLACI"),
    ("VENOTREX", "TOPLARDAMAR / VARİS İLACI"),
    # GÖZ
    ("MAXIDEX", "GÖZ İLACI"),
    ("TOBRASED", "GÖZ İLACI"),
    ("ACULAR", "GÖZ İLACI"),
    ("NETIRA", "GÖZ İLACI"),
    ("NETILDEX", "GÖZ İLACI"),
    ("EYESTIL", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("DEXTROCIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("DESMONT", "GÖZ İLACI"),
    ("KEYDROPS", "GÖZ İLACI"),
    ("PINADES", "GÖZ İLACI"),
    ("ATEROZ", "KOLESTEROL İLACI"),  # atorvastatin
    # İMMÜNOSUPRESİF
    ("IMURAN", "İMMÜNOSUPRESİF İLAÇ"),
    ("AZATIOPRIN", "İMMÜNOSUPRESİF İLAÇ"),
    ("MOFECEPT", "İMMÜNOSUPRESİF İLAÇ"),
    ("ADOPORT", "İMMÜNOSUPRESİF İLAÇ"),
    ("CELLCEPT", "İMMÜNOSUPRESİF İLAÇ"),
    ("MIKOFENOLAT", "İMMÜNOSUPRESİF İLAÇ"),
    ("KIOVIG", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    # KAN PIHTILAŞMASI / SULANDIRICI
    ("LIXIANA", "KAN SULANDIRICI"),
    ("EDOKSABAN", "KAN SULANDIRICI"),
    # ÜRİK ASİT
    ("PURINOL", "ÜRİK ASİT İLACI"),
    ("ULORIC", "ÜRİK ASİT İLACI"),
    # KARACİĞER
    ("URSOVEF", "KARACİĞER İLACI"),
    ("URSACTIVE", "KARACİĞER İLACI"),
    ("URSODEOKSIKOLIK", "KARACİĞER İLACI"),
    # BAĞIRSAK İLTİHABI
    ("PENTASA", "BAĞIRSAK İLTİHABI İLACI"),
    # NÖRO / PARKİNSON
    ("AKINETON", "PARKİNSON İLACI"),
    ("BIPERIDEN", "PARKİNSON İLACI"),
    ("MYSOLINE", "ANTİEPİLEPTİK"),  # primidon
    ("PRIMIDON", "ANTİEPİLEPTİK"),
    # SİNDİRİM ENZİMİ
    ("KREON", "SİNDİRİM ENZİMİ"),
    ("PANKREOFLAT", "SİNDİRİM ENZİMİ"),
    ("PANKREATIN", "SİNDİRİM ENZİMİ"),
    # BULANTI
    ("DRAMAMINE", "BULANTI KESİCİ"),
    ("DIMENHIDRINAT", "BULANTI KESİCİ"),
    ("KYTRIL", "BULANTI KESİCİ"),  # granisetron
    ("GRANISETRON", "BULANTI KESİCİ"),
    ("EMEDUR", "BULANTI KESİCİ"),
    # CİLT / YARA / VARİS
    ("HIRUDOID", "CİLT İLACI (DIŞ KULLANIM)"),
    # KEMİK İLİĞİ STİMÜLATÖR
    ("NEUPOGEN", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("LEUCOSTIM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("FILGRASTIM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    # KABIZLIK
    ("FLEET", "KABIZLIK İLACI"),
    ("PHILIPS", "KABIZLIK İLACI"),
    # SKLEROZAN
    ("AETHOXYSKLEROL", "VARİS İLACI"),
    ("LAUROMACROGOL", "VARİS İLACI"),
    # PSORYAZ / DERMATOLOJİ
    ("PSODERM", "SEDEF HASTALIĞI İLACI"),
    ("CALCIPOTRIOL", "SEDEF HASTALIĞI İLACI"),
    # AŞI / VAKSİN
    ("VAXIGRIP", "AŞI"),
    ("INFLUVAC", "AŞI"),
    ("FLUARIX", "AŞI"),
    ("PNEUMOVAX", "AŞI"),
    ("PREVENAR", "AŞI"),
    ("ENGERIX", "AŞI"),
    # B12 / B vitamini
    ("DECAVIT", "VİTAMİN DESTEĞİ"),
    ("BERAZINC", "ÇİNKO DESTEĞİ"),
    # BAŞKA
    ("PROCTO-SEDYL", "HEMOROİD İLACI"),
    ("ULTRACAIN", "LOKAL ANESTEZİK"),
    ("JETOKAIN", "LOKAL ANESTEZİK"),
    ("CITANEST", "LOKAL ANESTEZİK"),
    ("KENACORT", "KORTİZON TEDAVİSİ"),
    ("PRECORT", "KORTİZON TEDAVİSİ"),
    ("PREDNICORT", "KORTİZON TEDAVİSİ"),
    ("ONADRON", "KORTİZON TEDAVİSİ"),
    ("DEKSAMETAZON", "KORTİZON TEDAVİSİ"),  # zaten var
    # GÖZ ALERJİ
    ("OPATANOL", "GÖZ İLACI"),
    ("PATADAY", "GÖZ İLACI"),
    ("EMADIN", "GÖZ İLACI"),
    # GÖZ ENFLAMASYON
    ("OFTAKLOR", "GÖZ İLACI"),
    ("OFTAGEN", "GÖZ İLACI"),
    ("EFLOX", "GÖZ İLACI"),
    # BURUN / PAS
    ("FLIXONASE", "BURUN İLACI (KORTİZON)"),  # zaten var
    # JELOFEN
    ("JELOFEN", "AĞRI KESİCİ"),
    # ZYLLT (klopidogrel)
    ("ZYLLT", "KAN SULANDIRICI"),
    # SOMATOSTATİN
    ("SANDOSTATIN", "SOMATOSTATİN İLACI"),
    # TBC
    ("ISONIAZID", "VEREM İLACI"),
    ("TEBESIUM", "VEREM İLACI"),
    ("ETAMBUTOL", "VEREM İLACI"),
    ("PIRAZINAMID", "VEREM İLACI"),

    # ============ BATCH 4 — Bilinen marka eşlemeleri ============
    ("PEXA", "PARKİNSON İLACI"),           # pramipeksol
    ("PARKYN", "PARKİNSON İLACI"),         # pramipeksol
    ("ROLASTYM", "ASTIM İLACI"),           # formoterol+budesonid
    ("FORPACK", "ASTIM İLACI"),            # formoterol+budesonid
    ("KEDAY", "ANTİPSİKOTİK"),             # kuetiapin XR
    ("ZESTAT", "ANTİDEPRESAN"),            # mirtazapin solüsyon
    ("SEF", "ANTİBİYOTİK"),                # sefadroksil 1g
    ("ARLEC", "TANSİYON İLACI"),           # metoprolol succinate
    ("AYRA", "TANSİYON İLACI"),            # kandesartan
    ("CANTAB", "TANSİYON İLACI"),          # kandesartan
    ("CARDORITM", "KALP RİTM İLACI"),
    ("OFNOL", "GÖZ İLACI"),                # olopatadin
    ("TERMINUS", "MANTAR İLACI"),          # terbinafin krem
    ("NIBULEN", "MANTAR İLACI"),
    ("OPAXOL", "RADYOLOJİK KONTRAST MADDESİ"),
    ("SULINEX", "ANTİDEPRESAN"),           # venlafaksin XR
    ("VENEGIS", "ANTİDEPRESAN"),
    ("SYMRA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),  # pregabalin
    ("ALYSE", "ANTİEPİLEPTİK / SİNİR AĞRISI"),  # pregabalin
    ("PERGE", "ANTİEPİLEPTİK / SİNİR AĞRISI"),  # pregabalin
    ("KWELLADA", "BİT / UYUZ İLACI"),       # permetrin şampuan
    ("METRIN", "BİT / UYUZ İLACI"),         # permetrin
    ("PERMETRIN", "BİT / UYUZ İLACI"),
    ("ANTI-SKAB", "BİT / UYUZ İLACI"),
    ("NASOVINE", "BURUN AÇICI"),
    ("METSIL", "KARIN GAZI İLACI"),         # simetikon
    ("SIMETIKON", "KARIN GAZI İLACI"),
    ("DISFLATYL", "KARIN GAZI İLACI"),
    ("MOMECON", "CİLT İLACI (KORTİZON)"),
    ("MOMETAZON", "CİLT İLACI (KORTİZON)"),
    ("M-FURO", "CİLT İLACI (KORTİZON)"),
    ("TARDEN", "KOLESTEROL İLACI"),         # atorvastatin
    ("VAZKOR", "KOLESTEROL İLACI"),
    ("LIVERCOL", "KOLESTEROL İLACI"),
    ("COLASTIN-L", "KOLESTEROL İLACI"),
    ("DEPORES", "KURU GÖZ RAHATSIZLIĞINDA"),  # siklosporin damla
    ("VIDAPTIN", "DİYABET"),               # vildagliptin (+metformin)
    ("ELEKTRA", "AĞRI KESİCİ"),            # deksketoprofen jel
    ("RECOSIDE", "KORTİZON TEDAVİSİ"),     # metilprednizolon
    ("EVOSTEN", "ANTİBİYOTİK"),
    ("EVICAP", "E VİTAMİNİ DESTEĞİ"),
    ("E-VİT", "E VİTAMİNİ DESTEĞİ"),
    ("VITAMIN E", "E VİTAMİNİ DESTEĞİ"),
    ("TREGS", "ANTİBİYOTİK"),              # seftriakson IM
    ("SARILEN", "TANSİYON İLACI"),         # losartan
    ("RICUS", "ANTİPSİKOTİK"),             # risperidon
    ("TEOKAP", "ASTIM İLACI"),             # teofilin
    ("TEOFILIN", "ASTIM İLACI"),
    ("FRENAG", "AĞRI KESİCİ"),             # diklofenak topical
    ("OLAXINN", "ANTİPSİKOTİK"),           # olanzapin
    ("K-MEXADER", "CİLT İLACI (KORTİZON)"),  # mometazon
    ("ANKEP", "ANTİEPİLEPTİK"),            # levetirasetam
    ("BIPERIDEN", "PARKİNSON İLACI"),      # zaten var ama

    # ============ BATCH 4 — Daha fazla bilinen marka ============
    # ANTİBİYOTİK / ANTİVİRAL / MANTAR
    ("MENEKLIN", "ANTİBİYOTİK"),           # tetrasiklin
    ("MOLCEF", "ANTİBİYOTİK"),
    ("CEFAZILIN", "ANTİBİYOTİK"),
    ("DOXIUM", "TOPLARDAMAR / VARİS İLACI"),  # kalsiyum dobesilat
    ("CALSIYUM DOBESILAT", "TOPLARDAMAR / VARİS İLACI"),
    ("DERMO-TROSYD", "MANTAR İLACI"),
    ("OCERAL", "MANTAR İLACI"),            # oxiconazole
    ("FUNGOSAN", "MANTAR İLACI"),
    # GÖZ
    ("TAMPROST", "GLOKOM İLACI"),          # latanoprost
    ("TOBRASED", "GÖZ İLACI"),
    ("DESMONT", "GÖZ İLACI"),
    # SOĞUK ALGINLIĞI / GRİP
    ("DESMONT-MUR", "GÖZ İLACI"),
    ("CETRYN", "ALLERJİ / KAŞINTI İLACI"),
    # KAS / NÖRO
    ("MUSCORIL", "KAS GEVŞETİCİ"),         # zaten var
    ("TIYOKOLŞIKOSID", "KAS GEVŞETİCİ"),   # zaten var
    # MİDE
    ("MAGNORM", "MAGNEZYUM DESTEĞİ"),
    ("OXEZOLE", "MİDE İLACI"),             # belki başka
    # GUT
    ("ALLOPURIM", "ÜRİK ASİT İLACI"),
    ("FEBUKSO", "ÜRİK ASİT İLACI"),
    # DİĞER (eski adlar ve sık)
    ("DEXTROMET", "ÖKSÜRÜK KESİCİ"),
    ("LEVOLON", "ÖKSÜRÜK KESİCİ"),
    ("PRAXAR", "ANTİDEPRESAN"),            # paroksetin
    ("PROFRAN", "ANTİDEPRESAN"),
    # ASTIM
    ("PULMICORT", "ASTIM İLACI (KORTİZON)"),  # zaten var
    ("DUOAIR", "ASTIM İLACI"),
    ("SPIRIVA", "ASTIM İLACI"),            # zaten var
    # BURUN
    ("CIRA", "BURUN AÇICI"),
    ("CIROFINA", "BURUN AÇICI"),
    # CİLT
    ("TROSYD", "MANTAR İLACI"),
    ("LOTRIDERM", "CİLT İLACI (KORTİZON)"),
    ("LOTRADERM", "CİLT İLACI (KORTİZON)"),
    ("LOCOID", "CİLT İLACI (KORTİZON)"),
    ("TRIDERM", "CİLT İLACI (KORTİZON)"),
    ("DIPROSALIC", "CİLT İLACI (KORTİZON)"),
    ("BETASALIC", "CİLT İLACI (KORTİZON)"),
    ("FLUCINAR", "CİLT İLACI (KORTİZON)"),
    ("FUCICORT", "CİLT İLACI (KORTİZON)"),
    # KEMOTERAPİ / ROMATİZMA
    ("CYCLOSPORIN", "İMMÜNOSUPRESİF İLAÇ"),
    ("PREDNICORT", "KORTİZON TEDAVİSİ"),
    # GÖZ
    ("LATIM", "GLOKOM İLACI"),
    ("TIMOSAN", "GLOKOM İLACI"),
    # ÖKSÜRÜK
    ("TUSSIN", "ÖKSÜRÜK KESİCİ"),
    ("KARBOSISTEIN", "ÖKSÜRÜK KESİCİ"),
    # MİDE
    ("PARILAN", "MİDE İLACI"),
    ("DEPRELANS", "MİDE İLACI"),
    # ALERJİ
    ("ALERSET", "ALLERJİ / KAŞINTI İLACI"),
    ("SETIRIN", "ALLERJİ / KAŞINTI İLACI"),
    ("FEXADYNE", "ALLERJİ / KAŞINTI İLACI"),
    ("FEXOFENADIN", "ALLERJİ / KAŞINTI İLACI"),
    # KAN / İMMÜN
    ("FOSTIMON", "KISIRLIK TEDAVİSİ"),
    ("CETROTIDE", "KISIRLIK TEDAVİSİ"),
    ("ORGALUTRAN", "KISIRLIK TEDAVİSİ"),
    ("OVITRELLE", "KISIRLIK TEDAVİSİ"),
    # ASTIM / NEFES
    ("FOSTAIR", "ASTIM İLACI"),
    ("DUORESP", "ASTIM İLACI"),
    # NÖROLOJİ
    ("NEUROCETAM", "NÖROLOJİ İLACI"),
    ("LUCETAM", "NÖROLOJİ İLACI"),
    ("PIRACETAM", "NÖROLOJİ İLACI"),
    # KEMOTERAPİ
    ("HALAVEN", "KANSER İLACI"),
    ("XELODA", "KANSER İLACI"),
    ("CISPLATIN", "KANSER İLACI"),
    ("CARBOPLATIN", "KANSER İLACI"),
    ("OXALIPLATIN", "KANSER İLACI"),
    ("PACLITAXEL", "KANSER İLACI"),
    ("DOCETAXEL", "KANSER İLACI"),
    ("DOXORUBICIN", "KANSER İLACI"),
    ("FLUOROURACIL", "KANSER İLACI"),
    ("GEMCITABINE", "KANSER İLACI"),
    ("HERCEPTIN", "KANSER İLACI"),
    ("TRASTUZUMAB", "KANSER İLACI"),
    ("AVASTIN", "KANSER İLACI"),
    ("BEVACIZUMAB", "KANSER İLACI"),
    ("ALIMTA", "KANSER İLACI"),
    ("LETROZOL", "KANSER İLACI"),
    ("FEMARA", "KANSER İLACI"),
    ("ANASTROZOL", "KANSER İLACI"),
    ("ARIMIDEX", "KANSER İLACI"),
    ("EXEMESTAN", "KANSER İLACI"),
    # PROBİYOTİK / İSHAL
    ("ENTEROL", "PROBİYOTİK"),
    ("FLOREN", "PROBİYOTİK"),
    ("LACTOFOS", "PROBİYOTİK"),
    # ALERJİ / EGZEMA
    ("ELOCOM", "CİLT İLACI (KORTİZON)"),
    # KEMİK
    ("PROLIA", "OSTEOPOROZ İLACI"),
    ("BONVIVA", "OSTEOPOROZ İLACI"),
    ("ZOMETA", "OSTEOPOROZ İLACI"),
    ("ZOLEDRONIK", "OSTEOPOROZ İLACI"),
    ("XGEVA", "OSTEOPOROZ İLACI"),
    # MİGREN
    ("RIZAMIG", "MİGREN İLACI"),
    ("ZOMIG-RAPIMELT", "MİGREN İLACI"),
    # KAS
    ("MIYOREL", "KAS GEVŞETİCİ"),
    # CİLT
    ("DERMOZON", "CİLT İLACI (KORTİZON)"),
    # KANANA
    ("KOAGULASYON", "KANAMA DURDURUCU"),
    # AŞI
    ("HAVRIX", "AŞI"),
    ("TWINRIX", "AŞI"),
    ("HBVAXPRO", "AŞI"),
    ("INFANRIX", "AŞI"),
    ("PRIORIX", "AŞI"),
    ("PEDIACEL", "AŞI"),
    ("ROTARIX", "AŞI"),
    ("VARILRIX", "AŞI"),
    ("GARDASIL", "AŞI"),
    ("HEXAXIM", "AŞI"),
    # PROSTAT
    ("AVODART", "PROSTAT İLACI"),  # zaten var
    ("URIMAX", "PROSTAT İLACI"),
    # SAĞLIK ürünleri
    ("SUDOCREM", "CİLT İLACI (DIŞ KULLANIM)"),
    ("BEPANTHENE", "CİLT İLACI (DIŞ KULLANIM)"),
    ("SUDO CARE", "CİLT İLACI (DIŞ KULLANIM)"),
    # MS / MULTİPL SKLEROZ
    ("COPAXONE", "MS İLACI"),
    ("GILENYA", "MS İLACI"),
    ("TECFIDERA", "MS İLACI"),
    # ANEMİ
    ("FERICOSE", "DEMİR DESTEĞİ"),
    # SHOCK / AIRWAY
    ("ADRENALIN", "ACİL İLACI"),
    ("EPIPEN", "ACİL İLACI"),

    # ============ BATCH 5 — Daha fazla marka ============
    ("ACNEGEN", "SİVİLCE İLACI"),
    ("ADVAGRAF", "İMMÜNOSUPRESİF İLAÇ"),
    ("AIRTIDE", "ASTIM İLACI"),
    ("BYETTA", "DİYABET"),
    ("EKSENATID", "DİYABET"),
    ("CALBICOR", "KALSİYUM DESTEĞİ"),
    ("CEC", "ANTİBİYOTİK"),               # sefaklor
    ("CLARISCAN", "RADYOLOJİK KONTRAST MADDESİ"),
    ("CLIN", "ANTİBİYOTİK"),              # klindamisin
    ("CLINDAMYCIN", "ANTİBİYOTİK"),
    ("CLONEX", "TANSİYON İLACI"),         # klonidin
    ("KLONIDIN", "TANSİYON İLACI"),
    ("DEXTROCIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("ENOX", "KAN SULANDIRICI (İĞNE)"),    # enoksaparin jenerik
    ("EXODERIL", "MANTAR İLACI"),          # naftifin
    ("NAFTIFIN", "MANTAR İLACI"),
    ("EXTRAIR", "ASTIM İLACI"),
    ("FERPLEX", "DEMİR DESTEĞİ"),
    ("FUSIX", "TANSİYON İLACI"),           # furosemid
    ("GLISERIN", "KABIZLIK İLACI"),
    ("HEPAZEC", "KARACİĞER İLACI"),
    ("KATARIN", "GÖZ İLACI"),
    ("KEYDROPS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("KONGEST", "BURUN AÇICI"),
    ("KONSENIDAT", "DEHB İLACI"),          # konsantrat methylphenidate? metilfenidat
    ("KOPAQ", "RADYOLOJİK KONTRAST MADDESİ"),
    ("MAXIDEX", "GÖZ İLACI"),              # deksametazon göz
    ("MISOL", "MİDE İLACI"),               # misoprostol
    ("MISOPROSTOL", "MİDE İLACI"),
    ("NETIRA", "GÖZ İLACI"),
    ("NETILDEX", "GÖZ İLACI"),
    # RIF/RIFOCIN ampul (rifamisin SV, J04AB03) lokal antibakteriyel →
    # "ANTİBİYOTİK"; verem markaları (rifampisin) ayrıca verilir. Çıplak "RIF"
    # anahtarı kullanılmaz: FERIFER/TRIFLUCAN gibi adların içine de uyuyordu.
    ("RIFOCIN", "ANTİBİYOTİK"), ("RIFETEM", "ANTİBİYOTİK"),
    ("RIFOXTEM", "ANTİBİYOTİK"), ("RIF 250", "ANTİBİYOTİK"),
    ("RIF 125", "ANTİBİYOTİK"), ("RIF250", "ANTİBİYOTİK"),
    ("RIFADIN", "VEREM İLACI"), ("RIFCAP", "VEREM İLACI"),
    ("MYCOBUTIN", "VEREM İLACI"),
    ("SELOVITA-D", "D VİTAMİNİ"),
    ("SETINOX", "ANTİDEPRESAN"),           # sertralin
    ("SPRAMAX", "BOĞAZ SPREYİ"),
    ("TELVIS", "TANSİYON İLACI"),          # telmisartan
    ("TEMOMID", "KANSER İLACI"),           # temozolomid
    ("TERA-D", "D VİTAMİNİ"),
    ("THIOCILLINE", "ANTİBİYOTİK"),
    ("TOBREX", "GÖZ İLACI"),               # tobramisin
    ("TOPIKAZOL", "MANTAR İLACI"),
    ("TOLVON", "ANTİDEPRESAN"),            # mianserin
    ("MIANSERIN", "ANTİDEPRESAN"),
    ("TRIBEKSOL", "B VİTAMİNİ DESTEĞİ"),
    ("TRIGAST", "MİDE İLACI"),
    ("UROPAN", "AŞIRI AKTİF MESANE İLACI"),
    ("URIKOLIZ", "ÜRİK ASİT İLACI"),
    ("VILDEGA", "DİYABET"),                # vildagliptin
    ("VITABIOL", "VİTAMİN DESTEĞİ"),
    ("WINCEF", "ANTİBİYOTİK"),             # sefaleksin
    ("ZARZIO", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("FILGRASTIM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("DULESTER", "ANTİDEPRESAN"),          # duloksetin
    ("PALLADA", "TANSİYON İLACI"),         # perindopril+amlodipin?
    ("DYLOXIA", "ANTİDEPRESAN"),
    ("EFAMAT", "TANSİYON İLACI"),
    ("RECBUTIN", "ANTİDEPRESAN"),          # nortriptilin
    ("ARBESTA", "TANSİYON İLACI"),
    ("BENITIDE", "MİDE İLACI"),
    ("DAFLON", "TOPLARDAMAR / VARİS İLACI"),  # zaten var
    ("FRAVEN", "ANTİDEPRESAN"),            # fluvoksamin
    ("FLUVOKSAMIN", "ANTİDEPRESAN"),
    ("DULOSER", "ANTİDEPRESAN"),
    ("FONKSERA", "ANTİDEPRESAN"),
    ("FLOSEF", "ANTİBİYOTİK"),
    ("OKSAPAR", "KAN SULANDIRICI (İĞNE)"),  # zaten var
    ("ATEROZ", "GÖZ İLACI"),
    ("APFECTO", "ANTİDEPRESAN"),
    ("EBAFIT", "ALLERJİ / KAŞINTI İLACI"),  # ebastin
    ("EBASTIN", "ALLERJİ / KAŞINTI İLACI"),
    ("ANTI-FOSFAT", "BÖBREK HASTALIĞI İLACI"),
    ("SUTRIL", "TANSİYON İLACI"),          # torasemid
    ("TORASEMID", "TANSİYON İLACI"),
    ("DEPALEX", "ANTİDEPRESAN"),
    ("ACULAR", "GÖZ İLACI"),               # ketorolak göz
    ("TIMOPRESS", "GLOKOM İLACI"),
    ("LATIM", "GLOKOM İLACI"),
    ("FERAMIN", "DEMİR DESTEĞİ"),
    ("ECTIN", "MAGNEZYUM DESTEĞİ"),
    ("MAGNORM", "MAGNEZYUM DESTEĞİ"),
    ("MAGNEROT", "MAGNEZYUM DESTEĞİ"),
    ("VITALIPID", "BESLENME ÜRÜNÜ"),
    ("CERNEVIT", "VİTAMİN DESTEĞİ"),
    # diyabet beslenme
    ("DIBEN", "BESLENME ÜRÜNÜ"),
    ("FORTIMEL", "BESLENME ÜRÜNÜ"),
    # KAS - SPAZMOLITIK
    ("LIORESAL", "KAS GEVŞETİCİ"),
    ("BAKLOFEN", "KAS GEVŞETİCİ"),
    # GASTRO ENDOSKOPI HAZIRLIK
    ("FORTRANS", "KOLON TEMİZLEYİCİ"),
    ("ENDOFALK", "KOLON TEMİZLEYİCİ"),
    ("CITRAFLEET", "KOLON TEMİZLEYİCİ"),
    # ZONA / KANSER
    ("SUTENT", "KANSER İLACI"),
    ("GLEEVEC", "KANSER İLACI"),
    ("IMATINIB", "KANSER İLACI"),
    ("SUTENB", "KANSER İLACI"),
    ("TARCEVA", "KANSER İLACI"),
    ("ERLOTINIB", "KANSER İLACI"),
    # KEMOTERAPİ DESTEK
    ("NEULASTA", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    # MS / NÖROLOJİ
    ("PLEGRIDY", "MS İLACI"),
    ("BETAFERON", "MS İLACI"),
    # YENİDOĞAN
    ("CUROSURF", "AKCİĞER İLACI (YENİDOĞAN)"),
    ("SURVANTA", "AKCİĞER İLACI (YENİDOĞAN)"),
    # KALP YETMEZLİĞİ
    ("ENTRESTO", "KALP YETMEZLİĞİ İLACI"),
    ("SAKUBITRIL", "KALP YETMEZLİĞİ İLACI"),
    # DİĞER
    ("DECONTRACTYL", "KAS GEVŞETİCİ"),
    ("VOLON-A", "KORTİZON TEDAVİSİ"),
    ("DEPO-MEDROL", "KORTİZON TEDAVİSİ"),
    ("CALCIJEX", "KALSİYUM DESTEĞİ"),
    ("ROCALTROL", "D VİTAMİNİ"),
    ("KALSITRIOL", "D VİTAMİNİ"),

    # ============ BATCH 6 — Daha derinlemesine markalar ============
    ("PROVIRON", "HORMON"),                  # mesterolon
    ("MESTEROLON", "HORMON"),
    ("IPRASAL", "ASTIM İLACI"),               # ipratropium+salbutamol nebül
    ("RHOPHYLAC", "BAĞIŞIKLIK SİSTEMİ İLACI"),  # Rh immün
    ("CEZOL", "ANTİBİYOTİK"),                 # sefazolin
    ("EQIZOLIN", "ANTİBİYOTİK"),
    ("CEFAMED", "ANTİBİYOTİK"),
    ("PATANOL", "GÖZ İLACI"),                 # olopatadin
    ("OLOPATADIN", "GÖZ İLACI"),
    ("QSMOK", "SİGARA BIRAKMA"),              # vareniklin
    ("DESLORAN", "ALLERJİ / KAŞINTI İLACI"),   # desloratadin
    ("DESLORATIN", "ALLERJİ / KAŞINTI İLACI"),
    ("VARIDOS", "TOPLARDAMAR / VARİS İLACI"),
    ("VEMLIDY", "HEPATİT İLACI"),             # tenofovir alafenamid
    ("TENOFOVIR", "HEPATİT İLACI"),
    ("ENTECAVIR", "HEPATİT İLACI"),
    ("BARACLUDE", "HEPATİT İLACI"),
    ("TAGLIN", "DİYABET"),                    # sitagliptin+metformin
    ("BRONCHO-MUNAL", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("VAXORAL", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("REDOX-C", "VİTAMİN DESTEĞİ"),
    ("TRANKO-BUSKAS", "KARIN AĞRISI / KASILMA İLACI"),
    ("GRIBO", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("FERVION", "DEMİR DESTEĞİ"),
    ("NASACORT", "BURUN İLACI"),
    ("REGEN-D", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("DYMISTA", "BURUN İLACI"),
    ("XALACOM", "GLOKOM İLACI"),
    ("MOXAGUT", "GÖZ İLACI"),
    ("MOKSIFLOKSAS", "ANTİBİYOTİK"),
    ("TOLPERON", "KAS GEVŞETİCİ"),
    ("ITRAXYL", "MANTAR İLACI"),
    ("CANDIMAX", "MANTAR İLACI"),
    ("AKLOFEN", "AĞRI KESİCİ"),               # aseklofenak
    ("ASEKLOFENAK", "AĞRI KESİCİ"),
    ("LOPID", "KOLESTEROL İLACI"),
    ("GEMFIBROZIL", "KOLESTEROL İLACI"),
    ("SINAKORT-A", "KORTİZON TEDAVİSİ"),
    ("TRIAMSINOLON", "KORTİZON TEDAVİSİ"),
    ("KALIDREN", "TANSİYON İLACI"),           # torasemid
    ("TRIANSERIL", "TANSİYON İLACI"),         # triamteren+HCT
    ("TRIAMTERIL", "TANSİYON İLACI"),
    ("TRIAMTEREN", "TANSİYON İLACI"),
    ("TIOPATI-B", "B VİTAMİNİ DESTEĞİ"),
    ("IBANOS", "OSTEOPOROZ İLACI"),           # ibandronik
    ("IBANDRON", "OSTEOPOROZ İLACI"),
    ("BRONTIO", "ASTIM İLACI"),               # tiotropium
    ("CARDOFIX", "TANSİYON İLACI"),
    ("ATEROZ", "KOLESTEROL İLACI"),           # atorvastatin (önceki yanlış kategori düzeltildi)
    ("EXAGYN", "KADIN HASTALIKLARINDA"),
    ("ULTRAPROCT", "HEMOROİD İLACI"),
    ("HELIPAK", "MİDE İLACI"),                # H. pylori tedavi paketi
    ("INSOMIN", "UYKU İLACI"),                # doksilamin
    ("UNISOM", "UYKU İLACI"),
    ("DOKSILAMIN", "UYKU İLACI"),
    ("ESOM", "MİDE İLACI"),                   # esomeprazol
    ("PROSEK", "MİDE İLACI"),                 # omeprazol
    ("PENEPIN", "ACİL İLACI"),                # epinefrin oto-enjektör
    ("AXID", "MİDE İLACI"),                   # nizatidin
    ("NIZATIDIN", "MİDE İLACI"),
    ("SANTAFER", "DEMİR DESTEĞİ"),
    ("FLESSI", "MİDE İLACI"),                 # rabeprazol
    ("BRUMETON", "GÖZ İLACI"),                # betametazon göz
    ("ALBACORT", "CİLT İLACI (KORTİZON)"),
    ("ARISTU", "KANSER İLACI"),               # anastrozol
    ("CODERMO", "CİLT İLACI (KORTİZON)"),
    ("LUDIOMIL", "ANTİDEPRESAN"),             # maprotilin
    ("MAPROTILIN", "ANTİDEPRESAN"),
    ("HEMANGIOL", "KALP RİTM İLACI"),         # propranolol pediatrik
    ("CALCI-NET", "KALSİYUM DESTEĞİ"),
    ("MODIOGEN", "UYANIKLIK İLACI"),          # modafinil
    ("MODAFINIL", "UYANIKLIK İLACI"),
    ("KLOGEL-A", "KAN SULANDIRICI"),          # klopidogrel+aspirin
    ("KOLSIN", "FMF / GUT TEDAVİSİ"),         # kolşisin
    ("KOLŞIN", "FMF / GUT TEDAVİSİ"),
    ("RUPAFIN", "ALLERJİ / KAŞINTI İLACI"),   # rupatadin
    ("RUPATADIN", "ALLERJİ / KAŞINTI İLACI"),
    ("ARMEC", "PARAZİT İLACI"),               # ivermektin
    ("IVERMEKTIN", "PARAZİT İLACI"),
    ("MEBENDAZOL", "PARAZİT İLACI"),
    ("VERMAZOL", "PARAZİT İLACI"),
    ("MEBEN", "PARAZİT İLACI"),
    ("VERMOX", "PARAZİT İLACI"),
    ("VILDABET", "DİYABET"),                  # vildagliptin+metformin
    ("METICURE", "KORTİZON TEDAVİSİ"),
    ("VEMCAINE", "LOKAL ANESTEZİK"),
    ("EVIGEN", "E VİTAMİNİ DESTEĞİ"),
    ("SWISS ENERGY", "VİTAMİN DESTEĞİ"),
    ("OLEDRO", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),  # parasetamol pediatrik
    ("FORZA", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("RELAMAX", "UYKU İLACI"),                # melatonin
    ("MELATONIN", "UYKU İLACI"),
    ("CIRCADIN", "UYKU İLACI"),
    ("GADONANS", "RADYOLOJİK KONTRAST MADDESİ"),
    ("NEOTIGASON", "SEDEF HASTALIĞI İLACI"),
    ("ASITRETIN", "SEDEF HASTALIĞI İLACI"),
    ("DIVINA", "HORMON"),                     # estradiol+MPA
    ("BIOKADIN", "KADIN HASTALIKLARINDA"),
    ("ACLASTA", "OSTEOPOROZ İLACI"),          # zoledronik
    ("TERBIN", "MANTAR İLACI"),
    ("SEPTIX", "BOĞAZ SPREYİ"),
    ("PAFESAN", "BOĞAZ SPREYİ"),
    ("BENZYDEX", "AĞIZ-DİŞ İLACI"),
    ("LOMOTIL", "İSHAL KESİCİ"),              # difenoksilat
    ("DIFENOKSILAT", "İSHAL KESİCİ"),
    ("OFTOMIX", "GÖZ İLACI"),
    ("COLNAR", "KOLESTEROL İLACI"),           # atorvastatin
    ("FUSIDAS", "CİLT İLACI (ANTİBİYOTİK)"),
    ("CHORIOMON", "KISIRLIK TEDAVİSİ"),
    ("TAMIDRA", "PROSTAT İLACI"),             # tamsulosin MR
    ("JETEX", "LOKAL ANESTEZİK"),
    ("ENDOXAN", "KANSER İLACI"),
    ("NEULASTIM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("MULTICOLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("URESAL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("KERASAL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("BRONCHOREST", "ASTIM İLACI"),
    ("ELLEACNELLE", "DOĞUM KONTROL"),
    ("DROSETIL", "DOĞUM KONTROL"),
    ("DIANE", "DOĞUM KONTROL"),
    ("FEMARIS", "KALSİYUM DESTEĞİ"),
    ("BRITIL-T", "GLOKOM İLACI"),
    ("TRIMOKS", "ANTİBİYOTİK"),               # kotrimoksazol
    ("KOTRIMOKSAZOL", "ANTİBİYOTİK"),
    ("ALBAREN", "AĞRI KESİCİ"),               # diklofenak veya benzeri jel
    ("INFLADOX", "AĞRI KESİCİ"),
    ("ETOFAST", "AĞRI KESİCİ"),
    ("THERMO", "AĞRI KESİCİ"),
    # Yine MİDE/ÖKSÜRÜK/ALERJİ
    ("LEVODROP", "ALLERJİ / KAŞINTI İLACI"),
    ("LEVOSET", "ALLERJİ / KAŞINTI İLACI"),
    # OFTALMİK Anestezi/Antibiyotik
    ("BRITIL", "GÖZ İLACI"),
    # FMF
    ("COLCHIDOZA", "FMF / GUT TEDAVİSİ"),
    ("KOL-DOZ", "FMF / GUT TEDAVİSİ"),
    # GUT
    ("PROBENECID", "ÜRİK ASİT İLACI"),
    # ALZH
    ("ALZAIM", "ALZHEİMER İLACI"),
    ("MENRIST", "ALZHEİMER İLACI"),
    # NÖROLEPSI
    ("VYVANSE", "DEHB İLACI"),
    # PARKİNSON
    ("RASILEZ", "TANSİYON İLACI"),            # aliskiren
    ("ALISKIREN", "TANSİYON İLACI"),
    # Çocuk akut
    ("CALPOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    # Otitis
    ("OTOFA", "KULAK İLACI"),
    ("OTOMIDONE", "KULAK İLACI"),
    ("OTOSEPTIL", "KULAK İLACI"),
    ("CILOXAN", "GÖZ İLACI"),                 # siprofloksasin göz
    # Tüm sefin/sefa marka
    ("KEFLOR", "ANTİBİYOTİK"),
    ("KEFZOL", "ANTİBİYOTİK"),
    ("KEFLEX", "ANTİBİYOTİK"),
    ("CEFEKS", "ANTİBİYOTİK"),
    ("PROSEFIN", "ANTİBİYOTİK"),
    # KAN BASINCI KOMBİNASYONLAR
    ("LERCATEN", "TANSİYON İLACI"),
    ("ZESTRA", "TANSİYON İLACI"),
    ("AMOZARTAN", "TANSİYON İLACI"),          # amlodipin+losartan
    # GUT
    ("AZURIX", "TANSİYON İLACI"),
    # SPESİFİK İLAÇLAR
    ("RELESTAT", "GÖZ İLACI"),
    ("LASTACAFT", "GÖZ İLACI"),
    # GASTROENTERİT
    ("CARBOSORB", "İSHAL KESİCİ"),
    ("SMECTA", "İSHAL KESİCİ"),
    ("HIDRASEC", "İSHAL KESİCİ"),
    ("RACECADOTRIL", "İSHAL KESİCİ"),
    # PERİYODONTAL
    ("ELYZOL", "AĞIZ-DİŞ İLACI"),
    # MİYOM
    ("ESMYA", "HORMON"),
    # BRONŞİYAL
    ("PRONTODOL", "AĞRI KESİCİ"),

    # ============ BATCH 7 — Çok geniş marka eşlemesi ============
    ("EMEND", "BULANTI KESİCİ"),
    ("APREPITANT", "BULANTI KESİCİ"),
    ("LACIPIL", "TANSİYON İLACI"),         # lasidipin
    ("LASIDIPIN", "TANSİYON İLACI"),
    ("PARAFLEX", "KAS GEVŞETİCİ"),         # klorzoksazon
    ("KLORZOKSAZON", "KAS GEVŞETİCİ"),
    ("ACNEMIX", "SİVİLCE İLACI"),
    ("AKNILOX", "SİVİLCE İLACI"),
    ("AKNETOP", "SİVİLCE İLACI"),
    ("ROZA", "CİLT İLACI (DIŞ KULLANIM)"),
    ("SEBIROX", "MANTAR İLACI"),           # ketokonazol şampuan
    ("BUTOPAN", "KARIN AĞRISI / KASILMA İLACI"),
    ("BLEPHAMIDE", "GÖZ İLACI"),
    ("METHOTREXATE", "ROMATİZMA / İLTİHAP İLACI"),
    ("SINORETIK", "TANSİYON İLACI"),
    ("PLASBUMIN", "ALBUMİN / IV"),
    ("UMAN ALBUMIN", "ALBUMİN / IV"),
    ("TROMBOXAR", "KAN SULANDIRICI"),
    ("PLATEXAR", "KAN SULANDIRICI"),
    ("CLOPRA", "KAN SULANDIRICI"),
    ("RIVOKSAR", "KAN SULANDIRICI"),
    ("BRIMOGUT", "GLOKOM İLACI"),
    ("BIRIGLO", "GLOKOM İLACI"),
    ("BRIMONIDIN", "GLOKOM İLACI"),
    ("REUMIL", "AĞRI KESİCİ"),             # piroksikam
    ("ACTINOMA", "CİLT İLACI (DIŞ KULLANIM)"),
    ("DONEPTIN", "ALZHEİMER İLACI"),
    ("DOENZA", "ALZHEİMER İLACI"),         # donezepil
    ("ALZAFON", "ALZHEİMER İLACI"),
    ("POSTPILL", "ACİL DOĞUM KONTROL"),
    ("LEVONORGESTREL", "ACİL DOĞUM KONTROL"),
    ("FOSETAZ", "TANSİYON İLACI"),         # zofenopril
    ("ZOFENOPRIL", "TANSİYON İLACI"),
    ("PINIX", "TANSİYON İLACI"),           # valsartan+amlodipin
    ("PHOS-OUT", "BÖBREK HASTALIĞI İLACI"),  # kalsiyum asetat
    ("KALSIYUM ASETAT", "BÖBREK HASTALIĞI İLACI"),
    ("FOSRENOL", "BÖBREK HASTALIĞI İLACI"),
    ("EBICOMB", "TANSİYON İLACI"),         # olmesartan+amlodipin
    ("LIPOTEARS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("FULLFRESH", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("KARVEA", "TANSİYON İLACI"),
    ("NASOWELL", "BURUN AÇICI"),
    ("PRONAT", "MİDE İLACI"),
    ("FIXDUAL", "TANSİYON İLACI"),
    ("FOLBETAKE", "FOLİK ASİT DESTEĞİ"),
    ("FOLIDNEU", "FOLİK ASİT DESTEĞİ"),
    ("FOLIN", "FOLİK ASİT DESTEĞİ"),
    ("TRENTAL", "TOPLARDAMAR / VARİS İLACI"),  # pentoksifilin
    ("PENTOKSIFILIN", "TOPLARDAMAR / VARİS İLACI"),
    ("BERAVIT", "B VİTAMİNİ DESTEĞİ"),
    ("AMETIK", "KARIN GAZI İLACI"),
    ("SAB", "KARIN GAZI İLACI"),
    ("SAB SIMPLEX", "KARIN GAZI İLACI"),
    ("ESPUMISAN", "KARIN GAZI İLACI"),
    ("MERIOFERT", "KISIRLIK TEDAVİSİ"),
    ("MERIONAL", "KISIRLIK TEDAVİSİ"),
    ("ACTIFED", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("REFACTO", "HEMOFİLİ İLACI"),
    ("ADVATE", "HEMOFİLİ İLACI"),
    ("KOATE", "HEMOFİLİ İLACI"),
    ("BERIATE", "HEMOFİLİ İLACI"),
    ("OCTANATE", "HEMOFİLİ İLACI"),
    ("RIXUBIS", "HEMOFİLİ İLACI"),
    ("FAVERIN", "ANTİDEPRESAN"),
    ("TARGOCID", "ANTİBİYOTİK"),           # teikoplanin
    ("TEKOPLANIN", "ANTİBİYOTİK"),
    ("DICLASIL", "AĞRI KESİCİ"),
    ("RECTODERM", "HEMOROİD İLACI"),
    ("PLETAL", "TOPLARDAMAR / VARİS İLACI"),
    ("SILOSTAZOL", "TOPLARDAMAR / VARİS İLACI"),
    ("MEKINIST", "KANSER İLACI"),          # trametinib
    ("BENZOXIN", "SİVİLCE İLACI"),
    ("LONGIS", "EREKSİYON İLACI"),         # tadalafil
    ("SILNORM", "EREKSİYON İLACI"),
    ("SILFECT", "EREKSİYON İLACI"),
    ("SILMED", "EREKSİYON İLACI"),
    ("ORCAFIL", "EREKSİYON İLACI"),
    ("UREACORT", "CİLT İLACI (DIŞ KULLANIM)"),
    ("DORAMYCIN", "ANTİBİYOTİK"),
    ("SPIRAMISIN", "ANTİBİYOTİK"),
    ("FERRISITA", "DEMİR DESTEĞİ"),
    ("FENISTIL", "ALLERJİ / KAŞINTI İLACI"),
    ("DIMETINDEN", "ALLERJİ / KAŞINTI İLACI"),
    ("CIRRUS", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("ANTI-ASIDOZ", "BÖBREK HASTALIĞI İLACI"),
    ("SELOVITA", "VİTAMİN DESTEĞİ"),
    ("QUANTAVIR", "HEPATİT İLACI"),
    ("AVIRAVIR", "HEPATİT İLACI"),
    ("VEFORIX", "HEPATİT İLACI"),
    ("HIVENT", "HIV İLACI"),
    ("TRUVADA", "HIV İLACI"),
    ("ATRIPLA", "HIV İLACI"),
    ("STOCRIN", "HIV İLACI"),
    ("EVIPLERA", "HIV İLACI"),
    ("KALETRA", "HIV İLACI"),
    ("EVOTAZ", "HIV İLACI"),
    ("PREZISTA", "HIV İLACI"),
    ("DESCOVY", "HIV İLACI"),
    ("FML", "GÖZ İLACI"),                  # florometolon
    ("FLOROMETOLON", "GÖZ İLACI"),
    ("DAPADAP", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("DAPGEON", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("SISTRAL", "ALLERJİ / KAŞINTI İLACI"),
    ("OSTRIOL", "D VİTAMİNİ"),
    ("DERMABEL", "CİLT İLACI (KORTİZON)"),
    ("TENIPRA", "MİDE İLACI"),
    ("INVEGA", "ANTİPSİKOTİK"),            # paliperidon
    ("PALIPERIDON", "ANTİPSİKOTİK"),
    ("VENOMIA", "AŞIRI AKTİF MESANE İLACI"),
    ("TOVIAZ", "AŞIRI AKTİF MESANE İLACI"),
    ("FESOTERODIN", "AŞIRI AKTİF MESANE İLACI"),
    ("DOZYL", "PROSTAT İLACI"),
    ("APTAMIL", "BESLENME ÜRÜNÜ"),         # bebek maması
    ("INFATRINI", "BESLENME ÜRÜNÜ"),
    ("FRISO", "BESLENME ÜRÜNÜ"),
    ("BEBELAC", "BESLENME ÜRÜNÜ"),
    ("MILUPA", "BESLENME ÜRÜNÜ"),
    ("ESOPRO", "MİDE İLACI"),
    ("OMESEK", "MİDE İLACI"),
    ("POSAGIL", "BAĞIRSAK İLTİHABI İLACI"),
    ("SPOREX", "MANTAR İLACI"),
    ("FLUDALT", "ASTIM İLACI"),
    ("SALOMEX", "ASTIM İLACI"),
    ("BREQUAL", "ASTIM İLACI"),
    ("AIRFLUSAL", "ASTIM İLACI"),
    ("LINTREJAMET", "DİYABET"),
    ("LOCASALENE", "CİLT İLACI (KORTİZON)"),
    ("BACLOREX", "KAS GEVŞETİCİ"),
    ("LIORESAL", "KAS GEVŞETİCİ"),
    ("DOPALEVO", "PARKİNSON İLACI"),
    ("TAVEGYL", "ALLERJİ / KAŞINTI İLACI"),  # klemastin
    ("KLEMASTIN", "ALLERJİ / KAŞINTI İLACI"),
    ("NIPIDOL", "TANSİYON İLACI"),
    ("TREMFYA", "BİYOLOJİK İLAÇ"),         # guselkumab
    ("STELARA", "BİYOLOJİK İLAÇ"),
    ("COSENTYX", "BİYOLOJİK İLAÇ"),
    ("TROPAMID", "GÖZ İLACI"),
    ("TROPIKAMID", "GÖZ İLACI"),
    ("ISORDIL", "TANSİYON İLACI"),         # isosorbid (angina)
    ("ISOSORBID", "TANSİYON İLACI"),
    ("KEYRELAKS", "KAS GEVŞETİCİ"),
    ("OROFEN", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("BUDENOSIN", "ASTIM İLACI (KORTİZON)"),
    ("BUDENOFALK", "BAĞIRSAK İLTİHABI İLACI"),
    ("PARKIPEX", "PARKİNSON İLACI"),
    ("ANTHIX", "ALLERJİ / KAŞINTI İLACI"),
    ("EYENAT", "GÖZ İLACI"),
    ("PRIDESMO", "KORTİZON TEDAVİSİ"),
    ("EXTRANEAL", "PERİTON DİYALİZ SOLÜSYONU"),
    ("DIANEAL", "PERİTON DİYALİZ SOLÜSYONU"),
    ("NUTRINEAL", "PERİTON DİYALİZ SOLÜSYONU"),
    ("VITAKOBAL", "B12 VİTAMİNİ DESTEĞİ"),
    ("PSORETIN", "SEDEF HASTALIĞI İLACI"),
    ("MAGCAR", "MİDE İLACI (REFLÜ)"),
    ("TIOUMIT", "ASTIM İLACI"),
    ("CORIVA", "ASTIM İLACI"),
    ("TIOTROPIUM", "ASTIM İLACI"),         # zaten var ama
    ("YOMESAN", "PARAZİT İLACI"),
    ("NIKLOZAMID", "PARAZİT İLACI"),
    ("REMOXIL", "ANTİBİYOTİK"),
    ("OFTAMYCIN", "GÖZ İLACI"),
    ("LOCERYL", "MANTAR İLACI"),           # amorolfin tırnak
    ("AMOROLFIN", "MANTAR İLACI"),
    ("ZADISOL", "ALLERJİ / KAŞINTI İLACI"),
    ("KETOTIFEN", "ALLERJİ / KAŞINTI İLACI"),
    ("SULPIR", "ANTİPSİKOTİK"),
    ("SÜLPİRİD", "ANTİPSİKOTİK"),
    ("SULPIRID", "ANTİPSİKOTİK"),
    ("POTASYUM KLORUR", "ELEKTROLİT"),
    ("REGAPEN", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("TAMOXIT", "KANSER İLACI"),
    ("FEVERE", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("TRAVOGEN", "MANTAR İLACI"),
    ("MIKODERM", "MANTAR İLACI"),
    ("OSMOLAK", "KABIZLIK İLACI"),
    ("LIBALAKS", "KABIZLIK İLACI"),
    ("MAGNEZINC", "MAGNEZYUM DESTEĞİ"),
    ("MAGNEDUO", "MAGNEZYUM DESTEĞİ"),
    ("MAGNERAL", "MAGNEZYUM DESTEĞİ"),
    ("MAGNETON", "MAGNEZYUM DESTEĞİ"),
    ("KOMBOGLYZE", "DİYABET"),
    ("ONGLYZA", "DİYABET"),
    ("SAXAGLIPTIN", "DİYABET"),
    ("ONZYD", "BULANTI KESİCİ"),
    ("ONDANSETRON", "BULANTI KESİCİ"),
    ("PERBRONS", "ÖKSÜRÜK KESİCİ"),
    ("NEFROSET", "BÖBREK HASTALIĞI İLACI"),
    ("FOTEROL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("OCURIN", "GLOKOM İLACI"),
    ("LITHURIL", "ANTİPSİKOTİK"),          # lityum
    ("LITYUM", "ANTİPSİKOTİK"),
    ("SIMGAST", "MİDE İLACI"),
    ("CIBINQO", "BİYOLOJİK İLAÇ"),
    ("CETMONT", "ASTIM İLACI"),
    ("PIASCLEDINE", "ROMATİZMA / İLTİHAP İLACI"),
    ("LUTINUS", "HORMON"),
    ("CASODEX", "KANSER İLACI"),           # bikalutamid
    ("BIKALUTAMID", "KANSER İLACI"),
    ("CASUKAL", "KANSER İLACI"),
    ("NETILCIN", "GÖZ İLACI"),
    ("RULID", "ANTİBİYOTİK"),              # roksitromisin
    ("ROKSITROMISIN", "ANTİBİYOTİK"),
    ("ONEPTUS", "KALP YETMEZLİĞİ İLACI"),  # sakubitril+valsartan
    ("GAMUNEX", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("FLEBOGAMMA", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("PRIVIGEN", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("OCTAGAM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("FENOKODIN", "ÖKSÜRÜK KESİCİ"),
    ("TEKFIN", "MANTAR İLACI"),            # terbinafin
    ("XALFU", "PROSTAT İLACI"),            # alfuzosin
    ("KALMOSAN", "ALLERJİ / KAŞINTI İLACI"),
    ("KALAMIN", "ALLERJİ / KAŞINTI İLACI"),
    ("RAZINA", "KALP RİTM İLACI"),         # ranolazin
    ("RANOLAZIN", "KALP RİTM İLACI"),
    ("RANEXA", "KALP RİTM İLACI"),
    ("GINERA", "DOĞUM KONTROL"),
    ("NERISONA", "CİLT İLACI (KORTİZON)"),
    ("SPASMOMEN", "KARIN AĞRISI / KASILMA İLACI"),
    ("OTILONIUM", "KARIN AĞRISI / KASILMA İLACI"),
    ("BEKUNIS", "KABIZLIK İLACI"),
    ("OMNISCAN", "RADYOLOJİK KONTRAST MADDESİ"),
    ("PROLUTON", "HORMON"),
    ("ZOSTEX", "ANTİVİRAL"),               # brivudin
    ("BRIVUDIN", "ANTİVİRAL"),
    ("BRONPAX", "ÖKSÜRÜK KESİCİ"),

    # ============ BATCH 7 — Ekstra çeşitli ============
    ("OXOPANE", "TANSİYON İLACI"),
    ("DIAMOX", "GÖZ İLACI"),               # asetazolamid
    ("ASETAZOLAMID", "GÖZ İLACI"),
    ("AZOPT", "GLOKOM İLACI"),
    ("BRINZOLAMID", "GLOKOM İLACI"),
    ("DORZOLAMID", "GLOKOM İLACI"),
    ("TRUSOPT", "GLOKOM İLACI"),
    ("MIRTAZON", "ANTİDEPRESAN"),
    ("PSORIASIS", "SEDEF HASTALIĞI İLACI"),
    ("XELJANZ", "BİYOLOJİK İLAÇ"),
    ("TOFACITINIB", "BİYOLOJİK İLAÇ"),
    ("RINVOQ", "BİYOLOJİK İLAÇ"),
    ("OLUMIANT", "BİYOLOJİK İLAÇ"),
    ("BARICITINIB", "BİYOLOJİK İLAÇ"),
    # Pediatrik / besleyici
    ("VIDAYLIN", "VİTAMİN DESTEĞİ"),
    ("PEDIVIT", "VİTAMİN DESTEĞİ"),
    # Lavman
    ("ENEMA", "KABIZLIK İLACI"),
    ("B.T. ENEMA", "KABIZLIK İLACI"),
    # Bronş genişleticiler
    ("CORTAIR", "ASTIM İLACI"),
    ("AIROCORT", "ASTIM İLACI (KORTİZON)"),
    # GUT / FMF
    ("GUT", "FMF / GUT TEDAVİSİ"),
    # MS
    ("OCREVUS", "MS İLACI"),
    ("LEMTRADA", "MS İLACI"),
    # IBS
    ("DUSPATAL", "KARIN AĞRISI / KASILMA İLACI"),
    ("MEVERIN", "KARIN AĞRISI / KASILMA İLACI"),
    # ANTIDOT
    ("NALOKSON", "ACİL İLACI"),
    ("NALMEFEN", "ALKOL BAĞIMLILIĞI"),
    # KAS
    ("FLEXISERIN", "KAS GEVŞETİCİ"),
    # MOOD STABILIZER
    ("VALPROL", "ANTİEPİLEPTİK"),
    # OLGOOSEMİ
    ("HUMANTROPE", "BÜYÜME HORMONU"),
    # TANI / BAĞIRSAK
    ("FECT", "BAĞIRSAK İLTİHABI İLACI"),
    # ALERJİ HOMEO
    ("LACERAN", "BURUN BAKIMI"),
    # SİVRİ SİNEK / İLAÇ
    ("CICAPLAST", "CİLT İLACI (DIŞ KULLANIM)"),
    # TIROİD KANSER
    ("THYROGEN", "GUATR İLACI"),
    # KAN BAĞIŞ
    ("ECULIZUMAB", "BİYOLOJİK İLAÇ"),
    ("SOLIRIS", "BİYOLOJİK İLAÇ"),

    # ============ BATCH 8 — Daha derin marka eşlemeleri ============
    ("FENABRIN", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("TACROLIN", "İMMÜNOSUPRESİF İLAÇ"),
    ("PROTAZ", "MİDE İLACI"),
    ("RILEPTID", "ANTİPSİKOTİK"),
    ("EMSELEX", "AŞIRI AKTİF MESANE İLACI"),
    ("DARIFENASIN", "AŞIRI AKTİF MESANE İLACI"),
    ("ELMIRON", "AŞIRI AKTİF MESANE İLACI"),
    ("SPASMEX", "AŞIRI AKTİF MESANE İLACI"),
    ("TROSPIUM", "AŞIRI AKTİF MESANE İLACI"),
    ("TARDYFERON", "DEMİR DESTEĞİ"),
    ("FERAMAT", "DEMİR DESTEĞİ"),
    ("EMFER", "DEMİR DESTEĞİ"),
    ("NEXETIN", "ANTİDEPRESAN"),
    ("DEPARTON", "ANTİDEPRESAN"),
    ("VIENOKS", "ANTİDEPRESAN"),
    ("URODAY", "ANTİBİYOTİK (İDRAR YOLU)"),  # fosfomisin
    ("MULTIMIX", "VİTAMİN DESTEĞİ"),
    ("DUACT", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("CODACTIV", "ÖKSÜRÜK KESİCİ"),
    ("LEDROPIN", "ÖKSÜRÜK KESİCİ"),
    ("LEVODROPROPIZIN", "ÖKSÜRÜK KESİCİ"),
    ("BUSICOD", "ÖKSÜRÜK KESİCİ"),
    ("TUSEBRON", "ÖKSÜRÜK KESİCİ"),
    ("ARPIN", "ANTİPSİKOTİK"),
    ("RILEPID", "ANTİPSİKOTİK"),
    ("QALYVIZ", "D VİTAMİNİ"),
    ("CALDEROL", "D VİTAMİNİ"),
    ("CALCITRON", "D VİTAMİNİ"),
    ("FESTAL", "SİNDİRİM ENZİMİ"),
    ("CREON", "SİNDİRİM ENZİMİ"),
    ("ROMATIM", "AĞRI KESİCİ"),
    ("KARBALEX", "ANTİEPİLEPTİK"),
    ("NIMEKSIL", "AĞRI KESİCİ"),
    ("SULIDIN", "AĞRI KESİCİ"),
    ("DEXPADU", "AĞRI KESİCİ"),
    ("DEXPLUS", "AĞRI KESİCİ"),
    ("ALEVE", "AĞRI KESİCİ"),
    ("VAGIFEM", "HORMON"),
    ("VASOCARD", "TANSİYON İLACI"),
    ("NORMOPRES", "TANSİYON İLACI"),
    ("HYPERIUM", "TANSİYON İLACI"),         # rilmenidin
    ("RILMENIDIN", "TANSİYON İLACI"),
    ("INSPRA", "KALP YETMEZLİĞİ İLACI"),    # eplerenon
    ("EPLERENON", "KALP YETMEZLİĞİ İLACI"),
    ("CALCIDAY", "KALSİYUM DESTEĞİ"),
    ("CALCI-D3", "KALSİYUM DESTEĞİ"),
    ("BONEPLUS", "KALSİYUM DESTEĞİ"),
    ("VEGABON", "KALSİYUM DESTEĞİ"),
    ("OS-VITAL", "KALSİYUM DESTEĞİ"),
    ("AIRPUFF", "ASTIM İLACI"),
    ("TOBRALOT", "GÖZ İLACI"),
    ("GONAPEPTYL", "KISIRLIK TEDAVİSİ"),
    ("TRIPTORELIN", "KISIRLIK TEDAVİSİ"),
    ("HUMANA", "BESLENME ÜRÜNÜ"),
    ("LUCENTIS", "GÖZ İLACI"),              # ranibizumab AMD
    ("RANIBIZUMAB", "GÖZ İLACI"),
    ("EYLEA", "GÖZ İLACI"),
    ("AFLIBERSEPT", "GÖZ İLACI"),
    ("SANTADINE", "ANTİBİYOTİK"),
    ("CRAVIT", "ANTİBİYOTİK"),               # levofloksasin
    ("ENCEF", "ANTİBİYOTİK"),
    ("ELIGARD", "KANSER İLACI"),              # leuprolid
    ("LEUPRORELIN", "KANSER İLACI"),
    ("LOCANEST", "LOKAL ANESTEZİK"),
    ("POT-OUT", "BÖBREK HASTALIĞI İLACI"),
    ("ANTI-POTASIUM", "BÖBREK HASTALIĞI İLACI"),
    ("KAYEXALATE", "BÖBREK HASTALIĞI İLACI"),
    ("PRELICA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("LYPRE", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("PREGABA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("EKSOFED", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("PATRIL", "MİDE İLACI"),
    ("PANTHEC", "MİDE İLACI"),
    ("PANOCER", "MİDE İLACI"),
    ("PROTINUM", "MİDE İLACI"),
    ("DUOLANS", "MİDE İLACI"),
    ("LARGACTIL", "ANTİPSİKOTİK"),          # klorpromazin
    ("KLORPROMAZIN", "ANTİPSİKOTİK"),
    ("CLOPIXOL", "ANTİPSİKOTİK"),
    ("MAXIDEX", "GÖZ İLACI"),               # zaten var
    ("CORTIMYCINE", "GÖZ İLACI"),
    ("VALIDOL", "BAŞ AĞRISI İLACI"),
    ("SPECTRACEF", "ANTİBİYOTİK"),
    ("SEFDITOREN", "ANTİBİYOTİK"),
    ("KONAZOL", "MANTAR İLACI"),
    ("ERTES", "ACİL DOĞUM KONTROL"),
    ("RESPIRO-D", "ASTIM İLACI"),
    ("RESPIRO", "ASTIM İLACI"),
    ("AIRFLUS", "ASTIM İLACI"),
    ("AIRCOMB", "ASTIM İLACI"),
    ("SERAIR", "ASTIM İLACI"),
    ("OXOTIDE", "SOMATOSTATİN İLACI"),
    ("OKTREOTID", "SOMATOSTATİN İLACI"),
    ("EUMOVATE", "CİLT İLACI (KORTİZON)"),  # klobetazon
    ("KLOBETAZON", "CİLT İLACI (KORTİZON)"),
    ("CUTIVATE", "CİLT İLACI (KORTİZON)"),
    ("TEMETEX", "CİLT İLACI (KORTİZON)"),
    ("DIPROSALIC", "CİLT İLACI (KORTİZON)"),
    ("LOTRIDERM", "CİLT İLACI (KORTİZON)"),
    ("CLIMARA", "HORMON"),
    ("DEPO-PROVERA", "HORMON"),
    ("HYQVIA", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("FLEBOGAMMA", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("NANOGAM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("TRIO", "MİDE İLACI"),                  # H. pylori paketi
    ("IRDA", "TANSİYON İLACI"),
    ("COBALEX", "B12 VİTAMİNİ DESTEĞİ"),
    ("SILVADIAZIN", "CİLT İLACI (YANIK)"),
    ("BRIMODER", "GLOKOM İLACI"),
    ("ARCAPTA", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("INDAKATEROL", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("NEOVEN", "ANTİDEPRESAN"),
    ("RHOGAM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("SYSTRAL", "ALLERJİ / KAŞINTI İLACI"),  # klorfeniramin
    ("KLORFENIRAMIN", "ALLERJİ / KAŞINTI İLACI"),
    ("PLAQUENIL", "ROMATİZMA / İLTİHAP İLACI"),
    ("HIDROKSIKLOROKIN", "ROMATİZMA / İLTİHAP İLACI"),
    ("PANLIFE", "BİTKİSEL DESTEK"),
    ("ÇÖREK", "BİTKİSEL DESTEK"),
    ("EKIPIM", "ANTİBİYOTİK"),
    ("OPAGIS", "MİDE İLACI"),
    ("AZELDERM", "SİVİLCE İLACI"),
    ("AZELAIK", "SİVİLCE İLACI"),
    ("AFTOJEL", "AĞIZ-DİŞ İLACI"),
    ("VENTOPIUM", "ASTIM İLACI"),
    ("TROMBOLIZ", "KAN SULANDIRICI"),
    ("TRIPLUS", "KARIN AĞRISI / KASILMA İLACI"),
    ("STREPNAZ", "BOĞAZ İLACI"),
    ("MOMESALIC", "CİLT İLACI (KORTİZON)"),
    ("COSEBLAR", "ASTIM İLACI"),
    ("GLINIUM", "ASTIM İLACI"),
    ("DEVAMOX", "ANTİBİYOTİK"),
    ("DENTAMAX", "ANTİBİYOTİK"),
    ("POLINOKSID", "VARİS İLACI"),
    ("POLIDOCANOL", "VARİS İLACI"),
    ("ELUCEF", "ANTİBİYOTİK"),
    ("FUCITHALMIC", "GÖZ İLACI"),
    ("VISINE", "GÖZ İLACI"),
    ("TETRAHIDROZOLIN", "GÖZ İLACI"),
    ("DIENILLE", "DOĞUM KONTROL"),
    ("DIENOGEST", "DOĞUM KONTROL"),
    ("MOFLODEKSA", "GÖZ İLACI"),
    ("ARITMAL", "KALP RİTM İLACI"),
    ("VIRGAN", "GÖZ İLACI"),
    ("GANSIKLOVIR", "GÖZ İLACI"),
    ("RITALIN", "DEHB İLACI"),
    ("RITALIN-LA", "DEHB İLACI"),
    ("ORNITOP", "ANTİBİYOTİK"),
    ("TESTOGEL", "HORMON"),
    ("ANDROGEL", "HORMON"),
    ("TESTOSTERON", "HORMON"),
    ("SALAGEN", "GLOKOM İLACI"),             # pilokarpin
    ("PILOKARPIN", "GLOKOM İLACI"),
    ("NEFOVIR", "HEPATİT İLACI"),
    ("HEDNAVIR", "HEPATİT İLACI"),
    ("SUBOXONE", "ALKOL BAĞIMLILIĞI"),
    ("METADON", "ALKOL BAĞIMLILIĞI"),
    ("ANTABUS", "ALKOL BAĞIMLILIĞI"),
    ("DISULFIRAM", "ALKOL BAĞIMLILIĞI"),
    ("SKYRIZI", "BİYOLOJİK İLAÇ"),
    ("RISANKIZUMAB", "BİYOLOJİK İLAÇ"),
    ("BEXSERO", "AŞI"),
    ("NIMENRIX", "AŞI"),
    ("MENVEO", "AŞI"),
    ("TRETIN", "SİVİLCE İLACI"),
    ("PIVERTEL", "KARIN AĞRISI / KASILMA İLACI"),
    ("RECTUS", "HEMOROİD İLACI"),
    ("FANHDI", "HEMOFİLİ İLACI"),
    ("FOLIDOCE", "FOLİK ASİT DESTEĞİ"),
    ("ZODINASIL", "ANTİBİYOTİK"),
    ("İHTİYOL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("IHTIYOL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("FLOCIP", "CİLT İLACI (ANTİBİYOTİK)"),
    ("BIOGAIA", "PROBİYOTİK"),
    ("REUTERI", "PROBİYOTİK"),
    ("DEKSAMET", "KORTİZON TEDAVİSİ"),
    ("ALZANCER", "ALZHEİMER İLACI"),
    ("MEMARI", "ALZHEİMER İLACI"),
    ("TRENTILIN", "TOPLARDAMAR / VARİS İLACI"),
    ("FLOXAPEN", "ANTİBİYOTİK"),
    ("FLUKLOKSASILIN", "ANTİBİYOTİK"),
    ("IPRATOM", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("LOTEBRA", "GÖZ İLACI"),
    ("LOTEPREDNOL", "GÖZ İLACI"),
    ("ALOMIDE", "GÖZ İLACI"),
    ("LODOKSAMID", "GÖZ İLACI"),
    ("POTCIT", "BÖBREK HASTALIĞI İLACI"),
    ("POTASYUM SITRAT", "BÖBREK HASTALIĞI İLACI"),
    ("ROVAMYCINE", "ANTİBİYOTİK"),
    ("VIGAROO", "EREKSİYON İLACI"),
    ("DONAXYL", "KADIN HASTALIKLARINDA"),
    ("DEKLUALINYUM", "KADIN HASTALIKLARINDA"),
    ("REPARIL-GEL", "TOPLARDAMAR / VARİS İLACI"),
    ("REPARIL", "TOPLARDAMAR / VARİS İLACI"),
    ("DENCOL", "AĞIZ-DİŞ İLACI"),
    ("PRIMOVIST", "RADYOLOJİK KONTRAST MADDESİ"),
    ("VANIKET", "CİLT İLACI (DIŞ KULLANIM)"),
    ("MAGVITAL", "MAGNEZYUM DESTEĞİ"),
    ("BETOPTIC", "GLOKOM İLACI"),
    ("BETAKSOLOL", "GLOKOM İLACI"),
    ("DEXTROCIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("DUPATIN", "GÖZ İLACI"),
    ("DIAFURYL", "İSHAL KESİCİ"),
    # FORM/MEDİKAL ÜRÜN
    ("LANSET", "TIBBİ MALZEME"),
    ("ŞEKER ÖLÇME", "TIBBİ MALZEME"),
    ("FORA", "TIBBİ MALZEME"),
    ("DEFANS", "TIBBİ MALZEME"),
    ("SİNEK", "TIBBİ MALZEME"),
    ("SPANISH FLY", "GIDA TAKVİYESİ"),
    # ÇOK YAYGIN ANTİBİYOTİK
    ("ALFASILIN", "ANTİBİYOTİK"),
    ("AMFENOL", "ANTİBİYOTİK"),
    # KEMOTERAPİ JENERİK
    ("DOSETAKSEL", "KANSER İLACI"),
    ("KAPESITABIN", "KANSER İLACI"),
    ("METHOTREXATE", "ROMATİZMA / İLTİHAP İLACI"),
    ("RITUKSIMAB", "BİYOLOJİK İLAÇ"),
    # GENİŞLETİLMİŞ alerji
    ("ALERSET", "ALLERJİ / KAŞINTI İLACI"),
    ("ANTIFEN", "ALLERJİ / KAŞINTI İLACI"),
    # KEMİK
    ("ALENDRA", "OSTEOPOROZ İLACI"),
    ("OSTERON", "OSTEOPOROZ İLACI"),
    # AKCİĞER
    ("MUCOFLU", "ÖKSÜRÜK KESİCİ"),
    # KOLON
    ("CITRAFLEET", "KOLON TEMİZLEYİCİ"),
    ("PICOLAX", "KOLON TEMİZLEYİCİ"),
    # NASAL DAMLA / SPRAY
    ("XYMELYN", "BURUN AÇICI"),
    ("XYLOMETAZOLIN", "BURUN AÇICI"),
    # ROMATIZMA
    ("ARAVA", "ROMATİZMA / İLTİHAP İLACI"),  # zaten var
    ("LEFLUR", "ROMATİZMA / İLTİHAP İLACI"),
    # ŞAMPUAN
    ("SELSUN", "MANTAR İLACI"),
    # MARKER
    ("EZILON", "TANSİYON İLACI"),
    # ANTIASTHM
    ("MONTECREST", "ASTIM İLACI"),
    # MİDE PILORI
    ("HYLAK", "PROBİYOTİK"),
    # SAĞLIK MALZEMELER
    ("INFLUVAC", "AŞI"),
    # DUO HAP
    ("DUOPLAVIN", "KAN SULANDIRICI"),
    # CO-IRDA gibiler
    ("CO-DIOVAN", "TANSİYON İLACI"),
    # MIRR
    ("MIRR", "ANTİDEPRESAN"),

    # ============ BATCH 9 — Toplu çoklu marka eşlemeleri ============
    ("HYTRIN", "TANSİYON İLACI / PROSTAT İLACI"),  # terazosin
    ("TERAZOSIN", "TANSİYON İLACI / PROSTAT İLACI"),
    ("ARTROCOL", "AĞRI KESİCİ"),
    ("MAXALJIN", "AĞRI KESİCİ"),
    ("TARIVID", "ANTİBİYOTİK"),
    ("OFLOKSASIN", "ANTİBİYOTİK"),
    ("AZAX", "ANTİBİYOTİK"),
    ("LEVONAT", "ANTİBİYOTİK"),
    ("FLOXILEVO", "ANTİBİYOTİK"),
    ("CRAVIT", "ANTİBİYOTİK"),               # zaten var
    ("LEVOFLOK", "ANTİBİYOTİK"),
    ("FULSAC", "ANTİDEPRESAN"),              # fluoksetin
    ("CALIRA-MET", "DİYABET"),               # linagliptin+metformin
    ("PERIVEL", "TANSİYON İLACI"),
    ("DERMO-REST", "MANTAR İLACI"),
    ("SINEGRA", "EREKSİYON İLACI"),
    ("CAPCIDERM", "AĞRI KESİCİ"),
    ("KAPSAISIN", "AĞRI KESİCİ"),
    ("OPTIRAY", "RADYOLOJİK KONTRAST MADDESİ"),
    ("BRUPREX", "AĞRI KESİCİ"),
    ("FLUOSINE", "KANSER İLACI"),
    ("PHOS-NO", "BÖBREK HASTALIĞI İLACI"),
    ("HIPPURIN", "ANTİBİYOTİK (İDRAR YOLU)"),
    ("FIX-AT", "BÖBREK HASTALIĞI İLACI"),
    ("RENALAMER", "BÖBREK HASTALIĞI İLACI"),
    ("SEVAREN", "BÖBREK HASTALIĞI İLACI"),
    ("SEVELAMER", "BÖBREK HASTALIĞI İLACI"),
    ("FOSRENOL", "BÖBREK HASTALIĞI İLACI"),
    ("LANTHANUM", "BÖBREK HASTALIĞI İLACI"),
    ("NORM-ASIDOZ", "BÖBREK HASTALIĞI İLACI"),
    ("PARICAL", "D VİTAMİNİ"),
    ("PARIKALSITOL", "D VİTAMİNİ"),
    ("SIMKELMA", "BÖBREK HASTALIĞI İLACI"),
    ("PATIROMER", "BÖBREK HASTALIĞI İLACI"),
    ("MYCOZINC", "MANTAR İLACI"),
    ("BERAVIT", "B VİTAMİNİ DESTEĞİ"),
    ("RISONEL", "BURUN İLACI"),
    ("TUSCOD", "ÖKSÜRÜK KESİCİ"),
    ("MOTIS", "ALZHEİMER İLACI"),            # donezepil
    ("NIDICARD", "TANSİYON İLACI"),
    ("FUNGINAIL", "MANTAR İLACI"),
    ("TIOFIX", "ASTIM İLACI"),
    ("TIODAY", "ASTIM İLACI"),
    ("SPIRACT", "ASTIM İLACI"),
    ("GABATEVA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("MYFORTIC", "İMMÜNOSUPRESİF İLAÇ"),
    ("ROSUVAS", "KOLESTEROL İLACI"),
    ("CHOLVAST", "KOLESTEROL İLACI"),
    ("LIVAZO", "KOLESTEROL İLACI"),
    ("PITAVASTATIN", "KOLESTEROL İLACI"),
    ("EZETEC", "KOLESTEROL İLACI"),
    ("EZETIMIB", "KOLESTEROL İLACI"),
    ("INEGY", "KOLESTEROL İLACI"),
    ("SUPPORTAN", "BESLENME ÜRÜNÜ"),
    ("INFASOURCE", "BESLENME ÜRÜNÜ"),
    ("SOLARVIT", "D VİTAMİNİ"),
    ("DUTAPROS", "PROSTAT İLACI"),
    ("SIPRAKTIN", "ALLERJİ / KAŞINTI İLACI"),
    ("PRAKTEN", "ALLERJİ / KAŞINTI İLACI"),
    ("SIPROHEPTADIN", "ALLERJİ / KAŞINTI İLACI"),
    ("CELESTONE", "KORTİZON TEDAVİSİ"),
    ("DIPROSPAN", "KORTİZON TEDAVİSİ"),
    ("DIPROVER", "KORTİZON TEDAVİSİ"),
    ("ASTONIN", "KORTİZON TEDAVİSİ"),
    ("FLUDROKORTIZON", "KORTİZON TEDAVİSİ"),
    ("SEREX", "ANTİPSİKOTİK"),               # kuetiapin
    ("ZYZAPIN", "ANTİPSİKOTİK"),
    ("CLOZARIL", "ANTİPSİKOTİK"),
    ("KLOZAPIN", "ANTİPSİKOTİK"),
    ("STILIZAN", "ANTİPSİKOTİK"),
    ("FLUFENAZIN", "ANTİPSİKOTİK"),
    ("MERESA", "ANTİPSİKOTİK"),
    ("IGNIS", "ANTİPSİKOTİK"),
    ("PALIGIS", "ANTİPSİKOTİK"),
    ("LUTICASS", "ASTIM İLACI"),
    ("ALVESCO", "ASTIM İLACI (KORTİZON)"),
    ("SIKLESONID", "ASTIM İLACI (KORTİZON)"),
    ("FLIXAIR", "ASTIM İLACI"),
    ("FLOBEN", "ASTIM İLACI"),
    ("MAGNESIUM", "MAGNEZYUM DESTEĞİ"),
    ("RAZOGEN", "MİDE İLACI"),
    ("NEWCAL", "KALSİYUM DESTEĞİ"),
    ("OROFERON", "DEMİR DESTEĞİ"),
    ("GYNOFERON", "DEMİR DESTEĞİ"),
    ("FOLIODE", "FOLİK ASİT DESTEĞİ"),
    ("RIMOBOLAN", "HORMON"),
    ("SUSTANON", "HORMON"),
    ("NEBIDO", "HORMON"),
    ("DUXALTA", "ANTİDEPRESAN"),
    ("ESLOTIN", "ANTİDEPRESAN"),
    ("LOSIRAM", "ANTİDEPRESAN"),
    ("BUPRAPAN", "ANTİDEPRESAN"),
    ("ZYBAN", "SİGARA BIRAKMA"),
    ("ANAFRANIL", "ANTİDEPRESAN"),
    ("KLOMIPRAMIN", "ANTİDEPRESAN"),
    ("ARIA-DES", "ALLERJİ / KAŞINTI İLACI"),
    ("PULMOREST", "ÖKSÜRÜK KESİCİ"),
    ("MUCOPLUS", "ÖKSÜRÜK KESİCİ"),
    ("FULLCEF", "ANTİBİYOTİK"),
    ("TEXEF", "ANTİBİYOTİK"),
    ("MEIACT", "ANTİBİYOTİK"),
    ("AZYTER", "GÖZ İLACI"),
    ("MOXAGUT", "GÖZ İLACI"),                # zaten var
    ("MOXIDEXA", "GÖZ İLACI"),
    ("IECILLINE", "ANTİBİYOTİK"),
    ("CEFOZIN", "ANTİBİYOTİK"),
    ("BENZILPENISILIN", "ANTİBİYOTİK"),
    ("AMIJEKSIN", "ANTİBİYOTİK"),
    ("AMIKASIN", "ANTİBİYOTİK"),
    ("MADESCAR", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("RESTASIS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("DRYEX", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("HYONAT", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("GENVOYA", "HIV İLACI"),
    ("TRUVENT", "HIV İLACI"),
    ("BARAVIR", "HEPATİT İLACI"),
    ("ZEFFIX", "HEPATİT İLACI"),
    ("LAMIVUDIN", "HEPATİT İLACI"),
    ("ROTATEQ", "AŞI"),
    ("SHINGRIX", "AŞI"),
    ("ROTARIX", "AŞI"),                       # zaten var
    ("ALOPEXY", "SAÇ DÖKÜLMESİ İLACI"),
    ("MIRENA", "DOĞUM KONTROL"),
    ("ORGAMETRIL", "DOĞUM KONTROL"),
    ("LINESTRENOL", "DOĞUM KONTROL"),
    ("RAGI", "MİDE İLACI"),
    ("LANSOPROL", "MİDE İLACI"),
    ("OMHEAL", "MİDE İLACI"),
    ("ESODAX", "MİDE İLACI"),
    ("GASTROFAM", "MİDE İLACI"),
    ("RANITAB", "MİDE İLACI"),
    ("PANTACTIVE", "MİDE İLACI"),
    ("VOGAST", "MİDE İLACI"),
    ("BIZMOPEN", "MİDE İLACI"),
    ("SIMBRINZA", "GLOKOM İLACI"),
    ("COMBIGAN", "GLOKOM İLACI"),
    ("LATAFREE", "GLOKOM İLACI"),
    ("MODIWAKE", "UYANIKLIK İLACI"),
    ("AGNUCASTON", "BİTKİSEL DESTEK"),
    ("BALEN", "BİTKİSEL DESTEK"),
    ("PALMETTO", "BİTKİSEL DESTEK"),
    ("ISIRGAN", "BİTKİSEL DESTEK"),
    ("MINAFEN", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("GRIPORT", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("SNOXX-MET", "DİYABET"),
    ("LINATIN", "DİYABET"),
    ("BASAGLAR", "DİYABET"),
    ("DROFLU", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("PANALGINE", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("EFIKAS", "DİYABET"),
    ("GLIKLAZID", "DİYABET"),                # zaten var
    ("ACLOREM", "CİLT İLACI (KORTİZON)"),
    ("SENSICORT", "CİLT İLACI (KORTİZON)"),
    ("DILOPIN", "TANSİYON İLACI"),
    ("KAPTORIL", "TANSİYON İLACI"),
    ("INDURIN", "TANSİYON İLACI"),
    ("ROMACTIL", "KAS GEVŞETİCİ"),
    ("ANDROCUR", "HORMON"),
    ("AGRILOR", "AĞRI KESİCİ"),
    ("ETORIKOKSIB", "AĞRI KESİCİ"),
    ("ARCOXIA", "AĞRI KESİCİ"),
    ("CAFERGOT", "MİGREN İLACI"),
    ("ERGOTAMIN", "MİGREN İLACI"),
    ("AKNEFLOKS", "CİLT İLACI (ANTİBİYOTİK)"),
    ("EPLEDAY", "KALP YETMEZLİĞİ İLACI"),
    ("FLOSE", "BURUN İLACI"),
    ("FLUTEL", "BURUN İLACI"),
    ("PROLUTEX", "HORMON"),
    ("DALMAN", "BURUN İLACI"),
    ("NAZOBEC", "BURUN İLACI"),
    ("MEBUCAIN", "BOĞAZ İLACI"),
    ("CLIACIL", "ANTİBİYOTİK"),
    ("PENISILIN V", "ANTİBİYOTİK"),
    ("DEXFULL", "AĞRI KESİCİ"),
    ("BUTAMCOD", "ÖKSÜRÜK KESİCİ"),
    ("PULMOTUS", "ÖKSÜRÜK KESİCİ"),
    ("CLOGAN", "KAN SULANDIRICI"),
    ("OKSAMEN", "AĞRI KESİCİ"),
    ("EXELDERM", "MANTAR İLACI"),
    ("FUNGOID", "MANTAR İLACI"),
    ("MANTAZOL", "MANTAR İLACI"),
    ("FUNDERYL", "MANTAR İLACI"),
    ("FURADERM", "MANTAR İLACI"),
    ("TADLIS", "EREKSİYON İLACI"),
    ("EMLA", "LOKAL ANESTEZİK"),
    ("FLUZAMED", "MANTAR İLACI"),
    ("DICLACTIVE", "AĞRI KESİCİ"),
    ("GEROFEN", "AĞRI KESİCİ"),
    ("SIMFLAT", "KARIN GAZI İLACI"),
    ("BENZAMYCIN", "SİVİLCE İLACI"),
    ("CLARICIDE", "ANTİBİYOTİK"),
    ("KLARITRO", "ANTİBİYOTİK"),             # zaten var
    ("KLO-SAL", "CİLT İLACI (KORTİZON)"),
    ("BIEMEXOL", "RADYOLOJİK KONTRAST MADDESİ"),
    ("LUMINALETTEN", "ANTİEPİLEPTİK"),
    ("FENOBARBITAL", "ANTİEPİLEPTİK"),
    ("URSOFALK", "KARACİĞER İLACI"),
    ("ZOFRAN", "BULANTI KESİCİ"),
    ("PHOS-OUT", "BÖBREK HASTALIĞI İLACI"),  # zaten var
    ("ROTAVIRUS", "AŞI"),
    ("INFLUENZA", "AŞI"),
    ("MENINGITIS", "AŞI"),
    ("PASSEAR", "KULAK İLACI"),
    ("OTOLIN", "KULAK İLACI"),
    ("KEDIROL", "KAS GEVŞETİCİ"),
    ("MIDOCALM", "KAS GEVŞETİCİ"),

    # ============ BATCH 9 — Sefalosporin/penisilin marka ailesi ============
    # Çoğu xxxCEF, CEFxxx, xxxCILLIN paterni
    ("CEFADUR", "ANTİBİYOTİK"),
    ("CEFAGEN", "ANTİBİYOTİK"),
    ("CEFAGUR", "ANTİBİYOTİK"),
    ("CEFAKS", "ANTİBİYOTİK"),
    ("CEFASYN", "ANTİBİYOTİK"),
    ("CEFAZER", "ANTİBİYOTİK"),
    ("CEFAZIN", "ANTİBİYOTİK"),
    ("CEFLOR", "ANTİBİYOTİK"),
    ("CEFOTAX", "ANTİBİYOTİK"),
    ("CEFOZIN", "ANTİBİYOTİK"),
    ("DEKSEF", "ANTİBİYOTİK"),
    ("DEPSEF", "ANTİBİYOTİK"),
    ("LONSEF", "ANTİBİYOTİK"),
    ("MAKSIPOR", "ANTİBİYOTİK"),
    ("MEROCEF", "ANTİBİYOTİK"),
    ("PROCEF", "ANTİBİYOTİK"),
    ("PROCID", "ANTİBİYOTİK"),
    ("CECLOR", "ANTİBİYOTİK"),
    ("MOLKEF", "ANTİBİYOTİK"),
    ("UNICEF", "ANTİBİYOTİK"),
    ("SUPRACEF", "ANTİBİYOTİK"),
    # MOXIFLOX/CIPROFLOX paterni
    ("MOXICA", "ANTİBİYOTİK"),
    ("CIPROZ", "ANTİBİYOTİK"),
    ("CIPRO-DEXA", "GÖZ İLACI"),
    # ATORVASTATIN benzerleri
    ("LIPDOWN", "KOLESTEROL İLACI"),
    ("LIPRIMAR", "KOLESTEROL İLACI"),
    ("ATOMINEX", "DEHB İLACI"),              # zaten var
    # METFORMİN aileleri
    ("BIOMET", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("METFAST", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("METPHARM", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("METFOR", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    # AMLODIPIN aileleri
    ("LODICOX", "TANSİYON İLACI"),
    ("AMLOZER", "TANSİYON İLACI"),
    ("AMLOLET", "TANSİYON İLACI"),
    # KAS GEVŞETİCİ
    ("MIORELAX", "KAS GEVŞETİCİ"),
    ("MUSCLO", "KAS GEVŞETİCİ"),
    # YENİDEN BAŞKA İPUÇLARI
    ("ACTIDEM", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("MUCOFLU", "ÖKSÜRÜK KESİCİ"),
    ("MUCOLIT", "ÖKSÜRÜK KESİCİ"),           # zaten var

    # ============ BATCH 10 — Daha derin marka eşlemeleri ============
    ("COMBIPACK", "ASTIM İLACI"),
    ("EASYHALER", "ASTIM İLACI"),
    ("LIPOLIN", "ANTİEPİLEPTİK / SİNİR AĞRISI"),  # α-lipoik asit
    ("ALA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("THIOCTACID", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("BURNIL", "BURUN AÇICI"),
    ("METCEF", "ANTİBİYOTİK"),
    ("GLUFORCE", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("ANPEKS", "KARIN AĞRISI / KASILMA İLACI"),
    ("HERPAZON", "ANTİVİRAL"),
    ("SPAZMOL", "KARIN AĞRISI / KASILMA İLACI"),
    ("ALDARA", "SİVİLCE İLACI"),             # imikimod
    ("IMIKIMOD", "CİLT İLACI (DIŞ KULLANIM)"),
    ("MESTINON", "MİYASTENİA İLACI"),
    ("PIRIDOSTIGMIN", "MİYASTENİA İLACI"),
    ("RAMELDA", "UYKU İLACI"),               # ramelteon
    ("RAMELTEON", "UYKU İLACI"),
    ("DEXPANTEN", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("DEKSPANTENOL", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("PANTHENOL", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("LETU", "KANSER İLACI"),                # letrozol
    ("LETROZOL", "KANSER İLACI"),
    ("KALINOR", "ELEKTROLİT"),
    ("BROKSIN", "ÖKSÜRÜK KESİCİ"),
    ("BROMHEKZIN", "ÖKSÜRÜK KESİCİ"),
    ("SIGMASPORIN", "İMMÜNOSUPRESİF İLAÇ"),
    ("DROSPORIN", "İMMÜNOSUPRESİF İLAÇ"),
    ("AZEKAZ", "BURUN İLACI"),
    ("ORALDIN", "AĞIZ-DİŞ İLACI"),
    ("DEMENT", "ALZHEİMER İLACI"),
    ("REMEMBA", "ALZHEİMER İLACI"),
    ("MEMARI", "ALZHEİMER İLACI"),
    ("ESOPRAL", "MİDE İLACI"),
    ("TRICEF", "ANTİBİYOTİK"),
    ("BEFIXO", "ANTİBİYOTİK"),
    ("ATAFLOKS", "ANTİBİYOTİK"),
    ("INVANZ", "ANTİBİYOTİK"),               # ertapenem
    ("ERTAPENEM", "ANTİBİYOTİK"),
    ("ACTRAPID", "DİYABET"),
    ("HUMULIN", "DİYABET"),                  # zaten var
    ("IBU-BABY", "AĞRI KESİCİ"),
    ("DIAZOMID", "GLOKOM İLACI"),
    ("DERMITON", "CİLT İLACI"),
    ("LORDES", "ALLERJİ / KAŞINTI İLACI"),
    ("ALERINIT", "ALLERJİ / KAŞINTI İLACI"),
    ("MAYFEX", "ALLERJİ / KAŞINTI İLACI"),
    ("EMADINE", "GÖZ İLACI"),
    ("SALOFALK", "BAĞIRSAK İLTİHABI İLACI"),
    ("SALAZOPYRIN", "BAĞIRSAK İLTİHABI İLACI"),
    ("MESAIN", "BAĞIRSAK İLTİHABI İLACI"),
    ("SALMIDEN", "BAĞIRSAK İLTİHABI İLACI"),
    ("VENAPERTA", "KAN SULANDIRICI (İĞNE)"),
    ("NADROPARIN", "KAN SULANDIRICI (İĞNE)"),
    ("ADEPIRON", "AĞRI KESİCİ"),
    ("METAMIZOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),  # zaten var
    ("RESTAFEN", "AĞRI KESİCİ"),
    ("LOPERMID", "İSHAL KESİCİ"),
    ("ACTOS", "DİYABET"),                     # pioglitazon
    ("PIOGLITAZON", "DİYABET"),
    ("STARLIX", "DİYABET"),                   # nateglinid
    ("NATEGLINID", "DİYABET"),
    ("GLUCOTROL", "DİYABET"),
    ("GLIPIZID", "DİYABET"),                  # zaten var
    ("TRIVASTAL", "PARKİNSON İLACI"),
    ("PIRIBEDIL", "PARKİNSON İLACI"),
    ("PACTO", "PARKİNSON İLACI"),
    ("ANTIPAR", "PARKİNSON İLACI"),
    ("KONAKION", "K VİTAMİNİ DESTEĞİ"),
    ("VITAMIN K", "K VİTAMİNİ DESTEĞİ"),
    ("LEVOWORLD", "GÖZ İLACI"),
    ("LEVOXIMED", "GÖZ İLACI"),
    ("CILOXAN", "GÖZ İLACI"),                # zaten var
    ("EXOCIN", "GÖZ İLACI"),
    ("MOXAI", "GÖZ İLACI"),
    ("MOXAFLOX", "GÖZ İLACI"),
    ("THILO-TEARS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("VERRUTOL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("CARVEXAL", "TANSİYON İLACI"),
    ("INBROXA", "NEFES AÇICI (BRONKODİLATÖR)"),
    ("MICLAST", "MANTAR İLACI"),
    ("SICLOPIROKS", "MANTAR İLACI"),
    ("SIROKSIL", "MANTAR İLACI"),
    ("DEXANETIL", "GÖZ İLACI"),
    ("DEKSAMETAZON", "KORTİZON TEDAVİSİ"),
    ("DEMROSE", "B VİTAMİNİ DESTEĞİ"),
    ("ASEC", "ANTİVİRAL"),
    ("ANDROVIUM", "SAÇ DÖKÜLMESİ İLACI"),
    ("FINHAIR", "SAÇ DÖKÜLMESİ İLACI"),
    ("FINASTERID", "SAÇ DÖKÜLMESİ İLACI"),
    ("LEKARNITIN", "BESLENME ÜRÜNÜ"),
    ("L-KARNITIN", "BESLENME ÜRÜNÜ"),
    ("LUXAT", "ASTIM İLACI"),
    ("LEVOKAST", "ASTIM İLACI"),
    ("BALABAN", "CİLT İLACI (DIŞ KULLANIM)"),
    ("ERITSA", "SİVİLCE İLACI"),
    ("ETREXIN", "SİVİLCE İLACI"),
    ("ISOTREXIN", "SİVİLCE İLACI"),
    ("BENZAMYCIN", "SİVİLCE İLACI"),         # zaten var
    ("BENZALIN", "SİVİLCE İLACI"),
    ("MONODUR", "TANSİYON İLACI"),           # isosorbid
    ("MONOKET", "TANSİYON İLACI"),           # zaten var
    ("IMUPRET", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("POLIVIT", "VİTAMİN DESTEĞİ"),
    ("LEVEMAX", "ANTİEPİLEPTİK"),
    ("LEVETIRASETAM", "ANTİEPİLEPTİK"),       # zaten var
    ("CANLOX", "TANSİYON İLACI"),
    ("VALCOR", "TANSİYON İLACI"),
    ("URSOMED", "KARACİĞER İLACI"),
    ("KORTILON", "KORTİZON TEDAVİSİ"),
    ("DETROITS", "KAS GEVŞETİCİ"),
    ("DESTIYO", "KAS GEVŞETİCİ"),
    ("MUNDERM", "CİLT İLACI (DIŞ KULLANIM)"),
    ("DUODERM", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("MEGACE", "KANSER İLACI"),               # megestrol
    ("MEGESTROL", "KANSER İLACI"),
    ("XOLAIR", "BİYOLOJİK İLAÇ"),
    ("RIVOCLON", "ANTİEPİLEPTİK"),
    ("KLONAZEPAM", "ANTİEPİLEPTİK"),          # zaten var (anksiyolitik)
    ("HEPARGRIZOVIM", "B VİTAMİNİ DESTEĞİ"),
    ("VITOEL-D3", "D VİTAMİNİ"),
    ("FORTE-D", "D VİTAMİNİ"),
    ("D-3 FEROL", "D VİTAMİNİ"),
    ("PEDIA-D", "D VİTAMİNİ"),
    ("ABETYL", "KAN SULANDIRICI"),           # aspirin
    ("POVISOL", "ANTİSEPTİK"),
    ("POVIDON", "ANTİSEPTİK"),
    ("BATTICON", "ANTİSEPTİK"),
    ("ISOSEPT", "ANTİSEPTİK"),
    ("CERIS", "ANTİSEPTİK"),
    ("OCTENISEPT", "ANTİSEPTİK"),
    ("MINAMOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("SERUM FIZYOLIJIK", "ELEKTROLİT"),
    ("SERUM FIZYOLOJIK", "ELEKTROLİT"),
    ("SERUM FİZYOLOJİK", "ELEKTROLİT"),
    ("HELISEN", "ALERJİ AŞISI"),
    ("BEXSERO", "AŞI"),                       # zaten var
    ("DEPHASTON", "HORMON"),
    ("DUPHASTON", "HORMON"),
    ("DIDROGESTERON", "HORMON"),
    ("PRIMOLUT", "HORMON"),
    ("NORETISTERON", "HORMON"),
    ("UROGRAFIN", "RADYOLOJİK KONTRAST MADDESİ"),
    ("BIEMEXOL", "RADYOLOJİK KONTRAST MADDESİ"),  # zaten var
    ("OPTIMARK", "RADYOLOJİK KONTRAST MADDESİ"),
    ("OPTIRAY", "RADYOLOJİK KONTRAST MADDESİ"),
    ("SILVAMED", "CİLT İLACI (YANIK)"),
    ("SEDERGINE", "AĞRI KESİCİ"),
    ("RILUTEK", "MS İLACI"),
    ("RILUZOLE", "MS İLACI"),
    ("HIBERIX", "AŞI"),
    ("SODYUM BIKARBONAT", "BÖBREK HASTALIĞI İLACI"),
    ("RAMELTEON", "UYKU İLACI"),
    ("KETOBER", "CİLT İLACI"),
    ("SEKROL", "ÖKSÜRÜK KESİCİ"),
    ("SERODERM", "CİLT İLACI (KORTİZON)"),
    ("PEFSAL", "ASTIM İLACI"),
    ("PASSIFLORA", "BİTKİSEL DESTEK"),
    ("PASSIFL", "BİTKİSEL DESTEK"),
    ("PASSIBLE", "BİTKİSEL DESTEK"),
    ("ISOPTIN", "TANSİYON İLACI"),           # verapamil
    ("VERAPAMIL", "TANSİYON İLACI"),
    ("MORFIA", "AĞRI KESİCİ (KUVVETLİ)"),
    ("OPHTAL", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("NATURA OPHTAL", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("NOROGRIZOVIM", "B VİTAMİNİ DESTEĞİ"),
    ("URISPAS", "AŞIRI AKTİF MESANE İLACI"),
    ("FLAVOKSAT", "AŞIRI AKTİF MESANE İLACI"),
    ("GABTIN", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("GLUCAGEN", "ACİL İLACI"),
    ("GLUKAGON", "ACİL İLACI"),
    ("RINOGEST", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("TUTAST", "ASTIM İLACI"),
    ("BIKTARVY", "HIV İLACI"),
    ("DIPROMED", "KORTİZON TEDAVİSİ"),
    ("FLOSE", "BURUN İLACI"),                # zaten var
    ("FLUTEL", "BURUN İLACI"),               # zaten var
    ("FLUTEL-F", "BURUN İLACI"),
    ("FLUTIKAZON", "ASTIM İLACI (KORTİZON)"),  # zaten var
    ("SEBRALER", "ASTIM İLACI"),
    ("KALSIMAG", "KALSİYUM DESTEĞİ"),
    ("CALCIDOL", "KALSİYUM DESTEĞİ"),
    ("GE-ORAL", "ELEKTROLİT"),
    ("ORALYTE", "ELEKTROLİT"),
    ("REHIDRATASYON", "ELEKTROLİT"),
    ("VFEND", "MANTAR İLACI"),               # vorikonazol
    ("VORIKONAZOL", "MANTAR İLACI"),
    ("JODID", "GUATR İLACI"),
    ("POTASYUM IYODUR", "GUATR İLACI"),
    ("GRIPAMOL", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("NORMOTRI", "TANSİYON İLACI"),
    ("UROMAX", "PROSTAT İLACI"),
    ("HEPA-ORNITAT", "KARACİĞER İLACI"),
    ("HEPATEL", "KARACİĞER İLACI"),
    ("HEPAMERZ", "KARACİĞER İLACI"),
    ("TIOPATI", "B VİTAMİNİ DESTEĞİ"),
    ("AMGEVITA", "BİYOLOJİK İLAÇ"),
    ("XEPLION", "ANTİPSİKOTİK"),
    ("COMBIVENT", "ASTIM İLACI"),
    ("LOTEFORTE", "GÖZ İLACI"),
    ("PRED FORTE", "GÖZ İLACI"),
    ("PRED MILD", "GÖZ İLACI"),
    ("PREDNIZOLON ASETAT", "GÖZ İLACI"),
    ("TAFINLAR", "KANSER İLACI"),
    ("DABRAFENIB", "KANSER İLACI"),
    ("METOPRIM", "ANTİBİYOTİK"),
    ("KEMOPRIM", "ANTİBİYOTİK"),
    ("PEREBRON", "ÖKSÜRÜK KESİCİ"),
    ("PEDITUS", "ÖKSÜRÜK KESİCİ"),
    ("HYDRYLLIN", "ÖKSÜRÜK KESİCİ"),
    ("LULIZOL", "MANTAR İLACI"),
    ("LULICONAZOL", "MANTAR İLACI"),
    ("FIVESAL", "MANTAR İLACI"),
    ("PRECOXIN", "AĞIZ-DİŞ İLACI"),
    ("DOLGIT", "AĞRI KESİCİ"),
    ("CYCLADOL", "AĞRI KESİCİ"),
    ("NADIXA", "CİLT İLACI (ANTİBİYOTİK)"),
    ("NADIFLOKSASIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("FOSFAT-EX", "BÖBREK HASTALIĞI İLACI"),
    ("RANEKS", "MİDE İLACI"),
    ("LODINE", "AĞRI KESİCİ"),
    ("ETODOLAK", "AĞRI KESİCİ"),             # zaten var
    ("CAMILLA", "AĞRI KESİCİ"),
    ("AGRILOR", "AĞRI KESİCİ"),              # zaten var
    ("AVITOREL", "ANTİDEPRESAN"),
    ("ALFAMET", "TANSİYON İLACI"),           # metildopa
    ("METILDOPA", "TANSİYON İLACI"),
    ("EYLEA", "GÖZ İLACI"),                  # zaten var
    ("ANRECTA", "HEMOROİD İLACI"),
    ("ANTI-BIT", "BİT / UYUZ İLACI"),
    ("EPOSTIN", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("OMEPRAZID", "MİDE İLACI"),
    ("COMBIDEX", "GÖZ İLACI"),
    ("GRANITRON", "BULANTI KESİCİ"),
    ("EMETRIL", "BULANTI KESİCİ"),
    ("ETOTAC", "AĞRI KESİCİ"),
    ("SIBELIUM", "MİGREN İLACI"),            # flunarizin
    ("FLUNARIZIN", "MİGREN İLACI"),
    ("AVICAP", "D VİTAMİNİ"),
    ("KORDEXA", "KORTİZON TEDAVİSİ"),
    ("TIVICAY", "HIV İLACI"),
    ("DOLUTEGRAVIR", "HIV İLACI"),
    ("HELICOL", "MİDE İLACI"),
    ("RABELIS", "MİDE İLACI"),
    ("PANDEV", "MİDE İLACI"),
    ("NEXSTEP", "MİDE İLACI"),
    ("VULGAREX", "CİLT İLACI (DIŞ KULLANIM)"),
    ("TIO-DEXIREN", "B VİTAMİNİ DESTEĞİ"),
    ("MODIODAL", "UYANIKLIK İLACI"),
    ("JAKAVI", "KANSER İLACI"),
    ("RUKSOLITINIB", "KANSER İLACI"),
    ("CINESET", "BÖBREK HASTALIĞI İLACI"),   # sinakalset
    ("SINAKALSET", "BÖBREK HASTALIĞI İLACI"),
    ("MIFLONID", "ASTIM İLACI (KORTİZON)"),
    ("BUDESONID", "ASTIM İLACI (KORTİZON)"),  # zaten var
    ("PURDOX", "CİLT İLACI (DIŞ KULLANIM)"),
    ("LAXENO", "KABIZLIK İLACI"),
    ("SUBMEX", "AĞRI KESİCİ (KUVVETLİ)"),    # buprenorfin
    ("BUPRENORFIN", "AĞRI KESİCİ (KUVVETLİ)"),
    ("IG VENA", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("DROPOETIN", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("NITRODERM", "TANSİYON İLACI"),
    ("NITROGLISERIN", "TANSİYON İLACI"),
    ("ACUFIX", "GÖZ İLACI"),
    ("OTIPAX", "KULAK İLACI"),
    ("DERISIV", "CİLT İLACI"),
    ("STATA", "KOLESTEROL İLACI"),
    ("KOMOX", "AŞIRI AKTİF MESANE İLACI"),
    ("ALATAB", "ALLERJİ / KAŞINTI İLACI"),
    ("SULJEL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("ADACEL", "AŞI"),
    ("KLOMEN", "KISIRLIK TEDAVİSİ"),
    ("KLOMIFEN", "KISIRLIK TEDAVİSİ"),
    ("PERFOSE", "BÖBREK HASTALIĞI İLACI"),
    ("FEROUT", "BÖBREK HASTALIĞI İLACI"),
    ("SIMPONI", "BİYOLOJİK İLAÇ"),
    ("GOLIMUMAB", "BİYOLOJİK İLAÇ"),
    ("AFEBRYL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("ORLOFF", "ZAYIFLAMA İLACI"),
    ("INFLASED", "GÖZ İLACI"),
    ("DRYBAY", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("NIPIDOL", "TANSİYON İLACI"),           # zaten var
    ("CLOZARYL", "ANTİPSİKOTİK"),
    ("VEGA", "EREKSİYON İLACI"),
    # YENİDEN
    ("PEITEL", "CİLT İLACI (KORTİZON)"),
    ("OXIMIN", "ALLERJİ / KAŞINTI İLACI"),
    ("OMEGA-3", "BESLENME ÜRÜNÜ"),
    ("BALIK YAĞI", "BESLENME ÜRÜNÜ"),
    # AŞI tipleri
    ("PEDVAX", "AŞI"),
    ("VARIVAX", "AŞI"),
    ("PROQUAD", "AŞI"),
    ("BOOSTRIX", "AŞI"),
    # GUT FMF
    ("COLCHITIN", "FMF / GUT TEDAVİSİ"),
    # KAS GEVŞETİCİ
    ("AVERTAL", "KAS GEVŞETİCİ"),
    # GASTRO MOTİLİTE
    ("DEBRIDAT", "KARIN AĞRISI / KASILMA İLACI"),  # zaten var
    # MS
    ("AUBAGIO", "MS İLACI"),
    ("TERIFLUNOMID", "MS İLACI"),
    # KEMOTERAPİ
    ("BUSULFEX", "KANSER İLACI"),
    ("CYTOSAR", "KANSER İLACI"),
    ("DACOGEN", "KANSER İLACI"),
    ("VIDAZA", "KANSER İLACI"),
    ("REVLIMID", "KANSER İLACI"),
    ("VELCADE", "KANSER İLACI"),
    ("THALIDOMID", "KANSER İLACI"),
    # MIGREN
    ("BETAMIG", "MİGREN İLACI"),
    # DEFAULT FALLBACK
    ("LANSAZOL", "MİDE İLACI"),
    ("ESOZOL", "MİDE İLACI"),

    # ============ BATCH 11 — Daha fazla marka ============
    ("BUSPON", "ANKSİYOLİTİK"),               # buspiron
    ("BUSPIRON", "ANKSİYOLİTİK"),
    ("CHINKO", "ÖKSÜRÜK KESİCİ"),
    ("IBUACTIVE", "AĞRI KESİCİ"),
    ("LAKSAFENOL", "KABIZLIK İLACI"),
    ("PIROXYN", "AĞRI KESİCİ"),
    ("TOBSIN", "GÖZ İLACI"),
    ("TOREDA", "AŞIRI AKTİF MESANE İLACI"),
    ("TROPAMID", "GÖZ İLACI"),                # zaten var
    ("CLIMEN", "HORMON"),
    ("DEXANETIL", "GÖZ İLACI"),
    ("EPORON", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("EPOSAL", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("EPRECIA", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("EPREX", "ANEMİ TEDAVİSİ (İĞNE)"),
    ("GISMOTAL", "KARIN GAZI İLACI"),
    ("INSIDON", "ANTİDEPRESAN"),
    ("OPIPRAMOL", "ANTİDEPRESAN"),
    ("LUVERIS", "KISIRLIK TEDAVİSİ"),
    ("MERIONAL", "KISIRLIK TEDAVİSİ"),         # zaten var
    ("AMIKAVER", "ANTİBİYOTİK"),
    ("AMIKOZIT", "ANTİBİYOTİK"),
    ("ANTOKSI-C", "VİTAMİN DESTEĞİ"),
    ("CIFLOSIN", "ANTİBİYOTİK"),
    ("DAPLIG", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("DAPITUS", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("SUGVIDA", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("DEXIREN", "AĞRI KESİCİ"),
    ("SERTOFEN", "AĞRI KESİCİ"),
    ("DOGMATIL", "ANTİPSİKOTİK"),
    ("FLAGENTYL", "ANTİBİYOTİK"),              # secnidazol
    ("SECNIDAZOL", "ANTİBİYOTİK"),
    ("FLUTEL", "BURUN İLACI"),
    ("LAXOSIFA", "KOLON TEMİZLEYİCİ"),
    ("LAX FOSFOSODA", "KOLON TEMİZLEYİCİ"),
    ("LEX", "ANTİDEPRESAN"),                   # essitalopram
    ("LUMIGAN", "GLOKOM İLACI"),
    ("BIMATOPROST", "GLOKOM İLACI"),
    ("NOPOT", "BÖBREK HASTALIĞI İLACI"),
    ("ERGAFEIN", "MİGREN İLACI"),
    ("HYDREA", "KANSER İLACI"),                # hidroksiüre
    ("HIDROKSIURE", "KANSER İLACI"),
    ("METACARTIN", "BESLENME ÜRÜNÜ"),
    ("MUPIDERM", "CİLT İLACI (ANTİBİYOTİK)"),
    ("MUPIROSIN", "CİLT İLACI (ANTİBİYOTİK)"),
    ("ARTROPAN", "KORTİZON TEDAVİSİ"),
    ("ASE-COLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("BACLOFEN", "KAS GEVŞETİCİ"),
    ("BRUMETON", "GÖZ İLACI"),
    ("COLCIOSPA", "KAS GEVŞETİCİ"),
    ("IMOVANE", "UYKU İLACI"),
    ("ZOPIKLON", "UYKU İLACI"),
    ("ZOLPIDEM", "UYKU İLACI"),
    ("STILNOX", "UYKU İLACI"),
    ("LORCLAST", "ASTIM İLACI"),
    ("NORLOPIN", "TANSİYON İLACI"),
    ("OKSIZINC", "CİLT İLACI"),
    ("PHOCUSS", "DEHB İLACI"),                 # amfetamin
    ("PINRAL", "ANTİEPİLEPTİK"),
    ("PROPYCIL", "GUATR İLACI"),               # propiltiyourasil
    ("PROPILTIYOURASIL", "GUATR İLACI"),
    ("TETAVAX", "AŞI"),
    ("TIBERSID", "ANTİBİYOTİK"),
    ("ULCURAN", "MİDE İLACI"),
    ("ACYL", "ANTİVİRAL"),
    ("AQUASER", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("ARTRIL", "AĞRI KESİCİ"),
    ("DEMOXIF", "GÖZ İLACI"),
    ("FEXOFEN", "ALLERJİ / KAŞINTI İLACI"),
    ("LACOMBI", "MİDE İLACI"),
    ("LOCAFEN", "LOKAL ANESTEZİK"),
    ("NIMOTOP", "TANSİYON İLACI"),             # nimodipin
    ("NIMODIPIN", "TANSİYON İLACI"),
    ("OXOFEN", "AĞRI KESİCİ"),
    ("RELESTAT", "GÖZ İLACI"),                 # zaten var
    ("ROSUFIX", "KOLESTEROL İLACI"),
    ("SELKAP", "VİTAMİN DESTEĞİ"),
    ("TIORELAX", "KAS GEVŞETİCİ"),
    ("IZOTONIK SODYUM KLORUR", "ELEKTROLİT"),
    ("ANZYL", "ANTİDEPRESAN"),
    ("B-KOMP", "B VİTAMİNİ DESTEĞİ"),
    ("CALES", "KALSİYUM DESTEĞİ"),
    ("JOSEI", "OSTEOPOROZ İLACI"),
    ("KAPEDA", "KANSER İLACI"),
    ("XELTABIN", "KANSER İLACI"),
    ("KAPESITABIN", "KANSER İLACI"),
    ("CAPETABIN", "KANSER İLACI"),
    ("CASOMID", "KANSER İLACI"),
    ("FASLODEX", "KANSER İLACI"),              # fulvestrant
    ("FULVESTRANT", "KANSER İLACI"),
    ("EMTHEXATE", "KANSER İLACI"),
    ("EKLIPS", "KANSER İLACI"),
    ("MERPURIN", "KANSER İLACI"),
    ("MERKAPTOPURIN", "KANSER İLACI"),
    ("TEMOZOLID", "KANSER İLACI"),
    ("EFUDIX", "CİLT İLACI"),
    ("KARDOZIN", "TANSİYON İLACI"),
    ("KUIFLEX", "KAS GEVŞETİCİ"),
    ("MARCAINE", "LOKAL ANESTEZİK"),
    ("BUPIVAKAIN", "LOKAL ANESTEZİK"),
    ("NETIZON", "GLOKOM İLACI"),
    ("NETROLEX", "ANTİEPİLEPTİK"),             # okskarbazepin
    ("OLFREX", "ANTİPSİKOTİK"),
    ("PICOPREP", "KOLON TEMİZLEYİCİ"),
    ("SICCAPROTECT", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("SITRAKS", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("SYNAGIS", "BİYOLOJİK İLAÇ"),
    ("ZENTIUS", "KALSİYUM DESTEĞİ"),
    ("AXIVOL", "TANSİYON İLACI"),
    ("ETKINIA", "KAN SULANDIRICI"),
    ("FLANTADIN", "MİDE İLACI"),
    ("JELIGRA", "EREKSİYON İLACI"),
    ("LOKALEN", "LOKAL ANESTEZİK"),
    ("MUSFIXA", "KAS GEVŞETİCİ"),
    ("NOACNE", "SİVİLCE İLACI"),
    ("PERGOVERIS", "KISIRLIK TEDAVİSİ"),
    ("SANASOL", "VİTAMİN DESTEĞİ"),
    ("TEORY", "BÖBREK HASTALIĞI İLACI"),
    ("ALECAST", "ASTIM İLACI"),
    ("ANGELIQ", "HORMON"),
    ("COMBIBERO", "ASTIM İLACI"),
    ("GINGUS", "BİTKİSEL DESTEK"),
    ("NETFEN", "AĞRI KESİCİ"),
    ("OLMEDAY", "TANSİYON İLACI"),
    ("OLMESARTAN", "TANSİYON İLACI"),          # zaten var
    ("PARICAVER", "BÖBREK HASTALIĞI İLACI"),
    ("PK-MERZ", "PARKİNSON İLACI"),
    ("AMANTADIN", "PARKİNSON İLACI"),
    ("RILACE", "MİDE İLACI"),
    ("SPAZMO-PANALGIN", "AĞRI KESİCİ"),
    ("PITOFENON", "AĞRI KESİCİ"),
    ("TOBRAZON", "GÖZ İLACI"),
    ("TRUJEL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("ALGESAL", "AĞRI KESİCİ"),
    ("BUTAFLY", "MANTAR İLACI"),
    ("TOLNAFTAT", "MANTAR İLACI"),
    ("CITOVIR", "ANTİVİRAL"),
    ("EVASIF", "HEPATİT İLACI"),
    ("VIRATIT", "HEPATİT İLACI"),
    ("TENOVIRAL", "HEPATİT İLACI"),
    ("FERINT", "DEMİR DESTEĞİ"),
    ("SUKROFER", "DEMİR DESTEĞİ"),
    ("FERTAMIR", "DEMİR DESTEĞİ"),
    ("FLIXON", "ASTIM İLACI"),
    ("KEYDROPS", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("KURSEPT", "ANTİSEPTİK"),
    ("LANOLIN", "CİLT İLACI (DIŞ KULLANIM)"),
    ("MYCOSPOR", "MANTAR İLACI"),
    ("BIFONAZOL", "MANTAR İLACI"),
    ("NITROLINGUAL", "TANSİYON İLACI"),
    ("NUTRAPLUS", "CİLT İLACI (DIŞ KULLANIM)"),
    ("SORMODREN", "PARKİNSON İLACI"),
    ("BORNAPRIN", "PARKİNSON İLACI"),
    ("DAYMOL", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("DEMAX", "ALZHEİMER İLACI"),              # memantin
    ("DEZIRA", "ANTİDEPRESAN"),
    ("DUOPEZIL", "ALZHEİMER İLACI"),
    ("ENIT", "TANSİYON İLACI"),
    ("EVENITY", "OSTEOPOROZ İLACI"),
    ("ROMOSOZUMAB", "OSTEOPOROZ İLACI"),
    ("FUNGAN", "MANTAR İLACI"),
    ("IMMUNORHO", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("INGLEX", "AĞRI KESİCİ"),
    ("LEVITRA", "EREKSİYON İLACI"),
    ("VARDENAFIL", "EREKSİYON İLACI"),
    ("LEVORUP", "ALLERJİ / KAŞINTI İLACI"),
    ("MADEFIX", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("MUKOLATIN", "ÖKSÜRÜK KESİCİ"),
    ("MYDFRIN", "GÖZ İLACI"),
    ("FENILEFRIN", "GÖZ İLACI"),
    ("SPAZZI", "KARIN AĞRISI / KASILMA İLACI"),
    ("TENORETIC", "TANSİYON İLACI"),
    ("TEVAGRASTIM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("TRIUMEQ", "HIV İLACI"),
    ("XENETIX", "RADYOLOJİK KONTRAST MADDESİ"),
    ("ULTRAVIST", "RADYOLOJİK KONTRAST MADDESİ"),
    ("ZIRID", "ÖKSÜRÜK KESİCİ"),
    ("ALOCORT", "CİLT İLACI (KORTİZON)"),
    ("CEFEC", "ANTİBİYOTİK"),
    ("DOLADAMON", "AĞRI KESİCİ"),
    ("ENFLUAT", "GÖZ İLACI"),
    ("EPINASTIN", "GÖZ İLACI"),
    ("FLEXTRA", "KAS GEVŞETİCİ"),
    ("GYNELLE", "DOĞUM KONTROL"),
    ("MAGNIS", "MAGNEZYUM DESTEĞİ"),
    ("MESIGYNA", "DOĞUM KONTROL"),
    ("MILEVIT", "B VİTAMİNİ DESTEĞİ"),
    ("NOSPAZM", "KARIN AĞRISI / KASILMA İLACI"),
    ("DROTAVERIN", "KARIN AĞRISI / KASILMA İLACI"),
    ("SPAZBEN", "KARIN AĞRISI / KASILMA İLACI"),
    ("RAXERIN", "ANTİPSİKOTİK"),
    ("REVAFEN", "AĞRI KESİCİ"),
    ("RONIGLOR", "GLOKOM İLACI"),
    ("SULTAMAT", "ANTİBİYOTİK"),
    ("SULTAMICILLIN", "ANTİBİYOTİK"),          # zaten var
    ("TESROJECT", "HORMON"),
    ("TRIAKNE", "SİVİLCE İLACI"),
    ("VALDOXAN", "ANTİDEPRESAN"),              # agomelatin
    ("AGOMELATIN", "ANTİDEPRESAN"),
    ("ADADERM", "SİVİLCE İLACI"),
    ("ADAPALEN", "SİVİLCE İLACI"),             # zaten var
    ("AURORIX", "ANTİDEPRESAN"),
    ("MOKLOBEMID", "ANTİDEPRESAN"),
    ("DOLARIT", "AĞRI KESİCİ"),
    ("ERDOBIL", "ÖKSÜRÜK KESİCİ"),
    ("ERDOSTEINE", "ÖKSÜRÜK KESİCİ"),
    ("FULDUO", "TANSİYON İLACI"),
    ("GENBUTROL", "RADYOLOJİK KONTRAST MADDESİ"),
    ("HIDROTEN", "CİLT İLACI (DIŞ KULLANIM)"),
    ("HIONIL", "CİLT İLACI (DIŞ KULLANIM)"),
    ("HIOTIN", "VİTAMİN DESTEĞİ"),
    ("BIOTIN", "VİTAMİN DESTEĞİ"),
    ("JERASSI", "DOĞUM KONTROL"),
    ("JUVELTA", "PARKİNSON İLACI"),
    ("LITO", "CİLT İLACI (DIŞ KULLANIM)"),
    ("LODUX", "ALZHEİMER İLACI"),
    ("MUSCAL", "KAS GEVŞETİCİ"),
    ("NEOGABA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("PHARON", "MİDE İLACI"),
    ("PREDNI-POS", "GÖZ İLACI"),
    ("QUANDO", "BULANTI KESİCİ"),
    ("ROTACEF", "ANTİBİYOTİK"),
    ("SALRES", "ASTIM İLACI"),
    ("SAXENDA", "ZAYIFLAMA İLACI"),
    ("LIRAGLUTID", "ZAYIFLAMA İLACI"),
    ("STALEVO", "PARKİNSON İLACI"),
    ("TOFRANIL", "ANTİDEPRESAN"),
    ("IMIPRAMIN", "ANTİDEPRESAN"),
    ("TRODERM", "MANTAR İLACI"),
    ("VELP", "KAN SULANDIRICI"),
    ("VERXANT", "KANSER İLACI"),
    ("ZINOMAG", "MAGNEZYUM DESTEĞİ"),
    ("ZINXX", "ÇİNKO DESTEĞİ"),
    ("B6", "B VİTAMİNİ DESTEĞİ"),
    ("BENSERI", "ANTİDEPRESAN"),
    ("CALS-D3", "KALSİYUM DESTEĞİ"),
    ("CEVIMAX", "VİTAMİN DESTEĞİ"),
    ("DAROB", "KALP RİTM İLACI"),
    ("SOTALOL", "KALP RİTM İLACI"),
    ("DESTEVIT", "D VİTAMİNİ"),
    ("DEXAWORLD", "GÖZ İLACI"),
    ("MEDEXOL", "GÖZ İLACI"),
    ("DIABEST", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("GLANGE", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),
    ("DIGOXIN", "KALP YETMEZLİĞİ İLACI"),
    ("DIGOKSIN", "KALP YETMEZLİĞİ İLACI"),
    ("DOPADEX", "PARKİNSON İLACI"),
    ("DOPADREN", "ACİL İLACI"),
    ("DOPAMIN", "ACİL İLACI"),
    ("DORZOTIM", "GLOKOM İLACI"),
    ("DUOSOPT", "GLOKOM İLACI"),
    ("EPITAM", "ANTİEPİLEPTİK"),
    ("FINDEL", "PROSTAT İLACI"),
    ("GERICA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("ISORAT", "TANSİYON İLACI"),
    ("KETILEPT", "ANTİPSİKOTİK"),
    ("KLIMADYNON", "BİTKİSEL DESTEK"),
    ("KOLESTRAN", "KOLESTEROL İLACI"),
    ("KOLESTIRAMIN", "KOLESTEROL İLACI"),
    ("MELOGEN", "AĞRI KESİCİ"),
    ("NAZETIN", "BURUN İLACI"),
    ("NEPRILEX", "KALP YETMEZLİĞİ İLACI"),
    ("NOVONORM", "DİYABET"),                   # repaglinid
    ("REPAGLINID", "DİYABET"),
    ("NOXAFIL", "MANTAR İLACI"),
    ("POSAKONAZOL", "MANTAR İLACI"),
    ("PACREA", "SİNDİRİM ENZİMİ"),
    ("PANKRAZA", "SİNDİRİM ENZİMİ"),
    ("PARASINUS", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("PAREGLIN", "DİYABET"),
    ("SERGILEX", "DİYABET"),
    ("PEDIMİX", "ÖKSÜRÜK KESİCİ"),
    ("PHYSIOTENS", "TANSİYON İLACI"),
    ("MOKSONIDIN", "TANSİYON İLACI"),
    ("PIOGTAN", "DİYABET"),
    ("PIROFEN", "AĞRI KESİCİ"),
    ("RECTONID", "HEMOROİD İLACI"),
    ("RINOBEK", "BURUN İLACI"),
    ("SINUPRET", "BİTKİSEL DESTEK"),
    ("SKINOREN", "SİVİLCE İLACI"),
    ("SOLIFAS", "AŞIRI AKTİF MESANE İLACI"),
    ("SOLIFENASIN", "AŞIRI AKTİF MESANE İLACI"),
    ("SUVALEN", "AĞRI KESİCİ"),
    ("TICLOCARD", "KAN SULANDIRICI"),
    ("TIKLOPIDIN", "KAN SULANDIRICI"),
    ("TIOTEK", "ASTIM İLACI"),
    ("HELIOS", "ASTIM İLACI"),
    ("VERAPIN", "TANSİYON İLACI"),
    ("APRAXIN", "KAN SULANDIRICI"),
    # son ekler
    ("DEXIREN", "AĞRI KESİCİ"),                # zaten var, garantiye al
    ("SEDERGINE", "AĞRI KESİCİ"),              # zaten var
    ("LEVOWORLD", "GÖZ İLACI"),                # zaten var
    # YAYGIN BİLİNEN
    ("NOVALGINA", "AĞRI KESİCİ"),
    ("DOLAREN", "AĞRI KESİCİ"),

    # ============ BATCH 12 — son temizleme ============
    ("DICLOFLAM", "AĞRI KESİCİ"),
    ("BILAXTEN", "ALLERJİ / KAŞINTI İLACI"),
    ("BILASTIN", "ALLERJİ / KAŞINTI İLACI"),
    ("PROTONEX", "MİDE İLACI"),
    ("VISINE", "GÖZ İLACI"),
    ("ANESTOL", "LOKAL ANESTEZİK"),
    ("WILKINSON", "CİLT İLACI (DIŞ KULLANIM)"),
    ("FASTJEL", "AĞRI KESİCİ"),
    ("DISINOL", "ANTİSEPTİK"),
    ("XATRAL", "PROSTAT İLACI"),
    ("ALFUZOSIN", "PROSTAT İLACI"),             # zaten var
    ("ZINCFORT", "ÇİNKO DESTEĞİ"),
    ("METEOSPASMYL", "KARIN AĞRISI / KASILMA İLACI"),
    ("ALVERIN", "KARIN AĞRISI / KASILMA İLACI"),
    ("NOVAQUA", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("DEXDAY", "AĞRI KESİCİ"),
    ("FURACIN", "CİLT İLACI (YANIK)"),
    ("NITROFURAZON", "CİLT İLACI (YANIK)"),
    ("HAMAZINC", "CİLT İLACI (DIŞ KULLANIM)"),
    ("BEN-GAY", "AĞRI KESİCİ"),
    ("METIL SALISILAT", "AĞRI KESİCİ"),
    ("LUROAN", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("CETAFLU", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("ELLA", "ACİL DOĞUM KONTROL"),
    ("ULIPRISTAL", "ACİL DOĞUM KONTROL"),
    ("PROSPAN", "ÖKSÜRÜK KESİCİ"),
    ("SARMAŞIK", "ÖKSÜRÜK KESİCİ"),
    ("CREBROS", "NÖROLOJİ İLACI"),
    ("SITIKOLIN", "NÖROLOJİ İLACI"),
    ("KATARIN", "GÖZ İLACI"),
    ("OSIREC", "BAĞIRSAK İLTİHABI İLACI"),
    ("MOMETIX", "BURUN İLACI"),
    ("COMBO", "DİYABET"),
    ("JELGO", "AĞRI KESİCİ"),
    ("BRUS", "AĞRI KESİCİ"),
    ("KARUM", "KAN SULANDIRICI"),
    ("AVMIGRAN", "MİGREN İLACI"),
    ("MAGOSIT", "MAGNEZYUM DESTEĞİ"),
    ("N-CORT", "BURUN İLACI"),
    ("MIYADREN", "AĞRI KESİCİ"),
    ("ADVIL", "AĞRI KESİCİ"),
    ("NAZOSTER", "BURUN İLACI"),
    ("NEVAKSON", "ANTİBİYOTİK"),
    ("FLUDEX", "TANSİYON İLACI"),               # indapamid
    ("PERIMEX", "AĞIZ-DİŞ İLACI"),
    ("TRAVOCORT", "CİLT İLACI (KORTİZON)"),
    ("ETOTIO", "KAS GEVŞETİCİ"),
    ("PRILAM", "MİDE İLACI"),
    ("DEXLANSOPRAZOL", "MİDE İLACI"),
    ("TERAPIX-JEL", "AĞRI KESİCİ"),
    ("MECO-JEL", "AĞRI KESİCİ"),
    ("SINERAL", "ANTİBİYOTİK"),  # ornidazol (ENFEXOL/BITERAL muadili)
    ("ZYLET", "GÖZ İLACI"),
    ("REFLOR", "PROBİYOTİK"),
    ("LOTEMAX", "GÖZ İLACI"),
    ("LOTEPREDNOL", "GÖZ İLACI"),               # zaten var
    ("DICOL", "AĞRI KESİCİ"),
    ("PROBLOK", "TANSİYON İLACI"),
    ("ACIDPASS", "MİDE İLACI (REFLÜ)"),
    ("MAGALDRAT", "MİDE İLACI (REFLÜ)"),
    ("X-M", "KABIZLIK İLACI"),       # senna glikozidi (A06AB06) — laksatif, adındaki "DIET" yanıltıcı
    ("X-M DIET", "KABIZLIK İLACI"),
    ("OPILOX", "MANTAR İLACI"),
    ("LOPROX", "MANTAR İLACI"),
    ("VIGAMOX", "GÖZ İLACI"),
    ("DENTINOX", "AĞIZ-DİŞ İLACI"),
    ("PENCOLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("AD-COLD", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("TOBRADEX", "GÖZ İLACI"),
    ("PIRALDYNE", "ANTİSEPTİK"),
    ("OLMYSAR", "TANSİYON İLACI"),
    ("RABBY-D", "MİDE İLACI"),
    ("DROPOLEV", "ÖKSÜRÜK KESİCİ"),
    ("OFTOMIX", "GÖZ İLACI"),                   # zaten var
    ("COLOPLAST", "TIBBİ MALZEME"),
    ("LORNOX", "AĞRI KESİCİ"),                  # lornoksikam zaten LORNOK var
    ("LORNOKSIKAM", "AĞRI KESİCİ"),
    ("KLORHEX", "AĞIZ-DİŞ İLACI"),
    ("NIMELID", "AĞRI KESİCİ"),
    ("CALGEL", "AĞIZ-DİŞ İLACI"),
    ("HIVERAC", "HIV İLACI"),
    ("PENFLOKS", "ANTİBİYOTİK"),
    ("PEFLOKSASIN", "ANTİBİYOTİK"),
    ("SUPRAVIT", "VİTAMİN DESTEĞİ"),
    ("DEKLARIT", "ANTİBİYOTİK"),
    ("UNIKLAR", "ANTİBİYOTİK"),
    ("DYNABAC", "ANTİBİYOTİK"),
    ("DIRITROMISIN", "ANTİBİYOTİK"),
    ("TOMEC", "GLOKOM İLACI"),
    ("DOLPHIN", "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"),
    ("CELGYN", "AĞRI KESİCİ"),
    ("CELEBREX", "AĞRI KESİCİ"),
    ("SELEKOKSIB", "AĞRI KESİCİ"),
    ("GYNO-LOMEXIN", "KADIN HASTALIKLARINDA"),
    ("FENTIKONAZOL", "KADIN HASTALIKLARINDA"),
    ("GYNO-FEM", "KADIN HASTALIKLARINDA"),
    ("GYNOFLOR", "KADIN HASTALIKLARINDA"),
    ("ENZOFEN", "KADIN HASTALIKLARINDA"),
    ("DEXPRO", "AĞRI KESİCİ"),
    ("INFENIL", "AĞRI KESİCİ"),
    ("MAXIFLU", "BURUN İLACI"),
    ("OLADIN", "GÖZ İLACI"),
    ("LIPOFEN", "KOLESTEROL İLACI"),
    ("EFERMAG", "MAGNEZYUM DESTEĞİ"),
    ("OMEPROL", "MİDE İLACI"),
    ("OMESEK", "MİDE İLACI"),                   # zaten var
    ("LANSOTER", "MİDE İLACI"),
    ("HELICOL", "MİDE İLACI"),                  # zaten var
    ("TENSINOR", "TANSİYON İLACI"),
    ("IPRALEV", "ASTIM İLACI"),
    ("NEURICA", "ANTİEPİLEPTİK / SİNİR AĞRISI"),
    ("BRELAX", "ÖKSÜRÜK KESİCİ"),
    ("BURAZIN", "BURUN İLACI"),
    ("OLVIN", "BURUN AÇICI"),
    ("ACETUDIL", "ÖKSÜRÜK KESİCİ"),
    ("CONTRACTUBEX", "CİLT İLACI (YARA İYİLEŞTİRİCİ)"),
    ("PRATIN", "PARKİNSON İLACI"),
    ("DUOTRAV", "GLOKOM İLACI"),
    ("TRAVOPROST", "GLOKOM İLACI"),             # zaten var
    ("TIRECORT", "CİLT İLACI (KORTİZON)"),
    ("MIYADREN", "AĞRI KESİCİ"),                # tekrar garantiye
    ("NOTTA", "ASTIM İLACI"),                   # montelukast
    ("METOJECT", "ROMATİZMA / İLTİHAP İLACI"),
    ("OPIREL", "KAN SULANDIRICI"),
    ("EXETU", "KANSER İLACI"),
    ("EKSEMESTAN", "KANSER İLACI"),
    ("AMPISID", "ANTİBİYOTİK"),
    ("DILOXOL", "AĞRI KESİCİ"),
    ("NIMOKAIN", "AĞRI KESİCİ"),
    ("DEPREKS", "ANTİDEPRESAN"),
    ("DESOLETT", "DOĞUM KONTROL"),
    ("EKZE-MANT", "CİLT İLACI (EGZEMA)"),
    ("EPDANTOIN", "ANTİEPİLEPTİK"),
    ("VECTAVIR", "ANTİVİRAL"),
    ("PENSIKLOVIR", "ANTİVİRAL"),
    ("AZIPAR", "ANTİPSİKOTİK"),
    ("CINETIX", "AĞRI KESİCİ"),
    ("MAXTHIO", "KAS GEVŞETİCİ"),
    ("DROSPERA", "DOĞUM KONTROL"),
    ("SUNDROP-D3", "D VİTAMİNİ"),
    ("SUNDROP", "D VİTAMİNİ"),
    ("TERNAVIR", "HEPATİT İLACI"),
    ("PRAMOFEN", "ALLERJİ / KAŞINTI İLACI"),
    ("KETOSTERIL", "BÖBREK HASTALIĞI İLACI"),
    ("REDEKAIN", "LOKAL ANESTEZİK"),
    ("TRISEQUENS", "HORMON"),
    ("GEMYSETIN", "GÖZ İLACI"),
    ("KEMICETINE", "GÖZ İLACI"),
    ("KLORAMFENIKOL", "GÖZ İLACI"),
    ("TERKUR", "CİLT İLACI (DIŞ KULLANIM)"),
    ("SIKLOPLEJIN", "GÖZ İLACI"),
    ("SIKLOPENTOLAT", "GÖZ İLACI"),
    ("RUPATEK", "ALLERJİ / KAŞINTI İLACI"),
    ("ZETION", "KARIN GAZI İLACI"),
    ("AZOSILIN", "ANTİBİYOTİK"),
    ("LINCOCIN", "ANTİBİYOTİK"),
    ("ALORES", "ALLERJİ / KAŞINTI İLACI"),
    ("MOXITEC", "ANTİBİYOTİK"),
    ("CILOXAN", "GÖZ İLACI"),                   # zaten var
    ("EYE-VISOL", "KURU GÖZ RAHATSIZLIĞINDA"),
    ("MYESED", "EREKSİYON İLACI"),
    ("NASACORT", "BURUN İLACI"),                # zaten var
    ("CLARITINE", "ALLERJİ / KAŞINTI İLACI"),
    ("LORATADIN", "ALLERJİ / KAŞINTI İLACI"),   # zaten var
    ("DIKLOFAR", "AĞRI KESİCİ"),
    ("DOMIRPA", "MİDE İLACI"),
    ("FORSTEO", "OSTEOPOROZ İLACI"),
    ("TERIPARATID", "OSTEOPOROZ İLACI"),
    ("NEPITIN", "ANTİEPİLEPTİK"),
    ("FLOPROST", "PROSTAT İLACI"),
    ("UROCIT-K", "BÖBREK HASTALIĞI İLACI"),
    ("ZELOXIM", "AĞRI KESİCİ"),
    ("MEKSRATU", "ROMATİZMA / İLTİHAP İLACI"),
    ("PANTHERO", "ASTIM İLACI"),
    ("FLYNTA", "EREKSİYON İLACI"),
    ("THINCAL", "ZAYIFLAMA İLACI"),
    ("XAMATE", "ANTİEPİLEPTİK"),                # topiramat
    # SPESİFİK markalar
    ("BACODERM", "CİLT İLACI (ANTİBİYOTİK)"),
    ("AIRPASS", "ASTIM İLACI"),
    ("LANSOTER", "MİDE İLACI"),
    ("PRED FORTE", "GÖZ İLACI"),                # zaten var
    ("LANSAZOL", "MİDE İLACI"),                 # zaten var
    ("CAPCIDERM", "AĞRI KESİCİ"),               # zaten var
    ("UROCARE", "ANTİBİYOTİK (İDRAR YOLU)"),
    ("DALMAN", "BURUN İLACI"),                  # zaten var
    ("CALCI-NET", "KALSİYUM DESTEĞİ"),
    ("MAGNEZI", "MAGNEZYUM DESTEĞİ"),
    ("MAGOSAN", "MAGNEZYUM DESTEĞİ"),
    ("FERSAN", "DEMİR DESTEĞİ"),
    ("BICANA", "ÖKSÜRÜK KESİCİ"),
    ("FLAREX", "GÖZ İLACI"),
    ("KONTIL", "BULANTI KESİCİ"),
    ("BIVOXA", "GÖZ İLACI"),
    ("MAGNESIUM DIASPORAL", "MAGNEZYUM DESTEĞİ"),
    ("ZEFFIX", "HEPATİT İLACI"),                # zaten var
    ("METILER", "BAĞIRSAK İLTİHABI İLACI"),
    ("MODET", "ANTİEPİLEPTİK"),
    ("OFTAMYCIN", "GÖZ İLACI"),                 # zaten var
    ("PROBLOK", "TANSİYON İLACI"),
    ("ALBITROL", "ANTİBİYOTİK"),                # ENFEXOL alternatif adı
    ("ENFEXOL", "ANTİBİYOTİK"),
    ("AZEKAZ", "BURUN İLACI"),                  # zaten var
    ("PRAMOFEN", "CİLT İLACI (DIŞ KULLANIM)"),
    ("ATARO", "ALLERJİ / KAŞINTI İLACI"),
    ("LAVENIL", "ÖKSÜRÜK KESİCİ"),

    # ============ BATCH 12 — daha fazla ============
    ("DEXTROCIN", "CİLT İLACI (ANTİBİYOTİK)"),  # zaten var
    ("TOBRASED", "GÖZ İLACI"),                  # zaten var
    ("FUCITHALMIC", "GÖZ İLACI"),               # zaten var
    ("PATANOL", "GÖZ İLACI"),                   # zaten var
    ("VIGAMOX", "GÖZ İLACI"),                   # zaten var
    ("OFNOL", "GÖZ İLACI"),                     # zaten var
    ("LOTEBRA", "GÖZ İLACI"),                   # zaten var
    ("EXOCIN", "GÖZ İLACI"),                    # zaten var
    ("EMADINE", "GÖZ İLACI"),                   # zaten var
    ("NETIRA", "GÖZ İLACI"),                    # zaten var
    ("MAXIDEX", "GÖZ İLACI"),                   # zaten var

    # ============ BATCH 13 — Web search ile bulunan son markalar ============
    ("GYREX", "ANTİPSİKOTİK"),                  # ketiapin
    ("NERUDA", "ANTİEPİLEPTİK / SİNİR AĞRISI"), # gabapentin
    ("TARLUSAL", "HORMON"),                     # medroksiprogesteron
    ("MASILVA", "PULMONER HİPERTANSİYON İLACI"),  # masitentan
    ("MACITRIN", "PULMONER HİPERTANSİYON İLACI"),  # masitentan
    ("MASITENTAN", "PULMONER HİPERTANSİYON İLACI"),
    ("SAYFREN", "ANTİPSİKOTİK"),                # aripiprazol
    ("ZOLERIP", "ANTİPSİKOTİK"),                # aripiprazol
    ("COGITO", "ALZHEİMER İLACI"),              # memantin
    ("RIPATRIN", "ALLERJİ / KAŞINTI İLACI"),    # rupatadin
    ("PLANOR", "KAN SULANDIRICI"),              # klopidogrel
    ("FORTINE", "AĞRI KESİCİ"),                 # flurbiprofen
    ("TEGLIX", "DİYABET"),                      # nateglinid
    ("NATEGLINID", "DİYABET"),
    ("TILANTA", "KAN SULANDIRICI"),             # tikagrelor
    ("TIKAGRELOR", "KAN SULANDIRICI"),
    ("VALCODIN", "TANSİYON İLACI"),             # valsartan+amlodipin
    ("PEPTICER", "MİDE İLACI"),                 # lansoprazol
    ("PIMARO", "BÖBREK HASTALIĞI İLACI"),       # sinakalset
    ("DESCASE", "ASTIM İLACI"),                 # desloratadin+montelukast
    ("INSOVEF", "UYKU İLACI"),                  # melatonin
    ("ASEKET", "AĞRI KESİCİ"),                  # deksketoprofen+parasetamol
    ("ZLYNDA", "DOĞUM KONTROL"),                # drospirenon
    ("BARCA", "AĞRI KESİCİ"),                   # etodolak SR
    ("NARISAT", "ASTIM İLACI"),                 # levosetirizin+montelukast
    ("NOKREV", "ALKOL BAĞIMLILIĞI"),            # naltrekson
    ("NALTREKSON", "ALKOL BAĞIMLILIĞI"),
    ("GAMAKUIL", "KAS GEVŞETİCİ"),              # fenprobamat
    ("FENPROBAMAT", "KAS GEVŞETİCİ"),
    ("ENEAS", "TANSİYON İLACI"),                # enalapril+nitrendipin
    ("NITRENDIPIN", "TANSİYON İLACI"),
    ("ZOLTEM", "BULANTI KESİCİ"),               # ondansetron
    ("ZAYON", "ERKEN BOŞALMA İLACI"),           # dapoksetin
    ("DORSILON", "KAS GEVŞETİCİ"),              # mefenoksalon+parasetamol
    ("MEFENOKSALON", "KAS GEVŞETİCİ"),
    ("DIFURAT", "MS İLACI"),                    # dimetil fumarat
    ("DIMETIL FUMARAT", "MS İLACI"),
    ("EPIZONYA", "ANTİEPİLEPTİK"),              # zonisamid
    ("ZONISAMID", "ANTİEPİLEPTİK"),
    ("FEPATIL", "KOLESTEROL İLACI"),            # fenofibrat
    ("RELIXAN", "ANTİPSİKOTİK"),                # fluoksetin+olanzapin
    ("VISANNE", "HORMON"),                      # dienogest (endometriozis)
    ("QLAIRISTA", "DOĞUM KONTROL"),             # estradiol valerat+dienogest
    ("VIGRANDE", "EREKSİYON İLACI"),            # sildenafil
    ("FLYNTA", "EREKSİYON İLACI"),              # tadalafil
    ("VIAMED", "EREKSİYON İLACI"),              # sildenafil
    ("HARDCIS", "EREKSİYON İLACI"),             # tadalafil
    ("RETOMIN", "EREKSİYON İLACI"),             # sildenafil
    ("FEIBA", "HEMOFİLİ İLACI"),                # faktör VIII inhibitör
    ("GRANOCYTE", "BAĞIŞIKLIK SİSTEMİ İLACI"),  # lenograstim
    ("LENOGRASTIM", "BAĞIŞIKLIK SİSTEMİ İLACI"),
    ("METIGAST", "KARIN GAZI İLACI"),           # simetikon
    ("PIROXYN", "AĞRI KESİCİ"),                 # piroksikam
    ("AKELA", "SİVİLCE İLACI"),                 # eritromisin
    ("HIRONIL", "TOPLARDAMAR / VARİS İLACI"),   # heparinoid
    ("SUPRAFEN", "AĞRI KESİCİ"),                # ibuprofen
    ("FUZO PLUS", "AĞRI KESİCİ"),               # nimesulid+lidokain
    ("FUZO", "AĞRI KESİCİ"),
    ("PREPAGEL", "AĞRI KESİCİ"),                # dietilamin salisilat
    ("FUGGY", "CİLT İLACI (KORTİZON)"),         # izokonazol+diflukortolon
    ("TRACOVOL", "CİLT İLACI (KORTİZON)"),
    ("IZOKONAZOL", "MANTAR İLACI"),
    ("DIFLUKORTOLON", "CİLT İLACI (KORTİZON)"),
    ("COLIDUR", "BAĞIRSAK İLTİHABI İLACI"),     # rifaksimin
    ("RIFAKSIMIN", "BAĞIRSAK İLTİHABI İLACI"),
    ("TILAC", "AĞRI KESİCİ"),                   # etodolak SR
    ("MELIMIN", "TOPLARDAMAR / VARİS İLACI"),   # diosmin+hesperidin
    ("DIOSMIN", "TOPLARDAMAR / VARİS İLACI"),
    ("HESPERIDIN", "TOPLARDAMAR / VARİS İLACI"),
    ("SARCOPEN", "AĞRI KESİCİ"),                # deksketoprofen+tiyokolşikosid
    ("STIDERM", "ALLERJİ / KAŞINTI İLACI"),     # mepiramin+lidokain+dekspantenol
    ("SOLERAT", "ALLERJİ / KAŞINTI İLACI"),     # mepiramin+lidokain+dekspantenol
    ("PERS-MANT", "MANTAR İLACI"),              # mikonazol+alüminyum
    ("IMPETEX", "CİLT İLACI (KORTİZON)"),       # diflukortolon+klorkinaldol
    ("SIVEX", "SİVİLCE İLACI"),                 # sodyum sülfasetamid
    ("EVIN", "E VİTAMİNİ DESTEĞİ"),             # E vitamini IM
    ("ETOVER", "AĞRI KESİCİ"),                  # etofenamat
    ("ETOFENAMAT", "AĞRI KESİCİ"),
    ("PODORA", "ANTİBİYOTİK"),                  # sefpodoksim
    ("SEFPODOKSIM", "ANTİBİYOTİK"),
    ("CEFPODOXIME", "ANTİBİYOTİK"),
    ("KOMFER", "AĞRI KESİCİ"),                  # parasetamol+kafein
    ("KOMFER FOL", "DEMİR DESTEĞİ"),            # demir+folik
    ("EXTAL", "ÖKSÜRÜK KESİCİ"),                # asetilsistein
    ("ANTIBEKSIN", "ÖKSÜRÜK KESİCİ"),           # efedrin+feniramin
    ("PRIZIN", "BULANTI KESİCİ"),               # meklozin
    ("MEKLOZIN", "BULANTI KESİCİ"),
    ("KUILIL", "KAS GEVŞETİCİ"),                # fenprobamat+parasetamol
    ("GAYABEN", "ÖKSÜRÜK KESİCİ"),              # karbetapentan+difenhidramin
    ("PELUMM", "ÖKSÜRÜK KESİCİ"),               # Pelargonium sidoides
    ("PELARGONIUM", "ÖKSÜRÜK KESİCİ"),
    ("RONIDRO", "OSTEOPOROZ İLACI"),            # zoledronik
    ("ZOLEDRONIK", "OSTEOPOROZ İLACI"),
    ("FILINSEL", "ASTIM İLACI"),                # teofilin/aminofilin
    ("AMINOFILIN", "ASTIM İLACI"),
    ("BERAVIT", "VİTAMİN DESTEĞİ"),             # multivitamin
    ("JECTERA", "EREKSİYON İLACI"),             # alprostadil
    ("ALPROSTADIL", "EREKSİYON İLACI"),
    ("ASIPEC", "PARKİNSON İLACI"),              # rasajilin
    ("RASAJILIN", "PARKİNSON İLACI"),
    ("MUSKAZON", "KAS GEVŞETİCİ"),              # parasetamol+klorzoksazon
    ("BUTIROL", "ÖKSÜRÜK KESİCİ"),              # butamirat
    ("BUTAMIRAT", "ÖKSÜRÜK KESİCİ"),
    ("PEDİMİX", "ÖKSÜRÜK KESİCİ"),              # pediatrik öksürük
    ("PEDIMIX", "ÖKSÜRÜK KESİCİ"),
    ("PEDITUS", "ÖKSÜRÜK KESİCİ"),
    ("KARBIDOZ", "BÖBREK HASTALIĞI İLACI"),     # sodyum bikarbonat
    ("FLUREND", "BOĞAZ İLACI"),                 # flurbiprofen
    ("GERAKS", "AĞIZ-DİŞ İLACI"),               # klorhekzidin+benzidamin
    ("DEMOXIF", "GÖZ İLACI"),                   # moksifloksasin
    ("BIVOXA", "GÖZ İLACI"),                    # moksifloksasin
    ("DEXA-SINE", "GÖZ İLACI"),                 # deksametazon
    ("OVADRIL", "ALLERJİ / KAŞINTI İLACI"),     # çinko+difenhidramin+lidokain
    ("SOKOL", "KABIZLIK İLACI"),                # likit parafin
    ("LIKIT PARAFIN", "KABIZLIK İLACI"),
    ("BT ORAL", "KOLON TEMİZLEYİCİ"),           # sodyum fosfat
    ("VAGI-HEX", "KADIN HASTALIKLARINDA"),      # heksetidin
    ("HEKSETIDIN", "KADIN HASTALIKLARINDA"),
    ("H-VAC", "AŞI"),                           # hepatit B aşısı
    ("NUROFARM", "GRİP / SOĞUK ALGINLIĞINDA"),  # ibuprofen+psödoefedrin
    ("NUROFARM-C", "GRİP / SOĞUK ALGINLIĞINDA"),
    ("MONOVIT", "D VİTAMİNİ"),                  # kolekalsiferol
    ("NORSOL", "GÖZ İLACI"),                    # prednizolon göz
    ("BIOAK", "VİTAMİN DESTEĞİ"),               # biotin
    ("BIOTIN", "VİTAMİN DESTEĞİ"),
    ("TURKTIPSAN VITAMIN C", "VİTAMİN DESTEĞİ"),
    ("TURKFLEKS", "ELEKTROLİT"),                # serum fizyolojik
    ("SIHHAT POVISOL", "ANTİSEPTİK"),
    ("MAJISTRAL", "TIBBİ MALZEME"),
    ("MAJİSTAL", "TIBBİ MALZEME"),
    ("MOLAR SODYUM BIKARARBONAT", "ELEKTROLİT"),
    ("MOLAR SODYUM", "ELEKTROLİT"),
    ("ELFENOR", "AĞRI KESİCİ"),                 # flurbiprofen jel
    ("KATARIN", "GÖZ İLACI"),                   # göz vitamini
    ("ORSA", "TIBBİ MALZEME"),                  # kol askısı
]


def guess_kategori(drug_name: str, kullanim_sekli: str = "") -> str:
    """İlaç adından etikette basılacak büyük kategori başlığı tahmin et.

    Referans etiket örneklerinden:
      ANTİBİYOTİK, AĞRI KESİCİ, AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ, TANSİYON İLACI,
      DİYABET / KALP YETMEZ. / BÖBREK HAS., KORTİZON TEDAVİSİ, KADIN HASTALIKLARINDA,
      KURU GÖZ RAHATSIZLIĞINDA, BOĞAZ SPREYİ, GRİP / SOĞUK ALGINLIĞINDA,
      ÖKSÜRÜK KESİCİ, GUATR İLACI, ANTİDEPRESAN.

    Bu fonksiyon, DB'de tarifi olmayan ilaçlar için makul bir tahmin döndürür.
    DB doldurulurken bu alan AI tarafından daha doğru atanmalı.
    """
    name = (drug_name or "").upper()
    sekli = (kullanim_sekli or "").upper()

    # En kapsamlı tarama: etken madde / marka sözlüğünde eşleşme ara.
    # Sıralama önemli: önce daha uzun/spesifik anahtarları kontrol et
    for key, kategori in sorted(ETKEN_MADDE_KATEGORI, key=lambda kv: -len(kv[0])):
        if key in name:
            return kategori

    # Generic suffix tabanlı tahmin (örn. "RAMI-PROFEN" → AĞRI)
    # Dikkat: false-positive olabilir, sadece yüksek güvenli suffix'ler.
    # İlaç adının ilk kelimesine bakıyoruz (markaadı/etken).
    first_word = name.split()[0] if name else ""
    suffix_map = [
        ("SARTAN", "TANSİYON İLACI"),       # ARB
        ("PRIL", "TANSİYON İLACI"),         # ACE-I
        ("DIPIN", "TANSİYON İLACI"),        # CCB
        ("OLOL", "TANSİYON İLACI"),         # β-blocker
        ("PRAZOL", "MİDE İLACI"),           # PPI
        ("TIDIN", "MİDE İLACI"),            # H2 blocker
        ("LIPTIN", "DİYABET"),              # DPP-4
        ("GLIFLOZIN", "DİYABET / KALP YETMEZ. / BÖBREK HAS."),  # SGLT-2
        ("ZEPAM", "ANKSİYOLİTİK"),          # benzodiazepin
        ("TRIPTAN", "MİGREN İLACI"),
        ("FENAK", "AĞRI KESİCİ"),           # diklofenak/aceclofenak
        ("PROFEN", "AĞRI KESİCİ"),          # ibuprofen/ketoprofen
        ("STATIN", "KOLESTEROL İLACI"),     # NOT: MIKOSTATIN/FUNGOSTATIN için liste önce alıyor
        ("PARIN", "KAN SULANDIRICI (İĞNE)"),
    ]
    for suf, kat in suffix_map:
        if first_word.endswith(suf):
            return kat

    # Antibiyotikler (sık görülen marka adları)
    antibiyotik = ("AMOKLAVIN", "AUGMENTIN", "KLAMOKS", "CROXILEX", "KLAVUNAT",
                   "CEFAKS", "SEFAKLOR", "AZITRO", "ZITROMAX", "CEFIXIM",
                   "FUCIDIN", "FUSIDIC", "DEPOSEL", "RİLİNDAVER", "SEPTIN")
    if any(a in name for a in antibiyotik):
        return "ANTİBİYOTİK"

    # Ağrı kesiciler
    if any(k in name for k in ("ARVELES", "DEXOFEN", "APRANAX", "APROL", "DOLOREX",
                                "DEX-FORTE", "VOLTAREN", "DOLO", "MAJEZIK", "ETOL",
                                "BI-PROFENID", "PROFENID", "PONSTAN", "NAPROXEN",
                                "DICLOFENAC", "IBUFEN", "NUROFEN")):
        return "AĞRI KESİCİ"
    if any(k in name for k in ("PAROL", "TYLOL", "MINOSET", "VERMIDON", "PARASET",
                                "IBURAMIN ZERO", "CALPOL", "DOLVEN", "PEDIFEN",
                                "IBU-FORT", "IBUFEN")):
        return "AĞRI KESİCİ - ATEŞ DÜŞÜRÜCÜ"

    # Mide ilaçları
    if any(k in name for k in ("OMEPRAZOL", "PANTPRAZOL", "LANSOPRAZOL", "NEXIUM",
                                "PARIET", "LANSOR", "PANTODAC", "ESOMEPRAZOL",
                                "RANITIDIN", "FAMOTIDIN", "RENNIE", "TALCID")):
        return "MİDE İLACI"

    # Tansiyon
    if any(k in name for k in ("AMLODIS", "AMLODIPIN", "CORALAN", "DELIX", "RAMI",
                                "COVERAM", "EXFORGE", "MICARDIS", "OLMETEC",
                                "NORVASC", "RAMIPRIL", "VALSAR", "LOSARTAN",
                                "PERINDOPRIL", "TENSAR")):
        return "TANSİYON İLACI"

    # Diyabet
    if any(k in name for k in ("GLUCOPHAGE", "GLUKOFEN", "DIAFORMIN", "METFORMIN",
                                "JANUVIA", "FORZIGA", "GALVUS", "AMARYL", "DIAMICRON",
                                "TRAJENTA", "JARDIANCE", "VICTOZA", "ONGLYZA",
                                "INSULIN", "LANTUS", "LEVEMIR")):
        return "DİYABET / KALP YETMEZ. / BÖBREK HAS."

    # Antidepresan
    if any(k in name for k in ("CIPRALEX", "ESCITALOPRAM", "PAROXAT", "PAROXETIN",
                                "SERTRALIN", "LUSTRAL", "FLUOXETIN", "PROZAC",
                                "VENLAFAXIN", "EFEXOR", "DULOXETIN", "CYMBALTA",
                                "MIRTAZAPIN", "REMERON", "LAGYL")):
        return "ANTİDEPRESAN"

    # Guatr
    if any(k in name for k in ("LEVOTIRON", "EUTHYROX", "BITIRON", "TIROMEL")):
        return "GUATR İLACI"

    # Kortizon
    if any(k in name for k in ("DEKORT", "DEPOMEDROL", "PREDNOL", "DELTACORTRIL",
                                "BETNESOL", "DEPRECT", "METİLPRED")):
        return "KORTİZON TEDAVİSİ"

    # Öksürük
    if any(k in name for k in ("KREVAL", "BRONKO", "EXPEKTORAN", "BISOLVON",
                                "MUKOLİT", "ERDOSTIN", "MUCOL")):
        return "ÖKSÜRÜK KESİCİ"

    # Grip
    if any(k in name for k in ("IBURAMIN COLD", "IBURAMIN PLUS", "GRİP", "CORYZA",
                                "THERAFLU", "BENICA")):
        return "GRİP / SOĞUK ALGINLIĞINDA"

    # Boğaz spreyi
    if "BOĞAZ" in name or ("BENPAIN" in name) or ("HEXORAL" in name) or ("STREPSILS" in name):
        return "BOĞAZ SPREYİ" if "SPREY" in name else "BOĞAZ İLACI"

    # Göz ilaçları
    if "GÖZ" in name or "GÖZ" in sekli or "GOZ" in name:
        if "JEL" in name or "JELI" in name:
            return "KURU GÖZ RAHATSIZLIĞINDA"
        if "VISCO" in name or "SYSTANE" in name or "TEARS" in name or "NATURA E" in name or "REFRESH" in name:
            return "KURU GÖZ RAHATSIZLIĞINDA"
        if "AZARGA" in name or "TIMOL" in name or "XALATAN" in name or "TRAVATAN" in name:
            return "GLOKOM İLACI"
        return "GÖZ İLACI"

    # Burun
    if "NAZOFIX" in name or "NAZAL" in name or "BURUN" in name:
        return "BURUN İLACI"

    # Kadın hastalıkları (fitil vb.)
    if "FİTİL" in name or "FITIL" in name or "OVUL" in name or "GINO" in name:
        return "KADIN HASTALIKLARINDA"

    # Kaşıntı
    if "ATARAX" in name or "ANTIHISTAMINIK" in name or "DESLORATADIN" in name or \
       "LORATADIN" in name or "ZYRTEC" in name or "DELODAY" in name:
        return "ALLERJİ / KAŞINTI İLACI"

    # Gargara
    if "GARGARA" in name or "MAXIMUS" in name or "KLOROBEN" in name:
        return "AĞIZ-DİŞ İLACI"

    return ""  # Bilinmiyor


def is_eye_ear_drop_name(drug_name: str) -> bool:
    """Hem göze HEM kulağa kullanılan damla mı (örn. ONADRON SIMPLE GÖZ VE KULAK)?

    Form tek kanala (eye_drop veya ear_drop) sabitlendiğinden ada bakılır.
    DB'de adlar aksanlı/aksansız karışık ("GÖZ" ve "GOZ") yazıldığından ikisi de denenir.
    """
    n = (drug_name or "").upper()
    return ("GÖZ" in n or "GOZ" in n) and "KULAK" in n and "DAMLA" in n


# ---------------------------------------------------------------------------
# route_class güvenlik kilidi
# ---------------------------------------------------------------------------
# drugs.route_class (virgüllü kod listesi) ile üretilen talimat cümlesinin
# uygulama kanalı çelişiyorsa cümlenin bitiş fiili sınıfa uygun olanla
# değiştirilir. Kodlar: 1 oral, 2 topikal, 3 IV, 4 IM, 5 diğer parenteral,
# 6 göz, 7 kulak, 8 ağız boşluğu, 9 saçlı deri, 10 burun, 11 boğaz,
# 12 inhalasyon, 13 rektal/vajinal, 14 dilaltı/bukal, 15 transdermal bant,
# 16 özel yol, 0 ilaç-dışı malzeme (cümle hiç basılmaz).

_ROUTE_CLASS_CHANNELS: dict[int, set[str]] = {
    # 3/4/5 alt kanalları AYRI: "KAS İÇİNE" metni IV-only ilaçla (veya tersi)
    # çelişki sayılır; jenerik "ENJEKSİYONLA UYGULANIR" ("parenteral") üçüyle
    # de uyumludur.
    1: {"oral"}, 2: {"skin"},
    3: {"inj_iv", "parenteral"}, 4: {"inj_im", "parenteral"},
    5: {"inj_sc", "parenteral"}, 6: {"eye", "eye_ear"}, 7: {"ear", "eye_ear"},
    8: {"mouth"}, 9: {"skin"}, 10: {"nose"}, 11: {"mouth"},
    12: {"inhal"}, 13: {"vaginal", "rectal"}, 14: {"sublingual"},
    15: {"patch"}, 16: {"special"},
}


def parse_route_class(route_class: str) -> set[int]:
    """'3,4' → {3, 4}. Boş/bozuk girdi → boş küme."""
    out: set[int] = set()
    for p in (route_class or "").split(","):
        p = p.strip()
        if p.isdigit():
            out.add(int(p))
    return out


def _talimat_channel(t: str) -> str:
    """Talimat/bitiş metninden uygulama kanalını çıkar ('' = belirsiz)."""
    t = (t or "").upper()
    if "GÖZE VEYA KULAĞA" in t:
        return "eye_ear"
    if "GÖZ" in t:
        return "eye"
    if "KULAK" in t:
        return "ear"
    if "BURUN" in t:
        return "nose"
    if "DİLALTI" in t or "DİL ALTINA" in t or "YANAK ARASINDA" in t:
        return "sublingual"
    if ("BOĞAZA SIKILIR" in t or "ÇALKALANIP TÜKÜRÜLÜR" in t
            or "AĞIZ İÇİNE" in t or "AĞIZDA EMİLİR" in t):
        return "mouth"
    if "VAJEN" in t:
        return "vaginal"
    if "MAKATTAN" in t or "MAKAT BÖLGESİNE" in t:
        return "rectal"
    if "YAPIŞTIRILIR" in t:
        return "patch"
    if ("SÜRÜLÜR" in t or "SAÇA UYGULANIR" in t or "SAÇLI DERİYE" in t
            or "ETKİLENEN BÖLGEYE" in t):
        return "skin"
    if "NEBÜLİZATÖR" in t or "İÇE ÇEKİLİR" in t or "SOLUNUR" in t:
        return "inhal"
    if "DAMAR İÇİNE" in t:
        return "inj_iv"
    if "KAS İÇİNE" in t:
        return "inj_im"
    if "CİLT ALTINA" in t:
        return "inj_sc"
    if "ENJEKSİYONLA" in t:
        return "parenteral"
    if "ÖZEL UYGULAMA" in t:
        return "special"
    if "YUTULUR" in t or "İÇİLİR" in t:
        return "oral"
    return ""


def talimat_route_conflict(talimat: str, route_class: str) -> bool:
    """Cümlenin kanalı route_class kodlarıyla çelişiyor mu?

    Kanal belirsizse (genel 'UYGULANIR' vb.) çelişki SAYILMAZ.
    """
    codes = parse_route_class(route_class)
    if not codes:
        return False
    if 0 in codes:
        return bool((talimat or "").strip())  # malzemeye cümle basılmamalı
    ch = _talimat_channel(talimat)
    if not ch:
        return False
    ok: set[str] = set()
    for c in codes:
        ok |= _ROUTE_CLASS_CHANNELS.get(c, set())
    return ch not in ok


def _route_class_ending(codes: set[int], name: str) -> tuple[str | None, str]:
    """Sınıf kodlarına uygun (bitiş fiili, 'suyla' eki) döner.

    None bitiş = cümle hiç basılmamalı (ilaç-dışı malzeme).
    """
    n = (name or "").upper()
    if 0 in codes:
        return None, ""
    if 6 in codes and 7 in codes:
        return "GÖZE VEYA KULAĞA DAMLATILIR", ""
    if 8 in codes and 11 in codes:
        return "AĞIZ İÇİNE VE BOĞAZA SIKILIR (YUTULMAZ)", ""
    if 12 in codes:
        if "NEBÜL" in n or "NEBUL" in n:
            return "NEBÜLİZATÖR İLE SOLUNUR", ""
        return "DERİN NEFES İLE İÇE ÇEKİLİR", ""
    if 14 in codes:
        if "SAKIZ" in n:
            return ("YAVAŞÇA ÇİĞNENİP ARA ARA DİŞ ETİ İLE YANAK ARASINDA "
                    "BEKLETİLİR (YUTULMAZ)"), ""
        if "SPREY" in n or "SPRAY" in n:
            return "DİL ALTINA SIKILIR (YUTULMAZ)", ""
        return "DİLALTINDA ERİYENE KADAR BEKLENİR (YUTULMAZ)", ""
    if 15 in codes:
        return "CİLDE YAPIŞTIRILIR", ""
    if 16 in codes:
        return ("ÖZEL UYGULAMA YOLU — HEKİMİNİZİN/ECZACINIZIN TARİFİNE GÖRE "
                "KULLANILIR"), ""
    if 13 in codes and (codes & {3, 4, 5}):
        # Çok-yollu hastane ürünü: IM/IV/SC + rektal (midazolam vb.)
        # Parenteral yol etiket önceliklidir; rektal yol hastane personeli uygular.
        par = codes & {3, 4, 5}
        if len(par) > 1:
            return "ENJEKSİYONLA UYGULANIR (sağlık personeli)", ""
        if 3 in par:
            return "DAMAR İÇİNE UYGULANIR (sağlık personeli)", ""
        if 4 in par:
            return "KAS İÇİNE UYGULANIR (sağlık personeli)", ""
        return "CİLT ALTINA UYGULANIR", ""
    if 13 in codes:
        # ASCII "VAGINAL" (NUVARING, VAGIFEM) ve "VAG." kısaltması (KETORAL
        # VAG.) da vajinaldir; yalnız "VAJ" arayınca MAKATTAN'a düşüyordu.
        if any(k in n for k in ("VAJ", "VAGİN", "VAGIN", "VAG.",
                                "OVÜL", "OVUL", "DOUCHE")):
            if "DOUCHE" in n:
                return "VAJİNAL DUŞ (YIKAMA) OLARAK UYGULANIR", ""
            return "VAJEN İÇİNE YERLEŞTİRİLİR", ""
        return "MAKATTAN UYGULANIR", ""
    if 6 in codes:
        if any(k in n for k in ("POMAD", "POMAT", "MERHEM", "JEL")):
            return ("ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE İNCE ŞERİT "
                    "HALİNDE UYGULANIR"), ""
        return "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE DAMLATILIR", ""
    if 7 in codes:
        return "KULAK İÇİNE DAMLATILIR", ""
    if 10 in codes:
        if "DAMLA" in n:
            return "BURUN İÇİNE DAMLATILIR", ""
        return "BURUN İÇİNE SIKILIR", ""
    if 11 in codes:
        return "AĞIZ İÇİNDEN BOĞAZA SIKILIR", ""
    if 8 in codes:
        if "GARGARA" in n:
            return "YUTMADAN AĞIZDA ÇALKALANIP TÜKÜRÜLÜR", ""
        if "PASTİL" in n or "PASTIL" in n or "DROPS" in n:
            return "AĞIZDA EMİLİR (ÇİĞNENMEZ, YUTULMAZ)", ""
        if "SPREY" in n or "SPRAY" in n:
            return "AĞIZ İÇİNE SIKILIR (YUTULMAZ)", ""
        return "AĞIZ İÇİNE UYGULANIR (YUTULMAZ)", ""
    if 9 in codes:
        return "SAÇLI DERİYE UYGULANIR", ""
    if 2 in codes:
        if "SPREY" in n or "SPRAY" in n:
            return "ETKİLENEN BÖLGEYE SIKILIR", ""
        return "ETKİLENEN BÖLGEYE SÜRÜLÜR", ""
    par = codes & {3, 4, 5}
    if len(par) > 1:
        return "ENJEKSİYONLA UYGULANIR (sağlık personeli)", ""
    if 3 in codes:
        return "DAMAR İÇİNE UYGULANIR (sağlık personeli)", ""
    if 4 in codes:
        return "KAS İÇİNE UYGULANIR (sağlık personeli)", ""
    if 5 in codes:
        return "CİLT ALTINA UYGULANIR", ""
    if 1 in codes:
        if "SAŞE" in n or "SASE" in n:
            return "BİR BARDAK SUYA BOŞALTILIP İÇİLİR", ""
        if "EFERVESAN" in n:
            return "BİR BARDAK SUDA ERİTİLEREK İÇİLİR", ""
        if "ÇİĞNEME" in n or "CIGNEME" in n:
            return "ÇİĞNENEREK YUTULUR", ""
        if "DAMLA" in n:
            return ("AĞIZA VEYA BİR İÇECEĞE (su/meyve suyu) DAMLATILARAK "
                    "İÇİLİR"), ""
        if any(k in n for k in ("ŞURUP", "SURUP", "SÜSPANS", "SUSPANS",
                                "SOLÜSYON", "SOLUSYON", "ÇÖZELTİ", "COZELTI",
                                "LIKIT", "LİKİT", "LIQUID")):
            return "İÇİLİR", ""
        return "YUTULUR", "BİR BARDAK SUYLA"
    return "", ""


# ---------------------------------------------------------------------------
# Parenteral (enjeksiyon) uygulama yolu — etiket metinleri + tespit
# ---------------------------------------------------------------------------
# Kaynak öncelik sırası: e-reçete "Kullanım Şekli" ("Intra müsküler" /
# "Intra venöz" / "Subkutan") → route_class kodu → ilaç adı ipuçları.
# Ayar KAPALI iken (varsayılan) IM/IV ayrımı GİZLENİR; parenteraller yalnız
# genel "SAĞLIK PERSONELİ TARAFINDAN UYGULANIR" cümlesini taşır. Cilt altı
# (SC) ilaçlar çoğu kez hasta TARAFINDAN uygulandığından (insülin, LMWH,
# GLP-1) "sağlık personeli" denmez ve ayar kapalıyken mevcut SC cümlesine
# dokunulmaz.
_PAR_END_IM = "SAĞLIK PERSONELİ TARAFINDAN KAS İÇİNE UYGULANIR"
_PAR_END_IV = "SAĞLIK PERSONELİ TARAFINDAN DAMAR İÇİNE (SERUM İLE) UYGULANIR"
_PAR_END_SC = "CİLT ALTI (SUBKUTAN) YAĞ DOKUSUNA UYGULANIR"
_PAR_END_GENERIC = "SAĞLIK PERSONELİ TARAFINDAN UYGULANIR"

# Ad'da geçtiğinde ilacı enjeksiyonluk sayan kelimeler (nebül ampulleri ad
# fallback'inde NEBÜL dalıyla zaten ayrılır → buraya düşmez).
_INJECTABLE_NAME_KW = (
    "ENJEK", "ENJ.", "FLAKON", "AMPUL", "AMP.", "İĞNE",
    "ŞIRINGA", "ŞIRİNGA", "SIRINGA", "ENJEKSIYON", "ENJEKSİYON",
    "SUBKUTAN", "SUBKÜTAN", "İMPLANT", "IMPLANT",
    "İNFÜZYON", "INFÜZYON", "INFUZYON", "İNFUZYON",
    "PERFÜZYON", "PERFUZYON", "İNTRAVEN", "INTRAVEN",
    "İNTRAMÜSK", "INTRAMUSK", "INTRAMUSKULER", "İNTRAVEZİKAL",
    "IM/SC", "IM/IV", "SC/IV", "I.V", "I.M", "S.C", "LİYOFİLİZE",
)


def _name_is_injectable(name: str) -> bool:
    n = (name or "").upper()
    return any(k in n for k in _INJECTABLE_NAME_KW)


def _parenteral_route_from_text(text: str) -> str:
    """Metinden (e-reçete 'Kullanım Şekli' veya ilaç adı) parenteral alt yolu
    çıkarır: 'im' / 'iv' / 'sc' / '' (belirsiz).

    Medula'nın aksanlı + boşluklu yazımı ("Intra müsküler", "Intra venöz")
    ve ASCII/kısaltma biçimleri ("INTRAMUSKULER", "S.C") için ASCII'ye
    indirgeyip arar. Yalın "IM"/"IV" iki harfi (kelime içine sızar) ARANMAZ;
    yalnız noktalı kısaltmalar (I.M / I.V / S.C) ve açık ibareler aranır.
    """
    t = (text or "").upper()
    t = (t.replace("İ", "I").replace("Ü", "U").replace("Ö", "O")
          .replace("Ç", "C").replace("Ş", "S").replace("Ğ", "G"))
    if ("SUBKUT" in t or "SUBCUT" in t or "CILT ALT" in t
            or "DERI ALT" in t or "S.C" in t):
        return "sc"
    if ("INTRA VEN" in t or "INTRAVEN" in t or "DAMAR" in t
            or "I.V" in t or "INFUZYON" in t or "INFUSION" in t
            or "SERUM" in t):
        return "iv"
    if ("INTRA MUSK" in t or "INTRAMUSK" in t or "KAS ICI" in t
            or "I.M" in t or "ADALE" in t):
        return "im"
    return ""


def build_kullanim_talimati(
    *,
    drug_name: str,
    gunluk_kez=None,
    saat_arasi=None,
    kullanim_zamani=None,
    yemek: str = "",
    doz_str: str = "",
    kullanim_sekli: str = "",
    form: str = "",
    route_class: str = "",
    parenteral_route_mode: str = "",
) -> str:
    """Yapılandırılmış alanlardan etiketteki büyük kullanım cümlesi üret.

    route_class verilirse GÜVENLİK KİLİDİ devreye girer: üretilen bitiş
    fiilinin kanalı sınıf kodlarıyla çelişiyorsa fiil sınıfa uygun olanla
    değiştirilir; ilaç-dışı malzemede ("0") boş string döner.

    parenteral_route_mode (enjeksiyonluk ilaçlar için, boşsa devre dışı):
        "recete"  → e-reçete "Kullanım Şekli"ne (kullanim_sekli) göre IM/IV/SC
                    spesifik cümle ("...KAS İÇİNE UYGULANIR" vb.).
        "generic" → IM/IV/belirsiz parenteral "SAĞLIK PERSONELİ TARAFINDAN
                    UYGULANIR"a indirgenir; SC (kendi-uygulanan) korunur.

    Çıktı örnekleri:
        "SABAH-AKŞAM [12 SAAT ARA İLE] 1 TANE TOK KARNINA BİR BARDAK SUYLA YUTULUR."
        "GÜNDE 1 DEFA 1 TANE AÇ VEYA TOK KARNINA BİR BARDAK SUYLA YUTULUR."
        "SABAH-AKŞAM 1 ÖLÇEK AÇ VEYA TOK KARNINA İÇİLİR."
        "SABAH-ÖĞLE-AKŞAM-GECE YATMADAN 1 DAMLA GÖZ KAPAĞI ARASINA DAMLATILIR."
    """
    name = (drug_name or "").upper()

    # 1) Zaman ifadesi (SABAH-AKŞAM / SABAH-ÖĞLE-AKŞAM / GÜNDE N DEFA)
    zaman_kelimeleri = {
        "sabah": "SABAH", "öğle": "ÖĞLE", "akşam": "AKŞAM",
        "gece": "GECE YATMADAN", "yatmadan": "GECE YATMADAN",
    }
    kullanim_zamani = kullanim_zamani or []
    zaman_parts = []
    for z in kullanim_zamani:
        k = (z or "").strip().lower()
        if k in zaman_kelimeleri:
            zaman_parts.append(zaman_kelimeleri[k])

    if zaman_parts:
        zaman_str = "-".join(zaman_parts)
        if saat_arasi:
            zaman_str += f" [{saat_arasi} SAAT ARA İLE]"
    elif gunluk_kez:
        if gunluk_kez == 2 and not zaman_parts:
            zaman_str = "SABAH-AKŞAM"
            if saat_arasi:
                zaman_str += f" [{saat_arasi} SAAT ARA İLE]"
        elif gunluk_kez == 3:
            zaman_str = "SABAH-ÖĞLE-AKŞAM"
        elif gunluk_kez == 4:
            zaman_str = "SABAH-ÖĞLE-AKŞAM-GECE YATMADAN"
        else:
            zaman_str = f"GÜNDE {gunluk_kez} DEFA"
    elif saat_arasi:
        zaman_str = f"{saat_arasi} SAATTE BİR"
    else:
        zaman_str = "GÜNDE 1 DEFA"

    # 2) Doz ifadesi
    doz_str = (doz_str or "").strip().upper() or "1 TANE"

    # 3) Yemek durumu
    yemek_text_map = {
        "aç":                  "AÇ KARNINA",
        "tok":                 "TOK KARNINA",
        "yemekten önce":       "YEMEKTEN ÖNCE",
        "yemekten sonra":      "YEMEKTEN SONRA",
        "yemek başlangıcında": "YEMEĞİN HEMEN BAŞINDA",
        "yemekle":             "YEMEKLE BİRLİKTE",
        "fark etmez":          "AÇ VEYA TOK KARNINA",
    }
    yemek_text = yemek_text_map.get((yemek or "").strip().lower(), "")

    # 4) Bitiş fiili — Öncelik:
    #    (a) form parametresi (en güvenilir, infer_form'dan gelir)
    #    (b) Medula'nın "Kullanım Şekli" alanı
    #    (c) ilaç adındaki form ipuçları
    ks = (kullanim_sekli or "").upper()
    f = (form or "").lower()
    suyla = ""

    # (a) FORM bazlı — en güvenilir
    # Hem göze HEM kulağa kullanılan damlalar (Onadron Simple, Cebedex vb.):
    # form tek kanala sabitlendiğinden ada bakıp iki uygulama yolunu da yazarız.
    if is_eye_ear_drop_name(name):
        bitis = "GÖZE VEYA KULAĞA DAMLATILIR"
    elif f == "eye_drop":
        bitis = "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE DAMLATILIR"
    elif f == "eye_ointment":
        bitis = "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE İNCE ŞERİT HALİNDE UYGULANIR"
    elif f == "ear_drop":
        bitis = "KULAK İÇİNE DAMLATILIR"
    elif f == "nasal_spray":
        bitis = "BURUN İÇİNE SIKILIR"
    elif f == "nasal_drop":
        bitis = "BURUN İÇİNE DAMLATILIR"
    elif f == "oral_spray_throat":
        bitis = "AĞIZ İÇİNDEN BOĞAZA SIKILIR"
    elif f == "gargara_mouthwash":
        bitis = "YUTMADAN AĞIZDA ÇALKALANIP TÜKÜRÜLÜR"
    elif f == "oromucosal_gel":
        bitis = "AĞIZ İÇİNE UYGULANIR"
    elif f == "inhaler_pmdi" or f == "inhaler_dpi":
        bitis = "DERİN NEFES İLE İÇE ÇEKİLİR"
    elif f == "nebule":
        bitis = "NEBÜLİZATÖR İLE SOLUNUR"
    elif f == "injection_sc":
        bitis = "CİLT ALTINA UYGULANIR"
    elif f == "injection_im":
        bitis = "KAS İÇİNE UYGULANIR (sağlık personeli)"
    elif f == "injection_iv":
        bitis = "DAMAR İÇİNE UYGULANIR (sağlık personeli)"
    elif f == "suppository_rectal" or f == "enema_rectal":
        bitis = "MAKATTAN UYGULANIR"
    elif f == "cream_rectal":
        # Hemoroid kremi/merhemi: "etkilenen bölgeye" yetersiz — rektal
        # kullanım açıkça söylenir (Proctoglyvenol/Kortos/Anrecta...).
        bitis = "MAKAT BÖLGESİNE SÜRÜLÜR"
    elif f == "vaginal_ovule_or_cream":
        bitis = "VAJEN İÇİNE YERLEŞTİRİLİR"
    elif f == "transdermal_patch":
        bitis = "CİLDE YAPIŞTIRILIR"
    elif f in ("cream_or_ointment_topical", "gel_topical"):
        # Topikal SPREY sürülmez, püskürtülür (Oxezole/Lamisil/Rheumon vb.)
        if "SPREY" in name or "SPRAY" in name or "PÜSKÜRT" in name:
            bitis = "ETKİLENEN BÖLGEYE PÜSKÜRTÜLÜR"
        else:
            bitis = "ETKİLENEN BÖLGEYE SÜRÜLÜR"
    elif f == "sublingual_spray":
        bitis = "DİL ALTINA SIKILIR"
    elif f == "shampoo_medicated":
        bitis = "SAÇA UYGULANIR"
    elif f == "oral_drop":
        bitis = "AĞIZA VEYA BİR İÇECEĞE (su/meyve suyu) DAMLATILARAK İÇİLİR"
    elif f in ("syrup_or_suspension", "powder_for_suspension"):
        bitis = "İÇİLİR"
    elif f == "sachet_oral":
        bitis = "BİR BARDAK SUYA BOŞALTILIP İÇİLİR"
    elif f == "nutritional_supplement_oral":
        # Hazır beslenme solüsyonu (Infasource/Ensure/Fortimel 200 ml vb.):
        # ASLA "bir bardak suyla yutulur" değil — şişeden doğrudan içilir.
        bitis = "DOĞRUDAN İÇİLİR (sulandırmadan)"
    elif f == "nutritional_powder_oral":
        bitis = "KUTUSUNDAKİ TARİFE GÖRE SU İLE HAZIRLANARAK İÇİLİR"
    elif f == "tablet_chewable":
        # Çiğneme tableti: bütün yutulmaz, çiğnenir → ana cümle de bunu söylemeli.
        bitis = "ÇİĞNENEREK YUTULUR"
    elif f == "tablet_effervescent":
        # Efervesan: bütün yutulmaz, suda eritilip içilir.
        bitis = "BİR BARDAK SUDA ERİTİLEREK İÇİLİR"
    elif f in ("tablet_normal", "tablet_enteric_or_extended",
               "capsule_normal", "capsule_pellet_open"):
        bitis = "YUTULUR"
        suyla = "BİR BARDAK SUYLA"
    elif f == "tablet_sublingual":
        bitis = "DİLALTINDA ERİYENE KADAR BEKLENİR"

    # (b) Medula kullanim_sekli — form belirtilmediyse
    elif "GÖZ" in ks:
        bitis = "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE DAMLATILIR"
    elif "BURUN" in ks or "NAZAL" in ks:
        bitis = "BURUN İÇİNE SIKILIR" if "SPREY" in name else "BURUN İÇİNE DAMLATILIR"
    elif "KULAK" in ks:
        bitis = "KULAK İÇİNE DAMLATILIR"
    elif "VAJİNAL" in ks or "VAJEN" in ks:
        bitis = "VAJEN İÇİNE YERLEŞTİRİLİR"
    elif "REKTAL" in ks or "MAKAT" in ks:
        bitis = "MAKATTAN UYGULANIR"
    elif "CİLT" in ks or "DERİ" in ks or "ÜZERİNE SÜR" in ks:
        bitis = "ETKİLENEN BÖLGEYE SÜRÜLÜR"
    elif "AĞIZ" in ks and "GARGARA" in name:
        bitis = "YUTMADAN AĞIZDA ÇALKALANIP TÜKÜRÜLÜR"
    elif "AĞIZ" in ks and "SPREY" in name:
        bitis = "AĞIZ İÇİNDEN BOĞAZA SIKILIR"

    # (c) Ad bazlı fallback
    # Beslenme ürünü (enteral/oral) — ASLA "bir bardak suyla yutulur" DEĞİL.
    # Marka listesi + toz/sıvı ayrımı tek yerde: application_techniques.
    #   SAŞE/POŞET (örn. Resource Glutamin) → suya/meyve suyuna karıştırılıp içilir.
    #   TOZ MAMA (örn. Pediasure Toz 400 gr) → kutusundaki tarife göre hazırlanır.
    #   HAZIR SIVI (örn. Infasource/Fortimel 200 ml) → doğrudan içilir (sulandırılmaz).
    elif (_nf := nutrition_form_for_name(name)) is not None:
        if _nf == "nutritional_powder_oral":
            if any(k in name for k in ("SAŞE", "SASE", "POŞET", "POSET",
                                       "POUCH")):
                bitis = "BİR BARDAK SU VEYA MEYVE SUYUNA KARIŞTIRILIP İÇİLİR"
            else:
                bitis = "KUTUSUNDAKİ TARİFE GÖRE SU İLE HAZIRLANARAK İÇİLİR"
        else:
            bitis = "DOĞRUDAN İÇİLİR (sulandırmadan)"
    # Vajinal preparatlar — ŞURUP/SÜSPANSİYON, JEL/KREM ve FİTİL/SUPOZ
    # kontrollerinden ÖNCE: vajinal fitil/krem makat veya cilt dalına düşmesin.
    # ASCII "VAGINAL" (NUVARING, VAGIFEM) ve "VAG." kısaltması da yakalanır.
    elif any(k in name for k in ("VAJİN", "VAJIN", "VAGİN", "VAGIN", "VAG.",
                                 "OVÜL", "OVUL")):
        bitis = "VAJEN İÇİNE YERLEŞTİRİLİR"
    # Rektal ürünler — ŞURUP/SÜSPANSİYON ve KREM/MERHEM dallarından ÖNCE:
    # rektal süspansiyon/lavman İÇİLMEZ, rektal merhem cilde sürülmez
    # (OSIREC REKTAL SÜSPANSİYON "İÇİLİR" sanılıyordu). Fitil varsayılanı
    # REKTAL'dir (vajinal olanlar yukarıda ad kalıbıyla yakalandı).
    elif any(k in name for k in ("FİTİL", "FITIL", "SUPPOZ", "SUPOZ",
                                 "LAVMAN", "ENEMA", "REKTAL")):
        bitis = "MAKATTAN UYGULANIR"
    elif any(k in name for k in ("ŞURUP", "SURUP", "SÜSPANS", "SÜSPANSIYON", "SÜSPANSİYON")):
        bitis = "İÇİLİR"
    elif "GARGARA" in name:
        bitis = "YUTMADAN AĞIZDA ÇALKALANIP TÜKÜRÜLÜR"
    elif "ORAL DAMLA" in name or "AĞIZDAN DAMLA" in name:
        bitis = "AĞIZA VEYA BİR İÇECEĞE (su/meyve suyu) DAMLATILARAK İÇİLİR"
    # SKRS adları aksansız da gelir ("GOZ DAMLASI, COZELTI") — ikisi de denenir.
    elif "GÖZ DAMLA" in name or "GOZ DAMLA" in name:
        bitis = "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE DAMLATILIR"
    # Göz merhem/pomad/jel — genel MERHEM/KREM/POMAD (cilde sürülür) dalından
    # ÖNCE yakalanmalı; OFTALMİK JEL / GOZ POMADI adları da göz preparatıdır.
    elif (any(g in name for g in ("GÖZ", "GOZ", "OFTALMİK", "OFTALMIK", "OFT."))
          and any(k in name for k in ("MERHEM", "POMAD", "POMAT", "JEL"))
          and "JELATİN" not in name and "JELATIN" not in name):
        bitis = "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE İNCE ŞERİT HALİNDE UYGULANIR"
    # Oftalmik solüsyon/süspansiyon (TOBREX OFT. SOL, VIGAMOX OFTALMIK SOLUSYON):
    # adda "DAMLA" geçmese de göz damlasıdır.
    elif "OFTALMİK" in name or "OFTALMIK" in name or "OFT." in name:
        bitis = "ALT GÖZ KAPAĞI AŞAĞI ÇEKİLEREK İÇİNE DAMLATILIR"
    elif "KULAK DAMLA" in name:
        bitis = "KULAK İÇİNE DAMLATILIR"
    elif "BURUN DAMLA" in name or "NAZAL DAMLA" in name:
        bitis = "BURUN İÇİNE DAMLATILIR"
    elif "DAMLA" in name:
        bitis = "DAMLATILIR"
    elif "SPREY" in name and ("BOĞAZ" in name or "AĞIZ" in name or "ORAL" in name):
        bitis = "AĞIZ İÇİNDEN BOĞAZA SIKILIR"
    elif "SPREY" in name and ("NAZAL" in name or "BURUN" in name):
        bitis = "BURUN İÇİNE SIKILIR"
    # Nebül/inhalasyon — ENJEKSİYON kontrolünden ÖNCE: nebül ampulleri de "AMPUL"
    # içerir ama solunur, enjekte edilmez (örn. TOBI ... NEBÜLİZASYON İÇİN ... AMPUL).
    elif any(k in name for k in ("NEBÜL", "NEBUL", "NEBÜLİZASYON",
                                 "NEBULIZASYON", "NEBÜLİZAS", "NEBULIZAS")):
        bitis = "NEBÜLİZATÖR İLE SOLUNUR"
    elif any(k in name for k in ("İNHALER", "INHALER", "İNHALASYON",
                                 "INHALASYON", "AEROSOL")):
        bitis = "DERİN NEFES İLE İÇE ÇEKİLİR"
    # Çiğneme tableti — ENJEKSİYON/JEL kontrolünden ÖNCE: "ÇİĞNEME" içinde "İĞNE"
    # (iğne) geçtiğinden injection dalına düşmesin; ağızda çiğnenir.
    elif "ÇİĞNE" in name or "CIGNE" in name or "ÇIGNE" in name:
        bitis = "ÇİĞNENEREK YUTULUR"
    # JEL → sürülür; ANCAK "JELATİN" (yumuşak/sert jelatin kapsül) oral kapsüldür,
    # topikal jel değildir — onu dışla (örn. Tamiflu, Aknetrent kapsül).
    # (Vajinal ve rektal preparatlar yukarıda, ŞURUP/SÜSPANSİYON dalından
    # önce yakalandı.)
    elif "DOUCHE" in name:
        bitis = "VAJİNAL DUŞ (YIKAMA) OLARAK UYGULANIR"
    # Rektal krem/merhem/pomad (Proctoglyvenol, Anrecta, Proctolog...) —
    # genel KREM dalına düşüp "etkilenen bölgeye" denmesin; makata sürülür.
    # Lavman hariç ("REKTAL JEL ... LAVMAN" Libalaks aşağıdaki dala düşsün).
    elif (("REKTAL" in name or "RECTAL" in name or "MAKAT" in name)
          and "LAVMAN" not in name and "ENEMA" not in name
          and any(k in name for k in ("KREM", "MERHEM", "POMAD", "POMAT", "JEL"))):
        bitis = "MAKAT BÖLGESİNE SÜRÜLÜR"
    elif ((("JEL" in name and "JELATIN" not in name and "JELATİN" not in name)
           or "MERHEM" in name or "KREM" in name or "POMAD" in name)):
        bitis = "ETKİLENEN BÖLGEYE SÜRÜLÜR"
    # Parenteral (enjeksiyon/infüzyon/implant) — ASLA "YUTULUR"/"İÇİLİR" olmamalı.
    # Geniş kelime listesi: ampul, şırınga, enjektör, infüzyon, implant, IM/SC/IV.
    elif _name_is_injectable(name):
        bitis = "UYGULANIR"
        suyla = ""
    elif "ŞAMPUAN" in name or "SAMPUAN" in name:
        bitis = "SAÇA UYGULANIR"
    else:
        # Tablet/kapsül varsayılan
        bitis = "YUTULUR"
        suyla = "BİR BARDAK SUYLA"

    # --- route_class güvenlik kilidi ---
    # Bitiş fiilinin kanalı atanmış kullanım yoluyla çelişiyorsa (göz damlasına
    # "YUTULUR", dilaltına "İÇİLİR" gibi) fiili sınıfa uygun olanla değiştir.
    codes = parse_route_class(route_class)
    if codes:
        if 0 in codes:
            return ""  # ilaç değil (strip/lanset vb.) — kullanım cümlesi yok
        # Çok-yollu parenteral+rektal (IM/IV+rektal midazolam vb.):
        # "rectal" ok içinde olduğundan normal çelişki tespiti tetiklenmez ama
        # addan gelen MAKATTAN bitiş parenteral önceliğini gizler.
        if codes & {3, 4, 5} and 13 in codes and _talimat_channel(bitis) == "rectal":
            yeni_bitis, yeni_suyla = _route_class_ending(codes, name)
            if yeni_bitis:
                bitis, suyla = yeni_bitis, yeni_suyla
        ch = _talimat_channel(bitis)
        ok: set[str] = set()
        for c in codes:
            ok |= _ROUTE_CLASS_CHANNELS.get(c, set())
        if ch and ok and ch not in ok:
            yeni_bitis, yeni_suyla = _route_class_ending(codes, name)
            if yeni_bitis and 16 in codes:
                # Özel yol (RİA, intravezikal, periton...): "GÜNDE 1 DEFA
                # 1 TANE" öneki anlamsız — yalın cümle döner.
                return yeni_bitis + "."
            if yeni_bitis:
                bitis, suyla = yeni_bitis, yeni_suyla
        elif not ch and bitis == "DAMLATILIR" and codes & {6, 7, 10}:
            # Çıplak "DAMLATILIR" kanal belirtmez (örn. "TIMOSOL 5 ML DAMLA");
            # sınıf göz/kulak/burun ise uygulama yerini açıkça yaz.
            yeni_bitis, yeni_suyla = _route_class_ending(codes, name)
            if yeni_bitis:
                bitis, suyla = yeni_bitis, yeni_suyla

    # --- Parenteral uygulama yolu politikası (e-reçete ayarı) ---
    # route_class kilidinden SONRA çalışır → e-reçete "Kullanım Şekli"
    # (kullanim_sekli) bitiş fiilinin son sözünü söyler. Sınıflandırma yalnız
    # bitiş kanalına / enjeksiyonluk ada dayanır (oral/topikal asla buraya
    # girmez); yol ise önce e-reçeteden, sonra route_class'tan, en son addan.
    if parenteral_route_mode:
        _ch = _talimat_channel(bitis)
        _is_par = (_ch in ("inj_iv", "inj_im", "inj_sc", "parenteral")
                   or (bitis == "UYGULANIR" and _name_is_injectable(name)))
        if _is_par:
            # Yol kaynağı önceliği: e-reçete "Kullanım Şekli" → bitiş kanalı →
            # route_class kodu (tek parenteral kod) → ilaç adı ipucu.
            _route = _parenteral_route_from_text(kullanim_sekli)
            if not _route:
                _route = {"inj_im": "im", "inj_iv": "iv",
                          "inj_sc": "sc"}.get(_ch, "")
            if not _route:
                _par_codes = codes & {3, 4, 5}
                if len(_par_codes) == 1:
                    _route = {3: "iv", 4: "im", 5: "sc"}.get(
                        next(iter(_par_codes)), "")
            if not _route:
                _route = _parenteral_route_from_text(name)
            if parenteral_route_mode == "recete":
                # Ayar AÇIK: e-reçetedeki yola göre spesifik cümle.
                bitis = {"im": _PAR_END_IM, "iv": _PAR_END_IV,
                         "sc": _PAR_END_SC}.get(_route, _PAR_END_GENERIC)
                suyla = ""
            elif _route != "sc":
                # Ayar KAPALI: IM/IV/belirsiz parenteral → genel personel
                # cümlesi (yol gizli). SC kendi-uygulanan olduğundan dokunulmaz.
                bitis = _PAR_END_GENERIC
                suyla = ""

    # Damlatılan ilaçta doz birimi "TANE" değil "DAMLA"dır
    # ("GÜNDE 1 DEFA 1 TANE DAMLATILIR" → "... 1 DAMLA ...").
    if "DAMLAT" in bitis and "TANE" in doz_str:
        doz_str = doz_str.replace("TANE", "DAMLA")
    # Hazır beslenme solüsyonunda birim "TANE" değil "ŞİŞE"dir
    # ("GÜNDE 2 DEFA 1 TANE DOĞRUDAN İÇİLİR" → "... 1 ŞİŞE ...").
    if "DOĞRUDAN İÇİLİR" in bitis and "TANE" in doz_str:
        doz_str = doz_str.replace("TANE", "ŞİŞE")
    # Makattan uygulanan ilaçta birim: gerçek fitilde "FİTİL"; lavman/rektal
    # süspansiyon-krem FİTİL DEĞİLDİR ve adetli birimi yoktur → "KEZ"
    # ("SABAH-ÖĞLE-AKŞAM 1 KEZ MAKATTAN UYGULANIR").
    if "MAKAT" in bitis and "TANE" in doz_str:
        if (f == "suppository_rectal" or "FİTİL" in name or "FITIL" in name
                or "SUPOZ" in name or "SUPPOZ" in name):
            doz_str = doz_str.replace("TANE", "FİTİL")
        else:
            doz_str = doz_str.replace("TANE", "KEZ")
            # Zaman ifadesi zaten sayı içeriyorsa ("GÜNDE 1 DEFA 1 KEZ" /
            # "8 SAATTE BİR 1 KEZ" tekrarı) doz parçası tümden atılır.
            if "DEFA" in zaman_str or "SAATTE BİR" in zaman_str:
                doz_str = ""
    # Göz merhemi: doz zaten "1 İNCE ŞERİT" ise bitişteki "İNCE ŞERİT HALİNDE"
    # tekrarını at ("1 İNCE ŞERİT ... İÇİNE UYGULANIR").
    if "İNCE ŞERİT" in doz_str and "İNCE ŞERİT HALİNDE" in bitis:
        bitis = bitis.replace(" İNCE ŞERİT HALİNDE", "")

    # Cümleyi birleştir (boş doz parçası eklenmez)
    parts = [p for p in (zaman_str, doz_str) if p]
    if yemek_text:
        parts.append(yemek_text)
    if suyla:
        parts.append(suyla)
    parts.append(bitis)
    cumle = " ".join(parts).strip()
    if not cumle.endswith("."):
        cumle += "."
    return cumle


# ---------------------------------------------------------------------------
# Günde 1 kez ilaçlar için "tercih edilen zaman" çipleri
# ---------------------------------------------------------------------------
# Kullanıcı bir çipe basınca talimatın baştaki zaman ifadesi değişir; doz/yemek/
# bitiş fiili korunur. Örn: "GÜNDE 1 DEFA 1 TANE ... YUTULUR." → çip 'akşam' →
# "AKŞAM 1 TANE ... YUTULUR.". 'reset' → tekrar "GÜNDE 1 DEFA".
ZAMAN_CHIP_KELIME = {
    "reset": "GÜNDE 1 DEFA",
    "sabah": "SABAH",
    "öğle":  "ÖĞLE",
    "öğlen": "ÖĞLE",
    "akşam": "AKŞAM",
    "gece":  "GECE YATMADAN",
}

# Bir talimatın başında bulunabilecek olası zaman ifadeleri.
# Eşleştirme uzundan kısaya yapılır (önce "SABAH-AKŞAM", sonra "SABAH").
_ZAMAN_PREFIXLER = (
    "SABAH-ÖĞLE-AKŞAM-GECE YATMADAN",
    "SABAH-ÖĞLE-AKŞAM",
    "SABAH-AKŞAM",
    "GECE YATMADAN",
    "GÜNDE 1 DEFA",
    "SABAH", "ÖĞLEN", "ÖĞLE", "AKŞAM", "GECE",
)


def set_talimat_zaman(talimat: str, chip: str) -> str:
    """Günde 1 kez talimatının baştaki zaman ifadesini ``chip``'e göre değiştir.

    chip: 'reset' | 'sabah' | 'öğle' | 'akşam' | 'gece'
    Talimatın geri kalanı (doz, yemek durumu, bitiş fiili) olduğu gibi kalır.
    """
    yeni = ZAMAN_CHIP_KELIME.get((chip or "").strip().lower(), "GÜNDE 1 DEFA")
    t = (talimat or "").strip()
    if not t:
        return yeni
    for pre in sorted(_ZAMAN_PREFIXLER, key=len, reverse=True):
        if t.upper().startswith(pre):
            return (yeni + t[len(pre):]).strip()
    # Baş ifade tanınmadı → başa ekle
    return f"{yeni} {t}".strip()


def detect_talimat_zaman(talimat: str) -> str:
    """Talimatın baştaki zaman ifadesinden hangi çipin seçili olduğunu döndür.

    Döner: 'reset' | 'sabah' | 'öğle' | 'akşam' | 'gece' | "" (tanınmadı/çoklu).
    """
    t = (talimat or "").strip().upper()
    if t.startswith("GÜNDE 1 DEFA"):
        return "reset"
    # Çoklu zaman (SABAH-AKŞAM gibi) → tek çip eşleşmesi yok
    if t.startswith("SABAH-"):
        return ""
    if t.startswith("GECE"):
        return "gece"
    if t.startswith("AKŞAM"):
        return "akşam"
    if t.startswith("ÖĞLE") or t.startswith("ÖĞLEN"):
        return "öğle"
    if t.startswith("SABAH"):
        return "sabah"
    return ""


def guess_form(drug_name: str) -> str:
    """İlaç adından genel farmasötik form/kategori tahmin et.

    DB'de tarifi yokken etiketin 2. satırında ('ilaç türü') gösterilebilir.
    Kategori değil, FORM döndürür ('Göz damlası', 'Süspansiyon' gibi).
    """
    name = (drug_name or "").upper()
    if "GÖZ" in name and "DAML" in name:    return "Göz damlası"
    if "GÖZ" in name and "JEL" in name:     return "Göz jeli"
    if "GÖZ" in name and "POMAD" in name:   return "Göz pomadı"
    if "NAZAL" in name or "BURUN" in name:  return "Burun spreyi" if "SPREY" in name else "Burun damlası"
    if "KULAK" in name and "DAML" in name:  return "Kulak damlası"
    if "ŞURUP" in name or "SURUP" in name:  return "Şurup"
    # Rektal sıvı formlar fitil DEĞİLDİR — genel "Süspansiyon"dan önce ayrılır
    if "LAVMAN" in name or "ENEMA" in name: return "Lavman"
    if "REKTAL" in name and ("SÜSPANS" in name or "SUSPANS" in name):
        return "Rektal süspansiyon"
    if "SÜSPANSIYON" in name or "SÜSPANSİYON" in name: return "Süspansiyon"
    if "GARGARA" in name:                   return "Gargara"
    if "ŞAMPUAN" in name or "SAMPUAN" in name: return "Şampuan"
    if "MERHEM" in name:                    return "Merhem"
    if "KREM" in name:                      return "Krem"
    if "POMAD" in name:                     return "Pomad"
    if "JEL " in name or " JEL" in name:    return "Jel"
    if "FİTİL" in name or "FITIL" in name:  return "Fitil"
    if "EFERVESAN" in name:                 return "Efervesan tablet"
    if "ÇİĞNEME" in name:                   return "Çiğneme tablet"
    if "AĞIZDA DAĞILAN" in name or "AGIZDA DAGILAN" in name: return "Ağızda dağılan tablet"
    if "FİLM TABLET" in name or "FILM TB" in name or "FTB" in name: return "Film tablet"
    if "TABLET" in name or "TB." in name:   return "Tablet"
    if "KAPSÜL" in name or "KAPSUL" in name: return "Kapsül"
    if "DRAJE" in name:                     return "Draje"
    if "ENJEK" in name:                     return "Enjeksiyon"
    if "FLAKON" in name:                    return "Flakon"
    if "SPREY" in name:                     return "Sprey"
    return ""
