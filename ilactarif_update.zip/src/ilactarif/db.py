"""SQLite şeması ve bağlantı yönetimi.

Tablolar:
  drugs         — İlaç ana kaydı (Excel'den import edilen + sonradan eklenen)
  drug_labels   — Bir ilaca ait 1/2/3 numaralı etiket içerikleri (JSON)
  settings      — Eczane bilgileri, uygulama ayarları

Şema sade tutuldu; FTS5 vb. iyileştirmeler veri modeli onaylandıktan sonra eklenecek.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "data" / "ilactarif.db"


SCHEMA = """
CREATE TABLE IF NOT EXISTS drugs (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode             TEXT    UNIQUE,
    name                TEXT    NOT NULL,
    manufacturer        TEXT,
    drug_type           TEXT,            -- 'İLAÇ' veya 'PASİF İLAÇ'
    sales_count         INTEGER DEFAULT 0,   -- Excel 'Çıkış' sütunu
    stock               INTEGER DEFAULT 0,
    equivalent_code     TEXT,
    rank                INTEGER,         -- Çıkış'a göre sıralama (1 = en çok satan)
    -- NOT: storage_conditions/usage_warnings/interactions sütunları kaldırıldı.
    -- İçerik artık drug_label_blocks tablosunda block_type='saklama'/'dikkat'/'etkilesim'
    -- olarak saklanıyor (source ile kategorize: manual / prospektus_kt / general_knowledge).
    atc_code            TEXT,            -- SKRS'den: WHO ATC kodu (etken madde sınıfı), örn. "J01CR02"
    atc_name            TEXT,            -- SKRS'den: ATC açıklaması (etken madde adı)
    prescription_type   TEXT,            -- SKRS'den: "Normal", "Mor", "Turuncu" vb. reçete türü
    skrs_status         TEXT,            -- SKRS'den: "Aktif" / "Pasif" (SKRS listesi durumu)
    -- Yapısal alanlar (sorgulanabilir; etiket render'ında doğrudan kullanılır)
    active_ingredient   TEXT,            -- Etken maddenin sade Türkçe adı (ATC adından farklı olabilir)
    form                TEXT,            -- "tablet", "süspansiyon", "krem", "inhaler", "damla", "sprey", ...
    route               TEXT,            -- "ağızdan", "cilt üzerine", "göze", "buruna", "kulağa", "solunum", "rektal", "vajinal", "cilt altı", "kas içi", "damar içi"
    dose_unit           TEXT,            -- "tablet", "ml", "puf", "damla", "uygulama", "fitil", "ovül"
    default_dose        TEXT,            -- "1", "5", "2" — ilacın etiketteki varsayılan miktarı (Medula gerçek dozu ile override edilir)
    daily_freq          INTEGER,         -- günde kaç kez (1-6)
    hours_apart         INTEGER,         -- saat arası (örn. 8 = "8 saatte bir")
    meal_relation       TEXT,            -- "aç" | "tok" | "yemekten önce" | "yemekle" | "yemekten sonra" | "fark etmez"
    treatment_days      INTEGER,         -- tedavi süresi (gün). NULL = belirsiz / kronik
    indication_short    TEXT,            -- Etiket başlığı için kısa endikasyon, örn. "AĞRI KESİCİ", "ANTİBİYOTİK"
    created_at          TEXT    DEFAULT CURRENT_TIMESTAMP,
    updated_at          TEXT    DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_drugs_rank ON drugs(rank);
CREATE INDEX IF NOT EXISTS idx_drugs_name ON drugs(name);

CREATE TABLE IF NOT EXISTS drug_labels (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    drug_id      INTEGER NOT NULL REFERENCES drugs(id) ON DELETE CASCADE,
    label_type   INTEGER NOT NULL CHECK (label_type IN (1, 2, 3)),
    -- 1 = Kullanım/dozaj etiketi
    -- 2 = Hazırlama etiketi (şurup/süspansiyon)
    -- 3 = Uyarı etiketi
    content_json TEXT    NOT NULL,    -- Yapısal içerik (bkz. models.py)
    source_url   TEXT,                -- Bilginin alındığı kaynak (Titck, prospektüs vb.)
    reviewed     INTEGER DEFAULT 0,   -- Eczacı onayı (0=AI, 1=onaylanmış, 2=düzeltilmiş)
    filled_at    TEXT    DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(drug_id, label_type)
);

CREATE INDEX IF NOT EXISTS idx_labels_drug ON drug_labels(drug_id);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- Bir ilaca ait, KT/etiket içeriğini oluşturan modüler bilgi blokları.
-- Aynı drug_id + block_type için farklı kaynaklardan birden fazla satır olabilir
-- (UNIQUE drug_id+block_type+source).
-- block_type değerleri: 'endikasyon' | 'teknik' | 'hazirlama' | 'sivi' |
--                       'sonlandirma' | 'dikkat' | 'etkilesim' | 'yan_etki' |
--                       'saklama' | 'hatirlatma'
-- source değerleri:     'category_template' (AI/şablon — atc_label_blocks.py)
--                       'prospektus_kt'     (Gerçek TITCK Kullanma Talimatı çekimi)
--                       'manual'            (Eczacı tarafından eklenmiş)
CREATE TABLE IF NOT EXISTS drug_label_blocks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    drug_id      INTEGER NOT NULL REFERENCES drugs(id) ON DELETE CASCADE,
    block_type   TEXT    NOT NULL,
    source       TEXT    NOT NULL DEFAULT 'category_template',
    content      TEXT    NOT NULL,            -- Bloğun metni (sade Türkçe, hasta dili)
    source_url   TEXT,                        -- Bilginin kaynağı (TITCK KT linki vb.)
    template_key TEXT,                        -- application_techniques şablon anahtarı (varsa)
    reviewed     INTEGER DEFAULT 0,           -- 0 = AI/şablon, 1 = eczacı onayı, 2 = düzeltilmiş
    created_at   TEXT    DEFAULT CURRENT_TIMESTAMP,
    updated_at   TEXT    DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(drug_id, block_type, source)
);

CREATE INDEX IF NOT EXISTS idx_label_blocks_drug   ON drug_label_blocks(drug_id);
CREATE INDEX IF NOT EXISTS idx_label_blocks_type   ON drug_label_blocks(block_type);
CREATE INDEX IF NOT EXISTS idx_label_blocks_source ON drug_label_blocks(source);

-- Kullanıcı tercihleri: bir ilaç için B (hazırlama/teknik) veya C (ciddi uyarı)
-- etiketinin kalıcı olarak kapatılması ("bir daha gösterme") ve/veya metnin
-- kullanıcı tarafından düzenlenmiş özel sürümü.
--   label_kind: 'A' (temel kullanım) | 'B' (hazırlama/teknik) | 'C' (ciddi uyarı) | 'D' (dikkat)
--   suppressed:     1 = bu ilaç için bu etiketi bir daha üretme/gösterme
--   custom_text:    doluysa etikete bloklardan üretilen metin yerine bu basılır
--   print_override: etiket GÖSTERİLİR ama baskı kutusunun VARSAYILAN durumunu ezer.
--                   NULL = hesaplanan varsayılan; 0 = zorla İŞARETSİZ; 1 = zorla İŞARETLİ.
--                   (suppress'ten farklı: etiketi gizlemez, sadece kutu işaretini etkiler.)
CREATE TABLE IF NOT EXISTS drug_label_prefs (
    drug_id     INTEGER NOT NULL REFERENCES drugs(id) ON DELETE CASCADE,
    label_kind  TEXT    NOT NULL,
    suppressed  INTEGER NOT NULL DEFAULT 0,
    custom_text TEXT,
    print_override INTEGER,
    updated_at  TEXT    DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (drug_id, label_kind)
);

CREATE INDEX IF NOT EXISTS idx_label_prefs_drug ON drug_label_prefs(drug_id);

-- Yakalanan reçetelerin hasta bilgisi (reçete no → ad/TC).
-- Amaç: hasta adı "Reçete Başı" (E-Reçete Görüntüle) sayfasında görünür ama
-- "Reçete Sonu" (SGK onay) sayfasında bazen boş gelir. Adı bir kez gördüğümüz
-- anda buraya kaydederiz; sonra (farklı oturumda bile) reçete no ile geri
-- alınır. Böylece doğrudan sonuç sayfasına gidilse de etikette hasta adı olur.
CREATE TABLE IF NOT EXISTS recete_hasta (
    recete_no   TEXT PRIMARY KEY,
    hasta_ad    TEXT,
    hasta_tc    TEXT,
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Etiket KONTROL modülü (3. sekme) ilerleme durumu: bir grup temsilcisinin
-- etiketinin gözden geçirilip "kontrol edildi" olarak işaretlenmesi. Grup,
-- temsilci ilacın id'si (build_review_list rep_id) ile anahtarlanır.
CREATE TABLE IF NOT EXISTS label_review_status (
    drug_id     INTEGER PRIMARY KEY REFERENCES drugs(id) ON DELETE CASCADE,
    reviewed    INTEGER NOT NULL DEFAULT 0,
    reviewed_at TEXT    DEFAULT CURRENT_TIMESTAMP
);

-- Kargo etiketi alıcı (hasta) adres defteri. Bir hastaya kargo etiketi
-- basıldığında ad/telefon/adres buraya kaydedilir; sonraki seferlerde ad veya
-- telefon ile aranıp adres otomatik geri yüklenir. kullanim = kaç kez kullanıldı
-- (sık kullanılan üste sıralanır), kargo_firma = o alıcı için son seçilen firma.
CREATE TABLE IF NOT EXISTS kargo_alici (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ad          TEXT NOT NULL,
    telefon     TEXT NOT NULL DEFAULT '',
    adres       TEXT NOT NULL DEFAULT '',
    kargo_firma TEXT NOT NULL DEFAULT '',
    kullanim    INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ad, telefon)
);

CREATE INDEX IF NOT EXISTS idx_kargo_alici_ad ON kargo_alici(ad);

-- Emanet ilaç kayıtları (hangi hasta hangi ilacı ne zaman emanet aldı / ne zaman
-- yazdırılmalı). Eczane nüshası etiketi + kayıt takibi için.
CREATE TABLE IF NOT EXISTS emanet_records (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    hasta_ad        TEXT NOT NULL DEFAULT '',
    ilac_ad         TEXT NOT NULL DEFAULT '',
    barkod          TEXT NOT NULL DEFAULT '',
    telefon         TEXT NOT NULL DEFAULT '',
    alis_tarihi     TEXT NOT NULL DEFAULT '',   -- emanetin alındığı (kayıt) tarihi
    yazdirma_tarihi TEXT NOT NULL DEFAULT '',   -- ilacın yazdırılması gereken tarih
    created_at      TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_emanet_hasta ON emanet_records(hasta_ad);

-- Botanik EOS ürün kataloğunun yerel kopyası (ad + barkod + satış fiyatı).
-- Botanik SQL veritabanından (UMIT\\BOTANIKSQL / eczane) SALT-OKUNUR çekilir ve
-- buraya senkronlanır. "Botanik'ten canlı fiyat çek" ayarı KAPALIYKEN fiyat
-- bu tablodan okunur (çevrimdışı/hızlı). Bir ürünün birden çok barkodu olabilir
-- → her (urun_id, barkod) ayrı satır; barkodsuz ürün barkod='' ile bir satır.
CREATE TABLE IF NOT EXISTS botanik_katalog (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    urun_id     INTEGER,
    barkod      TEXT NOT NULL DEFAULT '',
    ad          TEXT NOT NULL,
    fiyat       REAL,            -- UrunFiyatEtiket (perakende satış/etiket)
    kamu_fiyat  REAL,            -- UrunFiyatKamu (SGK/kamu)
    stok        INTEGER,
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_botanik_katalog_barkod ON botanik_katalog(barkod);
CREATE INDEX IF NOT EXISTS idx_botanik_katalog_ad     ON botanik_katalog(ad);

-- Majistral (yapma ilaç) hammadde/etken madde sözlüğü. Majistral etiketi
-- sekmesinde madde adı combobox'ı bu tablodan beslenir (otomatik tamamlama).
-- ad = hammadde adı, birim = önerilen varsayılan birim (g/ml; seçilince combo'ya
-- gelir), kategori = isteğe bağlı sınıf, kullanim = kaç kez kullanıldı (sık
-- kullanılan üste sıralanır). Hazır liste seed ile yüklenir; kullanıcı yeni
-- madde eklediğinde de buraya kaydedilir (bir dahaki sefere hazır gelir).
-- paket_miktar/paket_fiyat: hammadde nasıl satılıyorsa (ör. 100 g paket 250 TL);
-- birim fiyat = paket_fiyat / paket_miktar olarak maliyet hesabında türetilir.
CREATE TABLE IF NOT EXISTS magistral_hammadde (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ad           TEXT NOT NULL UNIQUE,
    birim        TEXT NOT NULL DEFAULT '',
    kategori     TEXT NOT NULL DEFAULT '',
    paket_miktar REAL NOT NULL DEFAULT 0,
    paket_fiyat  REAL NOT NULL DEFAULT 0,
    kullanim     INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at   TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_magistral_hammadde_ad ON magistral_hammadde(ad);

-- Majistral ambalaj malzemeleri (kilitli poşet, plastik/cam şişe, damlalık,
-- pomat kutusu, krem kavanozu, merhem tüpü...). fiyat = adet başı TL. Majistral
-- maliyet analizinde seçilen ambalajların tutarı toplama eklenir.
CREATE TABLE IF NOT EXISTS magistral_ambalaj (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ad          TEXT NOT NULL UNIQUE,
    fiyat       REAL NOT NULL DEFAULT 0,
    kategori    TEXT NOT NULL DEFAULT '',
    kullanim    INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_magistral_ambalaj_ad ON magistral_ambalaj(ad);
"""


DEFAULT_SETTINGS = {
    "eczane_adi":     "İKİZLER ECZANESİ",
    "eczane_telefon": "0 212 515 74 40",
    "eczane_adres":   "FATİH MAH VELİOĞLU CAD NO:82/B BAĞCILAR İSTANBUL",
    # Ağ yazıcısı (GPrinter GP-1125D — TSPL, ham TCP 9100)
    "printer_host":   "192.168.1.172",
    "printer_port":   "9100",
    # Fiziksel etiket boyutu (mm) — TSPL SIZE komutunda kullanılır
    "label_w_mm":  "60",
    "label_h_mm":  "40",
    "label_gap_mm": "2",
    # Yazıcı çözünürlüğü: GPrinter GP-1125D = 203 DPI; bazı modeller 300 DPI
    "printer_dpi": "203",
    # Kutu üstü fiyat etiketi (6. sekme) — ana etiketten BAĞIMSIZ küçük boyut +
    # ayrı yazıcı seçimi. box_printer_active boşsa aktif (ana) yazıcı kullanılır.
    "box_label_w_mm":  "40",
    "box_label_h_mm":  "25",
    "box_printer_active": "",
    # Raf etiketi (5. sekme) — barkod deseni + barkod no + ilaç adı + satış fiyatı.
    # Ana etiketten bağımsız boyut + ayrı yazıcı (raf_printer_active boşsa aktif
    # yazıcı). Varsayılan 60×40 = ana sarı stokla aynı → stok değiştirmeden basılır.
    "raf_label_w_mm":  "60",
    "raf_label_h_mm":  "40",
    "raf_printer_active": "",
    # Kargo etiketi (7. sekme) — alıcı + gönderen kargo etiketi. Ana etiketten
    # bağımsız boyut + ayrı yazıcı seçimi (kargo_printer_active boşsa aktif yazıcı).
    # kargo_firmalar: açılır listedeki kargo firmaları (| ile ayrılır, ayardan
    # düzenlenebilir). kargo_firma_son: en son seçilen firma (varsayılan gelir).
    "kargo_label_w_mm":  "60",
    "kargo_label_h_mm":  "40",
    "kargo_printer_active": "",
    "kargo_firmalar":    "Yurtiçi Kargo|Aras Kargo|MNG Kargo|PTT Kargo",
    "kargo_firma_son":   "Yurtiçi Kargo",
    # Majistral (yapma ilaç) etiketi — iki ayrı etiket (içerik + kullanım/bilgi).
    # Ana etiketten BAĞIMSIZ boyut + ayrı yazıcı (majistral_printer_active boşsa
    # aktif/ana yazıcı kullanılır). İçerik sığmazsa otomatik 2.+ etikete taşar.
    "majistral_label_w_mm":  "60",
    "majistral_label_h_mm":  "40",
    "majistral_printer_active": "",
    # Majistral maliyet analizi — varsayılan işçilik/ek maliyet (TL, son kullanılan).
    "magistral_iscilik": "0",
    # Botanik EOS veritabanı entegrasyonu (ürün adı/barkod/satış fiyatı).
    #   botanik_db_enabled = "1" → fiyat CANLI Botanik DB'den (calede, salt-okunur)
    #                        "0" → fiyat programın kendi botanik_katalog tablosundan
    # Bağlantı, Botanik SQL sunucusuna salt-okunur 'calede' kullanıcısı ile yapılır.
    # GÜVENLİK: server/şifre BURADA TUTULMAZ (git'e girmez). Bunlar her makinede
    # botanik_provision.py tarafından (Botanik'in kendi config'inden sunucu + sa
    # okunarak) calede oluşturulup YEREL DB'ye yazılır. Şifre makineye özgü üretilir.
    "botanik_db_enabled":  "0",
    "botanik_db_server":   "",
    "botanik_db_name":     "eczane",
    "botanik_db_user":     "calede",
    "botanik_db_pass":     "",
    "botanik_katalog_updated": "",   # son katalog senkron zamanı (ISO)
    # Global klavye kısayolları (keyboard modülü sözdizimi)
    "hotkey_recete_sonu":    "shift+f12",
    "hotkey_recete_basi":    "shift+i",
    "hotkey_parekende":      "shift+p",
    "hotkey_etiket_sayfasi": "shift+u",
    # Kalıcı etiket görünüm/baskı kısıtlamaları
    "only_basic_print":   "0",  # "1" → her zaman sadece A etiketi bas
    "only_basic_display": "0",  # "1" → ekranda sadece A etiketi göster
    # Parenteral (enjeksiyon: ampul/flakon/enjektör/IV solüsyon) ilaçlarda
    # e-reçete "Kullanım Şekli" alanındaki uygulama yolunu (Intra müsküler /
    # Intra venöz / Subkutan) etikete yazma tercihi:
    #   "0" (varsayılan) → yol GİZLİ: parenteraller yalnız
    #                      "SAĞLIK PERSONELİ TARAFINDAN UYGULANIR" der.
    #   "1"              → e-reçeteden gelen IM/IV/SC yolu SPESİFİK yazılır.
    "erecete_parenteral_route": "0",
}

# Boşsa geriye doldurulacak ayarlar: uygulama başlangıcında yazıcı tanımsızsa
# çökmemesi için minimum fallback. Gerçek değer kurulum wizard'ından gelir.
_BACKFILL_IF_EMPTY = {
    "printer_host": "",
    "printer_port": "9100",
}


def get_connection(db_path: Path | str | None = None) -> sqlite3.Connection:
    """SQLite bağlantısı döndürür. Foreign keys aktif, satırlar dict gibi erişilebilir."""
    path = Path(db_path) if db_path else DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    """Tabloları oluştur, sütun migration'larını uygula ve varsayılan ayarları ekle."""
    conn.executescript(SCHEMA)
    _migrate_drugs_columns(conn)
    _migrate_label_prefs_columns(conn)
    _migrate_magistral_hammadde_columns(conn)
    for k, v in DEFAULT_SETTINGS.items():
        conn.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (k, v)
        )
    # Eski DB'lerde boş kalmış ayarları anlamlı varsayılanla doldur (örn. telefon).
    for k, v in _BACKFILL_IF_EMPTY.items():
        conn.execute(
            "UPDATE settings SET value = ? "
            "WHERE key = ? AND (value IS NULL OR TRIM(value) = '')",
            (v, k),
        )
    conn.commit()


def get_settings(conn: sqlite3.Connection) -> dict[str, str]:
    """settings tablosunu {key: value} sözlüğü olarak döndürür."""
    return {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}


def save_setting(conn: sqlite3.Connection, key: str, value: str) -> None:
    """Tek bir ayarı kaydeder (varsa günceller). commit dahil."""
    conn.execute(
        "INSERT INTO settings(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )
    conn.commit()


# ---------------------------------------------------------------------------
# Kargo etiketi adres defteri (kargo_alici)
# ---------------------------------------------------------------------------
def upsert_kargo_alici(
    conn: sqlite3.Connection,
    ad: str,
    telefon: str = "",
    adres: str = "",
    kargo_firma: str = "",
) -> int | None:
    """Kargo alıcısını (hasta) ekle/güncelle; kullanım sayacını +1 yapar.

    Aynı (ad, telefon) varsa adres/firma güncellenir; yoksa yeni kayıt açılır.
    Yeni/güncellenen kaydın id'sini döndürür (ad boşsa None).
    """
    ad = (ad or "").strip()
    if not ad:
        return None
    telefon = (telefon or "").strip()
    adres = (adres or "").strip()
    kargo_firma = (kargo_firma or "").strip()
    row = conn.execute(
        "SELECT id FROM kargo_alici WHERE ad = ? AND telefon = ?",
        (ad, telefon),
    ).fetchone()
    if row:
        conn.execute(
            "UPDATE kargo_alici SET adres = ?, kargo_firma = ?, "
            "kullanim = kullanim + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (adres, kargo_firma, row["id"]),
        )
        rid = row["id"]
    else:
        cur = conn.execute(
            "INSERT INTO kargo_alici(ad, telefon, adres, kargo_firma, kullanim) "
            "VALUES(?, ?, ?, ?, 1)",
            (ad, telefon, adres, kargo_firma),
        )
        rid = cur.lastrowid
    conn.commit()
    return rid


def search_kargo_alici(
    conn: sqlite3.Connection, query: str, limit: int = 20
) -> list[dict]:
    """Ada/telefona göre kargo alıcılarını ara (sık kullanılan + yeni üste)."""
    q = (query or "").strip()
    if not q:
        return []
    like = f"%{q}%"
    rows = conn.execute(
        "SELECT * FROM kargo_alici WHERE ad LIKE ? OR telefon LIKE ? "
        "ORDER BY kullanim DESC, updated_at DESC LIMIT ?",
        (like, like, limit),
    ).fetchall()
    return [dict(r) for r in rows]


def list_kargo_alici(conn: sqlite3.Connection, limit: int = 200) -> list[dict]:
    """Tüm kargo alıcılarını sık kullanılana göre sıralı döndürür."""
    rows = conn.execute(
        "SELECT * FROM kargo_alici ORDER BY kullanim DESC, updated_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    return [dict(r) for r in rows]


def delete_kargo_alici(conn: sqlite3.Connection, alici_id: int) -> None:
    """Bir kargo alıcısını adres defterinden siler."""
    conn.execute("DELETE FROM kargo_alici WHERE id = ?", (alici_id,))
    conn.commit()


# ---------------------------------------------------------------------------
# Majistral hammadde sözlüğü (magistral_hammadde) — etiket combobox'ı için
# ---------------------------------------------------------------------------
_HAMMADDE_COLS = "ad, birim, kategori, paket_miktar, paket_fiyat, kullanim"


def list_magistral_hammadde(conn: sqlite3.Connection) -> list[dict]:
    """Tüm hammaddeleri (sık kullanılan üste, sonra alfabetik) döndürür."""
    rows = conn.execute(
        f"SELECT {_HAMMADDE_COLS} FROM magistral_hammadde "
        "ORDER BY kullanim DESC, ad COLLATE NOCASE"
    ).fetchall()
    return [dict(r) for r in rows]


def search_magistral_hammadde(
    conn: sqlite3.Connection, query: str, limit: int = 40
) -> list[dict]:
    """Ada göre hammadde ara (sık kullanılan + alfabetik). Boş sorgu → ilk N."""
    q = (query or "").strip()
    if not q:
        rows = conn.execute(
            f"SELECT {_HAMMADDE_COLS} FROM magistral_hammadde "
            "ORDER BY kullanim DESC, ad COLLATE NOCASE LIMIT ?",
            (limit,),
        ).fetchall()
    else:
        rows = conn.execute(
            f"SELECT {_HAMMADDE_COLS} FROM magistral_hammadde "
            "WHERE ad LIKE ? ORDER BY kullanim DESC, ad COLLATE NOCASE LIMIT ?",
            (f"%{q}%", limit),
        ).fetchall()
    return [dict(r) for r in rows]


def magistral_hammadde_price_map(conn: sqlite3.Connection) -> dict[str, dict]:
    """{ad.lower(): {ad, birim, paket_miktar, paket_fiyat}} — maliyet hesabı için."""
    rows = conn.execute(
        "SELECT ad, birim, paket_miktar, paket_fiyat FROM magistral_hammadde"
    ).fetchall()
    return {r["ad"].lower(): dict(r) for r in rows}


def set_magistral_hammadde_fiyat(
    conn: sqlite3.Connection, ad: str, paket_miktar: float, paket_fiyat: float,
    *, birim: str | None = None,
) -> None:
    """Hammaddenin paket miktar/fiyatını (ve istenirse birimini) günceller/ekler."""
    ad = (ad or "").strip()
    if not ad:
        return
    row = conn.execute(
        "SELECT id, birim FROM magistral_hammadde WHERE ad = ? COLLATE NOCASE", (ad,)
    ).fetchone()
    if row:
        if birim:
            conn.execute(
                "UPDATE magistral_hammadde SET paket_miktar = ?, paket_fiyat = ?, "
                "birim = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (paket_miktar, paket_fiyat, birim, row["id"]),
            )
        else:
            conn.execute(
                "UPDATE magistral_hammadde SET paket_miktar = ?, paket_fiyat = ?, "
                "updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (paket_miktar, paket_fiyat, row["id"]),
            )
    else:
        conn.execute(
            "INSERT INTO magistral_hammadde(ad, birim, paket_miktar, paket_fiyat) "
            "VALUES(?, ?, ?, ?)",
            (ad, birim or "", paket_miktar, paket_fiyat),
        )
    conn.commit()


# --- Majistral ambalaj malzemeleri (magistral_ambalaj) ---
def list_magistral_ambalaj(conn: sqlite3.Connection) -> list[dict]:
    """Tüm ambalajları (sık kullanılan üste, sonra alfabetik) döndürür."""
    rows = conn.execute(
        "SELECT ad, fiyat, kategori, kullanim FROM magistral_ambalaj "
        "ORDER BY kullanim DESC, ad COLLATE NOCASE"
    ).fetchall()
    return [dict(r) for r in rows]


def upsert_magistral_ambalaj(
    conn: sqlite3.Connection, ad: str, *, fiyat: float = 0.0, kategori: str = "",
    bump: bool = False,
) -> int | None:
    """Ambalajı ekle/güncelle. bump=True → kullanım sayacı +1; fiyat>0 verilirse
    fiyat güncellenir (bump'ta fiyat 0 ise mevcut korunur)."""
    ad = (ad or "").strip()
    if not ad:
        return None
    row = conn.execute(
        "SELECT id, fiyat, kategori FROM magistral_ambalaj WHERE ad = ? COLLATE NOCASE",
        (ad,),
    ).fetchone()
    if row:
        new_fiyat = fiyat if fiyat and fiyat > 0 else row["fiyat"]
        new_kat = kategori or row["kategori"]
        if bump:
            conn.execute(
                "UPDATE magistral_ambalaj SET fiyat = ?, kategori = ?, "
                "kullanim = kullanim + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (new_fiyat, new_kat, row["id"]),
            )
        else:
            conn.execute(
                "UPDATE magistral_ambalaj SET fiyat = ?, kategori = ? WHERE id = ?",
                (new_fiyat, new_kat, row["id"]),
            )
        rid = row["id"]
    else:
        cur = conn.execute(
            "INSERT INTO magistral_ambalaj(ad, fiyat, kategori, kullanim) "
            "VALUES(?, ?, ?, ?)",
            (ad, fiyat, kategori, 1 if bump else 0),
        )
        rid = cur.lastrowid
    conn.commit()
    return rid


def delete_magistral_ambalaj(conn: sqlite3.Connection, ad: str) -> None:
    """Bir ambalaj kalemini siler."""
    conn.execute("DELETE FROM magistral_ambalaj WHERE ad = ? COLLATE NOCASE", (ad,))
    conn.commit()


def upsert_magistral_hammadde(
    conn: sqlite3.Connection, ad: str, *, birim: str = "", kategori: str = "",
    bump: bool = True,
) -> int | None:
    """Hammaddeyi ekle/güncelle. Varsa (ad eşleşmesi) kullanım sayacını +1 yapar
    (bump=True); birim/kategori yalnız boşsa doldurulur. Yeni/var id döndürür.

    bump=False: seed yüklemede kullanılır (sayaç artırmadan ekle/koru)."""
    ad = (ad or "").strip()
    if not ad:
        return None
    birim = (birim or "").strip()
    kategori = (kategori or "").strip()
    row = conn.execute(
        "SELECT id, birim, kategori FROM magistral_hammadde WHERE ad = ? COLLATE NOCASE",
        (ad,),
    ).fetchone()
    if row:
        new_birim = row["birim"] or birim
        new_kat = row["kategori"] or kategori
        if bump:
            conn.execute(
                "UPDATE magistral_hammadde SET birim = ?, kategori = ?, "
                "kullanim = kullanim + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (new_birim, new_kat, row["id"]),
            )
        else:
            conn.execute(
                "UPDATE magistral_hammadde SET birim = ?, kategori = ? WHERE id = ?",
                (new_birim, new_kat, row["id"]),
            )
        rid = row["id"]
    else:
        cur = conn.execute(
            "INSERT INTO magistral_hammadde(ad, birim, kategori, kullanim) "
            "VALUES(?, ?, ?, ?)",
            (ad, birim, kategori, 1 if bump else 0),
        )
        rid = cur.lastrowid
    conn.commit()
    return rid


# ---------------------------------------------------------------------------
# Botanik ürün kataloğu (yerel kopya — botanik_katalog)
# ---------------------------------------------------------------------------
def sync_botanik_katalog(conn: sqlite3.Connection, urunler, *,
                         updated_iso: str | None = None) -> int:
    """botanik_katalog tablosunu Botanik'ten gelen ürünlerle TAM yeniler.

    urunler: .urun_id/.barkod/.ad/.fiyat/.kamu_fiyat/.stok alanlı nesneler
    (botanik_db.BotanikUrun). Eklenen satır sayısını döndürür.
    """
    rows = [(u.urun_id, u.barkod, u.ad, u.fiyat, u.kamu_fiyat, u.stok)
            for u in urunler]
    conn.execute("DELETE FROM botanik_katalog")
    conn.executemany(
        "INSERT INTO botanik_katalog(urun_id, barkod, ad, fiyat, kamu_fiyat, stok) "
        "VALUES (?, ?, ?, ?, ?, ?)", rows,
    )
    if updated_iso:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES('botanik_katalog_updated', ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (updated_iso,))
    conn.commit()
    return len(rows)


def botanik_katalog_count(conn: sqlite3.Connection) -> int:
    return conn.execute("SELECT COUNT(*) FROM botanik_katalog").fetchone()[0]


def botanik_katalog_price(conn: sqlite3.Connection, barkod: str) -> dict | None:
    """Yerel katalogdan barkodla ürün/fiyat (yoksa None)."""
    barkod = (barkod or "").strip()
    if not barkod:
        return None
    r = conn.execute(
        "SELECT * FROM botanik_katalog WHERE barkod = ? ORDER BY id LIMIT 1",
        (barkod,)).fetchone()
    return dict(r) if r else None


def save_emanet_record(
    conn: sqlite3.Connection, *,
    hasta_ad: str, ilac_ad: str, barkod: str = "", telefon: str = "",
    alis_tarihi: str = "", yazdirma_tarihi: str = "",
) -> int:
    """Bir emanet ilaç kaydı ekler; eklenen satırın id'sini döndürür."""
    cur = conn.execute(
        "INSERT INTO emanet_records"
        "(hasta_ad, ilac_ad, barkod, telefon, alis_tarihi, yazdirma_tarihi) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ((hasta_ad or "").strip(), (ilac_ad or "").strip(), (barkod or "").strip(),
         (telefon or "").strip(), (alis_tarihi or "").strip(),
         (yazdirma_tarihi or "").strip()),
    )
    conn.commit()
    return cur.lastrowid


def list_emanet_records(conn: sqlite3.Connection, limit: int = 200) -> list[dict]:
    """Son emanet kayıtlarını (yeni→eski) döndürür."""
    rows = conn.execute(
        "SELECT * FROM emanet_records ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]


def botanik_katalog_search(conn: sqlite3.Connection, query: str,
                           limit: int = 30) -> list[dict]:
    """Yerel katalogda ad/barkod araması (barkodlu olanlar önce)."""
    q = (query or "").strip()
    if not q:
        return []
    like = f"%{q}%"
    rows = conn.execute(
        "SELECT * FROM botanik_katalog WHERE ad LIKE ? OR barkod LIKE ? "
        "ORDER BY CASE WHEN barkod='' THEN 1 ELSE 0 END, ad LIMIT ?",
        (like, like, limit)).fetchall()
    return [dict(r) for r in rows]


def _migrate_drugs_columns(conn: sqlite3.Connection) -> None:
    """drugs tablosuna eksik sütunları ekler (eski DB'ler için idempotent migration)."""
    existing = {row[1] for row in conn.execute("PRAGMA table_info(drugs)")}
    # NOT: storage_conditions/usage_warnings/interactions kaldırıldı (drug_label_blocks'a taşındı).
    additions = [
        ("atc_code",           "TEXT"),
        ("atc_name",           "TEXT"),
        ("prescription_type",  "TEXT"),
        ("skrs_status",        "TEXT"),
        ("active_ingredient",  "TEXT"),
        ("form",               "TEXT"),
        ("route",              "TEXT"),
        ("dose_unit",          "TEXT"),
        ("default_dose",       "TEXT"),
        ("daily_freq",         "INTEGER"),
        ("hours_apart",        "INTEGER"),
        ("meal_relation",      "TEXT"),
        ("treatment_days",     "INTEGER"),
        ("indication_short",   "TEXT"),
        # Oral sıvı (şurup/süspansiyon) ölçü kabının bir ÖLÇEĞİNİN ml hacmi.
        # Çoğu şurup 5 ml kaşık/kapak; laktuloz (Duphalac vb.) ~30 ml dereceli
        # kap. Ölçek sayısı hesaplanırken bilinen büyük kaplar gruplanır; bkz.
        # drug_guess.medula_dose_display(olcek_ml).
        ("olcek_ml",           "REAL"),
    ]
    for col, col_type in additions:
        if col not in existing:
            conn.execute(f"ALTER TABLE drugs ADD COLUMN {col} {col_type}")


def _migrate_label_prefs_columns(conn: sqlite3.Connection) -> None:
    """drug_label_prefs'e eksik sütunları ekler (eski DB'ler için idempotent)."""
    existing = {row[1] for row in conn.execute("PRAGMA table_info(drug_label_prefs)")}
    if "print_override" not in existing:
        conn.execute(
            "ALTER TABLE drug_label_prefs ADD COLUMN print_override INTEGER"
        )


def _migrate_magistral_hammadde_columns(conn: sqlite3.Connection) -> None:
    """magistral_hammadde'ye fiyat sütunlarını ekler (eski DB'ler için idempotent).

    Tablo daha önce fiyatsız oluşturulmuş olabilir; paket_miktar/paket_fiyat
    sonradan eklenir. Tablo henüz yoksa SCHEMA zaten tam haliyle oluşturur."""
    tables = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    if "magistral_hammadde" not in tables:
        return
    existing = {row[1] for row in conn.execute(
        "PRAGMA table_info(magistral_hammadde)")}
    for col in ("paket_miktar", "paket_fiyat"):
        if col not in existing:
            conn.execute(
                f"ALTER TABLE magistral_hammadde ADD COLUMN {col} REAL NOT NULL DEFAULT 0"
            )


def save_recete_hasta(
    conn: sqlite3.Connection,
    recete_no: str,
    hasta_ad: str = "",
    hasta_tc: str = "",
) -> None:
    """Reçete no için hasta ad/TC'sini kaydeder/günceller (boş değerleri yazmaz).

    Yalnızca yeni bir bilgi geldiğinde üzerine yazar; eldeki dolu adı boş
    değerle ezmemek için COALESCE/NULLIF kullanır.
    """
    rno = (recete_no or "").strip()
    if not rno:
        return
    ad = (hasta_ad or "").strip()
    tc = (hasta_tc or "").strip()
    if not (ad or tc):
        return
    conn.execute(
        """
        INSERT INTO recete_hasta(recete_no, hasta_ad, hasta_tc, updated_at)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(recete_no) DO UPDATE SET
            hasta_ad   = COALESCE(NULLIF(excluded.hasta_ad, ''), recete_hasta.hasta_ad),
            hasta_tc   = COALESCE(NULLIF(excluded.hasta_tc, ''), recete_hasta.hasta_tc),
            updated_at = CURRENT_TIMESTAMP
        """,
        (rno, ad, tc),
    )
    conn.commit()


def lookup_recete_hasta(conn: sqlite3.Connection, recete_no: str) -> tuple[str, str]:
    """Reçete no için kayıtlı (hasta_ad, hasta_tc) döndürür; yoksa ('', '')."""
    rno = (recete_no or "").strip()
    if not rno:
        return ("", "")
    row = conn.execute(
        "SELECT hasta_ad, hasta_tc FROM recete_hasta WHERE recete_no = ?", (rno,)
    ).fetchone()
    if not row:
        return ("", "")
    return (row["hasta_ad"] or "", row["hasta_tc"] or "")


if __name__ == "__main__":
    with get_connection() as c:
        init_schema(c)
        print(f"OK: schema initialized at {DB_PATH}")
